#!/bin/bash

# Name of the virtual environment
ENV_NAME="c2p_screen-env"

echo "🔍 Checking for Python 3..."
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install it first."
    exit 1
fi

echo "✅ Python 3 found."

# Create the virtual environment if it doesn't exist
if [ ! -d "$ENV_NAME" ]; then
    echo "📦 Creating virtual environment: $ENV_NAME"
    python3 -m venv "$ENV_NAME"
else
    echo "ℹ️ Virtual environment already exists: $ENV_NAME"
fi

# Activate the virtual environment
echo "🔁 Activating virtual environment..."
source "$ENV_NAME/bin/activate"

# Upgrade pip to the latest version
echo "🔄 Updating pip..."
pip install --upgrade pip

# Install required Python libraries
echo "📚 Installing Python libraries..."
pip install \
    matplotlib \
    pytz \
    PyGithub \
    GitPython \
    pyudev \
    dbus-python \
    netifaces \
    opencv-python \
    websocket-client

# Deactivate the virtual environment
deactivate

# Install X server and related utilities (needed for GUI/image apps like feh)
echo "🖥️ Installing X server and dependencies..."
sudo apt update
sudo apt install -y xserver-xorg xinit x11-utils x11-xserver-utils feh

echo "✅ Setup complete!"

