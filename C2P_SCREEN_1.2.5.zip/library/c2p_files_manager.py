import os, re, logging, io
import ast
import configparser
import pickle
config = configparser.ConfigParser()
config1 = configparser.ConfigParser()
config2 = configparser.ConfigParser()
config3 = configparser.ConfigParser()

configs = [config, config1, config2, config3]
arr = ['extruder', 'extruder1', 'extruder2', 'extruder3']

home_dir = os.path.expanduser('~')

file0 = os.path.join(home_dir, 'printer_data', 'config',
                     'EbbCan42_T0.cfg')  # '/home/pinar/printer_data/config/EbbCan42_T0.cfg'
file1 = os.path.join(home_dir, 'printer_data', 'config',
                     'EbbCan42_T1.cfg')  # '/home/pinar/printer_data/config/EbbCan42_T1.cfg'
file2 = os.path.join(home_dir, 'printer_data', 'config',
                     'EbbCan42_T2.cfg')  # '/home/pinar/printer_data/config/EbbCan42_T2.cfg'
file3 = os.path.join(home_dir, 'printer_data', 'config',
                     'EbbCan42_T3.cfg')  # '/home/pinar/printer_data/config/EbbCan42_T3.cfg'

files = [file0, file1, file2, file3]

file_variable = os.path.join(home_dir, 'printer_data', 'config',
                             '.variables.stb')  # '/home/pinar/printer_data/config/.variables.stb'
file_tools_printer = os.path.join(home_dir, 'printer_data', 'config',
                                  'tools_printer.cfg')  # '/home/pinar/printer_data/config/tools_printer.cfg'
file_layers = os.path.join(home_dir, 'printer_data', 'printer_gcode', 'filelayers')
c2p_config = os.path.join(home_dir, 'printer_data', 'config', 'c2p_config.cfg')


class c2p:
    def __init__(self, screen=None):
        self._screen = screen
        if self._screen is not None:

            response = self._screen.apiclient.send_request(
                "printer/objects/query?c2p_save_variables"
            )
            self.variables = response.get('result', {}).get('status', {}).get('c2p_save_variables', {}).get('variables', {})
            
    def get_tools_filament_print(self):
        val = self.variables.get("tools_filament_detector")
        if val is None:
            return None
        if isinstance(val, str):
            try:
                return ast.literal_eval(val)
            except (ValueError, SyntaxError):
                return val
        else:
            return val

    def get_tools_print(self):
        config = configparser.ConfigParser()
        config.read(file_variable)
        val = config['Variables']['tools_print']
        return ast.literal_eval(val)

    def get_variables(self, state=''):
        config = configparser.ConfigParser()
        config_tools = configparser.ConfigParser()
        config.read(file_variable)
        config_tools.read(file_tools_printer)
        val = config['Variables'][state]
        return int(val)

    def get_xy_offset(self, numbertools):
        val = []
        try:
            val.append(round(float(self.variables.get(f't{numbertools}_offset_x')), 4))
            val.append(round(float(self.variables.get(f't{numbertools}_offset_y')), 4))
        except:
            val.append("None")
            val.append("None")
        return val

    def get_tools_position(self, numbertools):
        config = configparser.ConfigParser()
        config.read(c2p_config)
        try:
            val = config[f'c2p_tool {numbertools}']['park'].split(',')
        except:
            val = None
        return val

    def set_tools_position(self, numbertools, park):
        config = configparser.ConfigParser()
        config.read(c2p_config)
        try:
            config[f'c2p_tool {numbertools}']['park'] = ','.join(map(str, park))
            with open(c2p_config, 'w') as configfile:
                config.write(configfile)
            return True
        except:
            return False

    def get_z_switch_probe_position(self):
        config = configparser.ConfigParser()
        config.read(c2p_config)
        try:
            val = config[f'c2p_z_switch_calibation']['probe_position'].split(',')
        except:
            val = None
        return val

    def set_z_switch_probe_position(self, position):
        config = configparser.ConfigParser()
        config.read(c2p_config)
        try:
            config[f'c2p_z_switch_calibation']['probe_position'] = ','.join(map(str, position))
            with open(c2p_config, 'w') as configfile:
                config.write(configfile)
            return True
        except:
            return False

    def set_z_switch_nozzle_position(self, position):
        config = configparser.ConfigParser()
        config.read(c2p_config)
        try:
            config[f'c2p_z_switch_calibation']['nozzle_position'] = ','.join(map(str, position))
            with open(c2p_config, 'w') as configfile:
                config.write(configfile)
            return True
        except:
            return False

    def get_z_switch_nozzle_position(self):
        config = configparser.ConfigParser()
        config.read(c2p_config)
        try:
            val = config[f'c2p_z_switch_calibation']['nozzle_position'].split(',')
        except:
            val = None
        return val

    def get_camera_tools_position(self):
        config = configparser.ConfigParser()
        config.read(c2p_config)
        try:
            val = config[f'c2p_xy_camera_calibration']['tools_xy'].split(',')
            val.append(config[f'c2p_xy_camera_calibration']['z_position'])
        except:
            val = None
        return val

    def set_camera_tools_position(self, position):
        config = configparser.ConfigParser()
        config.read(c2p_config)
        try:
            val = ','.join(map(str, position[:1]))
            config[f'c2p_xy_camera_calibration']['tools_xy'] = ','.join(map(str, position[:2]))
            config[f'c2p_xy_camera_calibration']['z_position'] = ','.join(map(str, position[2:3]))
            with open(c2p_config, 'w') as configfile:
                config.write(configfile)
            return True
        except:
            return False

    def get_camera_offset_tools_position(self, numbertools):
        config = configparser.ConfigParser()
        config.read(c2p_config)
        try:
            val = config[f'c2p_xy_camera_calibration'][f't{numbertools}_offset_xy'].split(',')
        except:
            val = None
        return val

    def set_camera_offset_tools_position(self, numbertools, offset):
        config = configparser.ConfigParser()
        config.read(c2p_config)
        try:
            config[f'c2p_xy_camera_calibration'][f't{numbertools}_offset_xy'] = ','.join(map(str, offset))
            with open(c2p_config, 'w') as configfile:
                config.write(configfile)
            return True
        except:
            return False

    def get_z_offset(self, numbertools):
        config = configparser.ConfigParser()
        config.read(file_variable)
        val = 0.0
        try:
            val = (round(float(config['Variables'][f't{numbertools}_offset_z']), 4))
        except:
            val = None
        return val

    def get_z_adjust_offset(self, numbertools):
        config = configparser.ConfigParser()
        config.read(file_variable)
        val = 0.0
        try:
            val = (round(float(config['Variables'][f't{numbertools}_adjust_z']), 4))
        except:
            val = None
        return val

    def reset_x_offset(self, numbertools):
        config = configparser.ConfigParser()
        config.read(file_variable)
        try:
            config['Variables'][f't{numbertools}_offset_x'] = "0.0"
            with open(file_variable, 'w') as configfile:
                config.write(configfile)
            return True
        except:
            return False

    def reset_y_offset(self, numbertools):
        config = configparser.ConfigParser()
        config.read(file_variable)
        try:
            config['Variables'][f't{numbertools}_offset_y'] = "0.0"
            with open(file_variable, 'w') as configfile:
                config.write(configfile)
            return True
        except:
            return False

    # def reset_z_offset(self,numbertools):
    #     config = configparser.ConfigParser()
    #     config.read(file_variable)
    #     try:
    #         config['Variables'][f't{numbertools}_offset_z'] = "0.0"
    #         with open(file_variable, 'w') as configfile:
    #             config.write(configfile)
    #         return True
    #     except:
    #         return False

    def reset_z_adjust_offset(self, numbertools):
        config = configparser.ConfigParser()
        config.read(file_variable)
        try:
            config['Variables'][f't{numbertools}_adjust_z'] = "0.0"
            with open(file_variable, 'w') as configfile:
                config.write(configfile)
            return True
        except:
            return False

    def set_variables(self, val1, val2, val3, val4, state1, state2, state3, state4):
        self.Ranking(val1, val2, val3, val4)
        vals = [val1, val2, val3, val4]
        states = [state1, state2, state3, state4]
        config = configparser.ConfigParser()
        config.read(file_variable)
        for i in range(4):
            config['Variables'][states[i]] = str(vals[i])
            if vals[i] == 1 and states[i] == 'state_t0':
                self.enable_tool('[include EbbCan42_T0.cfg]')

            elif vals[i] == 0 and states[i] == 'state_t0':
                self.disable_tool('[include EbbCan42_T0.cfg]')

            elif vals[i] == 1 and states[i] == 'state_t1':
                self.enable_tool('[include EbbCan42_T1.cfg]')

            elif vals[i] == 0 and states[i] == 'state_t1':
                self.disable_tool('[include EbbCan42_T1.cfg]')

            elif vals[i] == 1 and states[i] == 'state_t2':
                self.enable_tool('[include EbbCan42_T2.cfg]')

            elif vals[i] == 0 and states[i] == 'state_t2':
                self.disable_tool('[include EbbCan42_T2.cfg]')

            elif vals[i] == 1 and states[i] == 'state_t3':
                self.enable_tool('[include EbbCan42_T3.cfg]')

            elif vals[i] == 0 and states[i] == 'state_t3':
                self.disable_tool('[include EbbCan42_T3.cfg]')

            with open(file_variable, 'w') as configfile:
                config.write(configfile)
            print(vals[i])

    def set_tools_filament_print(self, state='', val=0):
        config = configparser.ConfigParser()
        config.read(file_variable)
        val1 = ast.literal_eval(config['Variables']['tools_filament_detector'])
        if state == 'T0' and val1[0] != val:
            val1[0] = val
        elif state == 'T1' and val1[1] != val:
            val1[1] = val
        elif state == 'T2' and val1[2] != val:
            val1[2] = val
        elif state == 'T3' and val1[3] != val:
            val1[3] = val

        config['Variables']['tools_filament_detector'] = str(val1)
        with open(file_variable, 'w') as configfile:
            config.write(configfile)
        self._screen._ws.klippy.gcode_script("LOAD_VARIABLE")

    def disable_tool(self, state):

        counter_file = open(file_tools_printer, 'r+')
        content_lines = []

        for line in counter_file:
            if state in line:
                line_components = '#' + state + '\n'
                content_lines.append(line_components)

            else:
                content_lines.append(line)

        counter_file.seek(0)
        counter_file.truncate()
        counter_file.writelines(content_lines)
        counter_file.close()

    def enable_tool(self, state):
        counter_file = open(file_tools_printer, 'r+')
        content_lines = []

        for line in counter_file:
            if state in line:
                line_components = state + '\n'
                content_lines.append(line_components)

            else:
                content_lines.append(line)
        counter_file.seek(0)
        counter_file.truncate()
        counter_file.writelines(content_lines)
        counter_file.close()

    def rename_section(self, cp, section_from, section_to):
        if section_from == section_to:
            return
        items = cp.items(section_from)
        cp.add_section(section_to)
        for item in items:
            cp.set(section_to, item[0], item[1])
        cp.remove_section(section_from)

    def Ranking(self, a, b, c, d):
        fans = ['heater_fan hotend_fan', 'heater_fan hotend_fan1', 'heater_fan hotend_fan2', 'heater_fan hotend_fan3']
        sw = [a, b, c, d]
        index = 0
        for i in range(4):
            # print(i)
            if sw[i] == 1:
                configs[i].read(files[i])
                for each_section in configs[i].sections():
                    if "extruder" in each_section:
                        if "tmc2209" not in each_section:
                            self.rename_section(configs[i], each_section, arr[index])
                        else:
                            self.rename_section(configs[i], each_section, "tmc2209 " + arr[index])
                    elif "heater_fan hotend_fan" in each_section:
                        configs[i][each_section]['heater'] = str(arr[index])
                    elif "filament_motion_sensor" in each_section:
                        configs[i][each_section]['extruder'] = str(arr[index])

                index += 1
                with open(files[i], 'w') as configfile:
                    configs[i].write(configfile)
                print(configs[i].sections(), "Ok")
                print(index)

    def get_Layers_gcode(self, filepath, index):
        try:
            file_base_name = os.path.splitext(os.path.basename(filepath))[0]
            directory = f"{file_base_name}"
            layer_file = os.path.join(file_layers, directory, f"layer_{index}.pkl")
            with open(layer_file, 'rb') as in_file:
                # Load the data from the file
                layers = pickle.load(in_file)
            return layers
        except Exception as ex:
            print(f"error in get_Layers_gcode :{ex}")
            return False

    def get_Layers_count(self, filepath):
        try:
            file_base_name = os.path.splitext(os.path.basename(filepath))[0]
            directory = f"{file_base_name}"
            files = os.listdir(os.path.join(file_layers, directory))
            file_count = len(files)
            print(f"Total files in '{directory}': {file_count}")
            return file_count
        except Exception as ex:
            print(f"error in get_Layers_count :{ex}")
            return False
        # try:
        #     with open(file_layers, 'rb') as in_file:
        #         # Load the data from the file
        #         layers = pickle.load(in_file)
        #     return len(layers)
        # except Exception as ex:
        #     print(f"error in get_Layers_count :{ex}")
        #     return False

    def check_XYE(self, layer):
        return 'X' in layer and 'Y' in layer and 'E' in layer

    def get_Layers_gcode_filter(self, filename, index):
        try:
            with open(file_layers, 'rb') as in_file:
                layers = pickle.load(in_file)
            filtered_layers = [layer for layer in layers[index] if self.check_XYE(layer)]
            return filtered_layers
        except Exception as ex:
            print(f"error in get_Layers_gcode_filter :{ex}")
            return False

    def set_File_Visual_Gcode(self, filepath):
        if not os.path.exists(filepath):
            logging.error(f"path does not exist")
            print(f"path does not exist")
            return False
        try:
            f = io.open(filepath, 'r', newline='')
            f.seek(0)
            num_layers = self.separate_gcode_layers(filepath, f)
            if num_layers is None:
                return False
            print("Number of layers:", num_layers)
            return True
        except Exception as e:
            logging.exception("Error in File_VISUAL_GCODE :{e}")
            return False

    def separate_gcode_layers(self, filepath, file):
        file_base_name = os.path.splitext(os.path.basename(filepath))[0]
        directory = f"{file_base_name}"
        folder_path = os.path.join(file_layers, directory)
        if not os.path.exists(folder_path) and not os.path.isdir(folder_path):
            os.makedirs(folder_path, exist_ok=True)
            layers = []
            current_layer = []
            layer_index = []
            firstline = False
            z_change_pattern = re.compile(r"^;LAYER_CHANGE")
            gcode_lines = self.read_gcode_from_file(file)
            startgcode = re.compile("^[GT]")
            TGcode = re.compile("^[T]")
            lastTools = None
            FirstTools = None
            StoreTools = None

            for line in gcode_lines:
                if z_change_pattern.match(line):
                    if current_layer and firstline:
                        if FirstTools is not None:
                            current_layer.insert(0, FirstTools)
                            StoreTools = FirstTools
                            FirstTools = None
                        layers.append(current_layer)
                    firstline = True
                    current_layer = [line]
                    if lastTools is None:
                        current_layer.append(StoreTools)
                    else:
                        current_layer.append(lastTools)
                else:
                    if startgcode.match(line):
                        current_layer.append(line)
                        if TGcode.match(line):
                            if FirstTools is None and lastTools is None:
                                FirstTools = line
                            else:
                                lastTools = line
            if current_layer:
                layers.append(current_layer)

            if firstline is False:
                return None

            for i, layer in enumerate(layers):
                layer_file = os.path.join(file_layers, directory, f"layer_{i}.pkl")
                with open(layer_file, 'wb') as out_file:
                    pickle.dump(layer, out_file)
                layer_index.append(layer_file)

            # self.save_layer_index(directory,layer_index)
            print(f"how_Many_tools_layers: {len(layers)}")
            return len(layers)
        else:
            print(f"exsist file visual {self.get_Layers_count(filepath)}")
            return self.get_Layers_count(filepath)

    def read_gcode_from_file(self, file):
        gcode_lines = file.readlines()
        return gcode_lines

    def read_tool_id(self):
        config = configparser.ConfigParser()
        config.read(files)

        val0 = config["mcu EBBCan"]["canbus_uuid"]
        val1 = config["mcu EBBCan1"]["canbus_uuid"]
        val2 = config["mcu EBBCan2"]["canbus_uuid"]
        val3 = config["mcu EBBCan3"]["canbus_uuid"]
        return val0, val1, val2, val3

    def change_tool_id(self, tools_ids):
        config = configparser.ConfigParser()

        tool_ids = {
            "mcu EBBCan": tools_ids[0],
            "mcu EBBCan1": tools_ids[1],
            "mcu EBBCan2": tools_ids[2],
            "mcu EBBCan3": tools_ids[3]
        }

        for (section, tool_id), file in zip(tool_ids.items(), files):
            if tool_id is not None:
                config.read(file)

                if section in config and "canbus_uuid" in config[section]:
                    config[section]["canbus_uuid"] = tool_id
                else:
                    print("canbus uuid not found")
                with open(file, 'w') as configfile:
                    config.write(configfile)
                config.clear()

