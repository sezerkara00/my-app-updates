import math
import os
import gi

gi.require_version("Gtk", "3.0")  # Use "4.0" for GTK 4 if needed
from gi.repository import Gtk, cairo, Rsvg, Gdk
from elements.c2p_gtk import CtoPGtk


class FileElement(Gtk.Overlay):
    def __init__(self, screen, file_name, file_datetime=None, file_time=None, file_size=None, file_image=None, them_path=None,
                 button_labels=None, commands=None, panel_command = None,svg="picture",style="dark"):
        super().__init__()
        # Add a drawing area for the custom card
        self.screen = screen
        self.style = style
        self.drawing_area = Gtk.DrawingArea()
        self.set_size_request(screen.width/3.855, screen.height/3.4133)#225, 375
        self.drawing_area.set_size_request(screen.width/3.555, screen.height/3.4133) #225, 375
        self.drawing_area.connect("draw", self.on_draw)
        self.drawing_area.connect("button-press-event", self.on_button_press)
        self.file_name = file_name
        self.panel_command = panel_command # this used for calibrate menu
        self.file_datetime = file_datetime
        self.file_size = file_size
        self.svg = svg
        self.file_image = file_image
        self.file_time = file_time
        self.ctopgtk = CtoPGtk(screen, them_path)

        self.drawing_area.set_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK)
        self.add(self.drawing_area)
        if commands is not None:
            buttons = {}
            buttons_box = self.ctopgtk.c2p_box()
            buttons_box.set_valign(Gtk.Align.END)

            for button_label, command in zip(button_labels, commands):
                buttons[button_label] = self.ctopgtk.Button_new(label=button_label)
                if button_label == "edit":
                    buttons[button_label] = self.ctopgtk.Button_new("edit", style="print_edit", scale=.5)
                elif button_label == "delete":
                    buttons[button_label] = self.ctopgtk.Button_new("delete_print", style="print_delete", scale=.5)
                elif button_label == "Copy":
                    buttons[button_label] = self.ctopgtk.Button_new(label="Copy To Internal Storage", style="print_copyfile")
                else:
                    buttons[button_label] = self.ctopgtk.Button_new(label=button_label, style="print_select")
                buttons[button_label].connect("clicked", command, file_name, file_image)
                buttons[button_label].set_valign(Gtk.Align.END)
                buttons_box.add(buttons[button_label])
            self.add_overlay(buttons_box)




    def on_overlay_button_press(self, widget, event):
        self.screen.set_cursor_to_blank()
        print("overlay")
        return True

    def on_overlay_enter(self, widget, event):

        self.screen.set_cursor_to_blank()
        print("overlay")
        return True

    def on_draw(self, widget, ctx):
        width = widget.get_allocated_width()
        height = widget.get_allocated_height()
        # Draw rounded rectangle (card background)
        if self.style == "light":
            ctx.set_source_rgb(0.827, 0.839, 0.886)
        else:
            ctx.set_source_rgb(0.2706, 0.2706, 0.2706)  # Dark gray background
        self.draw_rounded_rect(ctx, 0, 0, width, height, 110, 110, 20, 20)
        ctx.fill()

        # Draw circle (image placeholder)
        radius = 106
        xc, yc = width / 2, height / 3.36
        self.draw_circle(ctx, xc, yc, radius, False, 0)
        # ctx.arc(xc, yc, radius, 0, 2 * 3.14159)
        ctx.fill()

        # Draw text below the placeholder
        if self.style == "light":
            ctx.set_source_rgb(0, 0, 0)
        else:
            ctx.set_source_rgb(1, 1, 1)  # White text
        ctx.select_font_face("Sans", cairo.FontSlant.NORMAL, cairo.FontWeight.NORMAL)




        if self.file_time is not None:
            ctx.set_font_size(12)
            if len(self.file_name) > 25:
                self.draw_text(ctx, self.file_name[:25]+ "...", xc, yc + 120, width)
            else:
                self.draw_text(ctx, self.file_name, xc, yc + 120, width)
            self.draw_text(ctx, f"Uploaded: {self.file_datetime}", xc, yc + 140, width)
            self.draw_text(ctx, f"Size: {self.file_size}", xc, yc + 160, width)
            self.draw_text(ctx, f"Print Time: {self.file_time}", xc, yc + 180, width)
        else:
            ctx.set_font_size(20)
            if len(self.file_name) > 20:
                self.draw_text(ctx, self.file_name[:18]+ "...", xc, yc + 150, width-10)
            else:
                self.draw_text(ctx, self.file_name, xc, yc + 150, width-10)

    def draw_rounded_rect(self, ctx, x, y, width, height, top_left_radius, top_right_radius, bottom_right_radius,
                          bottom_left_radius):
        # Top-right corner
        ctx.arc(x + width - top_right_radius, y + top_right_radius, top_right_radius, -0.5 * 3.14159, 0)

        # Bottom-right corner
        ctx.arc(x + width - bottom_right_radius, y + height - bottom_right_radius, bottom_right_radius, 0,
                0.5 * 3.14159)

        # Bottom-left corner
        ctx.arc(x + bottom_left_radius, y + height - bottom_left_radius, bottom_left_radius, 0.5 * 3.14159, 3.14159)

        # Top-left corner
        ctx.arc(x + top_left_radius, y + top_left_radius, top_left_radius, 3.14159, 1.5 * 3.14159)

        ctx.close_path()

    def draw_circle(self, ctx, x, y, circle_radius, pressed, text_angle,
                    label=None):
        """Draw a circle with an optional shadow and an SVG."""

        # Shadow properties
        shadow_layers = 6  # Number of shadow layers for smooth blur
        shadow_opacity = 0.1  # Opacity for the shadow
        shadow_spread = 3  # Spread size for the shadow
        shadow_color = (0, 0, 0)  # Black shadow

        # Step 1: Draw the shadow
        for i in range(shadow_layers):
            ctx.save()
            shadow_radius = circle_radius + shadow_spread + i * 0.5  # Gradually increase shadow size
            ctx.set_source_rgba(*shadow_color, shadow_opacity / (
                    i + 1))  # Semi-transparent black
            ctx.arc(x, y, shadow_radius, 0, 2 * math.pi)
            ctx.fill()
            ctx.restore()
        if self.style == "light":
            ctx.set_source_rgb(0.827, 0.839, 0.886)
        else:
            ctx.set_source_rgb(0.333, 0.333, 0.333)  # Light gray circle

        ctx.arc(x, y, circle_radius, 0, 2 * math.pi)
        ctx.fill()

        # Step 3: Draw the SVG with rotation
        ctx.save()
        if text_angle > 0:
            # Move the origin to the center of the circle
            ctx.translate(x, y)
            ctx.rotate(text_angle)  # Rotate the context by the given angle

            # Draw the SVG centered at the rotated origin
            if self.file_image is not None:
                self.ctopgtk.render_image(ctx, 0, 0, 1, self.file_image,self.style)
            else:
                self.ctopgtk.render_image(ctx, 0, 0, 1, self.svg,self.style)
        else:
            if self.file_image is not None:
                self.ctopgtk.render_image(ctx, x, y, 1, self.file_image,self.style)
            else:
                # Draw the SVG centered at the circle center without rotation
                self.ctopgtk.render_image(ctx, x, y, 1, self.svg,self.style)
        ctx.restore()

    def draw_text(self, ctx, text, x, y, width):
        # Center-align text
        extents = ctx.text_extents(text)
        ctx.move_to((width - extents.width) / 2, y)
        ctx.show_text(text)
    def on_button_press(self,widget,event):

        print("Button Pressed!")
        w = self.get_allocated_width()
        h = self.get_allocated_height()
        if 0 <= event.x <= w and 0 <= event.y <= h:
            if self.file_image is not None:
                self.panel_command(self.file_name,self.file_image)
            else:
                self.panel_command(self.file_name)
            print("Rectangle button pressed (vertical)")

        print("X", event.x, "Y", event.y)
        self.drawing_area.queue_draw()


