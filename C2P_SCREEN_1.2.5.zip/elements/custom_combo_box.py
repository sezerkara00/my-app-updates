import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk

# Function to Load CSS
def load_css():
    css_provider = Gtk.CssProvider()
    css_provider.load_from_path("style.css")  # Ensure the CSS file is in the same folder

    screen = Gdk.Screen.get_default()
    style_context = Gtk.StyleContext()
    style_context.add_provider_for_screen(
        screen,
        css_provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )

class CustomComboBox(Gtk.Box):
    def __init__(self, items, on_select_callback,button_label,button_style):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.on_select_callback = on_select_callback
        self.selected_item = None  # Store the selected item

        # Button to trigger popover
        self.button = Gtk.Button(label=button_label)
        self.button.get_style_context().add_class(
            button_style)
        self.button.connect("clicked", self.show_popover)
        self.pack_start(self.button, False, False, 0)

        # Create Popover
        self.popover = Gtk.Popover()
        self.popover.set_relative_to(self.button)
        self.popover.set_position(Gtk.PositionType.BOTTOM)

        # Add a style class to the popover
        self.popover.get_style_context().add_class("custom-popover")

        # Create ListBox inside the popover
        self.listbox = Gtk.ListBox()
        self.listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)  # Ensure only one selection
        self.listbox.connect("row-activated", self.on_item_selected)
        self.popover.add(self.listbox)

        # Populate listbox with items
        for item in items:
            row = Gtk.ListBoxRow()
            label = Gtk.Label(label=item, xalign=0)
            row.add(label)
            row.get_style_context().add_class("custom-list-item")  # Apply custom CSS class
            self.listbox.add(row)

        self.listbox.show_all()

    def show_popover(self, widget):
        self.popover.show_all()
        self.popover.popup()

    def on_item_selected(self, listbox, row):
        label = row.get_child()  # Get the Label inside the row
        self.selected_item = label.get_text()
        self.button.set_label(self.selected_item)  # Update button label
        self.popover.popdown()  # Close the popover

        # Trigger callback function
        if self.on_select_callback:
            self.on_select_callback(self.selected_item)
    def get_active_text(self):
        return self.selected_item