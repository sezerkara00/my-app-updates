from colorsys import rgb_to_hls, hls_to_rgb
import logging
import os
import cairo
import math
import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Rsvg", "2.0")
from gi.repository import Gdk, GdkPixbuf, Gio, Gtk, Pango,Rsvg


def format_label(widget, lines=2):
    if type(widget) == Gtk.Label:
        return widget
    if type(widget) in (Gtk.Container, Gtk.Bin, Gtk.Button, Gtk.Alignment, Gtk.Box):
        for _ in widget.get_children():
            lbl = format_label(_)
            if lbl is not None:
                lbl.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
                lbl.set_line_wrap(True)
                lbl.set_ellipsize(True)
                lbl.set_ellipsize(Pango.EllipsizeMode.END)
                lbl.set_lines(lines)
home_dir = os.path.expanduser('~')

class CtoPGtk:
    labels = {}

    def __init__(self, screen, theme_path):
        self.screen = screen
        self.theme_path = theme_path
        self.font_size_type = "medium"
        self.width = 600
        self.height = 800
        self.font_ratio = [43, 29]
        self.font_size = min(self.width / self.font_ratio[0], self.height / self.font_ratio[1])
        self.img_scale = self.font_size * 2
        self.button_image_scale = 1.38
        self.bsidescale = .65  # Buttons with image at the side

        if self.font_size_type == "max":
            self.font_size = self.font_size * 1.2
            self.bsidescale = .7
        elif self.font_size_type == "extralarge":
            self.font_size = self.font_size * 1.14
            self.img_scale = self.img_scale * 0.7
            self.bsidescale = 1
        elif self.font_size_type == "large":
            self.font_size = self.font_size * 1.09
            self.img_scale = self.img_scale * 0.9
            self.bsidescale = .8
        elif self.font_size_type == "small":
            self.font_size = self.font_size * 0.91
            self.bsidescale = .55
        self.img_width = self.font_size * 3
        self.img_height = self.font_size * 3
        self.titlebar_height = self.font_size * 2
        self.menubox_height = self.font_size * 10
        logging.info(f"Font size: {self.font_size:.1f} ({self.font_size_type})")


        self.action_bar_width = int(self.width * .1)
        self.action_bar_height = int(self.height)
        self.content_width = self.width - self.action_bar_width
        self.content_height = self.height - (self.titlebar_height + self.menubox_height)

        self.menubox_width = self.width - self.action_bar_width


        self.keyboard_height = self.content_height * 0.5
        if (self.height / self.width) >= 3:  # Ultra-tall
            self.keyboard_height = self.keyboard_height * 0.5

        self.color_list = {}  # This is set by screen.py init_style()
        for key in self.color_list:
            if "base" in self.color_list[key]:
                rgb = [int(self.color_list[key]['base'][i:i + 2], 16) for i in range(0, 6, 2)]
                self.color_list[key]['rgb'] = rgb

    def get_temp_color(self, device):
        # logging.debug("Color list %s" % self.color_list)
        if device not in self.color_list:
            return False, False

        if 'base' in self.color_list[device]:
            rgb = self.color_list[device]['rgb'].copy()
            if self.color_list[device]['state'] > 0:
                rgb[1] = rgb[1] + self.color_list[device]['hsplit'] * self.color_list[device]['state']
            self.color_list[device]['state'] += 1
            rgb = [x / 255 for x in rgb]
            # logging.debug(f"Assigning color: {device} {rgb}")
        else:
            colors = self.color_list[device]['colors']
            if self.color_list[device]['state'] >= len(colors):
                self.color_list[device]['state'] = 0
            color = colors[self.color_list[device]['state'] % len(colors)]
            rgb = [int(color[i:i + 2], 16) / 255 for i in range(0, 6, 2)]
            self.color_list[device]['state'] += 1
            # logging.debug(f"Assigning color: {device} {rgb} {color}")
        return rgb

    def reset_temp_color(self):
        for key in self.color_list:
            self.color_list[key]['state'] = 0

    @staticmethod
    def Label(label, style=None):
        la = Gtk.Label(label)
        if style is not None:
            la.get_style_context().add_class(style)
        return la

    def Image(self, image_name=None, width=None, height=None, scale=None):
        if image_name is None:
            return Gtk.Image()
        if scale is not None:
            width = height = self.img_scale * scale
        if image_name.endswith(".gif"):
            return self.GifFromFile(image_name, width, height)
        pixbuf = self.PixbufFromIcon(image_name, width, height)
        return Gtk.Image.new_from_pixbuf(pixbuf) if pixbuf is not None else Gtk.Image()

    def GifFromFile(self, filename, width=None, height=None):
        try:
            filename = os.path.join(self.theme_path, filename)
            animation = GdkPixbuf.PixbufAnimation.new_from_file(filename)
            return Gtk.Image.new_from_animation(animation)
        except Exception as e:
            print(f"Error loading GIF: {e}")
            return Gtk.Image()

    def PixbufFromIcon(self, filename, width=None, height=None):
        width = width if width is not None else self.img_width
        height = height if height is not None else self.img_height
        filename = os.path.join(self.theme_path, filename)

        for ext in ["svg", "png"]:
            pixbuf = self.PixbufFromFile(f"{filename}.{ext}", int(width), int(height))
            if pixbuf is not None:
                return pixbuf
        return None

    @staticmethod
    def PixbufFromFile(filename, width=-1, height=-1):
        try:
            return GdkPixbuf.Pixbuf.new_from_file_at_size(filename, int(width), int(height))
        except Exception as e:
            logging.exception(e)
            logging.error(f"Unable to find image {filename}")
            return None

    def pixbuf_from_file_circular(self,filename, width=-1, height=-1):
        try:
            # Load the image as a pixbuf at the desired size.
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_size(filename, int(width), int(height))
        except Exception as e:
            import logging
            logging.exception(e)
            logging.error(f"Unable to find image {filename}")
            return None

        # Get image dimensions.
        w = pixbuf.get_width()
        h = pixbuf.get_height()

        # Create a new Cairo image surface with ARGB format.
        surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
        cr = cairo.Context(surface)

        # Create a circular clip (center of the image with radius = half of the smallest dimension).
        cr.arc(w / 2, h / 2, min(w, h) / 2, 0, 2 * math.pi)
        cr.clip()

        # Draw the pixbuf onto the Cairo surface.
        # The function Gdk.cairo_set_source_pixbuf() sets the pixbuf as the drawing source.
        Gdk.cairo_set_source_pixbuf(cr, pixbuf, 0, 0)
        cr.paint()

        # Convert the Cairo surface back into a GdkPixbuf.
        circular_pixbuf = Gdk.pixbuf_get_from_surface(surface, 0, 0, w, h)
        return circular_pixbuf

    def PixbufFromHttp(self, resource, width=-1, height=-1):
        response = self.screen.apiclient.get_thumbnail_stream(resource)
        if response is False:
            return None
        stream = Gio.MemoryInputStream.new_from_data(response, None)
        try:
            pixbuf = GdkPixbuf.Pixbuf.new_from_stream_at_scale(stream, int(width), int(height), True)
        except Exception as e:
            logging.exception(e)
            return None
        stream.close_async(2)
        return pixbuf

    def Button(self, image_name=None, label=None, style=None, scale=None, position=Gtk.PositionType.TOP, lines=2, label1=None):
        if self.font_size_type == "max" and label is not None and scale is None:
            image_name = None
        b = Gtk.Button()
        if label is not None:
            b.set_label(label.replace("\n", " "))
        if label1 is not None:#added by ahmed
            b.set_label(label1)#added by ahmed
        b.set_hexpand(True)
        b.set_vexpand(True)
        b.set_can_focus(False)
        if image_name is not None:
            if scale is None:
                scale = self.button_image_scale
            if label is None:
                scale = scale * 1.4
            width = height = self.img_scale * scale
            b.set_image(self.Image(image_name, width, height))
        b.set_image_position(position)
        b.set_always_show_image(True)

        if label is not None:
            format_label(b, lines)
        if style is not None:
            b.get_style_context().add_class(style)
       # b.connect("clicked", self.reset_screensaver_timeout)
        return b

    def reset_screensaver_timeout(self,widget):
        print("Screensaver timeout reset")
    def Button_new(self, image_name=None, label=None, style=None, scale=None, position=Gtk.PositionType.TOP, lines=2):#######
        if self.font_size_type == "max" and label is not None and scale is None:
            image_name = None
        b = Gtk.Button()

        if label is not None:

            b.set_label(label)#.replace("\n", " "))
        #b.set_hexpand(True)
       # b.set_vexpand(True)

        #b.set_can_focus(False)
        if image_name is not None:
            if scale is None:
                scale = self.button_image_scale
            if label is None:
                scale = scale * 1.4
            width = height = self.img_scale * scale
            b.set_image(self.Image(image_name, width, height))
        b.set_image_position(position)
        b.set_always_show_image(True)

        if label is not None:
            format_label(b, lines)
        if style is not None:
            b.get_style_context().add_class(style)
        b.connect("clicked", self.reset_screensaver_timeout)
        return b
    def create_separator(self,horizontal):
        # Create a vertical separator (line)
        if horizontal :
            style = "separator_horizontal"
            orientation = Gtk.Orientation.HORIZONTAL
        else:
            orientation =  Gtk.Orientation.VERTICAL
            style = "separator_vertical"
        separator = Gtk.Separator(orientation=orientation)
        separator.get_style_context().add_class(style)  # Name for custom CSS styling
        return separator
    def Dialog(self, screen, buttons, content, callback=None, *args):
        dialog = Gtk.Dialog()
        dialog.set_default_size(screen.width, screen.height)
        dialog.set_resizable(False)
        dialog.set_transient_for(screen)
        dialog.set_modal(True)

        for button in buttons:
            dialog.add_button(button['name'], button['response'])
            button = dialog.get_widget_for_response(button['response'])
            button.set_size_request((screen.width - 30) / 3, screen.height / 5)
            format_label(button, 3)

        dialog.connect("response", self.screen.reset_screensaver_timeout)
        dialog.connect("response", callback, *args)
        dialog.get_style_context().add_class("dialog")

        content_area = dialog.get_content_area()
        content_area.set_margin_start(15)
        content_area.set_margin_end(15)
        content_area.set_margin_top(15)
        content_area.set_margin_bottom(15)
        content_area.add(content)

        dialog.show_all()
        # Change cursor to blank
        if self.cursor:
            dialog.get_window().set_cursor(
                Gdk.Cursor.new_for_display(Gdk.Display.get_default(), Gdk.CursorType.ARROW))
        else:
            dialog.get_window().set_cursor(
                Gdk.Cursor.new_for_display(Gdk.Display.get_default(), Gdk.CursorType.BLANK_CURSOR))

        self.screen.dialogs.append(dialog)
        logging.info(f"Showing dialog {dialog}")
        return dialog

    def remove_dialog(self, dialog, *args):
        if self.screen.updating:
            return
        dialog.destroy()
        if dialog in self.screen.dialogs:
            logging.info("Removing Dialog")
            self.screen.dialogs.remove(dialog)
            return
        logging.debug(f"Cannot remove dialog {dialog}")

    def header_bar(self, title, clock_label, callback_notification=None,callback_usb=None,callback_wifi=None,callback_network=None):
        # Create left-side icons
        self.wifi_icon = self.Image("wifi-regular", 25, 25)
        self.network_icon = self.Image("network", 25, 25)
        self.notification_icon = self.Image("notification", 25, 25)
        self.usb_icon = self.Image("usb", 25, 25)
        self.usb_icon.set_no_show_all(True)  # This widget might be hidden sometimes

        self.wifi_eventbox = Gtk.EventBox()
        self.wifi_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        self.wifi_box.pack_start(self.wifi_icon, False, False, 0)
        self.wifi_eventbox.add(self.wifi_box)
        self.wifi_eventbox.connect("button-press-event", callback_wifi)

        self.network_eventbox = Gtk.EventBox()
        self.network_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        self.network_box.pack_start(self.network_icon, False, False, 0)
        self.network_eventbox.add(self.network_box)
        if callback_network is not None:
            self.network_eventbox.connect("button-press-event", callback_network)

        # Build the notification area
        self.notification_eventbox = Gtk.EventBox()
        self.notification_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        self.notification_box.pack_start(self.notification_icon, False, False, 0)

        self.notification_label = Gtk.Label()
        self.notification_label.set_text("")
        self.notification_label.set_visible(False)
        self.notification_label.get_style_context().add_class("notification-text")
        self.notification_box.pack_end(self.notification_label, False, False, 0)
        self.notification_eventbox.add(self.notification_box)

        if callback_notification is not None:
            self.notification_eventbox.connect("button-press-event", callback_notification)




        self.usb_eventbox = Gtk.EventBox()
        self.usb_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        self.usb_box.pack_start(self.usb_icon, False, False, 0)
        self.usb_eventbox.add(self.usb_box)
        if callback_usb is not None:
            self.usb_eventbox.connect("button-press-event", callback_usb)

        # Create the header container (a single box)
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        header.set_size_request(self.screen.width, 50)
        header.get_style_context().add_class("title")
        right_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        right_box.set_size_request(100, 50)
        right_box.set_halign(Gtk.Align.END)
        center_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        center_box.set_halign(Gtk.Align.CENTER)
        center_box.set_size_request(100, 50)
        left_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        left_box.set_size_request(150, 50)
        left_box.set_halign(Gtk.Align.START)
        left_box.get_style_context().add_class("title-left")
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        # Create the title label
        title_label = Gtk.Label(label=title)
        title_label.get_style_context().add_class("title-center")
        # Set clock label style if needed
        clock_label.get_style_context().add_class("title-right")
        clock_label.get_style_context().add_class("move_box_z")
        # Pack left side widgets consistently using pack_start:
        left_box.pack_start(self.wifi_eventbox, False, False, 0)
        left_box.pack_start(self.network_eventbox, False, False, 0)
        left_box.pack_start(self.notification_eventbox, False, False, 0)
        left_box.pack_start(self.usb_eventbox, False, False, 0)

        # Pack the title label with expand=True so it occupies the center space
        center_box.pack_start(title_label, True, True, 0)

        # Pack right side widget (the clock) using pack_end:
        right_box.pack_end(clock_label, False, False, 0)
        header.pack_start(left_box,False,False,0)
        header.pack_start(center_box,True,True,0)
        header.pack_start(right_box,False,False,0)

        self.header = header
        return header,left_box, title_label



    def update_notification_count(self, count):
        self.notification_count = count
        if count > 0:
            self.notification_label.set_text(str(count))
            self.notification_label.set_visible(True)
        else:
            self.notification_label.set_visible(False) 

    def show_usb_icon(self, state):
        # Method to show/hide the USB icon
        if state:  # If state is True, show the USB icon
            self.usb_icon.set_visible(True)
        else:  # If state is False, hide the USB icon
            self.usb_icon.set_visible(False)
            
        # # Update the layout to reflect visibility change
        self.header.queue_draw()  # This ensures the UI gets refreshed

        
        

    def make_shadow(self, element):
        b = Gtk.Box()
        b.add(element)
        b.get_style_context().add_class("custom_button")
        return b
    def c2p_box(self,style=None,width=None,height=None,orientation=Gtk.Orientation.HORIZONTAL,spacing=5,position=None):

        box = Gtk.Box(orientation=orientation,
                           spacing=spacing)
        if position is not None:
            box.set_halign(position)
        if width and height is not None:
            box.set_size_request(width,
                                height)
        if style is not None:
            box.get_style_context().add_class(style)
        return box
    def c2p_label(self,text=None,style=None):

        label = Gtk.Label((text))
        if style is not None:
            label.get_style_context().add_class(style)
        return label

    def box_margin(self):
        border_box = Gtk.Box()
        border_box.set_size_request(3,
                                    150)  # Width and height of the extended line
        border_box.override_background_color(Gtk.StateFlags.NORMAL,
                                             Gdk.RGBA(0.31, 0.31, 0.31,
                                                      1))  # #505050 color
        border_box.get_style_context().add_class("box_margin")
        return border_box
    @staticmethod
    def HomogeneousGrid(width=None, height=None):
        g = Gtk.Grid()
        g.set_row_homogeneous(True)
        g.set_column_homogeneous(True)
        if width is not None and height is not None:
            g.set_size_request(width, height)
        return g

    def ToggleButton(self, text):
        b = Gtk.ToggleButton(text)
        b.props.relief = Gtk.ReliefStyle.NONE
        b.set_hexpand(True)
        b.set_vexpand(True)
        b.connect("clicked", self.screen.reset_screensaver_timeout)
        return b

    # @staticmethod
    def ScrolledWindow(self,style=None):
        scroll = Gtk.ScrolledWindow()

        scroll.set_property("overlay-scrolling", False)
        scroll.set_vexpand(True)

        scroll.add_events(Gdk.EventMask.BUTTON_PRESS_MASK |
                          Gdk.EventMask.TOUCH_MASK |
                          Gdk.EventMask.BUTTON_RELEASE_MASK)
        scroll.set_kinetic_scrolling(True)
        if style is not None:
            scroll.get_style_context().add_class(style)
        return scroll

    def generate_colors(self,base_rgb, num_colors):
        # Convert base RGB to HLS
        base_h, base_l, base_s = rgb_to_hls(*base_rgb)
        colors = []
        for i in range(num_colors):
            # Adjust hue by evenly spacing
            new_h = (base_h + i / num_colors) % 1
            # Convert back to RGB
            new_rgb = hls_to_rgb(new_h, base_l, base_s)
            colors.append(new_rgb)
        return colors

    def render_image(self, ctx, center_x, center_y, scale, image,style):
        if isinstance(image, str):
            self.render_svg(ctx, center_x, center_y, scale, image,style)
        else:
            self.render_raster(ctx, center_x, center_y, scale, image)

    def render_svg(self, ctx, center_x, center_y, scale, image,style):
        svg_path = os.path.join(home_dir, "C2P_SCREEN", "css", style, "images", image + ".svg")
        png_path = os.path.join(home_dir, "C2P_SCREEN", "css", style, "images", image + ".png")

        if os.path.exists(svg_path):
            handle = Rsvg.Handle.new_from_file(svg_path)
            svg_dim = handle.get_dimensions()
            svg_width = svg_dim.width
            svg_height = svg_dim.height
            scaled_width = svg_width * scale
            scaled_height = svg_height * scale
            translate_x = center_x - scaled_width / 2
            translate_y = center_y - scaled_height / 2
            ctx.save()
            ctx.translate(translate_x, translate_y)
            ctx.scale(scale, scale)
            handle.render_cairo(ctx)
            ctx.restore()

        elif os.path.exists(png_path):
            image_surface = cairo.ImageSurface.create_from_png(png_path)
            width = image_surface.get_width()
            height = image_surface.get_height()
            scaled_width = width * scale
            scaled_height = height * scale
            translate_x = center_x - scaled_width / 2
            translate_y = center_y - scaled_height / 2

            ctx.save()
            ctx.translate(translate_x, translate_y)
            ctx.scale(scale, scale)
            ctx.set_source_surface(image_surface, 0, 0)
            ctx.paint()
            ctx.restore()
        else:
            print("Cant Found Image")
            
    def render_raster(self, ctx, center_x, center_y, scale, image):
        """
        Render the raster image in a circular shape with proper scaling.

        :param ctx: Cairo context.
        :param center_x: X-coordinate of the circle's center.
        :param center_y: Y-coordinate of the circle's center.
        :param scale: Scale factor for the image.
        :param image: GdkPixbuf image to be rendered.
        """
        # Get original image dimensions
        pixbuf_width = image.get_width()
        pixbuf_height = image.get_height()

        # Scale the image dimensions
        scaled_width = pixbuf_width * scale
        scaled_height = pixbuf_height * scale

        # Adjust the radius for the clipping circle based on the scaled image size
        radius = min(scaled_width, scaled_height) / 2

        # Calculate translation to center the scaled image within the circle
        translate_x = center_x - scaled_width / 2
        translate_y = center_y - scaled_height / 2

        ctx.save()

        # Create a circular clipping path
        ctx.arc(center_x, center_y, radius, 0, 2 * 3.14159)  # Draw the clipping circle
        ctx.clip()  # Restrict drawing to the circle

        # Translate and render the scaled image
        ctx.translate(translate_x, translate_y)
        Gdk.cairo_set_source_pixbuf(ctx, image, 0, 0)
        ctx.paint()

        ctx.restore()  # Reset the context
