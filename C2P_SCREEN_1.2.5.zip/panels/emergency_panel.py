import gi
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf
from elements.c2p_gtk import CtoPGtk
gi.require_version("Gtk", "3.0")
from elements.c2p_gtk import CtoPGtk
from elements.c2p_dialog import C2PDialog



class EmergencyPanel(Gtk.Box):
    def __init__(self, screen, theme_path):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.screen = screen
        self.theme_path = theme_path
        self.ctop_gtk = CtoPGtk(screen, theme_path)
        self.emergency_finish = False
        # # Main content area
        # content_area = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, 
        #                                     width=screen.width/1.45,
        #                                     height=screen.height/3.2,
        #                                     style="dialog")
        # content_area.set_valign(Gtk.Align.CENTER)
        # content_area.set_halign(Gtk.Align.CENTER)

        # # Info box for the top section
        # box_info = self.ctop_gtk.c2p_box("dialog_box_info")
        
        # # Info icon
        # image_info = self.ctop_gtk.Image("info-dialog")
        # box_info.pack_start(image_info, False, False, 0)

        # # Title label
        # title_label = self.ctop_gtk.c2p_label("Emergency!!!! DONT PANIC", "message_label")
        # box_info.pack_start(title_label, False, False, 0)
        
        # # Separator line
        # border_box = self.ctop_gtk.c2p_box("dialog_box_margin", 400, 1,
        #                                   Gtk.Orientation.VERTICAL)
        # border_box.set_vexpand(False)

        # emergency_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL)
        # emergency_box.set_halign(Gtk.Align.CENTER)
        # emergency_box.set_valign(Gtk.Align.CENTER)

        # emergency_label = self.ctop_gtk.c2p_label("Emergency ACTIVE!!!! DONT PANIC", "message_label")
        # emergency_box.pack_start(emergency_label, False, False, 10)

        # # Error icon
        # self.emergency_picture = self.ctop_gtk.Image("error-dark", scale=5.5)
        # emergency_box.pack_start(self.emergency_picture, False, False, 10)

        # # GIF container
        # self.gif_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        # emergency_box.pack_start(self.gif_container, False, False, 10)

        # # GIF için Image widget
        # self.gif_image = Gtk.Image()
        # try:
        #     animation = GdkPixbuf.PixbufAnimation.new_from_file(f"{self.theme_path}/waiting1.gif")
        #     self.gif_image.set_from_animation(animation)
        #     self.gif_image.set_size_request(100, 100)
        #     self.gif_container.pack_start(self.gif_image, False, False, 0)
        # except GLib.Error as e:
        #     print(f"GIF yüklenemedi: {e}")

        # # Box for buttons
        # self.buttons_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
        # self.buttons_box.set_halign(Gtk.Align.CENTER)
        # self.buttons_box.set_valign(Gtk.Align.CENTER)
        # self.buttons_box.set_margin_bottom(10)
        
        # # Apply button
        # self.finish_button = self.ctop_gtk.Button_new(label="Finish", style="dialog_button")
        # self.finish_button.connect("clicked", self.on_finish_clicked)

        # self.apply_button = self.ctop_gtk.Button_new(label="Apply", style="dialog_button")
        # self.apply_button.connect("clicked", self.on_apply_clicked)
        
        # # Add buttons to box
        # self.buttons_box.pack_end(self.apply_button, False, False, 0)
        # self.buttons_box.pack_end(self.finish_button, False, False, 0)
        
        # # Add elements to content area
        # content_area.pack_start(box_info, False, False, 0)
        # content_area.pack_start(border_box, False, False, 0)
        # content_area.pack_start(emergency_box, False, False, 0)
        # content_area.pack_end(self.buttons_box, False, False, 0)
        
        # Add content to main box
        # self.pack_start(content_area, True, True, 0)
        

        self.emergency_finish_dialog()
        # Create and show window
        # self.show_back_dialog() 

        
    def show_back_dialog(self):
            # Create window
            self.dialog_window = Gtk.Window(title="Emergency")
            self.dialog_window.set_transient_for(self.screen)
            self.dialog_window.set_modal(True)
            self.dialog_window.set_decorated(False)
            self.dialog_window.set_resizable(False)
            self.dialog_window.get_style_context().add_class("power_panel")
            self.dialog_window.set_default_size(self.screen.width, self.screen.height)

            # RGBA visual settings
            screen = Gdk.Screen.get_default()
            visual = screen.get_rgba_visual()
            if visual is not None and screen.is_composited():
                self.dialog_window.set_visual(visual) 

            # Add box to window
            self.dialog_window.add(self)
            self.dialog_window.show_all()


    def on_apply_clicked(self, widget):
        self.dialog_window.destroy()
        self.emergency_finish_dialog()


    def on_finish_clicked(self, widget):
        """
        Finish butonuna tıklandığında GIF'i kaldır
        """
        self.emergency_finish = True
        # GIF'i container'dan kaldır
        for child in self.gif_container.get_children():
            self.gif_container.remove(child)
        # Container'ı gizle
        self.gif_container.hide()
        # Emergency picture'ı güncelle
        self.emergency_picture.set_from_icon_name("dialog-ok", Gtk.IconSize.DIALOG)

        # Butonları güncelle
        for child in self.buttons_box.get_children():
            self.buttons_box.remove(child)
        
        # Apply butonunu tekrar ekle
        self.buttons_box.pack_end(self.apply_button, False, False, 0)
        
        # Tüm değişiklikleri göster
        self.buttons_box.show_all()
        
        # Ekranı yenile
        self.queue_draw()




    def emergency_finish_dialog(self):
        def on_yes():
            dialog.destroy()
        dialog = C2PDialog(
            self.screen,
            self.screen,
            "Please save your work if The system needs to restart to recover. Please save your work if possible and click 'Restart' to proceed.",
            theme_path=self.theme_path,
            # image_name="error-dark",
            title="Emergency",
            button_names=["Restart"],
            sp_commands=[on_yes],
        )


