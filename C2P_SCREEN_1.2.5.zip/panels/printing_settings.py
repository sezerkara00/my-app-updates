from library.c2p_config import ConfigKeys
from library.global_manager import GlobalVariables
from elements.c2p_gtk import CtoPGtk
from elements.keypad import Keypad
from elements.custom_buttons import CustomButton
from elements.progress_circle import ProgressCircle
from library.c2p_gcodes import CtoPGcodes
from library.c2p_files_manager import c2p
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
import math
import contextlib

class PrintingSettings(GlobalVariables):

    def __init__(self, screen, panel):
        super().__init__(screen)
        self.c2p_func_h = c2p(screen)
        state_tools_filament = self.c2p_func_h.get_tools_filament_print()
        self.logger = self.logger_setup.get_logger("printing_panel")
        self.screen = screen
        self.currentFanValue = 0
        self.point_z_tune = 0.1
        self.point_extrude = 1
        self.point_speed = 1
        self.c2p_variables = self.screen.printer.get_c2p_variables()
        self.temp = {}
        self.pressed_buttons = []
        self.fans = {}
        self.progress_devices = {}
        self.ctop_gtk = CtoPGtk(screen,self.theme_path)

        self.main_printing_settings_box =  self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,spacing=20)
        temp_progresses_grid = Gtk.Grid()
        temp_progresses_grid.set_column_spacing(20)
        temp_progresses_grid.set_halign(Gtk.Align.CENTER)
        z_tune_box = self.ctop_gtk.c2p_box(style="print_control_box",width=self.screen.width/1.111,height=self.screen.height/9.846)
        z_tune_box.set_halign(Gtk.Align.CENTER)
        extrude_box = self.ctop_gtk.c2p_box(style="print_control_box",width=self.screen.width/1.111,height=self.screen.height/9.846)
        extrude_box.set_halign(Gtk.Align.CENTER)
        speed_box = self.ctop_gtk.c2p_box(style="print_control_box",width=self.screen.width/1.111,height=self.screen.height/9.846)
        speed_box.set_halign(Gtk.Align.CENTER)
        fan_part_box = self.ctop_gtk.c2p_box(style="print_control_box",width=self.screen.width/1.111,height=self.screen.height/9.846)
        fan_part_box.set_halign(Gtk.Align.CENTER)
        filament_sensor_box = self.ctop_gtk.c2p_box(style="print_control_box",width=self.screen.width/1.111,height=self.screen.height/9.846)
        filament_sensor_box.set_halign(Gtk.Align.CENTER)

        z_tune_label = self.ctop_gtk.c2p_label("Z Tune    ","printing_settings_label")
        extrude_label = self.ctop_gtk.c2p_label("Extrude     ", "printing_settings_label")
        speed_label = self.ctop_gtk.c2p_label("Speed       ", "printing_settings_label")
        fan_part_label = self.ctop_gtk.c2p_label("Fan Part", "printing_settings_label")
        filament_sensor_label = self.ctop_gtk.c2p_label("Filament Sensor", "printing_settings_label")
        self.z_tune_custom_buttons = CustomButton(button_side= "left", width=350, height=104,svg=["Left",None,"Right"], orientation="horizontal3",label_up=12.33,label_low='' ,command=[lambda: self.reset_value("z_tune"),lambda: self.change_values("+",self.point_z_tune,"z_tune"),lambda: self.change_values("-",self.point_z_tune,"z_tune")],style=self.style)
        z_tune_buttons_center = self.ctop_gtk.make_shadow(self.z_tune_custom_buttons)
        self.extrude_custom_buttons = CustomButton(button_side="left", width=350, height=104, svg=["down",None, "up"], orientation="horizontal3",
                         label_up="", label_low=f"{''}%",command=[lambda: self.reset_value("flow"),lambda: self.change_values("+",self.point_extrude,"flow"),lambda: self.change_values("-",self.point_extrude,"flow")],style=self.style)
        extrude_center = self.ctop_gtk.make_shadow(self.extrude_custom_buttons)

        self.speed_custom_buttons =  CustomButton(button_side="left", width=350, height=104, svg=["Left",None, "Right"], orientation="horizontal3",
                         label_up="", label_low=f"{''}%",command=[lambda: self.reset_value("speed"),lambda: self.change_values("+",self.point_speed,"speed"),lambda: self.change_values("-",self.point_speed,"speed")],style=self.style)
        speed_center = self.ctop_gtk.make_shadow(self.speed_custom_buttons
           )

        z_tune_buttons_center.get_style_context().add_class("z_tune_buttons_center")
        extrude_center.get_style_context().add_class("z_tune_buttons_center")
        speed_center.get_style_context().add_class("z_tune_buttons_center")

        z_tune_labels =['0.01','0.05','0.1','0.5','...']
        self.z_tune_buttons = {}
        z_tune_buttons_grid = Gtk.Grid()
        ex_n = 0
        ex_m = 0
        for index, lbl in enumerate(z_tune_labels):
            self.z_tune_buttons[lbl] = self.ctop_gtk.Button_new(label=lbl,style="print_edit")
            if lbl != "...":
                self.z_tune_buttons[lbl].connect("clicked", self.change_z_tune_value, lbl)
                z_tune_buttons_grid.attach(self.z_tune_buttons[lbl], ex_n, ex_m, 1, 1)
            else:
                self.z_tune_buttons[lbl].connect("clicked", self.show_keypad, "z_tune")
                z_tune_buttons_grid.attach(self.z_tune_buttons[lbl], ex_n, ex_m, 2, 1)
            if not index:
                self.z_tune_buttons[lbl].get_style_context().add_class("filament_sensor_buttons_pressed")
            if ex_n > 0:
                ex_m += 1
                ex_n = 0
            else:
                ex_n += 1
        extrude_buttons_labels = ['1','5','10','20','...']
        self.extrude_buttons = {}
        extrude_buttons_grid = Gtk.Grid()
        extrude_buttons_grid.get_style_context().add_class("z_tune_buttons_box")
        ex_n = 0
        ex_m = 0
        for index, lbl in enumerate(extrude_buttons_labels):
            self.extrude_buttons[lbl] = self.ctop_gtk.Button_new(label=lbl,style="print_edit")
            if lbl != "...":
                 self.extrude_buttons[lbl].connect("clicked",self.change_extrude_value,lbl)
                 extrude_buttons_grid.attach(self.extrude_buttons[lbl], ex_n, ex_m, 1, 1)
            else:
                self.extrude_buttons[lbl].connect("clicked", self.show_keypad,"flow")
                extrude_buttons_grid.attach(self.extrude_buttons[lbl],ex_n,ex_m,2,1)
            if not index:
                self.extrude_buttons[lbl].get_style_context().add_class("filament_sensor_buttons_pressed")
            if ex_n>0:
                ex_m += 1
                ex_n=0
            else:
                ex_n += 1
        self.speed_buttons = {}
        speed_buttons_grid = Gtk.Grid()
        speed_buttons_grid.get_style_context().add_class("z_tune_buttons_box")
        ex_n = 0
        ex_m = 0
        for index, lbl in enumerate(extrude_buttons_labels):
            self.speed_buttons[lbl] = self.ctop_gtk.Button_new(label=lbl, style="print_edit")
            if lbl != "...":
                 self.speed_buttons[lbl].connect("clicked",self.change_speed_value,lbl)
                 speed_buttons_grid.attach(self.speed_buttons[lbl], ex_n, ex_m, 1, 1)
            else:
                self.speed_buttons[lbl].connect("clicked", self.show_keypad,"speed")
                speed_buttons_grid.attach(self.speed_buttons[lbl], ex_n, ex_m, 2, 1)
            if not index:
                self.speed_buttons[lbl].get_style_context().add_class("filament_sensor_buttons_pressed")
            if ex_n > 0:
                ex_m += 1
                ex_n = 0
            else:
                ex_n += 1


        # Slider (Gtk.Scale)
        adj_fan_part = Gtk.Adjustment(self.currentFanValue, 0, 100, 1, 5, 0)
        self.fan_part_slider = Gtk.Scale.new(
        orientation=Gtk.Orientation.HORIZONTAL,
        adjustment=adj_fan_part)
        self.fan_part_slider.set_digits(0)
        #self.fan_part_slider.set_value(20)  # Set initial value
        self.fan_part_slider.set_hexpand(True)
        self.fan_part_slider.set_draw_value(False)
        self.fan_part_slider.get_style_context().add_class("fan_part_scale")

        self.fan_part_value_label = self.ctop_gtk.c2p_label(f"{self.fan_part_slider.get_value():.0f}%","printing_settings_label")
        for fan in self.screen.printer.get_fans():
            # fan_types = ["controller_fan", "fan_generic", "heater_fan"]
            if fan == "fan":
                name = " "
            elif fan.startswith("fan_generic"):
                fan_name = fan.split(" ")[1:]
                name = " ".join(fan_name)[4].upper() + " ".join(fan_name)[7:] + ":"
                if name.startswith("_"):
                    continue
            else:
                continue
            self.fan_part_slider.connect("value-changed", self.change_fan_speed,fan)
            self.fans[fan] = {
                "name": name,
                "speed": "-"
            }

        self.filament_sensor_buttons_labels = ['01', '02', '03', '04']
        tools_name = ['T0', 'T1', 'T2', 'T3']
        self.filament_sensor_buttons = {}
        filament_sensor_buttons_grid = Gtk.Grid()
        filament_sensor_buttons_grid.get_style_context().add_class("z_tune_buttons_box")
        ex_n = 0
        ex_m = 0
        for idx, (lbl, name) in enumerate(zip(self.filament_sensor_buttons_labels, tools_name)):
            self.filament_sensor_buttons[lbl] = self.ctop_gtk.Button_new(label=lbl, style="filament_sensor_buttons")
            self.filament_sensor_buttons[lbl].connect("clicked", self.select_filament_sensor, lbl, name)
            if state_tools_filament[idx] == '1':
                self.filament_sensor_buttons[lbl].get_style_context().add_class("filament_sensor_buttons_pressed")
            else:
                self.filament_sensor_buttons[lbl].get_style_context().remove_class("filament_sensor_buttons_pressed")

            filament_sensor_buttons_grid.attach(self.filament_sensor_buttons[lbl], ex_n, ex_m, 1, 1)
            if ex_n > 0:
                ex_m += 1
                ex_n = 0
            else:
                ex_n += 1

        self.show_temp_circles(temp_progresses_grid)

        z_tune_box.pack_start(z_tune_label, False,False, 0)
        z_tune_box.pack_start(z_tune_buttons_center, True, False, 0)
        z_tune_box.pack_start(z_tune_buttons_grid, False,False, 0)
        extrude_box.pack_start(extrude_label, False,False, 0)
        extrude_box.pack_start(extrude_center, True, False, 0)
        extrude_box.pack_start(extrude_buttons_grid, False, False, 0)
        speed_box.pack_start(speed_label, False, False, 0)
        speed_box.pack_start(speed_center, True, False, 0)
        speed_box.pack_start(speed_buttons_grid, False, False, 0)
        fan_part_box.pack_start(fan_part_label, False, False, 0)
        fan_part_box.pack_start(self.ctop_gtk.create_separator(False), True, False, 0)
        fan_part_box.pack_start(self.fan_part_slider, True, False, 0)
        fan_part_box.pack_start(self.fan_part_value_label, True, False, 0)
        filament_sensor_box.pack_start(filament_sensor_label, False, False, 0)
        filament_sensor_box.pack_start(self.ctop_gtk.create_separator(False), True, False, 0)
        filament_sensor_box.pack_start(filament_sensor_buttons_grid,False, False, 0)

        self.main_printing_settings_box.add(temp_progresses_grid)
        self.main_printing_settings_box.add(z_tune_box)
        self.main_printing_settings_box.add(extrude_box)
        self.main_printing_settings_box.add(speed_box)
        self.main_printing_settings_box.add(fan_part_box)
        self.main_printing_settings_box.add(filament_sensor_box)
        ########
        self.z_tune_custom_buttons.update_label_up(f'{self.screen.printer.data["gcode_move"]["homing_origin"][2]:.3f}mm')
        self.z_tune_custom_buttons.update_label_low(f'{self.screen.printer.data["gcode_move"]["homing_origin"][2]:.3f}mm')
        extrusion = round(float(self.screen.printer.data["gcode_move"]["extrude_factor"]) * 100)
        self.extrude_custom_buttons.update_label_low(f"{extrusion:3}%")
        speed = round(float(self.screen.printer.data["gcode_move"]["speed_factor"]) * 100)
        self.speed_custom_buttons.update_label_low(f"{speed:3}%")
    def parse_print_tools(self):
            if self.screen.base_panel.c2p_print_tools is None:
                return
            variable = self.screen.printer.get_origin_extruders()
            for i, dev in enumerate(variable):
                if str(i) not in self.screen.base_panel.c2p_print_tools["tools_print"]:
                    variable[i] = None
            return variable
    def show_temp_circles(self, temp_progress_grid):
        for child in temp_progress_grid.get_children():
            temp_progress_grid.remove(child)
        self.progress_circle1 = ProgressCircle(self.screen, panel="printing", w=100, h=214,
                                               name="extruder",
                                               label="01",
                                               progress=0,

                                               current_temp=0,

                                               style=self.style,
                                               active=False,
                                               angle=-math.pi / 2, filament_type=self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,"extruder"),
                                               command=lambda: self.get_object_name(name="extruder"),filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder")))
        self.progress_circle2 = ProgressCircle(self.screen, panel="printing", w=100, h=214,
                                               name="extruder1",
                                               label="02",
                                               progress=0,

                                               current_temp=0,

                                               style=self.style, active=False,
                                               angle=-math.pi / 2, filament_type=self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,"extruder1"),
                                               command=lambda: self.get_object_name(name="extruder1"),filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder")))
        self.progress_circle3 = ProgressCircle(self.screen, panel="printing", w=100, h=214,
                                               name="extruder2",
                                               label="03",
                                               progress=0,

                                               current_temp=0,

                                               style=self.style, active=False,
                                               angle=-math.pi / 2,filament_type=self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,"extruder2"),
                                               command=lambda: self.get_object_name(name="extruder2"),filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder")))
        self.progress_circle4 = ProgressCircle(self.screen, panel="printing", w=100, h=214,
                                               name="extruder3",
                                               label="04",
                                               progress=0,

                                               current_temp=0,

                                               style=self.style, active=False,
                                               angle=-math.pi / 2,filament_type=self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,"extruder3"),
                                               command=lambda: self.get_object_name(name="extruder3"),filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder")))
        self.progress_bed = ProgressCircle(self.screen, panel="printing", w=100, h=214,
                                           name="heater_bed", label="Bed",
                                           progress=0,

                                           current_temp=0,
                                           style=self.style, active=False, angle=-math.pi / 2,
                                           command=lambda: self.get_object_name(name="heater_bed"))
        self.progress_env = ProgressCircle(self.screen, panel="printing", w=100, h=214,
                                           label="Env",
                                           name="heater_generic Env_heater",
                                           progress=0,

                                           current_temp=0, style=self.style,
                                           active=False, angle=-math.pi / 2,
                                           command=lambda: self.get_object_name(name="heater_generic Env_heater"))
        self.progress_devices = [
            self.progress_circle1, self.progress_circle2,
            self.progress_circle3, self.progress_circle4, self.progress_bed, self.progress_env

        ]

        temp_progress_grid.attach(self.progress_circle1, 0, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle2, 1, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle3, 2, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle4, 3, 1, 1, 1)
        temp_progress_grid.attach(self.progress_bed, 4, 1, 1, 1)
        temp_progress_grid.attach(self.progress_env, 5, 1, 1, 1)
        temp_progress_grid.show_all()

    def update_temp(self,data):
        if self.screen.base_panel.c2p_print_tools is None:
            return

        for device, progress in zip(
               self.parse_print_tools() + self.screen.printer.get_heaters(), self.progress_devices,
                ):
            if device is None:
                continue
            self.temp[device] = self.screen.printer.get_dev_stat(device, "temperature")
            target = self.screen.printer.get_dev_stat(device, "target")
            progress.set_target(target)
            if "temperature_sensor" not in device:
                if "extruder" in device:

                    progress.update_filament_color(self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,device)))
                    progress.update_filament_type(self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,device))
                max_temp = self.screen.printer.get_dev_stat(device,
                                                            "max_temp")
                min_temp = self.screen.printer.get_dev_stat(device,
                                                            "min_extrude_temp")
                if self.temp[device] is not None:
                    progress.set_current_temp(self.temp[device],
                                              self.temp[device] / max_temp, max_temp, True)
        self.update_info_print(data)

    def update_info_print(self,data):
        if "gcode_move" in data:
                if "homing_origin" in data["gcode_move"]:
                    # self.labels['zoffset'].set_label(f'  {data["gcode_move"]["homing_origin"][2]:.3f}mm')
                    self.z_tune_custom_buttons.update_label_up(f'{self.screen.printer.data["gcode_move"]["homing_origin"][2]:.3f}mm')
                    self.z_tune_custom_buttons.update_label_low(f'{data["gcode_move"]["homing_origin"][2]:.3f}mm')
                if "extrude_factor" in data["gcode_move"]:
                    extrusion = round(float(data["gcode_move"]["extrude_factor"]) * 100)
                    self.extrude_custom_buttons.update_label_low(f"{extrusion:3}%")
                    # self.labels['extrudefactor'].set_label(f"  {self.extrusion:3}%")
                if "speed_factor" in data["gcode_move"]:
                    speed = round(float(data["gcode_move"]["speed_factor"]) * 100)
                    self.speed_custom_buttons.update_label_low(f"{speed:3}%")
                    # self.labels['speedfactor'].set_label(f"  {self.speed:3}%")

    def process_update(self, action, data):
           if action != "notify_status_update":
            return
           self.update_temp(data)
           for fan in self.fans:
            with contextlib.suppress(KeyError):
                self.set_fan_speed(fan)
    def parse_rgb_string_safe(self,rgb_string):
        try:
            r, g, b = map(float, rgb_string.split(","))
            return [r, g, b]
        except (ValueError, TypeError) as e:
            print("Invalid RGB string format:", e)
            return None
    def get_object_name(self, widget=None, name=None):
        self.show_keypad(widget, name)
    
    def show_keypad(self, widget=None, type=None):
        # Determine the initial value for the keypad
        if type in self.screen.printer.get_active_extruders() + self.screen.printer.get_heaters():
            for progress, device in zip(self.progress_devices,
                                        self.screen.printer.get_active_extruders() + self.screen.printer.get_heaters()):
                if device != type:
                    progress.on_button_release()
                else:
                    self.keypad_value = self.screen.printer.get_dev_stat(device, "target")
                    self.device_name = device
        elif widget:  # Read from widget label
            label_text = widget.get_label()
            try:
                # Try to parse the label as a number
                self.keypad_value = float(label_text)
            except (ValueError, TypeError):
                # If parsing fails, set the default value to 0
                self.keypad_value = 0
        else:
            self.keypad_value = 0  # Default value if none of the conditions match

        # Create a new Keypad instance and use lambda to pass the value directly to handle_keypad
        keypad_window = Keypad(
            self.screen,
            self.theme_path,
            lambda value: self.handle_keypad(value, widget, type)
        )
        keypad_window.show_keypad(text=self.keypad_value)

    def handle_keypad(self, value, widget, type):
        """
        Handle the value returned from the Keypad and update UI or state accordingly.
        """
        if type == "heater_bed":
            self.screen._ws.klippy.set_bed_temp(value)
        elif type == "z_tune":
            # self.screen._ws.klippy.gcode_script(f"SAVE_Z_ADJUST T=0")
            # self.screen._ws.klippy.gcode_script(f"SAVE_Z_ADJUST T=1")
            # self.screen._ws.klippy.gcode_script(f"SAVE_Z_ADJUST T=2")
            # self.screen._ws.klippy.gcode_script(f"SAVE_Z_ADJUST T=3")
           # self.z_tune_custom_buttons.update_label_low(value)
            if float(value)<=1 and float(value)>1:
                self.point_z_tune = value
            else:
                return
            for button in self.z_tune_buttons.values():
                button.get_style_context().remove_class("filament_sensor_buttons_pressed")
            widget.get_style_context().add_class("filament_sensor_buttons_pressed")
        elif type == "flow":
           # self.extrude_custom_buttons.update_label_low(value)
            value = int(float(value))
            if value > 0 and value<999:
                self.point_extrude = value
            else:
                return
            for button in self.extrude_buttons.values():
               button.get_style_context().remove_class("filament_sensor_buttons_pressed")
            widget.get_style_context().add_class("filament_sensor_buttons_pressed")
        elif type == "speed":
            #self.speed_custom_buttons.update_label_low(value)
            value = int(float(value))
            if value > 0 and value<999:
                self.point_speed = value
            else:
                return
            for button in self.speed_buttons.values():
                button.get_style_context().remove_class("filament_sensor_buttons_pressed")
            widget.get_style_context().add_class("filament_sensor_buttons_pressed")
        elif type.startswith("heater_generic"):
            self.screen._ws.klippy.set_heater_temp(type, value)
        else:
            self.screen._ws.klippy.set_tool_temp(
                self.screen.printer.get_tool_number(type), value
            )

        # Optionally update the label of the widget
        if widget:
            try:
                if isinstance(value, str) and "%" in value:
                    # If the value contains '%', leave it as is
                    widget.set_label(value)
                else:
                    numeric_value = float(value)
                    # Check if the value is an integer
                    if numeric_value.is_integer():
                        # If the value is an integer, set it without decimals
                        widget.set_label(f"{int(numeric_value)}")
                    else:
                        # If the value is a float, format it with 2 decimal places
                        widget.set_label(f"{numeric_value:.2f}")
            except ValueError:
                # Handle non-numeric value gracefully
                widget.set_label("0")

        print(f"Updated {type} with value: {value}")
    
    def set_fan_speed(self,fan):
        if fan == "fan_generic partfan":
            value = self.screen.printer.get_fan_speed(fan) * 100
            if self.currentFanValue != value:
                self.currentFanValue = value
                self.fan_part_slider.set_value(value)
                self.fan_part_value_label.set_label(f"{value:3.0f}%")
        # if fan == "fan":
        #     self.screen._ws.klippy.gcode_script(CtoPGcodes.set_fan_speed(value))
        # else:
        #     self.screen._ws.klippy.gcode_script(f"SET_FAN_SPEED FAN={fan.split()[1]} SPEED={float(value) / 100}")
        # Check the speed in case it wasn't applied

    def change_fan_speed(self,widget,fan):
        value = self.fan_part_slider.get_value()
        if self.currentFanValue != value:
            if fan == "fan":
                self.screen._ws.klippy.gcode_script(CtoPGcodes.set_fan_speed(value))
            else:
                self.screen._ws.klippy.gcode_script(f"SET_FAN_SPEED FAN={fan.split()[1]} SPEED={float(value) / 100}")
    
    def change_z_tune_value(self, widget,lbl):
        #self.z_tune_custom_buttons.update_label_low(label)
        for button in self.z_tune_buttons.values():
            button.get_style_context().remove_class("filament_sensor_buttons_pressed")
        widget.get_style_context().add_class("filament_sensor_buttons_pressed")
        self.point_z_tune = lbl
    
    def change_extrude_value(self, widget,lbl):
        #self.extrude_custom_buttons.update_label_low(label)
        for button in self.extrude_buttons.values():
            button.get_style_context().remove_class("filament_sensor_buttons_pressed")
        widget.get_style_context().add_class("filament_sensor_buttons_pressed")
        self.point_extrude = lbl
    
    def change_speed_value(self, widget,lbl):
        #self.speed_custom_buttons.update_label_low(label)
        for button in self.speed_buttons.values():
            button.get_style_context().remove_class("filament_sensor_buttons_pressed")
        widget.get_style_context().add_class("filament_sensor_buttons_pressed")
        self.point_speed = lbl

    def select_filament_sensor(self, widget, lbl, name):
        toolsindex = self.filament_sensor_buttons_labels.index(lbl)
        current_state = self.filament_sensor_buttons[lbl].get_style_context().has_class(
            "filament_sensor_buttons_pressed")
        if current_state:
            widget.get_style_context().remove_class("filament_sensor_buttons_pressed")
            self.screen._ws.klippy.gcode_script(f"CP_SET_FILAMENT_TOOL TOOL={toolsindex} VALUE={0}")
        else:
            widget.get_style_context().add_class("filament_sensor_buttons_pressed")
            self.screen._ws.klippy.gcode_script(f"CP_SET_FILAMENT_TOOL TOOL={toolsindex} VALUE={1}")

        #     widget.get_style_context().add_class("filament_sensor_buttons_pressed")
        #     self.c2p_func_h.set_tools_filament_print(name, val=1)
        #     self.pressed_buttons.append(lbl)
    
    def change_values(self,pr,current_label,tipe):
        if tipe == "z_tune":
            label = float(current_label)
            try:
                current_value_z_tune = float(self.z_tune_custom_buttons.get_label().replace("mm", "").strip())  # Remove 'mm' and convert to float
            except ValueError:
                current_value_z_tune = 0.0
            if pr == "+":
                current_value_z_tune += label
            elif pr == "-":
                current_value_z_tune -= label
            self.z_tune_custom_buttons.update_label_low(f'{current_value_z_tune:.3f}mm')
            self.set_Z_Offset(pr,label)

        elif tipe == "flow":
            label = int(current_label)
            current_value_extrude = 0
            try:
                current_value_extrude = int(self.extrude_custom_buttons.get_label().replace("%", "").strip())  # Remove '%' and convert to int
            except ValueError:
                current_value_extrude = 0 
            if pr == "+":
                current_value_extrude += label
            elif pr == "-":
                current_value_extrude -= label
                if current_value_extrude <= 0:
                    current_value_extrude = 0
            self.extrude_custom_buttons.update_label_low(f"{current_value_extrude:3}%")
            self.screen._ws.klippy.gcode_script(CtoPGcodes.set_extrusion_rate(current_value_extrude))
        elif tipe == "speed":
            label = int(current_label)
            current_value_speed = 0
            try:
                current_value_speed = int(self.speed_custom_buttons.get_label().replace("%", "").strip())  # Remove '%' and convert to int
            except ValueError:
                current_value_speed = 0
            if pr == "+":
                current_value_speed += label
            elif pr == "-":
                current_value_speed -= label
                if current_value_speed <= 0:
                    current_value_speed = 0
            self.speed_custom_buttons.update_label_low(f"{current_value_speed:3}%")
            self.screen._ws.klippy.gcode_script(CtoPGcodes.set_speed_rate(current_value_speed))
    
    def reset_value(self,tipe):
        if tipe == "z_tune":
            # self.z_tune_custom_buttons.update_label_low(f'{self.screen.printer.data["gcode_move"]["homing_origin"][2]:.3f}mm')
            self.reset_Z_Offset()
        elif tipe == "flow":
            extrusion = 100
            self.extrude_custom_buttons.update_label_low(f"{extrusion:3}%")
            self.screen._ws.klippy.gcode_script(CtoPGcodes.set_extrusion_rate(extrusion))
        elif tipe == "speed":
            speed = 100
            self.speed_custom_buttons.update_label_low(f"{speed:3}%")
            self.screen._ws.klippy.gcode_script(CtoPGcodes.set_speed_rate(self.speed))

    def set_Z_Offset(self,direction,value):
        current_extruder = self.screen.printer.get_stat("toolhead", "extruder")
        if current_extruder == "extruder":
            self.screen._ws.klippy.gcode_script(f"CP_SET_GCODE_OFFSET T=0 Z_ADJUST={direction}{value} MOVE=1")
        elif current_extruder == "extruder1":
            self.screen._ws.klippy.gcode_script(f"CP_SET_GCODE_OFFSET T=1 Z_ADJUST={direction}{value} MOVE=1")
        elif current_extruder == "extruder2":
            self.screen._ws.klippy.gcode_script(f"CP_SET_GCODE_OFFSET T=2 Z_ADJUST={direction}{value} MOVE=1")
        elif current_extruder == "extruder3":
            self.screen._ws.klippy.gcode_script(f"CP_SET_GCODE_OFFSET T=3 Z_ADJUST={direction}{value} MOVE=1")

    def reset_Z_Offset(self):
        current_extruder = self.screen.printer.get_stat("toolhead", "extruder")
        if current_extruder == "extruder":
            self.screen._ws.klippy.gcode_script("CP_SET_GCODE_OFFSET T=0 Z_ADJUST=CLR MOVE=1")
        elif current_extruder == "extruder1":
            self.screen._ws.klippy.gcode_script("CP_SET_GCODE_OFFSET T=1 Z_ADJUST=CLR MOVE=1")
        elif current_extruder == "extruder2":
            self.screen._ws.klippy.gcode_script("CP_SET_GCODE_OFFSET T=2 Z_ADJUST=CLR MOVE=1")
        elif current_extruder == "extruder3":
            self.screen._ws.klippy.gcode_script("CP_SET_GCODE_OFFSET T=3 Z_ADJUST=CLR MOVE=1")

    def get_content(self):
        return self.main_printing_settings_box,"Print Settings"
