import math
from xml.etree.ElementTree import canonicalize

from library.c2p_gcodes import CtoPGcodes
from library.global_manager import GlobalVariables
from elements.heatergraph import HeaterGraph
from elements.c2p_gtk import CtoPGtk
from elements.custom_buttons import CustomButton
from elements.progress_circle import ProgressCircle
from elements.keypad import Keypad
from gi.repository import Gtk, GLib, Gdk


class Temp_panel(GlobalVariables):

    def __init__(self, screen):
        super().__init__(screen)
        self.screen = screen
        self.logger = self.logger_setup.get_logger("Temp_panel")
        self.logger.info("Temp_panel initialized.")  # Initialization log
        self.temp = {}
        self.devices = {}
        self.keypad_value = 0
        self.device_name = ""
        self.can_show_graph = False
        self.showed_devices = ["extruder","extruder1","extruder2","extruder3","heater_bed","heater_generic Env_heater"]
        self.progress_devices = {}
        self.heater_graph = None
        self.distance = 1
        self.speed = 5
        # signal_router.register("common_action", self.handle_common)
        self.extrude_buttons = {"speed": {}, "distance": {}}
        self.ctop_gtk = CtoPGtk(screen, self.theme_path)
        self.temp_main_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        temp_progress_grid = Gtk.Grid()
        # temp_progress_grid.set_hexpand(False)
        # temp_progress_grid.set_vexpand(False)
        # temp_progress_grid.set_row_homogeneous(False)
        # temp_progress_grid.set_column_homogeneous(False)
        temp_progress_grid.set_column_spacing(33)
        temp_progress_grid.set_row_spacing(20)
        temp_progress_grid.set_halign(Gtk.Align.CENTER)

        extrude_grid = Gtk.Grid()
        extrude_grid.set_halign(Gtk.Align.CENTER)
        extrude_grid.set_column_spacing(30)
        extrude_grid.set_row_spacing(2)
        speed_box = self.ctop_gtk.c2p_box(style="speed_box", width=self.screen.width / 2,
                                          height=self.screen.height / 11.736, orientation=Gtk.Orientation.VERTICAL,
                                          spacing=5)
        speed_box.set_halign(Gtk.Align.START)
        speed_degree_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL,
                                                 spacing=5,style="speed_degree_box")
        speed_degree_box.set_halign(Gtk.Align.CENTER)

        distance_box = self.ctop_gtk.c2p_box(style="speed_box", width=self.screen.width / 2,
                                             height=self.screen.height / 11.736, orientation=Gtk.Orientation.VERTICAL,
                                             spacing=5)
        distance_box.set_halign(Gtk.Align.START)
        distance_degree_box = self.ctop_gtk.c2p_box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=5,style="speed_degree_box")
        distance_degree_box.set_halign(Gtk.Align.CENTER)
        extrude_box = self.ctop_gtk.c2p_box(style="move_bottom_box", width=self.screen.width / 1.159,
                                             height=self.screen.height / 4, orientation=Gtk.Orientation.VERTICAL,
                                             spacing=5)
        extrude_box.set_halign(Gtk.Align.CENTER)
        self.graph_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,
                                               spacing=5, width=self.screen.width / 1.119,
                                               height=self.screen.height / 6.533, style="move_bottom_box")
        graph_title_box = self.ctop_gtk.c2p_box()
        self.graph_box.set_halign(Gtk.Align.CENTER)
        line_box = self.ctop_gtk.c2p_box("text_box", self.screen.width / 2.66,
                                         4,
                                         Gtk.Orientation.VERTICAL)
        line_d_box = self.ctop_gtk.c2p_box("text_box", self.screen.width / 2.66,
                                           4,
                                           Gtk.Orientation.VERTICAL)
        line_g_box = self.ctop_gtk.c2p_box("text_box", self.screen.width / 2.66,
                                           4,
                                           Gtk.Orientation.VERTICAL)
        line_e_box = self.ctop_gtk.c2p_box("text_box", self.screen.width / 2.66,
                                           4,
                                           Gtk.Orientation.VERTICAL)

        speed_l = self.ctop_gtk.c2p_label("Speed (mm)", "print_label")
        speed_l.set_halign(Gtk.Align.START)
        distance_l = self.ctop_gtk.c2p_label("Distance (mm)", "print_label")
        distance_l.set_halign(Gtk.Align.START)
        graph_l = self.ctop_gtk.c2p_label("Show The Graph (mm)", "print_label")
        graph_l.set_halign(Gtk.Align.START)
        extrude_l = self.ctop_gtk.c2p_label("Extrude", "print_label")
        extrude_l.set_halign(Gtk.Align.START)
        graph_zoom_button = self.ctop_gtk.Button_new("capture",style="browse_button",scale=.75)
        graph_zoom_button.set_valign(Gtk.Align.CENTER)
        graph_zoom_button.set_halign(Gtk.Align.END)
        graph_zoom_button.connect("clicked",self.zoom_graph)
        # speed_buttons
        speed_button_labels = ["1", "2", "5", "10", "..."]
        for index,button_label in enumerate(speed_button_labels):
            self.extrude_buttons["speed"][button_label] = self.ctop_gtk.Button_new(label=button_label,style="extrude_button")

            speed_degree_box.add(
                self.extrude_buttons["speed"][button_label])
            if button_label == "...":
                self.extrude_buttons["speed"][button_label].connect(
                    "clicked", self.get_object_name, "s")
            else:
                self.extrude_buttons["speed"][button_label].connect("clicked",
                                                                    self.change_value,
                                                                    button_label,
                                                                    self.extrude_buttons[
                                                                        "speed"][
                                                                        button_label],
                                                                    "s")
            if not index:
                self.extrude_buttons["speed"][button_label].get_style_context().add_class("extrude_button_pressed")

        # distance_buttons
        dis_button_labels = ["5", "10", "15", "25", "..."]
        for index,button_label in enumerate(dis_button_labels):
            self.extrude_buttons["distance"][button_label] = self.ctop_gtk.Button_new(label=button_label,
                                                                                      style="extrude_button")
            distance_degree_box.add(self.extrude_buttons["distance"][button_label])
            if button_label == "...":

                self.extrude_buttons["distance"][button_label].connect(
                    "clicked", self.get_object_name, "d")
            else:
                self.extrude_buttons["distance"][button_label].connect("clicked", self.change_value, button_label,
                                                                       self.extrude_buttons["distance"][button_label],
                                                                       "d")
            if not index:
                self.extrude_buttons["distance"][button_label].get_style_context().add_class("extrude_button_pressed")
        self.custom_button = CustomButton([None,"01",None], "bottom", 73, 250, panel ="extrude",orientation="bottom",command=[lambda: self.extrude("+"), lambda: self.extrude("-"), None],svg=["down-camera",None,"up-camera"],style=self.style)
        self.extrude_buttons["extrude_retract"] = self.ctop_gtk.make_shadow(self.custom_button)
        self.extrude_buttons["extrude_retract"].get_style_context().add_class("margin_bottom")
        self.extrude_buttons["extrude_retract"].set_valign(Gtk.Align.CENTER)
        self.extrude_buttons["cooldown"] = self.ctop_gtk.Button_new(label="Cooldown", style="cooldown")
        self.extrude_buttons["cooldown"].connect("clicked", self.cooldown, 0)
        self.extrude_buttons["cooldown"].set_valign(Gtk.Align.CENTER)



        speed_box.add(speed_l)
        speed_box.add(line_box)
        speed_box.add(speed_degree_box)
        distance_box.add(distance_l)
        distance_box.add(line_d_box)
        distance_box.add(distance_degree_box)

        graph_title_box.add(graph_l)
        graph_title_box.pack_start(graph_zoom_button,True,True,0)
        self.graph_box.add(graph_title_box)
        self.graph_box.add(line_g_box)

        GLib.timeout_add_seconds(5, self.update_graph)

        extrude_grid.attach(speed_box, 0, 0, 1, 1)
        extrude_grid.attach(distance_box, 0, 1, 1, 1)
        extrude_grid.attach(self.extrude_buttons["extrude_retract"], 1, 0, 1, 2)
        extrude_grid.attach(self.extrude_buttons["cooldown"], 2, 0, 1,
                            2)
        extrude_box.add(extrude_l)
        extrude_box.add(line_e_box)
        extrude_box.add(extrude_grid)
        self.show_temp_circles(temp_progress_grid)
        self.temp_main_box.add(temp_progress_grid)
        self.temp_main_box.add(extrude_box)
        self.temp_main_box.add(self.graph_box)
    def get_content(self):
        return self.temp_main_box,"Temperature Panel"


    def zoom_graph(self,widget):
        buttons = {}
        def close_on(widget):
            self.keypad.destroy()
            self.can_show_graph = False
        def show_selected_graph(widget,dev):
            if dev == "01":
                if "extruder" in self.showed_devices:
                    self.heater_graph.set_showing("extruder", False)
                    self.showed_devices.remove("extruder")
                    buttons["01"].get_style_context().remove_class("nozzle_auto_tools_buttons_pressed")
                    buttons["01"].get_style_context().add_class("nozzle_auto_tools_buttons")
                else:
                    self.heater_graph.set_showing("extruder",True)
                    self.showed_devices.append("extruder")
                    buttons["01"].get_style_context().add_class("nozzle_auto_tools_buttons_pressed")
            elif dev == "02":
                if "extruder1" in self.showed_devices:
                    self.heater_graph.set_showing("extruder1", False)
                    self.showed_devices.remove("extruder1")
                    buttons["02"].get_style_context().remove_class("nozzle_auto_tools_buttons_pressed")
                    buttons["02"].get_style_context().add_class("nozzle_auto_tools_buttons")
                else:
                    self.heater_graph.set_showing("extruder1", True)
                    self.showed_devices.append("extruder1")
                    buttons["02"].get_style_context().add_class("nozzle_auto_tools_buttons_pressed")
            elif dev == "03":
                if "extruder2" in self.showed_devices:
                    self.heater_graph.set_showing("extruder2", False)
                    self.showed_devices.remove("extruder2")
                    buttons["03"].get_style_context().remove_class("nozzle_auto_tools_buttons_pressed")
                    buttons["03"].get_style_context().add_class("nozzle_auto_tools_buttons")
                else:
                    self.heater_graph.set_showing("extrude2", True)
                    self.showed_devices.append("extrude2")
                    buttons["03"].get_style_context().add_class("nozzle_auto_tools_buttons_pressed")
            elif dev == "04":
                if "extruder" in self.showed_devices:
                    self.heater_graph.set_showing("extruder3", False)
                    self.showed_devices.remove("extruder3")
                    buttons["04"].get_style_context().remove_class("nozzle_auto_tools_buttons_pressed")
                    buttons["04"].get_style_context().add_class("nozzle_auto_tools_buttons")
                else:
                    self.heater_graph.set_showing("extruder", True)
                    self.showed_devices.append("extruder")
                    buttons["04"].get_style_context().add_class("nozzle_auto_tools_buttons_pressed")
            elif dev == "Bed":
                if "heater_bed" in self.showed_devices:
                    self.heater_graph.set_showing("heater_bed", False)
                    self.showed_devices.remove("heater_bed")
                    buttons["Bed"].get_style_context().remove_class("nozzle_auto_tools_buttons_pressed")
                    buttons["Bed"].get_style_context().add_class("nozzle_auto_tools_buttons")
                else:
                    self.heater_graph.set_showing("heater_bed", True)
                    self.showed_devices.append("heater_bed")
                    buttons["Bed"].get_style_context().add_class("nozzle_auto_tools_buttons_pressed")
            elif dev == "Env":
                if "heater_generic Env_heater" in self.showed_devices:
                    self.heater_graph.set_showing("heater_generic Env_heater", False)
                    self.showed_devices.remove("heater_generic Env_heater")
                    buttons["Env"].get_style_context().remove_class("nozzle_auto_tools_buttons_pressed")
                    buttons["Env"].get_style_context().add_class("nozzle_auto_tools_buttons")
                else:
                    self.heater_graph.set_showing("heater_generic Env_heater", True)
                    self.showed_devices.append("heater_generic Env_heater")
                    buttons["Env"].get_style_context().add_class("nozzle_auto_tools_buttons_pressed")
            self.heater_graph.queue_draw()
        self.keypad = Gtk.Window(title="Keypad")
        self.keypad.set_transient_for(
            self.screen)  # Make it behave like a dialog
        self.keypad.set_modal(True)  # Block interaction with the main window
        self.keypad.set_decorated(False)
        self.keypad.set_resizable(False)
        self.keypad.get_style_context().add_class(
            "power_panel")
        self.keypad.set_default_size(self.screen.width, self.screen.height)
        # self.keypad.set_position(Gtk.WindowPosition.CENTER)
        screen = Gdk.Screen.get_default()
        visual = screen.get_rgba_visual()
        if visual is not None and screen.is_composited():
            self.keypad.set_visual(visual)
        self.graph_box.remove(self.heater_graph)

        button_labels = ["01", "02", "03", "04","Bed","Env"]
        buttons_box = self.ctop_gtk.c2p_box()

        for button_label,dev in zip(button_labels,self.screen.printer.get_active_extruders()+self.screen.printer.get_heaters()):
            buttons[button_label] = self.ctop_gtk.Button_new(label=button_label,style="nozzle_auto_tools_buttons")
            if dev is None:
                buttons[button_label].set_sensitive(False)
            if dev in self.showed_devices:
                buttons[button_label].get_style_context().add_class("nozzle_auto_tools_buttons_pressed")
            buttons[button_label].connect("clicked",show_selected_graph,button_label)
            buttons_box.add(buttons[button_label])

        close_button = self.ctop_gtk.Button_new("close_keypad",style="keypad_button")
        close_button.connect("clicked",close_on)
        close_button.set_halign(Gtk.Align.END)
        buttons_box.pack_start(close_button,True,True,0)
        box = self.ctop_gtk.c2p_box(style="main_box", width=self.screen.width / 1.111,
                                          height=self.screen.height / 1.736,orientation=Gtk.Orientation.VERTICAL)
        box.set_valign(Gtk.Align.CENTER)
        box.set_halign(Gtk.Align.CENTER)
        box.add(buttons_box)
        box.add(self.heater_graph)

        self.keypad.add(box)
        self.keypad.show_all()
    def disable_all_graph_devices(self):
        for dev in self.screen.printer.get_origin_extruders() + self.screen.printer.get_heaters():
            self.heater_graph.set_showing(dev, False)
    def change_value(self, widget, value, button, type=None):
        if type == "d":
            self.distance = value
            for d_button in self.extrude_buttons["distance"].values():
                style_context = d_button.get_style_context()
                if style_context.has_class(
                        "extrude_button_pressed"):  # Check if the style class exists
                    style_context.remove_class(
                        "extrude_button_pressed")  # Remove the class if it exists
        elif type == "s":
            self.speed = value
            for d_button in self.extrude_buttons["speed"].values():
                style_context = d_button.get_style_context()
                if style_context.has_class(
                        "extrude_button_pressed"):  # Check if the style class exists
                    style_context.remove_class(
                        "extrude_button_pressed")  # Remove the class if it exists
        button.get_style_context().add_class("extrude_button_pressed")

    def show_temp_circles(self, temp_progress_grid):
        for child in temp_progress_grid.get_children():
            temp_progress_grid.remove(child)
        w=150
        h=308
        self.progress_circle1 = ProgressCircle(self.screen, panel="gcode",w=w,h=h,
                                               name="extruder",
                                               label="01",
                                               progress=0,
                                               current_temp=0,
                                               style=self.style,
                                               active=True,
                                               angle=-math.pi / 2,
                                               command=[lambda: self.select_tool(tool="01",device="extruder",prog = self.progress_circle1),lambda: self.get_object_name(name="extruder")])
        self.progress_circle2 = ProgressCircle(self.screen, panel="gcode",w=w,h=h,
                                               name="extruder1",
                                               label="02",
                                               progress=0,
                                               current_temp=0,
                                               style=self.style, active=True,
                                               angle=-math.pi / 2,
                                               command=[lambda: self.select_tool(tool="02",device="extruder1",prog = self.progress_circle2),lambda: self.get_object_name(name="extruder1")])
        self.progress_circle3 = ProgressCircle(self.screen, panel="gcode",w=w,h=h,
                                               name="extruder2",
                                               label="03",
                                               progress=0,
                                               current_temp=0,
                                               style=self.style, active=False,
                                               angle=-math.pi / 2,
                                               command=[lambda: self.select_tool(tool="03",device="extruder2",prog = self.progress_circle2),lambda: self.get_object_name(name="extruder2")])
        self.progress_circle4 = ProgressCircle(self.screen, panel="gcode",w=w,h=h,
                                               name="extruder3",
                                               label="04",
                                               progress=0,
                                               current_temp=0,
                                               style=self.style, active=False,
                                               angle=-math.pi / 2,
                                               command=[lambda: self.select_tool(tool="04",device="extruder3",prog = self.progress_circle3),lambda: self.get_object_name(name="extruder3")])
        self.circle = ProgressCircle(self.screen, panel="gcode", name="heater_bed", label="Bed", progress=0,
                                     current_temp=0, side="left", style=self.style, active=False, w = 340, h = 160,
                                     command=lambda: self.get_object_name(name="heater_bed"))
        self.progress_bed = self.circle
        self.progress_env = ProgressCircle(self.screen, panel="gcode",
                                           label="Env",
                                           name="Env_heater",
                                           progress=0,
                                           w = 340, h = 160,
                                           current_temp=0, style=self.style,
                                           active=False,
                                           command=lambda: self.get_object_name(name="Env_heater"))
        self.progress_devices = [
            self.progress_circle1, self.progress_circle2,
            self.progress_circle3, self.progress_circle4, self.progress_bed, self.progress_env

        ]
        self.select_tool("01","extruder",self.progress_circle1)
        bed_env_box = self.ctop_gtk.c2p_box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=20)
        bed_env_box.add(self.progress_bed)
        bed_env_box.add(self.progress_env)
        temp_progress_grid.attach(bed_env_box, 0, 0, 4, 1)
        temp_progress_grid.attach(self.progress_circle1, 0, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle2, 1, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle3, 2, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle4, 3, 1, 1, 1)
        temp_progress_grid.show_all()

    def process_update(self, action, data):
        # data = kwargs.get("data")
        if not self.can_show_graph:
            self.heater_graph = HeaterGraph(self.screen.printer, 22.3)
            self.graph_box.add(self.heater_graph)
            self.graph_box.show_all()
            self.can_show_graph = True
        self.update_temp()

    def update_temp(self):
        for device, progress, dev_color in zip(
                self.screen.printer.get_active_extruders() + self.screen.printer.get_heaters(), self.progress_devices,
                self.screen.printer.get_device_color()):
            self.temp[device] = self.screen.printer.get_dev_stat(device, "temperature")
            target = self.screen.printer.get_dev_stat(device, "target")
            progress.set_target(target)
            self.custom_button.temp = self.temp[device]
            # if self.screen.printer.get_dev_stat(
            #         switch, "state") == "PRESSED":  # Show tool is in park
            #     progress.set_park_status(True)
            # elif self.screen.printer.get_dev_stat(switch, "state") == "RELEASED":
            #     progress.set_park_status(False)
            if device is not None and "temperature_sensor" not in device:
                max_temp = self.screen.printer.get_dev_stat(device,
                                                            "max_temp")
                min_temp = self.screen.printer.get_dev_stat(device,
                                                            "min_extrude_temp")
                if self.temp[device] is not None and max_temp is not None:
                    progress.set_current_temp(self.temp[device],
                                              self.temp[device] / max_temp, max_temp, True)
                if device == self.device_name and min_temp is not None:
                    # Check if the button needs to be updated
                    if self.temp[device] < min_temp:
                        if self.extrude_buttons["extrude_retract"].get_sensitive():
                            # Only disable if the button is currently enabled
                            self.extrude_buttons["extrude_retract"].set_sensitive(False)
                            self.custom_button.disable_button()

                    else:
                        if not self.extrude_buttons["extrude_retract"].get_sensitive():
                            # Only enable if the button is currently disabled
                            self.extrude_buttons["extrude_retract"].set_sensitive(True)
                            self.custom_button.enable_button()
                elif min_temp is None and "extruder" not in self.device_name:
                    if self.extrude_buttons["extrude_retract"].get_sensitive():
                        # Only disable if the button is currently enabled
                        self.extrude_buttons["extrude_retract"].set_sensitive(False)
                if self.can_show_graph:
                    if device in self.showed_devices:

                        self.heater_graph.add_object(device, "temperatures", dev_color, False,
                                                     False)
                        self.heater_graph.add_object(device, "targets", dev_color, True,
                                                     False)
                        self.heater_graph.set_showing(device,True)

    def show_keypad(self, widget=None, type=None):
        # Determine the initial value for the keypad
        if type in self.screen.printer.get_active_extruders() + self.screen.printer.get_heaters():
            for progress, device in zip(self.progress_devices,
                                        self.screen.printer.get_active_extruders() + self.screen.printer.get_heaters()):
                if device != type:
                    progress.on_button_release()
                else:
                    self.keypad_value = self.screen.printer.get_dev_stat(device, "target")
                    self.device_name = device
        elif widget:  # Read from widget label
            label_text = widget.get_label()
            try:
                # Try to parse the label as a number
                self.keypad_value = float(label_text)
            except (ValueError, TypeError):
                # If parsing fails, set the default value to 0
                self.keypad_value = 0
        else:
            self.keypad_value = 0  # Default value if none of the conditions match

        # Create a new Keypad instance and use lambda to pass the value directly to handle_keypad
        keypad_window = Keypad(
            self.screen,
            self.theme_path,
            lambda value: self.handle_keypad(value, widget, type)
        )
        keypad_window.show_keypad(text=self.keypad_value)

    def handle_keypad(self, value, widget, type):
        """
        Handle the value returned from the Keypad and update UI or state accordingly.
        """
        if type == "heater_bed":
            self.screen._ws.klippy.set_bed_temp(value)
        elif type.startswith("Env"):
            self.screen._ws.klippy.set_heater_temp(type, value)
        elif type == "s":
            print("Speed updated")
            self.change_value(widget, value, widget, "s")
        elif type == "d":
            print("Distance updated")
            self.change_value(widget, value, widget, "d")
        else:
            self.screen._ws.klippy.set_tool_temp(
                self.screen.printer.get_tool_number(type), value
            )
        # Optionally update the label of the widget
        if widget:
            try:
                numeric_value = float(value)
                # Check if the value is an integer
                if numeric_value.is_integer():
                    # If the value is an integer, set it without decimals
                    widget.set_label(f"{int(numeric_value)}")
                else:
                    # If the value is a float, format it with 2 decimal places
                    widget.set_label(f"{numeric_value:.2f}")
            except ValueError:
                # Handle non-numeric value gracefully
                widget.set_label("0")

        print(f"Updated {type} with value: {value}")

    def get_object_name(self, widget=None, name=None):
        self.show_keypad(widget, name)

    def extrude(self, direction):
        print(self.speed, self.distance)
        print(self.device_name)
        if "extruder" in self.device_name:
            self.screen._ws.klippy.gcode_script(f"ACTIVATE_EXTRUDER EXTRUDER={self.device_name}")
            self.screen._ws.klippy.gcode_script(CtoPGcodes.EXTRUDE_REL)
            self.screen._ws.klippy.gcode_script(
                CtoPGcodes.extrude(f"{direction}{self.distance}", f"{int(self.speed) * 60}"))

    def show_heater_graph(self):
        heater_graph = HeaterGraph(self.screen.printer, 2)

    def update_graph(self):
        if self.heater_graph is not None:
            self.heater_graph.queue_draw()
        return True

    def cooldown(self, widget, value):
        for device in self.screen.printer.get_active_extruders() + self.screen.printer.get_heaters():
            if device is None:
                continue
            if device == "heater_bed":
                self.screen._ws.klippy.set_bed_temp(value)
            elif device.startswith("heater_generic"):
                self.screen._ws.klippy.set_heater_temp("Env_heater", value)
            elif device.startswith("extruder"):
                self.screen._ws.klippy.set_tool_temp(
                    self.screen.printer.get_tool_number(device), value
                )

    def select_tool(self,tool,device,prog):
        for progress in self.progress_devices:
            progress.remove_change_label_color_m()
        prog.change_label_color_m()
        self.custom_button.update_circle_label(tool)
        self.device_name = device
       # self.selected_tool = tool
