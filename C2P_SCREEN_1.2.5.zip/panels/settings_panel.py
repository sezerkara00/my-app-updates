from elements.file_element import FileElement
from library.global_manager import GlobalVariables
from elements.c2p_gtk import CtoPGtk
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk

from panels.network_panel import NetWorkPanel
from panels.screen_setting_panel import ScreenSettingsPanel
from panels.select_tool import ToolsSelect


class SettingsMenu(GlobalVariables):
    def __init__(self, screen):
        super().__init__(screen)
        self.screen = screen
        self.ctop_gtk = CtoPGtk(self.screen, self.theme_path)
        self.settings_menu_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL)
        self.settings_menu_box.set_valign(Gtk.Align.CENTER)
        settings_menu_grid = Gtk.Grid()
        settings_menu_grid.get_style_context().add_class("calibrate_menu_grid")
        settings_menu_grid.set_halign(Gtk.Align.CENTER)
        settings_menu_grid.set_valign(Gtk.Align.CENTER)
        settings_menu_grid.set_row_spacing(30)
        settings_menu_grid.set_column_spacing(25)
        self.file_element = {}
        settings_panels = ['Tool Select','NetWork','Screen Settings']
        settings_images = ['nozzle_calibrate','nozzle_calibrate','nozzle_calibrate']
        
        for index, (panel, img_name) in enumerate(zip(settings_panels,settings_images)):

            self.file_element[panel] = FileElement(
                self.screen, panel,panel_command=lambda x: self.show_settings_panel(x),svg=img_name,style=self.style
            )
            if index >2:
                settings_menu_grid.attach(self.file_element[panel], index-3, 1, 1, 1)
            else:
                settings_menu_grid.attach(self.file_element[panel],index,0,1,1)
        self.settings_menu_box.pack_start(settings_menu_grid,True,True,0)

    def get_content(self):
        return self.settings_menu_box, "Settings Panel"

    def show_settings_panel(self, panel):
        self.screen.base_panel.pressed_button = 'sub'
        if panel == 'Tool Select':
            self.refresh_content(ToolsSelect(self.screen))
        elif panel == 'NetWork':
            self.refresh_content(NetWorkPanel(self.screen))
        elif panel == 'Screen Settings':
            self.refresh_content(ScreenSettingsPanel(self.screen))
        # elif panel == 'Bed Mesh':
        #     self.refresh_content(BedMesh(self.screen))

    def get_file_loc_image(self, fileloc, width=None, height=None):
        if fileloc is None or fileloc == "":
            return None
        width = width if width is not None else self.img_width
        height = height if height is not None else self.img_height
        return self.ctop_gtk.PixbufFromFile(fileloc, width, height)
