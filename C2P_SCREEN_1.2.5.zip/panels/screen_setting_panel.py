from elements.custom_combo_box import CustomComboBox
from library.global_manager import GlobalVariables
from elements.c2p_gtk import CtoPGtk
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
import time
import subprocess
from library.c2p_config import ConfigKeys,C2PConfig
import os
from packaging import version
import requests
import zipfile
class ScreenSettingsPanel(GlobalVariables):

    def __init__(self, screen):
        super().__init__(screen)
        self.ctop_gtk = CtoPGtk(screen,self.theme_path)
        self.config = C2PConfig()
        self.config.read_c2p_config()
        self.blank_time = self.config.get_value(ConfigKeys.BLANK_TIME)
        self.current_version = self.config.get_value(ConfigKeys.CURRENT_VERSION)
        #
        # # If there is a saved setting, apply it
        # # example: 10 min -> 10
        # if self.blank_time:
        #     initial_time = self.blank_time.split(" ")[0]
        #     self.set_screen_blanking(initial_time)


        # Define the switch as a class variable
        self.switch_dpms = Gtk.Switch()
        self.switch_dpms.get_style_context().add_class("custom-switch")
        self.switch_dpms.get_style_context().add_class("ssid_grid")
        self.switch_dpms.set_valign(Gtk.Align.CENTER)
        self.switch_dpms.set_halign(Gtk.Align.END)
        self.switch_dpms.connect("notify::active", self.on_switch_dpms_toggled)

        # Read the DPMS state from the config and apply it
        is_dpms = self.config.get_value(ConfigKeys.DPMS)
        if is_dpms == "on":
            self.switch_dpms.set_active(True)
            # subprocess.run(["xset", "s", "on"])
            # subprocess.run(["xset", "+dpms"])
        else:
            self.switch_dpms.set_active(False)
            # subprocess.run(["xset", "s", "off"])
            # subprocess.run(["xset", "-dpms"])

        self.main_screen_settings_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,spacing=15)
        self.main_screen_settings_box.set_halign(Gtk.Align.CENTER)
        top_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,  spacing=20,
                                             width=self.screen.width / 1.111, height=self.screen.height / 1.6,style="print_control_box")
        bottom_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=15,width=self.screen.width / 1.111, height=self.screen.height / 6.8,style="print_control_box")
        line_box_top = self.ctop_gtk.c2p_box("text_box", self.screen.width / 1.86,
                                             4,
                                             Gtk.Orientation.VERTICAL)
        theme_box = self.ctop_gtk.c2p_box(width=self.screen.width / 1.25, height=self.screen.height / 12.8,style="image_box_dialog",position=Gtk.Align.CENTER)
        lang_box = self.ctop_gtk.c2p_box(width=self.screen.width / 1.25, height=self.screen.height / 12.8,style="image_box_dialog",position=Gtk.Align.CENTER)
        dpms_box = self.ctop_gtk.c2p_box(width=self.screen.width / 1.25, height=self.screen.height / 12.8,style="image_box_dialog",position=Gtk.Align.CENTER)
        blanking_box = self.ctop_gtk.c2p_box(width=self.screen.width / 1.25, height=self.screen.height / 12.8,style="image_box_dialog",position=Gtk.Align.CENTER)
        current_v_box = self.ctop_gtk.c2p_box(width=self.screen.width / 1.25, height=self.screen.height / 12.8,
                                        style="image_box_dialog", position=Gtk.Align.CENTER)

        theme_label = self.ctop_gtk.c2p_label("Theme","select_tool_label")
        lang_label = self.ctop_gtk.c2p_label("Language","select_tool_label")
        dpms_label = self.ctop_gtk.c2p_label("Screen DPMS","select_tool_label")
        blanking_label = self.ctop_gtk.c2p_label("Screen Blanking","select_tool_label")
        screen_settings_label = self.ctop_gtk.c2p_label("Screen Settings","print_label")
        screen_settings_label.set_halign(Gtk.Align.START)
        current_v_label = self.ctop_gtk.c2p_label("Current Version:", "select_tool_label")
        self.latest_version  = self.get_latest_version_from_github()
        current_v_value_label = self.ctop_gtk.c2p_label(self.current_version, "version_label_settings")
        current_v_value_label.set_halign(Gtk.Align.END)
        
        # Create a horizontal box to hold version info and download button
        version_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
        version_box.set_halign(Gtk.Align.END)
        
        if self.current_version != self.latest_version:
            update_button = self.ctop_gtk.Button_new(label="Latest version : "+self.latest_version,style="update_button_settings")
            download_button = self.ctop_gtk.Image("download")
            download_button_event_box = Gtk.EventBox()
            download_button_event_box.add(download_button)
            download_button_event_box.connect("button-press-event",self.download_update)
            
            # Add version label and download button to horizontal box
            version_box.pack_start(current_v_value_label, False, False, 5)
            version_box.pack_start(download_button_event_box, False, False, 0)
        else:
            update_button = self.ctop_gtk.Button_new(label="Latest Version is installed",style="update_button_settings")
            # Only add version label if no download button
            version_box.pack_start(current_v_value_label, False, False, 0)

        update_button.set_halign(Gtk.Align.CENTER)
        update_button.set_sensitive(self.current_version != self.latest_version)
        
        # Update the current_v_box to use the new version_box
        current_v_box.add(current_v_label)
        current_v_box.pack_start(version_box, True, True, 0)

        self.combo_lang = CustomComboBox(['en','tr'],self.select_option,'en',"custom-combo")

        self.combo_lang.set_halign(Gtk.Align.END)
        self.combo_lang.set_valign(Gtk.Align.CENTER)

        self.style = self.config.get_value(ConfigKeys.THEME)
        self.combo_theme = CustomComboBox(['dark','light'],self.select_option,self.style,"custom-combo")

        self.combo_theme.set_halign(Gtk.Align.END)
        self.combo_theme.set_valign(Gtk.Align.CENTER)


        self.combo_blanking = CustomComboBox(['1 min','5 min','10 min','30 min','None'],
                                           self.select_option,
                                           self.blank_time or '1 min',  # Use saved value or default
                                           "custom-combo")

        self.combo_blanking.set_halign(Gtk.Align.END)
        self.combo_blanking.set_valign(Gtk.Align.CENTER)


        theme_box.add(theme_label)
        theme_box.pack_start(self.combo_theme,True,True,0)
        lang_box.add(lang_label)
        lang_box.pack_start(self.combo_lang,True,True,0)
        dpms_box.add(dpms_label)
        dpms_box.pack_start(self.switch_dpms,True,True,0)
        blanking_box.add(blanking_label)
        blanking_box.pack_start(self.combo_blanking, True, True,0)

        top_box.add(screen_settings_label)
        top_box.add(line_box_top)
        top_box.add(theme_box)
        top_box.add(lang_box)
        top_box.add(dpms_box)
        top_box.add(blanking_box)

        bottom_box.add(current_v_box)
        bottom_box.add(update_button)


        self.main_screen_settings_box.add(top_box)
        self.main_screen_settings_box.add(bottom_box)
    def select_option(self, text):
        # example: 10 min -> 10
        if self.combo_blanking.get_active_text() == text:
            self.current_blanking_time = text
            print(f"Screen blanking time changed to: {text}")
            self.set_screen_blanking(text)
        elif self.combo_theme.get_active_text() == text:
            print(f"Theme changed to: {text}")
            self.style=text
            self.config.update_sub_value(ConfigKeys.THEME, None, text)
            self.restart_service("C2P_SCREEN")
        elif self.combo_lang.get_active_text() == text:
            print(f"Language changed to: {text}")
    def get_content(self):
        return self.main_screen_settings_box,"Settings Panel"
    def on_switch_dpms_toggled(self, switch, gparam):
        """When the switch state changes, the method is called"""
        is_active = switch.get_active()
        dpms_state = "on" if is_active else "off"
        self.config.update_sub_value(ConfigKeys.DPMS, None, dpms_state)
        print(f"DPMS switch state changed: {dpms_state}")

        # DPMS setting
        if is_active:
            subprocess.run(["xset", "s", "on"])
            subprocess.run(["xset", "+dpms"])
        else:
            subprocess.run(["xset", "s", "off"])
            subprocess.run(["xset", "-dpms"])

    def download_update(self, widget, event):
        """Handle download button click event
        
        Args:
            widget: The widget that triggered the event
            event: The event details
        """
        print("Download update")
        # Add your download logic here
        self.download_update_from_github()
    def blanking_mode_value(self):
        blanking_mode = self.config.get_value(ConfigKeys.BLANK_TIME)
        is_dpms = self.config.get_value(ConfigKeys.DPMS)
        if blanking_mode == "None":
            subprocess.run(["xset", "s", is_dpms])
            subprocess.run(["xset", "-dpms"])
        else:
            blanking_mode = blanking_mode.split(" ")[0]
            blanking_mode = int(blanking_mode)*60
            blanking_mode = str(blanking_mode)
            subprocess.run(["xset", "s", is_dpms])


    def get_latest_version_from_github(self):
        """Get the latest version from GitHub releases"""
                # GitHub'dan sürüm bilgisini çek
        url = "https://api.github.com/repos/sezerkara00/fluiddv1/releases/latest"
        response = requests.get(url)
        data = response.json()
        
        # GitHub'dan gelen en son sürüm
        latest_version = data["tag_name"]
        return latest_version
        # try:
        #     # Tüm release'leri al
        #     url = "https://api.github.com/repos/sezerkara00/fluiddv1/releases"
        #     response = requests.get(url, timeout=5)
        #     response.raise_for_status()
        #     releases = response.json()
            
        #     # Tüm release'leri yazdır (en son hariç)
        #     print("\nMevcut Release'ler:")
        #     for release in releases[1:]:  # İlk release'i atla (en son)
        #         print(f"Version: {release['tag_name']}")
        #         print(f"Yayın Tarihi: {release['published_at']}")
        #         print(f"Açıklama: {release['body']}")
        #         print("-" * 50)
            
        #     # En son release'i döndür
        #     if releases:
        #         return releases[0]["tag_name"]  # İlk release en son olanıdır
        #     return self.current_version
            
        # except (requests.RequestException, KeyError) as e:
        #     print(f"Error fetching latest version: {e}")
        #     return self.current_version  # Return current version if fetch fails
    
    def download_update_from_github(self):
        """Download and update to the latest version"""
        try:
            series = self.config.get_value(ConfigKeys.SERIES)
            # url of the zip file on the server
                
            url = f"http://localhost:8000/download/{series}" # put the url of the zip file you want to download
            download_path = "/home/pinar/fluiddNew/deneme/downloaded_test.zip"
            extract_path = "/home/pinar/fluiddNew/deneme/extracted"  # extract directory

            # clean extract directory
            self.clear_dir(extract_path)
            
            print("downloading...")
            response = requests.get(url, stream=True)
            response.raise_for_status()  # check for HTTP errors
            
            # download zip file
            with open(download_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

            print(f"downloading completed: {download_path}")

            # unzip file
            os.makedirs(extract_path, exist_ok=True)
            with zipfile.ZipFile(download_path, 'r') as zip_ref:
                zip_ref.extractall(extract_path)

            print(f"file downloaded and extracted: {extract_path}")

        except Exception as e:
            print(f"error: {e}")

    def clear_dir(self, directory):
        """
        . if directory not exists, create it.
        . if directory exists, delete all files and folders inside it.
        Args:
            directory (str): directory to be cleaned
        """
        import shutil
        
        try:
            # if directory exists, clean it
            if os.path.exists(directory):
                # delete all files and folders inside it
                for item in os.listdir(directory):
                    item_path = os.path.join(directory, item)
                    if os.path.isfile(item_path):
                        os.unlink(item_path)
                    elif os.path.isdir(item_path):
                        shutil.rmtree(item_path)
                print(f"directory cleaned: {directory}")
            else:
                # if directory not exists, create it
                os.makedirs(directory)
                print(f"directory created: {directory}")
                
        except Exception as e:
            print(f"error: {e}")