from elements.keyboard import VirtualKeyboard
from elements.keypad import Keypad
from library.c2p_config import C2PConfig, ConfigKeys
from library.global_manager import GlobalVariables
from elements.c2p_gtk import CtoPGtk
from gi.repository import Gtk, GLib, Gdk
from elements.color_chooser import ColorChooserWidget
from elements.c2p_dialog import C2PDialog
from elements.popup import PopupNotification
import re,threading
from library.c2p_files_manager import c2p
from elements.material_select import FilamentSelectionModal



class ToolsSelect(GlobalVariables):

    def __init__(self, screen):
        super().__init__(screen)
        self.screen = screen
        self.uuidfilename = ["EBBCan", "EBBCan1", "EBBCan2", "EBBCan3"]
        self.materials = {
            "PLA": 1.275,
            "ABS": 1.055,
            "PETG": 1.25,
            "TPU": 1.175,
            "Nylon": 1.14,
            "PC": 1.20,
            "HIPS": 1.045,
            "ASA": 1.065,
            "PVA": 1.27,
            "PP": 0.90,
            "Carbon Fiber": 1.30,
            "Wood Filament": 1.30,
        }
        self.toolstate = {}
        self.toolsindex= 0
        self.state_tools_filament = None
        self.tool_name = "t0"
        ctop_gtk = CtoPGtk(self.screen,self.theme_path)
        self.ctop_config = C2PConfig(screen)
        self.main_tools_select_box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=30)
        top_box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, style="print_control_box",
                                   width=self.screen.width / 1.111, height=self.screen.height / 4.2181, spacing=10)
        top_box.set_halign(Gtk.Align.CENTER)
        bottom_box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, style="print_control_box",
                                      width=self.screen.width / 1.111, height=self.screen.height / 2.1)
        bottom_box.set_halign(Gtk.Align.CENTER)
        tools_box = ctop_gtk.c2p_box(spacing=15)
        tools_box.set_halign(Gtk.Align.CENTER)
        id_box = ctop_gtk.c2p_box(style="front_view_box", width=self.screen.width / 1.212, height=self.screen.height / 12.8)
        id_box.set_halign(Gtk.Align.CENTER)
        material_box = ctop_gtk.c2p_box(style="front_view_box", width=self.screen.width / 1.212, height=self.screen.height / 12.8)
        material_box.set_halign(Gtk.Align.CENTER)
        nozzle_size_box_all = ctop_gtk.c2p_box(spacing=26, width=self.screen.width / 1.212, height=self.screen.height / 12.8)
        nozzle_size_box_all.set_halign(Gtk.Align.CENTER)
        nozzle_size_box = ctop_gtk.c2p_box(style="front_view_box", width=self.screen.width / 2.5, height=self.screen.height / 12.8)
        filament_sensor_box = ctop_gtk.c2p_box(style="front_view_box", width=self.screen.width / 2.5, height=self.screen.height / 12.8,spacing=140)
        version_tools_all = ctop_gtk.c2p_box( width=self.screen.width / 1.212, height=self.screen.height / 12.8,spacing=30)
        version_tools_all.set_halign(Gtk.Align.CENTER)
        version_tools = ctop_gtk.c2p_box(style="front_view_box",width=self.screen.width / 2.5, height=self.screen.height / 12.8)
        up_time = ctop_gtk.c2p_box(style="front_view_box", width=self.screen.width / 2.5, height=self.screen.height / 12.8)
        filament_used_box = ctop_gtk.c2p_box(style="front_view_box",width=self.screen.width / 2.5, height=self.screen.height / 21.333)
        filament_total_box = ctop_gtk.c2p_box(style="front_view_box", width=self.screen.width / 2.5,
                                             height=self.screen.height / 21.333)
        filament_all_box =  ctop_gtk.c2p_box( width=self.screen.width / 1.212, height=self.screen.height / 12.8,spacing=30)
        filament_all_box.set_halign(Gtk.Align.CENTER)
        line_box_top = ctop_gtk.c2p_box("text_box", self.screen.width / 1.86,
                                    4,
                                    Gtk.Orientation.VERTICAL)
        line_box_bottom = ctop_gtk.c2p_box("text_box", self.screen.width / 1.86,
                                    4,
                                    Gtk.Orientation.VERTICAL)
        tool_status_box = ctop_gtk.c2p_box("front_view_box", self.screen.width / 2.285,
                                    self.screen.height / 14.185,spacing=140
                                   )
        tool_status_box.set_halign(Gtk.Align.CENTER)
        select_tool_label = ctop_gtk.c2p_label("Select Tool","print_label")
        select_tool_label.set_halign(Gtk.Align.START)
        tools_status_label = ctop_gtk.c2p_label("Tools Status:","select_tool_label")
        tools_info_label = ctop_gtk.c2p_label("Tools Information","print_label")
        tools_info_label.set_halign(Gtk.Align.START)
        id_label = ctop_gtk.c2p_label("ID:","print_label")
        material_label = ctop_gtk.c2p_label("Material:", "print_label")
        nozzle_size_label = ctop_gtk.c2p_label("Nozzle Size:", "select_tool_label")
        self.version_label = ctop_gtk.c2p_label("Version Tools:", "select_tool_label")
        self.filament_label = ctop_gtk.c2p_label("PLA","print_label")
        self.nozzle_value_label = ctop_gtk.c2p_label("0.0","select_tool_label")
        filament_sensor_label = ctop_gtk.c2p_label("Filament:","select_tool_label")
        up_time_label = ctop_gtk.c2p_label("UP Time:", "select_tool_label")
        filament_wight_label = ctop_gtk.c2p_label("Filam Used(g):", "select_tool_label")
        filament_total_label = ctop_gtk.c2p_label("Filam Total(g):", "select_tool_label")
        self.filament_used_value_label = ctop_gtk.c2p_label("100","select_tool_label")
        self.filament_total_value_label = ctop_gtk.c2p_label("100","select_tool_label")
        tools_button_labels = ["01", "02", "03", "04"]
        tools_name = self.screen.printer.get_origin_extruders()
        self.tool_buttons = {}
        for index, (lbl,t_name) in enumerate(zip(tools_button_labels,tools_name)):
            self.tool_buttons[lbl] = ctop_gtk.Button_new(label=lbl, style="bed_mesh_points_button")
            self.tool_buttons[lbl].connect('clicked', self.select_tool,t_name,index)
            tools_box.add(self.tool_buttons[lbl])

        set_tools_button = ctop_gtk.Button_new(label="Set Tools",style="set_tools_calibrate_button")
        set_tools_button.connect('clicked', self.set_tool)
        set_tools_button.set_halign(Gtk.Align.CENTER)

        self.tool_id = ctop_gtk.c2p_label("ID Not Found")
        self.tool_id.set_valign(Gtk.Align.CENTER)
        self.tool_id.set_size_request(100, 50)
        self.tool_id.get_style_context().add_class("print_label")

        edit_button = ctop_gtk.Button_new("edit","Edit",position=Gtk.PositionType.RIGHT,style="nozzle_auto_tools_buttons",scale=.45)
        edit_button.connect("clicked",self.on_edit_clicked,"id")
        auto_fill_button = ctop_gtk.Button_new("edit", "Auto Fill", position=Gtk.PositionType.RIGHT,style="nozzle_auto_tools_buttons",scale=.45)
        auto_fill_button.connect("clicked", self.on_auto_fill_clicked)
        material_edit_button = ctop_gtk.Button_new("edit", "Edit", position=Gtk.PositionType.RIGHT,style="nozzle_auto_tools_buttons",scale=.45)
        material_edit_button.connect("clicked", self.on_edit_clicked, "material")
        nozzle_edit_button = ctop_gtk.Button_new("edit", "Edit", position=Gtk.PositionType.RIGHT,
                                                   style="nozzle_auto_tools_buttons", scale=.45)
        nozzle_edit_button.connect("clicked", self.on_edit_clicked, "size")
        filament_total_edit_button = ctop_gtk.Button_new("edit", "Edit", position=Gtk.PositionType.RIGHT,
                                                 style="nozzle_auto_tools_buttons", scale=.45)
        filament_total_edit_button.connect("clicked", self.on_edit_clicked, "f_total")
        filament_used_edit_button = ctop_gtk.Button_new("edit", "Edit", position=Gtk.PositionType.RIGHT,
                                                 style="nozzle_auto_tools_buttons", scale=.45)
        filament_used_edit_button.connect("clicked", self.on_edit_clicked, "f_used")
        self.color_picker_button = ColorChooserWidget(self.set_filament_color)

        #color_picker_button.connect("clicked",self.show_color_widget)
        self.switch = Gtk.Switch()
        self.switch.get_style_context().add_class("custom-switch")
        self.switch.set_active(False)
        self.switch.set_valign(Gtk.Align.CENTER)
        self.switch.connect("notify::active", self.on_switch_toggled)
        self.filament_detector = Gtk.Switch()
        self.filament_detector.get_style_context().add_class("custom-switch")
        self.filament_detector.set_active(False)
        self.filament_detector.set_valign(Gtk.Align.CENTER)
        self.filament_detector.set_halign(Gtk.Align.END)
        self.filament_detector.connect("notify::active", self.on_switch_filament_toggled)
        #adding
        tool_status_box.add(tools_status_label)
        tool_status_box.add(self.switch)
        nozzle_size_box_all.add(nozzle_size_box)
        nozzle_size_box_all.add(filament_sensor_box)
        version_tools_all.add(version_tools)
        version_tools_all.add(up_time)
        #version_tools_all.add(filament_wgit_box)
        filament_sensor_box.add(filament_sensor_label)
        filament_sensor_box.add(self.filament_detector)
        up_time.add(up_time_label)
        filament_used_box.add(filament_wight_label)
        filament_used_box.pack_start(self.filament_used_value_label,True,True,0)
        filament_used_box.add(filament_used_edit_button)
        filament_total_box.add(filament_total_label)
        filament_total_box.pack_start(self.filament_total_value_label,True,True,0)
        filament_total_box.add(filament_total_edit_button)
        filament_all_box.add(filament_total_box)
        filament_all_box.add(filament_used_box)
        id_box.add(id_label)
        id_box.pack_start(self.tool_id,True,True,0)
        id_box.pack_start(edit_button,False,False,0)
        id_box.pack_start(auto_fill_button,False,False,0)
        material_box.add(material_label)
        material_box.pack_start(self.filament_label,True,True,0)
        material_box.add(material_edit_button)
        material_box.add(self.color_picker_button)
        nozzle_size_box.add(nozzle_size_label)
        nozzle_size_box.pack_start(self.nozzle_value_label,True,True,0)
        nozzle_size_box.add(nozzle_edit_button)
        version_tools.add(self.version_label)
        top_box.add(select_tool_label)
        top_box.add(line_box_top)
        top_box.add(tools_box)
        top_box.add(tool_status_box)
        bottom_box.add(tools_info_label)
        bottom_box.add(line_box_bottom)
        bottom_box.add(id_box)
        bottom_box.add(material_box)
        bottom_box.add(nozzle_size_box_all)
        bottom_box.add(filament_all_box)
        bottom_box.add(version_tools_all)

        self.main_tools_select_box.add(top_box)
        self.main_tools_select_box.add(bottom_box)
        self.main_tools_select_box.add(set_tools_button)
        ###
        self.show_wait_dialog_and_update()

    def show_wait_dialog_and_update(self):
        """Displays a waiting dialog and runs update_toolstate in the background."""
        # Create the waiting dialog
        dialog = C2PDialog(
            self.screen,
            self.screen,
            "Please wait while updating tool state...",
            theme_path=self.theme_path,
            title="Processing",
            button_names=[],  # No buttons, so the user must wait
        )
        def on_update_complete():
            """Callback function to close the dialog and update the UI after toolstate is ready."""
            dialog.destroy()  # Close the dialog
            self.select_tool(self.tool_buttons["01"], "extruder", 0)  # Update UI
        # Run update_toolstate asynchronously with the callback
        threading.Thread(target=self.update_toolstate, args=(on_update_complete,), daemon=True).start()

    def update_toolstate(self, callback):
        """Fetches tool state, updates UI, and calls a callback when done."""
        tool_all = self.screen.printer.get_origin_extruders()
        tool_active = set(self.screen.printer.get_active_extruders())  # Convert to set for O(1) lookup
        self.toolstate = {}

        for index, tool in enumerate(tool_all):
            state = int(tool in tool_active)
            ID, version = self.get_uuid_version(index)
            self.toolstate[tool] = {"state": state,"state_change": state, "ID": ID, "version": version}
        self.c2p_func_h = c2p(self.screen)
        self.state_tools_filament = self.c2p_func_h.get_tools_filament_print()
        # Run the callback on the main thread to update UI and close dialog
        GLib.idle_add(callback)

    def on_switch_toggled(self, switch, param):
        new_state = int(switch.get_active())  # Converts True → 1, False → 0
        self.toolstate[self.tool_name]["state_change"] = new_state  # Update toolstate dictionary
        # state = "On" if switch.get_active() else "Off"
        # print(f"Switch is now {state}")

    def on_switch_filament_toggled(self, switch, param):
        new_state = int(switch.get_active())  # Converts True → 1, False → 0
        self.state_tools_filament[self.toolsindex] = new_state
        self.screen._ws.klippy.gcode_script(f"CP_SET_FILAMENT_TOOL TOOL={self.toolsindex} VALUE={new_state}")
    
    def set_filament_color(self,r,g,b):
        r_color = r/255
        g_color = g/255
        b_color = b/255
        entrytext = f"{r_color},{g_color},{b_color}"
        self.screen.config_file.update_sub_value(ConfigKeys.FILAMENT_COLOR, self.tool_name, entrytext)
        # self.update_filament_color(r_color,g_color,b_color)

    def get_content(self):
        return self.main_tools_select_box,"Select Tool"
    
    def parse_rgb_string_safe(self,rgb_string):
        """
          Parse an RGB string into individual r, g, b components.

          Args:
              rgb_string (str): A string containing RGB values separated by commas (e.g., "0.1,0.2,0.3").

          Returns:
              tuple: A tuple of floats (r, g, b).
          """
        try:
            return tuple(map(float, rgb_string.split(",")))
        except ValueError:
            raise ValueError(f"Invalid RGB string format: {rgb_string}")
    
    def select_tool(self,widget,tool_name,toolsindex):
        ID, Version = self.toolstate[tool_name]["ID"], self.toolstate[tool_name]["version"]
        if ID is None:
            self.tool_id.set_text("ID Not Found")
            self.version_label.set_text(f"Version: None")
        else:
            self.tool_id.set_text(ID)
            self.version_label.set_text(f"Version: {Version}")
        self.tool_name = tool_name
        self.toolsindex = toolsindex
        r, g, b = self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,tool_name))

        # Create the Gdk.RGBA object
        default_color = Gdk.RGBA(r, g, b, 1.0)  # Full opacit
        self.color_picker_button.set_rgba(default_color)
        self.filament_label.set_text(self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,tool_name,default="PLA"))
        self.nozzle_value_label.set_text(self.screen.config_file.get_value(ConfigKeys.NOZZLE_SIZE,tool_name,default="0.4"))
        f_total = self.screen.config_file.get_value(ConfigKeys.FILAMENT_TOTAL,tool_name,default="0")
        self.filament_total_value_label.set_text(f"{float(f_total):.1f}")
        f_used = self.screen.config_file.get_value(ConfigKeys.FILAMENT_USED,tool_name,default="0")
        self.filament_used_value_label.set_text(f"{float(f_used):.1f}")
        self.switch.handler_block_by_func(self.on_switch_toggled)
        if self.toolstate[tool_name]["state_change"]:  # Defaults to 0 if tool_name is not found
            self.switch.set_active(True)
        else:
            self.switch.set_active(False)
        self.switch.handler_unblock_by_func(self.on_switch_toggled)
        self.filament_detector.handler_block_by_func(self.on_switch_filament_toggled)
        if int(self.state_tools_filament[toolsindex]):
            self.filament_detector.set_active(True)
        else:
            self.filament_detector.set_active(False)
        self.filament_detector.handler_unblock_by_func(self.on_switch_filament_toggled)

        for b in self.tool_buttons.values():
            b.get_style_context().remove_class("bed_mesh_points_button_pressed")
        widget.get_style_context().add_class("bed_mesh_points_button_pressed")

    def on_edit_clicked(self, widget,tipe):
        if tipe == "id":
           if not self.toolstate[self.tool_name]["state"]:
               PopupNotification(
                    message="Tool is disabled",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=5,
                    tipe="E"
                )
               return
           VirtualKeyboard(self.screen,self.theme_path,self.tool_id.get_text(),self.on_edit_changed)
        elif tipe == "material":
            modal = FilamentSelectionModal(self.screen,self.theme_path,self.materials,selected_material=self.filament_label.get_text())
            response = modal.run()
            if response == Gtk.ResponseType.OK:
                self.selected_density = modal.selected_density
                self.selected_material = modal.selected_material
                self.filament_label.set_text(self.selected_material)
                self.tipe = tipe
                self.on_edit_changed(self.selected_material)
                # self.update_filament_name(self.selected_material)
                # self.read_filament_name()
                # print(f"Selected Density: {self.selected_density} g/cm³")
            modal.destroy()
            # VirtualKeyboard(self.screen, self.theme_path, self.filament_label.get_text(), self.on_edit_changed)
        elif tipe == "size" or tipe == "f_total" or tipe == "f_used":
            min_v = 0
            max_v = 10000
            text = ""
            if  tipe == "size":
                text = self.nozzle_value_label.get_text()
                max_v = 5
            elif  tipe == "f_total":
                text = self.filament_total_value_label.get_text()
            elif  tipe == "f_used":
                text = self.filament_used_value_label.get_text()
            keypad_window = Keypad(self.screen, self.theme_path, lambda value: self.on_edit_changed(value),min_value=min_v,max_value=max_v)
            keypad_window.show_keypad(text=text)
            # VirtualKeyboard(self.screen, self.theme_path, self.nozzle_value_label.get_text(), self.on_edit_changed)
        self.tipe = tipe
    
    def on_edit_changed(self, entrytext):
        if self.tipe == "id":
            # print("dsssssssss")
            if self.tool_id.get_text() != entrytext:
                def on_yes():
                    self.screen._ws.klippy.gcode_script(f"CP_SETIDTOOL TOOL={self.toolsindex} ID={entrytext}")
                    dialog.destroy()
                def on_no():

                    dialog.destroy()
                    
                dialog = C2PDialog(
                    self.screen,
                    self.screen,
                    "Are you sure you want to SET This ID? If you press 'Yes' the firmware will reboot.",
                    theme_path=self.theme_path,
                    title="Warning",
                    button_names=["Yes", "No"],
                    sp_commands=[on_yes, on_no]
                )
            # self.tool_id.set_text(entrytext)
        elif self.tipe == "material":
            self.filament_label.set_text(entrytext)
            self.screen.config_file.update_sub_value(ConfigKeys.FILAMENT_NAME,self.tool_name, entrytext)

            #self.ctop_config.read_filament_name()
        elif self.tipe == "size":
            self.nozzle_value_label.set_text(str(entrytext))
            self.screen.config_file.update_sub_value(ConfigKeys.NOZZLE_SIZE,self.tool_name, entrytext)
            # self.update_nozzle_size(entrytext)
        elif self.tipe == "f_total":
            self.filament_total_value_label.set_text(str(entrytext))
            self.screen.config_file.update_sub_value(ConfigKeys.FILAMENT_TOTAL,self.tool_name, entrytext)
        elif self.tipe == "f_used":
            self.filament_used_value_label.set_text(str(entrytext))
            self.screen.config_file.update_sub_value(ConfigKeys.FILAMENT_USED,self.tool_name, entrytext)

    def on_auto_fill_clicked(self, widget):
        def on_yes():
            self.screen._ws.klippy.gcode_script(f"SET_ID_AUTO_FIND T={self.toolsindex}")
            dialog.destroy()
        def on_no():
            dialog.destroy()
            
        dialog = C2PDialog(
            self.screen,
            self.screen,
            "Are you sure you want to FIND AUTO ID?\n If you press 'Yes' the firmware will reboot.",
            theme_path=self.theme_path,
            title="Warning",
            button_names=["Yes", "No"],
            sp_commands=[on_yes, on_no]
        )

    def get_uuid_version(self, tool_index):
        try:
            response = self.screen.apiclient.send_request(
                f"printer/objects/query?mcu {self.uuidfilename[tool_index]}"
            )
            # Ensure the response contains the expected data structure
            if 'result' in response and 'status' in response['result']:
                ID = response['result']['status'][f'mcu {self.uuidfilename[tool_index]}'].get('mcu_serialport', None)
                version = response['result']['status'][f'mcu {self.uuidfilename[tool_index]}'].get('mcu_version', None)
                if version is not None:
                    match = re.match(r'^(v\d+\.\d+\.\d+-\d+)', version)
                    version = match.group(1) if match else None
                return ID,version
            else:
                print(f"Unexpected response structure: {response}")
                return None,None
        except Exception as e:
            print(f"Error fetching UUID for tool_index {tool_index}: {e}")
            return None,None

    def set_tool(self,widget):
        def on_yes():
            # Extract only the values from self.toolstate
            values_list = [tool_data["state_change"] for tool_data in self.toolstate.values()]
            # Convert to space-separated string
            values_string = " ".join(map(str, values_list))
            # Send the values to Klipper
            self.screen._ws.klippy.gcode_script(f"CP_SETTOOLS TOOLS='{values_string}'")
            dialog.destroy()
        def on_no():
            dialog.destroy()
            
        dialog = C2PDialog(
            self.screen,
            self.screen,
            "Are you sure you want to SET? If you press 'Yes' the firmware will reboot.",
            theme_path=self.theme_path,
            title="Warning",
            button_names=["Yes", "No"],
            sp_commands=[on_yes, on_no]
        )

    def filament_mm_to_g(self,length_mm, diameter_mm=1.75, density_g_cm3=1.24):
        radius = diameter_mm / 2
        volume_mm3 = math.pi * (radius ** 2) * length_mm  # in mm³
        volume_cm3 = volume_mm3 / 1000  # convert to cm³
        weight_g = volume_cm3 * density_g_cm3
        return round(weight_g, 2)