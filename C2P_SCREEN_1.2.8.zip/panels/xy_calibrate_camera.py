import math

from elements.custom_buttons import CustomButton
from library.global_manager import GlobalVariables
from elements.c2p_gtk import CtoPGtk
from elements.move_tool_changer_bottons import ToolChangerButtons
from elements.popup import PopupNotification
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
import numpy as np
import cv2
import os


class XYCalibrateCamera(GlobalVariables):
    def __init__(self, screen,refrencetool):
        super().__init__(screen)
        self.screen = screen
        references = ['Reference-T1', 'Reference-T2', 'Reference-T3', 'Reference-T4']
        self.refrencetool = references.index(refrencetool)
        self.currentrtool = 0
        self.prev_state_printer = True
        self.running = True
        self.camera_state = False
        self.img = None
        self.state = False
        self.limits = {}
        self.flg_press = False
        self.scale_zoom = 1
        self.X_circle_value = 100
        self.Y_circle_value = 100
        self.X_center_zoom = 300
        self.Y_center_zoom = 300
        self.scale_factor_event_x = 0
        self.scale_factor_event_y = 0
        self.raduse_value = 30
        self.MoveCircle = 2
        self.X_circle_value1 = 0
        self.Y_circle_value1 = 0
        self.raduse_value1 = 30
        self.rx = 0
        self.ry = 0
        self.tools = -1
        self.camera_index = 0
        self.vcap = self.initialize_camera()
        self.temp = {}
        self.progress_devices = []
        self.ctop_gtk = CtoPGtk(self.screen, self.theme_path)
        self.img_gtk = self.ctop_gtk.Image()
        frame_box = Gtk.EventBox()

        frame_box.add(self.img_gtk)
        frame_box.set_halign(Gtk.Align.CENTER)
        frame_box.connect("event", self.event)
        frame_box.connect("button-press-event", self.event_press)
        frame_box.connect("button-release-event", self.event_release)
        self.xy_camera_calibrate_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,spacing=20)
        camera_box = self.ctop_gtk.c2p_box(style="print_control_box",width=self.screen.width/1.111,height=self.screen.height/1.977)
        camera_box.set_halign(Gtk.Align.CENTER)
        control_box = self.ctop_gtk.c2p_box(style="print_control_box",width=self.screen.width/1.111,height=self.screen.height/4.266)
        control_box.set_halign(Gtk.Align.CENTER)
        control_box.set_vexpand(False)
        arrows_buttons_grid =Gtk.Grid()
        control_box.set_vexpand(False)
        arrows_buttons_grid.set_valign(Gtk.Align.CENTER)
        settings_camera_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL)

        # Slider (Gtk.Scale)

        adj_zoom = Gtk.Adjustment(value=1, lower=1, upper=10, step_increment=2, page_increment=0, page_size=0)
        self.zoom_slider = Gtk.Scale.new(
            orientation=Gtk.Orientation.VERTICAL,
            adjustment=adj_zoom)
        self.zoom_slider.connect("value-changed", self.zoom_in)
        self.zoom_slider.set_digits(0)
        # self.fan_part_slider.set_value(20)  # Set initial value
        self.zoom_slider.set_hexpand(True)
        self.zoom_slider.set_draw_value(False)
        self.zoom_slider.set_inverted(True)
        self.zoom_slider.set_valign(Gtk.Align.CENTER)
        self.zoom_slider.get_style_context().add_class("zoom_scale")
        zoom_label = self.ctop_gtk.c2p_label("Zoom","info_label")
        zoom_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL)
        zoom_box.set_valign(Gtk.Align.CENTER)
        zoom_box.add(self.zoom_slider)
        zoom_box.add(zoom_label)

        radius_value = 80
        adj_radius = Gtk.Adjustment(self.raduse_value, 12, (radius_value * 1.5), 1, 5, 0)
        self.progress_slider = Gtk.Scale.new(
            orientation=Gtk.Orientation.VERTICAL,
            adjustment=adj_radius)
        self.progress_slider.connect("event", self.updateRaduseCircle, radius_value)
        self.progress_slider.set_digits(0)
        # self.fan_part_slider.set_value(20)  # Set initial value
        self.progress_slider.set_hexpand(True)
        self.progress_slider.set_draw_value(False)
        self.progress_slider.set_inverted(True)
        self.progress_slider.set_valign(Gtk.Align.CENTER)
        self.progress_slider.get_style_context().add_class("zoom_scale")
        radius_label = self.ctop_gtk.c2p_label("Radius","info_label")
        progress_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL)
        progress_box.set_valign(Gtk.Align.CENTER)
        progress_box.add(self.progress_slider)
        progress_box.add(radius_label)

        settings_camera_button = self.ctop_gtk.Button_new(label="Save",style="internal_storage_button")
        settings_camera_button.connect("clicked", self.settings_camera)
        self.tool_changer_buttons = ToolChangerButtons(self.tool_change_handler)
        self.tool_changer_buttons.enable_button(self.screen.printer.get_active_extruders())

        # self.circle_custom_button = CustomButton(button_side="fore", width=190, height=190,
        #                                           orientation="horizontal"
        #                                           )
        self.left_custom_button = CustomButton(button_side="rectangle_button", width=110, height=60,
                                                    orientation="horizontal",svg="Left",command=[None,self.updateXLeftCircle]
                                                    ,style=self.style)
        self.right_custom_button = CustomButton(button_side="rectangle_button", width=110, height=60,
                                               orientation="horizontal",angle=math.pi,svg="Right",command=[self.updateXRightCircle]
                                               ,style=self.style)
        self.top_custom_button = CustomButton(button_side="rectangle_button", width=60, height=110,
                                                orientation="vertical", angle=math.pi/2,svg="up-camera",command=[self.updateYTopCircle]
                                              , style=self.style )
        self.bottom_custom_button = CustomButton(button_side="rectangle_button", width=60, height=110,
                                                orientation="vertical", angle=-math.pi/2,svg="down-camera",command=[None,self.updateYDownCircle]
                                                 , style=self.style )
        set_point_button = self.ctop_gtk.Button_new(label="set\npoi",style="set_point_button_camera")
        set_point_button.connect("clicked", self.reference_circle)
        self.right_custom_button.set_valign(Gtk.Align.CENTER)
        self.left_custom_button.set_valign(Gtk.Align.CENTER)
        # left_button = self.ctop_gtk.make_shadow(self.left_custom_button)
        # top_button = self.ctop_gtk.make_shadow(self.top_custom_button)
        overlay = Gtk.Overlay()



        overlay.add(arrows_buttons_grid)
        set_point_button.set_halign(Gtk.Align.CENTER)
        set_point_button.set_valign(Gtk.Align.CENTER)
        overlay.add_overlay(set_point_button)
        # self.circle_custom_button.set_valign(Gtk.Align.CENTER)
        #self.left_custom_button.set_valign(Gtk.Align.CENTER)
        settings_camera_box.add(self.tool_changer_buttons)
        settings_camera_box.add(settings_camera_button)
        # arrows_buttons_grid.attach(self.left_custom_button,0,1,2,1)
        # arrows_buttons_grid.attach(self.right_custom_button, 1, 1, 2, 1)
        #arrows_buttons_grid.attach(overlay, 1, 1, 1, 1)
        arrows_buttons_grid.attach(self.top_custom_button, 0, 0, 1, 1)
        arrows_buttons_grid.attach(self.bottom_custom_button, 0, 1, 1, 1)
        arrows_buttons_all_grid = Gtk.Grid()
        arrows_buttons_all_grid.set_valign(Gtk.Align.CENTER)
        arrows_buttons_all_grid.attach(self.left_custom_button, 0, 0, 1, 1)
        arrows_buttons_all_grid.attach(overlay, 1, 0, 1, 1)
        arrows_buttons_all_grid.attach(self.right_custom_button, 2, 0, 1, 1)
       # arrows_buttons_grid.attach(self.circle_custom_button, 1, 0, 1, 1)

        camera_box.pack_start(frame_box,True,True,0)

        control_box.add(zoom_box)
        control_box.add(arrows_buttons_all_grid)
        control_box.add(settings_camera_box)
        control_box.add(progress_box)
        
        self.xy_camera_calibrate_box.add(camera_box)
        self.xy_camera_calibrate_box.add(control_box)
        self.screen._ws.klippy.gcode_script(f"CP_PRI_INIT_CAMERA T={self.refrencetool}")

        GLib.timeout_add(200, self.show_frame)
        
        

    def initialize_camera(self):
        cap = cv2.VideoCapture(self.camera_index, cv2.CAP_V4L2)
        if not cap.isOpened():
            # print(f"Camera at index {self.camera_index} not found. Retrying...")
            cap = self.retry_camera()
        return cap
    
    def retry_camera(self):
        cap = cv2.VideoCapture(self.camera_index , cv2.CAP_V4L2)
        if cap.isOpened():
            # print(f"Camera found at index {i}")
            return cap
        # print("No available cameras found.")
        return None

    def release_camera(self):
        if self.vcap and self.vcap.isOpened():
            self.vcap.release()

    def capture_frame(self):
        if not self.vcap or not self.vcap.isOpened():
            # print("Camera is not opened. Reinitializing...")
            self.vcap = self.initialize_camera()
            if self.vcap:
                # Desired width
                desired_width = 1440
                # Calculate height based on the 16:9 aspect ratio
                desired_height = int((9 / 16) * desired_width)
                self.vcap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter.fourcc('M', 'J', 'P', 'G'))
                self.vcap.set(cv2.CAP_PROP_FRAME_WIDTH, desired_width)
                self.vcap.set(cv2.CAP_PROP_FRAME_HEIGHT, desired_height)
        if self.vcap and self.vcap.isOpened():
            ret, frame = self.vcap.read()
            if ret:
                return ret,frame
            else:
                self.vcap = None
                # print("Failed to read frame.")
        return False,''
    
    def get_content(self):
        return self.xy_camera_calibrate_box,"XY Calibrate"
    
    def tool_change_handler(self, widget, tool_number):
        homed_axes = self.screen.printer.get_stat("toolhead", "homed_axes")
        if homed_axes == "xyz":
            self.tool_changer_buttons.select_tools(5)
            self.screen._ws.klippy.gcode_script(f"CP_CAMERA_CALIBRATION T={str(tool_number)}")
        else:
            PopupNotification(
                message="Printer is not homed.",
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                timeout=5,
                tipe="E"
            )
            
    def show_frame(self, *args):
        if not self.running:
            print("Stopping show_frame...")
            return False 
        ret, self.img = self.capture_frame()
        if not ret:
            home_dir = os.path.expanduser('~')
            no_image = os.path.join(home_dir, 'C2P_SCREEN', 'no-camera.png')
            if os.path.exists(no_image):
                img = cv2.imread(no_image)
                h, w, d = img.shape
                pixbuf = GdkPixbuf.Pixbuf.new_from_data(img.tobytes(),
                                                        GdkPixbuf.Colorspace.RGB,
                                                        False, 8, w, h, w * 3,
                                                        None,
                                                        None)
                self.img_gtk.set_from_pixbuf(pixbuf)
            else:
                print("Default image not found.")
            # GLib.timeout_add(500, self.retry_camera)
            return True

        if self.X_circle_value > 720:#in here changed xy by ahmed because is vertical
            self.X_circle_value = 720
        if self.X_circle_value < 20:
            self.X_circle_value = 20
        if self.Y_circle_value < 20:
            self.Y_circle_value = 20
        if self.Y_circle_value > 1220:
            self.Y_circle_value = 1220

        img = cv2.cvtColor(self.img, cv2.COLOR_BGR2RGB)
        img = cv2.rotate(img, cv2.ROTATE_90_COUNTERCLOCKWISE)
        img = cv2.flip(img, 0)
        text = 'X: ' + str(self.Y_circle_value) + '  ' + 'Y: ' + str(self.X_circle_value)
        text1 = 'R: ' + str(self.raduse_value)

        # Convert and display:
        h, w, d = img.shape
        # print("demetion",h, w, d)
        # Find the smaller dimension (height or width) to use for cropping
        min_dimension = min(h, w)
        # Calculate the coordinates for the center crop (square)
        start_x = (w - min_dimension) // 2
        start_y = (h - min_dimension) // 2
        # Crop the image to the square
        cropped_img = img[start_y:start_y + min_dimension,
                      start_x:start_x + min_dimension]
        # print("cropped", len(cropped_img),"-",len(cropped_img[0]))
        pixbuf = GdkPixbuf.Pixbuf.new_from_data(cropped_img.tobytes(), GdkPixbuf.Colorspace.RGB, False, 8,min_dimension , min_dimension , min_dimension * 3,
                                                None,
                                                None)

        scaled_pixbuf = GdkPixbuf.Pixbuf.scale_simple(pixbuf, 600, 600,GdkPixbuf.InterpType.NEAREST)
        scaled_img = np.frombuffer(scaled_pixbuf.get_pixels(),
                                   dtype=np.uint8).reshape((600, 600, 3))
        # print("scaled",len(scaled_img))
        writable_img = np.copy(scaled_img)
        # this for event
        self.scale_factor_event_x = w / scaled_img.shape[
                                        1]  # Width scaling factor
        self.scale_factor_event_y = h / scaled_img.shape[0]
        ###
        scale_factor_x = writable_img.shape[
                             1] / w  # new width / original width
        scale_factor_y = writable_img.shape[
                             0] / h  # new height / original height

        # Adjust the circle's position and radius based on the new scale factors
        self.adjusted_X_circle_value = int(self.X_circle_value * scale_factor_x)
        self.adjusted_Y_circle_value = int(self.Y_circle_value * scale_factor_y)
        adjusted_radius = int(self.raduse_value * scale_factor_x)

        # Draw the circle on the scaled image
        cv2.circle(writable_img,
                   (self.adjusted_X_circle_value, self.adjusted_Y_circle_value),
                   adjusted_radius, (255, 0, 255), 1)
        if self.state == True:
            adjusted_X_circle_value1 = int(
                self.X_circle_value1 * scale_factor_x)
            adjusted_Y_circle_value1 = int(
                self.Y_circle_value1 * scale_factor_y)
            adjusted_radius1 = int(self.raduse_value1 * scale_factor_x)
            cv2.circle(writable_img,
                       (adjusted_X_circle_value1, adjusted_Y_circle_value1),
                       adjusted_radius1, (0, 255, 0), 1)

        writable_img = self.zoom_at(writable_img, None, 'transition')
        cv2.putText(writable_img, text, (20, 25), cv2.FONT_HERSHEY_SIMPLEX, .7,
                    (255, 0, 0), 2, cv2.LINE_AA)
        cv2.putText(writable_img, text1, (20, 1400), cv2.FONT_HERSHEY_SIMPLEX, .7,
                    (255, 0, 0), 2, cv2.LINE_AA)


        pixbuf = GdkPixbuf.Pixbuf.new_from_data(
            writable_img.tobytes(),
            GdkPixbuf.Colorspace.RGB,
            False,
            8,
            scaled_img.shape[1],
            scaled_img.shape[0],
            scaled_img.shape[1] * 3,
            None,
            None
        )
        self.img_gtk.set_from_pixbuf(pixbuf)
        return True
    
    # def retry_camera(self):
    #     if not self.vcap.isOpened():
    #         print("Retrying to open camera...")
    #         self.vcap.open(0)
    #     GLib.idle_add(self.show_frame)
    #     return False
    
    def event(self, eventbox, event):
        if self.flg_press:
            if self.scale_zoom > 1 :
                self.show_error_workjoystick()
                return
            print("Event: %s" % event)
            print(event.x, event.y)
            x = round(event.x*self.scale_factor_event_x)  # Use event.y for x-axis
            y = round(event.y*self.scale_factor_event_y)
            self.ul(x, y)

    def event_press(self,eventbox, event):
        if self.scale_zoom > 1 :
            self.show_error_workjoystick()
            return
        self.flg_press = True
        print("Button Press Event: %s" % event)
        print(event.x, event.y)

        x = round(event.x*self.scale_factor_event_x)  # Use event.y for x-axis
        y = round(event.y*self.scale_factor_event_y)

        self.ul(x, y)

    def event_release(self, eventbox, event):
        if self.scale_zoom > 1 :
            self.show_error_workjoystick()
            return
        self.flg_press = False
        print("Button Release Event: %s" % event)
    
    def ul(self,x,y):
        self.updateXCircle(x)
        self.updateYCircle(y)

    def updateXCircle(self, value):
        self.X_circle_value = value
        # print("xx", self.X_circle_value)

    def updateYCircle(self, value):
        self.Y_circle_value = value
        # print("yy", self.Y_circle_value)

    def updateRaduseCircle(self, widget, event, value):
        self.raduse_value = int(self.progress_slider.get_value())

    def updateXRightCircle(self):
        self.X_circle_value = self.X_circle_value + self.MoveCircle

    def updateYDownCircle(self):
        self.Y_circle_value = self.Y_circle_value + self.MoveCircle
        print("bbb", self.Y_circle_value)

    def updateXLeftCircle(self):
        self.X_circle_value = self.X_circle_value - self.MoveCircle

    def updateYTopCircle(self):
        self.Y_circle_value = self.Y_circle_value - self.MoveCircle

    def reference_circle(self, widget):
        if self.currentrtool != self.refrencetool:
            PopupNotification(
                message="Only the reference tool can be used as the set point for calibration",
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                timeout=2,
                tipe="w"
            )
            return
        cv2.imwrite("calibrate.png", self.img)
        self.state = True
        self.rx = self.X_circle_value
        self.ry = self.Y_circle_value
        self.X_circle_value1 = self.rx
        self.Y_circle_value1 = self.ry
        self.raduse_value1 = self.raduse_value
        print("Referance ok", self.rx, "  ", self.ry)

    def move_z(self, widget):
        self.screen._ws.klippy.gcode_script(f"CP_Z_MOVE_CAMERA_CALIBRATION")

    def home_xy(self, widget):
        self.screen._ws.klippy.gcode_script(f"G28 x y")

    def save_values(self, widget):
        if self.currentrtool == self.refrencetool:
            PopupNotification(
                message="You cannot save the reference value directly; it must be compared with another tool",
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                timeout=3,
                tipe="w"
            )
            return
        if self.rx != self.X_circle_value and self.rx != 0:
            self.vx = ((self.X_circle_value - self.rx) * -2.79) / 1000  # 2.57  #4.92 #5.63
            self.vy = ((self.Y_circle_value - self.ry) * -2.79) / 1000
            vstr = f"CP_XY_SAVE_CAMERA_CALIBRATION " + "T=" + str(self.currentrtool) + " X=" + str(self.vy) + " Y=" + str(self.vx)  # in here changed xy by ahmed because is vertical
            self.screen._ws.klippy.gcode_script(vstr)
        else:
            PopupNotification(
                message="Please select the reference tool first, and then calibrate the other tools relative to it",
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                timeout=3,
                tipe="w"
            )
            return
            # self.screen.show_popup_message('Please select the reference tool', 'E', 5)  # adde by ahmed
    
    def zoom_at(self, image, coord=None, zoom_type=None):
        # Zoom logic
        zoom = self.scale_zoom
        # If coordinates for the zoom center are not specified, default to the image center
        # if coord is None:
        cy, cx = self.Y_center_zoom, self.X_center_zoom
        # else:
        #     cx, cy = coord

        h, w = image.shape[:2]

        # Translation matrix (3x3) to move the zoom point to the center
        translate_to_center = np.array([[1, 0, w / 2 - cx],
                                        [0, 1, h / 2 - cy],
                                        [0, 0, 1]], dtype=np.float32)

        # Zoom matrix (3x3) with scaling centered at the image center
        zoom_matrix = np.array([[zoom, 0, (1 - zoom) * w / 2],
                                [0, zoom, (1 - zoom) * h / 2],
                                [0, 0, 1]], dtype=np.float32)

        # # Combine the translation and zoom matrices
        transform_matrix = np.dot(zoom_matrix, translate_to_center)

        # Apply the transformation using warpAffine (only the first 2 rows of the 3x3 matrix are needed for warpAffine)
        result = cv2.warpAffine(image, transform_matrix[:2], (w, h),
                                flags=cv2.INTER_LINEAR)


        return result
        # else:
        #     return image
    
    def zoom_in(self, widget):
        value = widget.get_value()
        self.scale_zoom = value
      #  if self.camera_state == False:

        if value==1:
            self.Y_center_zoom = 300
            self.X_center_zoom = 300
        else:
            self.X_center_zoom = self.adjusted_X_circle_value
            self.Y_center_zoom = self.adjusted_Y_circle_value

       # self.camera_state = True
        # else:
        #
        #     # self.scale_zoom = 100
        #     self.camera_state = False

    def back(self):
        self.release_camera()
        return False
    
    def show_error_workjoystick(self):
        PopupNotification(
                message="When in zoom mode, only the joystick works",
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                timeout=2,
                tipe="w"
            )
        
    def process_update(self, action, data):
        if action == "notify_error":
            # self.active_move_buttons()
            return
        elif action == "notify_busy":
            self.handle_state(data)
            return

    def handle_state(self, state):
        if self.prev_state_printer == state :
            return
        self.prev_state_printer = state
        if not state:
            extruder = self.screen.printer.get_stat("toolhead", "extruder")
            for index, device in enumerate(self.screen.printer.get_active_extruders()):
                if device == extruder:
                    self.currentrtool = index
                    self.tool_changer_buttons.select_tools(index)
                    break

    def settings_camera(self, widget):
        self.save_values(widget)

    def on_close(self):
        print("Closing XYCalibrateCamera panel...")
        self.running = False
        self.release_camera()