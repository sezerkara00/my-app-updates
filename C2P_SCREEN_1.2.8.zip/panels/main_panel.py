from elements.progress_circle import ProgressCircle
from library.c2p_config import C2PConfig, ConfigKeys
# from library.c2p_files_manager import c2p_config
from library.global_manager import GlobalVariables
from elements.c2p_gtk import CtoPGtk
from elements.popup import PopupNotification
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
from panels.internal_storage_panel import InternalStorage_panel_main
from panels.printing_main_panel import Printing_panel

class Main_panel(GlobalVariables):

    def __init__(self,screen,panel):
        super().__init__(screen)
        self.screen = screen
        self.panel = panel
        self.temp = {}
        self.mainp =None
        self.devices = {}
        self.progress_devices = {}
        self.file_name = None
        self.file_image = None
        self.img_width = 50
        self.img_height = 50
        self.ctop_gtk = CtoPGtk(screen, self.theme_path)
        # self.ctop_config = C2PConfig(screen)
        # self.old_printfile = OldPrintfile()
        # self.dict_file_old = self.old_printfile._GetPintInfo(1)


        self.main_content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                spacing=15)
        self.main_box.get_style_context().add_class("main_box")
        self.main_box.set_size_request(200, self.screen.height/1.28)
        self.grid = Gtk.Grid()
        self.grid.set_column_spacing(20)


        self.grid_right = Gtk.Grid()
        self.grid_right.get_style_context().add_class("grid_right")

        self.grid_left = Gtk.Grid()

        self.grid_left.get_style_context().add_class("grid_left")
        self.grid.set_halign(Gtk.Align.CENTER)

        # self.grid.set_column_homogeneous(True)  # Equal width for all columns
        # self.grid.set_row_homogeneous(True)  # Equal height for all rows

        self.grid_right.set_row_spacing(20)  # Space between rows
        self.grid_left.set_row_spacing(20)  # Space between rows
        file_box = self.ctop_gtk.c2p_box("file_box",self.screen.width/1.11, self.screen.height/2.81,  orientation= Gtk.Orientation.VERTICAL)
        file_box.set_valign(Gtk.Align.CENTER)
        file_box.set_halign(Gtk.Align.CENTER)
        pixbuf1 = self.ctop_gtk.Image("picture", 100, 100)
        self.image_box = self.ctop_gtk.c2p_box(style="image_box",width=self.screen.width/1.33, height=self.screen.height/5.99

                                               )
        event_box = Gtk.EventBox()
        event_box.set_size_request(width=self.screen.width / 1.33, height=self.screen.height / 5)
        event_box.add(self.image_box)
        event_box.connect("button-press-event", self.browse_files)
        self.image_box.set_valign(Gtk.Align.CENTER)
        self.image_box.set_halign(Gtk.Align.CENTER)

        self.image_box.pack_start(pixbuf1, True, True, 0)
        # print_label = self.ctop_gtk.c2p_label("Print", "print_label")
        # print_label.set_halign(Gtk.Align.START)
        label_box = self.ctop_gtk.c2p_box("text_box", self.screen.width/1.86, 4,
                                          Gtk.Orientation.VERTICAL)
       # label_box.add(print_label)
        browse_box = self.ctop_gtk.c2p_box(width=self.screen.width/1.86, height=50)
       # browse_box.set_halign(Gtk.Align.CENTER)
        select_label = self.ctop_gtk.c2p_label("Please select your file.",
                                               "print_label")
        browse_button = self.ctop_gtk.Button_new(label="Browse",
                                                 style="browse_button",scale=1.6)
        browse_button.connect("clicked", self.browse_files)
        browse_button.set_halign(Gtk.Align.END)
        browse_box.add(select_label)
        browse_box.pack_start(browse_button,True,True,0)
        self.button_print = self.ctop_gtk.Button(image_name="print",label="Print",
                                                 style="file_buttons",scale=.7,position=Gtk.PositionType.LEFT)
        # self.button_info = self.ctop_gtk.Button(image_name="info",label="Info",
        #                                         style="file_buttons",scale=.7,position=Gtk.PositionType.LEFT)
        self.button_layers = self.ctop_gtk.Button(image_name="layer",label="Layers",
                                                  style="file_buttons",scale=.7,position=Gtk.PositionType.LEFT)

        self.button_print.connect("clicked",self.start_print)


        file_buttons = self.ctop_gtk.c2p_box(width=self.screen.width/1.86, height=33,spacing=40)
        file_buttons.set_halign(Gtk.Align.CENTER)
        file_buttons.add(self.button_print)
        # file_buttons.add(self.button_info)
        file_buttons.add(self.button_layers)
        file_buttons.set_valign(Gtk.Align.CENTER)
        file_box.add(browse_box)
        file_box.add(label_box)
        file_box.add(event_box)
        file_box.add(file_buttons)
        self.screen.config_file.read_c2p_config()
        # ctop_config.read_filament_name()
        self.show_temp_circles()
        #GLib.timeout_add_seconds(1, self.show_last_printed_file)
        self.main_content_box.add(self.grid)
        self.main_content_box.add(file_box)
        self.main_box.add(self.main_content_box)
        self.main_box.show_all()

    def get_content(self):
        return self.main_content_box,"Main Panel"
    def reload_values(self, mainwindows):  # for updating values
        self.mainp = mainwindows.files
    def browse_files(self,widget,event=None):
        self.screen.base_panel.pressed_button = 'internal_storage'
        self.refresh_content(InternalStorage_panel_main(self.screen, self))
        #self.show_last_printed_file()
        # self.print_panel=Print_panel()
        # image=self.print_panel.get_image()
    def show_temp_circles(self):
        for child in self.grid.get_children():
            self.grid.remove(child)

        self.progress_circle1 = ProgressCircle(self.screen,
            label="01",
            progress=0,

            current_temp=0,
            filament_type=self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,"extruder"),
             side="left",style=self.style,active=False,filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder")),nozzle=self.screen.config_file.get_value(ConfigKeys.NOZZLE_SIZE,"extruder"))
        self.progress_circle2 = ProgressCircle(self.screen,
            label="02",
            progress=0,

            current_temp=0,
            filament_type=self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,"extruder1"),style=self.style,active=False,filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder1")),nozzle=self.screen.config_file.get_value(ConfigKeys.NOZZLE_SIZE,"extruder1"))
        self.progress_circle3 = ProgressCircle(self.screen,
            label="03",
            progress=0,

            current_temp=0,
            filament_type=self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,"extruder2"),side="left",style=self.style,filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder2")),nozzle=self.screen.config_file.get_value(ConfigKeys.NOZZLE_SIZE,"extruder2"))
        self.progress_circle4 = ProgressCircle(self.screen,
            label="04",
            progress=0,

            current_temp=0,
            filament_type=self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,"extruder3"),style=self.style,active=False,filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder3")),nozzle=self.screen.config_file.get_value(ConfigKeys.NOZZLE_SIZE,"extruder3"))
        self.progress_bed = ProgressCircle(self.screen,label="Bed", progress=0,

                                           current_temp=0,side="left",style=self.style)
        self.progress_env = ProgressCircle(self.screen,label="Env", progress=0,

                                           current_temp=0,style=self.style,active=False)
        self.progress_devices = [
            self.progress_circle1,self.progress_circle2,self.progress_circle3,self.progress_circle4,self.progress_bed,self.progress_env
        ]
        self.grid_left.attach(self.progress_circle1, 0, 0, 1, 1)
        self.grid_right.attach(self.progress_circle2, 1, 0, 1, 1)
        self.grid_left.attach(self.progress_circle3, 0, 1, 1, 1)
        self.grid_right.attach(self.progress_circle4, 1, 1, 1, 1)
        self.grid_left.attach(self.progress_bed, 0, 2, 1, 1)
        self.grid_right.attach(self.progress_env, 1, 2, 1, 1)
        self.grid.attach(self.grid_left, 0, 1, 1, 1)
       # self.grid.attach(border_box, 1, 0, 1, 1)
        self.grid.attach(self.grid_right, 1, 1, 1, 1)
        self.grid.show_all()

    def update_filament_level(self):
        for dev,prog in zip(self.screen.printer.get_active_extruders(),self.progress_devices):
            if dev  is not None:
                f_used = self.screen.config_file.get_value(ConfigKeys.FILAMENT_USED, dev, default="0")
                f_total = self.screen.config_file.get_value(ConfigKeys.FILAMENT_TOTAL, dev, default="0")
                current_filament = float(f_total) - float(f_used)
                prog.update_internal_circle(current_filament/float(f_total))
    def parse_rgb_string_safe(self,rgb_string):
        try:
            r, g, b = map(float, rgb_string.split(","))
            return [r, g, b]
        except (ValueError, TypeError) as e:
            print("Invalid RGB string format:", e)
            return None

    def de_active_temp(self):
        self.progress_circle1.set_current_temp(0.0, 0)
        self.progress_circle2.set_current_temp(0.0, 0)
        self.progress_circle3.set_current_temp(0.0, 0)
        self.progress_circle4.set_current_temp(0.0,0)
        self.progress_bed.set_current_temp(0.0,0)
        self.progress_env.set_current_temp(0.0,0)

    def process_update(self, action, data):
        self.update_temp()

    def update_temp(self):
        for device,progress,switch in zip(self.screen.printer.get_active_extruders()+self.screen.printer.get_heaters(),self.progress_devices,self.screen.printer.get_switches()+self.screen.printer.get_heaters()):
            self.temp[device] = self.screen.printer.get_dev_stat(device, "temperature")
            target = self.screen.printer.get_dev_stat(device, "target")

            progress.set_target(target)
            if self.screen.printer.get_dev_stat(
                    switch, "state") == "PRESSED":  # Show tool is in park
                progress.set_park_status(True)
            elif self.screen.printer.get_dev_stat(switch, "state") == "RELEASED":
                progress.set_park_status(False)
            if device is not None and "temperature_sensor" not in device:
                if "extruder" in device:

                    progress.update_filament_color(self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,device)))
                    progress.update_filament_type(self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,device))
                    progress.update_nozzle_size(self.screen.config_file.get_value(ConfigKeys.NOZZLE_SIZE, device))
                max_temp = self.screen.printer.get_dev_stat(device,
                                                          "max_temp")
                if self.temp[device] is not None and  max_temp is not None:
                    progress.set_current_temp(self.temp[device],self.temp[device] / max_temp,max_temp, True)

    def upload_panel(self):
        return self.grid


    def show_selected_print_file(self,file_name,image=None):
        #files = list(self.dict_file_old.keys())
      #  image = self.image_load(files[0])
            self.file_name = file_name
            self.file_image = image
            for child in self.image_box.get_children():
                self.image_box.remove(child)
            info = self.mainp.get_file_info(file_name)
            time = info["estimated_time"]
            hours = time // 3600
            minutes = (time % 3600) // 60
            formatted_time = self.ctop_gtk.c2p_label(f"Time : {int(hours)}h.{int(minutes)}m", "info_label")

            extruder_temp = self.ctop_gtk.c2p_label(f'First Layer Temp : {info["first_layer_extr_temp"]}', "info_label")

            bed_temp = self.ctop_gtk.c2p_label(f'Bed Temp : {info["first_layer_bed_temp"]}', "info_label")

            filament_total = self.ctop_gtk.c2p_label(f'Filament : {info["filament_total"]}', "info_label")

            layers_count = self.ctop_gtk.c2p_label(f'Layers : {info["object_height"] / info["layer_height"]:.0f}',
                                                   "info_label")

            info_box = self.ctop_gtk.c2p_box(spacing=15, orientation=Gtk.Orientation.VERTICAL)
            info_box.set_valign(Gtk.Align.CENTER)

            info_box.add(formatted_time)
            info_box.add(extruder_temp)
            info_box.add(bed_temp)
            info_box.add(filament_total)
            info_box.add(layers_count)
            for child in info_box.get_children():
                child.set_halign(Gtk.Align.START)

            file_image = Gtk.Image.new_from_pixbuf(image)
            self.image_box.pack_start(file_image, True, True, 0)
            self.image_box.pack_start(info_box, True, True, 0)

            self.image_box.show_all()
    def start_print(self, widget):
        if self.file_name is None:
            PopupNotification(
                message="Please Select File.",
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                timeout=5,
                tipe="E"
            )
            return
        if self.screen.printer.evaluate_state()[0] == 'ready':
            self.screen._ws.klippy.print_start(self.file_name)
            self.refresh_content(Printing_panel(self.screen,self.file_name, self),printing_panel=True)

    def update_temp_circle(self):
        for prog in self.progress_devices:
            prog.update_progress_motion()