from library.notification_logger import NotificationLogger
from panels.calibrate_menu import CalibrateMenu
from panels.main_panel import Main_panel
from panels.move_panel import  Move_panel
from panels.power_panel import PowerPanel
from panels.settings_panel import SettingsMenu
from panels.temperature_panel import  Temp_panel
from panels.printing_main_panel import Printing_panel
from elements.c2p_dialog import C2PDialog
from elements.circular_hole import Make_Hole
from panels.notifaction_logger_dialog_panel import ShowLogNotificationDialog
from library.ethernet_manager import WifiManager, LANManager
from library.global_manager import GlobalVariables
from elements.c2p_gtk import CtoPGtk
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
from panels.datetime_picker_panel import DateTime_Picker_Panel
from library.datetime_picker import DateTimePicker
from panels.internal_storage_panel import InternalStorage_panel_main
from panels.screen_setting_panel import ScreenSettingsPanel
from panels.network_panel import NetWorkPanel
import pytz
from datetime import datetime
from library.c2p_config import C2PConfig, ConfigKeys
import os
import time
import subprocess
from library.c2p_config import ConfigKeys
# Step:1 class Base_panel(GlobalVariables)
class Base_panel(GlobalVariables):
    def __init__(self,screen):
        super().__init__(screen)
        self.error_dialog = C2PDialog
        self.screen = screen
        self.pressed_button = 'main'
        self.printing_panel = None
        self.ctop_gtk = CtoPGtk(screen,self.theme_path)
        self.wifi = WifiManager
        self.c2p_print_tools = None
        self.lan = LANManager
        self.main_panel_active = True
        self.circular_hole = Make_Hole(self.style)
        self.menu_buttons = {}
        self.wifi_state =False
        self.usb_state = False
        self.lan_state=False
        self.log_count= 0
        self.config = C2PConfig(screen)
        self.config.read_c2p_config()
        self.lock_button = self.ctop_gtk.Button("lock", style="lock", scale=.9)
        self.lock_button.connect("clicked", self.lock_screen,
                                 self.menu_buttons.values())
        self.lock_button.set_halign(Gtk.Align.CENTER)
        self.main_panel = Main_panel(screen, self)
        self.menu_buttons_images =[
            "move",  "temperature","power","main", "calibrate","settings",  "power"
        ]
        self.base_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                spacing=18)

        self.base_box.set_vexpand(False)
        self.base_box.get_style_context().add_class("main_box")

        config = C2PConfig(screen)
        self.current_timezone = DateTimePicker(config).get_current_timezone()

        bottom_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL,height=100,
                             spacing=0)

        # bottom_box.set_size_request(800,
        #               40)
        bottom_box.set_valign(Gtk.Align.END)
        #bottom_box.set_valign(Gtk.Align.END)

        bottom_box.get_style_context().add_class("bottom_box")

        bottom_box_l = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL,width=screen.width,height=140,
                             spacing=20)

        overlay = Gtk.Overlay()

        drawing_area = self.circular_hole
        drawing_area.set_valign(Gtk.Align.END)
        drawing_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,width=screen.width,height=140,
                             spacing=0)
        drawing_box.set_vexpand(False)
        drawing_box.set_valign(Gtk.Align.END)
        drawing_box.pack_start(drawing_area,True,True,0)
        overlay.add(drawing_box)
       # overlay.add(bottom_box)

      #  bottom_box_l.set_valign(Gtk.Align.END)
       # bottom_box_l.set_vexpand(False)

       # bottom_box_l.get_style_context().add_class("bottom_box_l")


        #bottom_box_l.set_valign(Gtk.Align.END)
        # Create buttons for the bottom box
        scale = 1.6
        self.menu_buttons["move"] = self.ctop_gtk.Button("move", style="bottom",scale=scale)
        #button_move = Gtk.Fixed()
        # button_move.put(self.menu_buttons["move"], 100, 100)

        self.menu_buttons["temp"] = self.ctop_gtk.Button("temperature", style="bottom",scale=scale)
        # button_temp = Gtk.Fixed()
        # button_temp.put(self.menu_buttons["temp"], 100, 100)
        self.menu_buttons["power"] = self.ctop_gtk.Button("power", style="bottom",scale=scale)
        # button_power = Gtk.Fixed()
        # button_power.put(self.menu_buttons["power"], 100, 100)

        self.menu_buttons["main"] = self.ctop_gtk.Button("main-active",
                                                            style="bottom",
                                                            scale=scale)
        # button_main = Gtk.Fixed()
        # button_main.put(self.menu_buttons["main"], 100, 100)

        self.menu_buttons["main"].get_style_context().add_class(
        "bottom_pressed")#added for make home button active when start


        self.menu_buttons["calibrate"] = self.ctop_gtk.Button("calibrate", style="bottom",scale=scale)
        # calibrate = Gtk.Fixed()
        # calibrate.put(self.menu_buttons["calibrate"], 100, 100)
        self.menu_buttons["settings"] = self.ctop_gtk.Button("settings", style="bottom",scale=scale)
        # settings = Gtk.Fixed()
        # settings.put(self.menu_buttons["settings"], 100, 100)
        self.menu_buttons["power"] = self.ctop_gtk.Button("power", style="bottom",scale=scale)
        # button_power= Gtk.Fixed()
        # button_power.put(self.menu_buttons["power"], 100, 100)
        back_button = self.ctop_gtk.Button("back",style="bottom",scale=scale)

        self.menu_buttons["move"].connect("clicked",self.move_pressed, self.menu_buttons["move"])

        self.menu_buttons["temp"].connect("clicked", self.temp_pressed,self.menu_buttons["temp"])
        self.menu_buttons["power"].connect("clicked", self.power_pressed, self.menu_buttons["power"])
        self.menu_buttons["calibrate"].connect("clicked", self.calibrate_pressed,self.menu_buttons["calibrate"])
        self.menu_buttons["main"].connect("clicked", self.main_pressed,self.menu_buttons["main"])


        self.menu_buttons["settings"].connect("clicked", self.settings_pressed,self.menu_buttons["settings"])

        for button in self.menu_buttons.values():
            button.set_valign(Gtk.Align.END)
        back_button.connect("clicked", self.back_panel)
        #overlay.add_overlay(drawing_area)
        bottom_box.pack_start(back_button, False,
                              False, 0)
        bottom_box.pack_start(self.menu_buttons["move"], False, False, 0)
        bottom_box.pack_start(self.menu_buttons["temp"], False, False, 0)
        bottom_box.pack_start(self.menu_buttons["main"], False, False, 0)

        #bottom_box.set_halign(Gtk.Align.CENTER)
        #bottom_box.set_valign(Gtk.Align.CENTER)

        bottom_box.pack_start(self.menu_buttons["calibrate"], False,
                              False,
                              0)

        bottom_box.pack_start(self.menu_buttons["settings"], False, False,
                              0)
        bottom_box.pack_start(self.menu_buttons["power"], False, False,
                              0)


      #  bottom_box.set_vexpand(False)

        overlay.add_overlay(bottom_box)
        #overlay.set_valign(Gtk.Align.END)

        back_button.set_halign(Gtk.Align.START)
        back_button.set_valign(Gtk.Align.END)
        #bottom_box_l.pack_start(bottom_box, False, True, 0)



        bottom_box_l.add(overlay)

       # overlay.add_overlay(bottom_box





        self.clock_label = Gtk.Label(label="")

        self.clock_event_box = self.ctop_gtk.Button_new(style='time_button')
        self.clock_event_box.add(self.clock_label)
        self.clock_event_box.connect("clicked", self.show_datetime_picker)


        self.header_bar,self.left_header,self.title_label = self.ctop_gtk.header_bar(title="Main Panel", clock_label=self.clock_event_box,
                                                                                     callback_notification=self.show_notification_logger,
                                                                                     callback_usb=self.handle_usb_click,callback_wifi=self.handle_wifi_click,callback_network=self.handle_lan_click)
        GLib.timeout_add_seconds(1, self.update_header)
        self.base_box.add(self.header_bar)
      #  self.base_box.add(self.lock_button)
        self.base_box.add(self.main_panel.main_box)
        self.base_box.add(bottom_box_l)
        self.set_screen_blanking("not_changed")
        self.screen.panels_back.append(self.main_panel)
        GLib.timeout_add_seconds(1, self.show_panel)
    # def lock_screen(self,widget):
    #     if self.lock_state:
    #         for button in self.menu_buttons:
    #             self.menu_buttons[button].set_sensitive(False)
    #         self.lock_state = False
    #     elif not self.lock_state:
    #         for button in self.menu_buttons:
    #               self.menu_buttons[button].set_sensitive(True)
    #         self.lock_state = True

    # Step:
    def update_title(self,title):
        self.title_label.set_label(title)
    def move_pressed(self, widget,button_pressed):# Step:
        if self.pressed_button == 'move':
            return
        for button, image in zip(self.menu_buttons,self.menu_buttons_images):
            if "move" in button:
                self.pressed_button = 'move'
                self.circular_hole.on_button_clicked(widget,button_pressed)
                self.refresh_content(Move_panel(self.screen, self))
                self.menu_buttons[button].get_style_context().add_class(
                    "bottom_pressed")
              #  self.menu_buttons[button].set_image()
            else:
                self.menu_buttons[button].get_style_context().remove_class(
                    "bottom_pressed")
            if self.style == "light":
                if "move" in image:
                    self.menu_buttons[button].set_image(self.ctop_gtk.Image("move-active",50,50))
                else:
                    self.menu_buttons[button].set_image(self.ctop_gtk.Image(image,50,50))
    def temp_pressed(self, widget,button_pressed):# Step:
        if self.pressed_button == 'temp':
            return
        for button, image in zip(self.menu_buttons,self.menu_buttons_images):
            if "temp" in button:
                self.pressed_button = 'temp'
                self.circular_hole.on_button_clicked(widget, button_pressed)
                self.refresh_content(Temp_panel(screen=self.screen))
                self.menu_buttons[button].get_style_context().add_class(
                    "bottom_pressed")
            else:
                self.menu_buttons[button].get_style_context().remove_class(
                    "bottom_pressed")
            if self.style == "light":
                if "temperature" in image:
                     self.menu_buttons[button].set_image(self.ctop_gtk.Image("temperature-active",50,50))
                else:
                     self.menu_buttons[button].set_image(self.ctop_gtk.Image(image,50,50))
    def power_pressed(self, widget,button_pressed):# Step:
        for button, image in zip(self.menu_buttons,self.menu_buttons_images):

            if "power" in button:
               # self.circular_hole.on_button_clicked(widget, button_pressed)

                PowerPanel(self.screen,self.theme_path)
            #     self.menu_buttons[button].get_style_context().add_class(
            #         "bottom_pressed")
            # else:
            #     self.menu_buttons[button].get_style_context().remove_class(
            #         "bottom_pressed")
            # if self.style == "light":
            #      if "power" in image:
            #         self.menu_buttons[button].set_image(self.ctop_gtk.Image("power",50,50))
            #      else:
            #         self.menu_buttons[button].set_image(self.ctop_gtk.Image(image,50,50))
    def main_pressed(self, widget,button_pressed):
        self.main_panel_active = False
        if self.pressed_button == 'main' or self.pressed_button == 'print':
            return
        for button, image in zip(self.menu_buttons,self.menu_buttons_images):
            if "main" in button:

                self.circular_hole.on_button_clicked(widget, button_pressed)
                self.show_panel()
                self.menu_buttons[button].get_style_context().add_class(
                    "bottom_pressed")
                self.main_panel.update_temp_circle()
            else:
                self.menu_buttons[button].get_style_context().remove_class(
                    "bottom_pressed")
            if self.style == "light":
                if "main" in image:
                     self.menu_buttons[button].set_image(self.ctop_gtk.Image("main-active",50,50))
                else:
                     self.menu_buttons[button].set_image(self.ctop_gtk.Image(image,50,50))
    def calibrate_pressed(self, widget,button_pressed):
        if self.pressed_button == 'calibrate':
            return
        for button, image in zip(self.menu_buttons,self.menu_buttons_images):
            if "calibrate" in button:
                self.pressed_button = 'calibrate'
                self.circular_hole.on_button_clicked(widget, button_pressed)
                self.menu_buttons[button].get_style_context().add_class(
                    "bottom_pressed")
                self.refresh_content(CalibrateMenu(self.screen))
            else:
                self.menu_buttons[button].get_style_context().remove_class(
                    "bottom_pressed")
            if self.style == "light":
                if "calibrate" in image:
                    self.menu_buttons[button].set_image(self.ctop_gtk.Image("calibrate-active",50,50))
                else:
                    self.menu_buttons[button].set_image(self.ctop_gtk.Image(image,50,50))
    # def power_pressed(self, widget,button_pressed):
    #     for button, image in zip(self.menu_buttons,self.menu_buttons_images):
    #         if "power" in button:
    #             self.circular_hole.on_button_clicked(widget, button_pressed)
    #             self.menu_buttons[button].get_style_context().add_class(
    #                 "bottom_pressed")
    #         else:
    #             self.menu_buttons[button].get_style_context().remove_class(
    #                 "bottom_pressed")
            # if "power" in image:
            #     self.menu_buttons[button].set_image(self.ctop_gtk.Image("power-active",50,50))
            # else:
            #     self.menu_buttons[button].set_image(self.ctop_gtk.Image(image,50,50))
    def settings_pressed(self, widget,button_pressed):
        if self.pressed_button == 'settings':
            return
        for button, image in zip(self.menu_buttons,self.menu_buttons_images):
            if "settings" in button:
                self.pressed_button = 'settings'
                self.circular_hole.on_button_clicked(widget, button_pressed)
                self.menu_buttons[button].get_style_context().add_class(
                    "bottom_pressed")
                self.refresh_content(SettingsMenu(self.screen))
            else:
                self.menu_buttons[button].get_style_context().remove_class(
                    "bottom_pressed")
            if self.style == "light":
                if "settings" in image:
                    self.menu_buttons[button].set_image(self.ctop_gtk.Image("settings-active",50,50))
                else:
                    self.menu_buttons[button].set_image(self.ctop_gtk.Image(image,50,50))




    def update_header(self):
        #SEZER 02.04.2025
        timezone = pytz.timezone(self.current_timezone)
        current_time = datetime.now(timezone)
        time_str = current_time.strftime("%H:%M")

        self.clock_label.set_text(time_str)


        wifi_state = self.wifi.is_wifi_connected(self)
        lan_state = self.lan.is_lan_connected(self)
        if wifi_state != self.wifi_state or lan_state!=self.lan_state:
            if wifi_state:
                wifi_icon = self.ctop_gtk.Image("wifi-regular-active",25, 25)
            else:
                wifi_icon = self.ctop_gtk.Image("wifi-regular", 25, 25)

            if lan_state:
                lan_icon = self.ctop_gtk.Image("network-active",25, 25)
            else:
                lan_icon = self.ctop_gtk.Image("network", 25, 25)
            for child in self.left_header.get_children()[:2]:  # To remove only the first two widgets
                self.left_header.remove(child)
            old_children = self.left_header.get_children()
            wifi_icon_box = Gtk.EventBox()
            wifi_icon_box.add(wifi_icon)
            wifi_icon_box.connect("button-press-event", self.handle_wifi_click)

            lan_icon_box = Gtk.EventBox()
            lan_icon_box.add(lan_icon)
            lan_icon_box.connect("button-press-event", self.handle_lan_click)

            new_children = [wifi_icon_box] + [lan_icon_box] + old_children
            for child in self.left_header.get_children():
                self.left_header.remove(child)  # Remove all current widgets
            i=0
            for child in new_children:
                if i == 5:
                    self.left_header.pack_end(child, False, True, 0)
                elif i == 4:
                    self.left_header.pack_start(child, True, False, 0)
                else:
                    self.left_header.add(child)
                i += 1
            self.wifi_state = wifi_state
            self.lan_state = lan_state
            self.header_bar.show_all()

        if self.screen.usb_monitor.get_is_usb() != self.usb_state:
            self.usb_state = self.screen.usb_monitor.get_is_usb()
            self.ctop_gtk.show_usb_icon(self.usb_state)

        logger = NotificationLogger()
        if logger.get_log_count() != self.log_count:
            self.log_count = logger.get_log_count()
            self.ctop_gtk.update_notification_count(self.log_count)

        return True

    def show_notification_logger(self, widget, event):
        logger = NotificationLogger()
        dialog = ShowLogNotificationDialog(self.screen, self.theme_path, logger.get_logs())

        
        return True

    def show_datetime_picker(self, widget):
        #SEZER 28.03.2025
        # TODO: Add a check to see if the datetime picker is already open
        DateTime_Picker_Panel(self.screen, self.theme_path)
        self.update_header()




    # def get_date_time(self):
    #     clock_time = self.clock_label.get_text()
    #     date_time = self.date_time_label.get_text()
    #     return clock_time, date_time

    def back_panel(self,widget):
        self.pressed_button = "back"
        if self.screen.panels_back != []:
            long = len(self.screen.panels_back)
            panel = self.screen.panels_back[long-2]
            print("long",self.screen.panels_back)
            self.refresh_content(panel,True)
            for button, image in zip(self.menu_buttons, self.menu_buttons_images):
                if  button in str(panel) :
                    self.circular_hole.on_button_clicked(widget, self.menu_buttons[button])
                    self.menu_buttons[button].get_style_context().add_class(
                        "bottom_pressed")
                    if self.style == "light":
                        self.menu_buttons[button].set_image(self.ctop_gtk.Image(image+"-active", 50, 50))



                else:
                    self.menu_buttons[button].get_style_context().remove_class(
                        "bottom_pressed")
                    if self.style == "light":
                        self.menu_buttons[button].set_image(self.ctop_gtk.Image(image, 50, 50))
                # if self.style == "light":
                #     if button in str(panel):
                #         self.menu_buttons[button].set_image(self.ctop_gtk.Image(image, 50, 50))
                #         self.menu_buttons[button].get_style_context().add_class("bottom_pressed")
                #     else:
                #         self.menu_buttons[button].set_image(self.ctop_gtk.Image(image+"-active", 50, 50))



    def get_tools_print(self):
        variables_stb = self.screen.apiclient.send_request(
            "printer/objects/query?c2p_save_variables")
        c2p_save_variables = variables_stb['result']['status']
        self.c2p_print_tools = c2p_save_variables['c2p_save_variables']['variables']
        return False
    def change_style(self,widget):
        with open(self.style_config_path, 'w') as file:
            # Write new content to the file
            if self.style == "light":
                file.write("dark")
            elif self.style == "dark":
                file.write("light")
        self.restart_service("C2P_SCREEN")

    def show_panel(self):
        # print("1")
        if self.screen.printer is None :
            return True

        if self.screen.printer.evaluate_state()[0] == 'printing' or self.screen.printer.evaluate_state()[0] == "paused":
            filename = self.screen.printer.get_stat('print_stats', 'filename')
            if self.screen.files.get_file_info(filename) is None:
                return True
            if 'estimated_time' not in self.screen.files.get_file_info(filename):
                return True
            if self.pressed_button == 'internal_storage' or self.pressed_button == "main":
                self.screen.panels_back = []
            self.buttons_panel_change(False)
            self.pressed_button = 'print'
            self.get_tools_print()
            self.printing_panel = Printing_panel(self.screen, filename, self,self.c2p_print_tools)
            self.refresh_content(self.printing_panel)
        if self.screen.printer.evaluate_state()[0] == "ready" and not self.main_panel_active:
            if self.printing_panel in self.screen.panels_back:
                self.screen.panels_back = []
            self.buttons_panel_change(True)
            self.pressed_button = 'main'
            self.main_panel.update_filament_level()
            self.update_title("Main Panel")
            self.refresh_content(self.main_panel)
        else:
            self.main_panel.update_filament_level()
        return False
    
    def buttons_panel_change(self,state):
        self.menu_buttons["move"].set_sensitive(state)
        self.menu_buttons["calibrate"].set_sensitive(state)

    def process_update(self, action, data):
        if "webhooks" in data:
            if data['webhooks']['Emergency'] == "True":
                print("emergency")
            else:
                print("no")

    def handle_usb_click(self,widget,event):
        """Handle clicks on the USB icon"""
        # Add your USB click handling logic here
        print("usb click")
        self.screen.base_panel.pressed_button = 'sub'
        self.refresh_content(InternalStorage_panel_main(self.screen,self,"usb_storage"))
        # Example: Show USB options dialog, toggle USB state, etc.

    def handle_wifi_click(self,widget,event):
        print("wifi click")
        self.screen.base_panel.pressed_button = 'sub'
        self.refresh_content(NetWorkPanel(self.screen))

    def handle_lan_click(self,widget,event):
        print("lan click")
        self.screen.base_panel.pressed_button = 'sub'
        self.refresh_content(NetWorkPanel(self.screen))


    def blanking_mode_value(self):
        blanking_mode = self.config.get_value(ConfigKeys.BLANK_TIME)
        is_dpms = self.config.get_value(ConfigKeys.DPMS)
        if blanking_mode == "None":
            subprocess.run(["xset", "s", is_dpms])
            subprocess.run(["xset", "-dpms"])
        else:
            blanking_mode = blanking_mode.split(" ")[0]
            blanking_mode = int(blanking_mode)*60
            blanking_mode = str(blanking_mode)
            subprocess.run(["xset", "s", is_dpms])
            subprocess.run(["xset", "+dpms"])
            subprocess.run(["xset", "dpms", blanking_mode, blanking_mode, blanking_mode])





