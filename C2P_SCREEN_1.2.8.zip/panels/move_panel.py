from library.global_manager import GlobalVariables
from library.c2p_gcodes import CtoPGcodes
from elements.c2p_gtk import CtoPGtk
from elements.keypad import Keypad
from elements.custom_buttons import CustomButton
from elements.move_tool_changer_bottons import ToolChangerButtons
# from library.signal_manager import signal_router
from elements.c2p_dialog import C2PDialog
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
from elements.popup import PopupNotification
import threading


class Move_panel(GlobalVariables):

    def __init__(self, screen, panel):
        super().__init__(screen)
        self.screen = screen
        self.panel = panel
        self.logger = self.logger_setup.get_logger("Move_panel")
        self.logger.info("Move_panel initialized.")  # Initialization log
        self.distance = 10
        self.prev_state = False
        # signal_router.register("move_action", self.handle_move)
        ctop_gtk = CtoPGtk(screen, self.theme_path)
        self.button_ids = {}
        self.move_buttons = {"distance": {}, "move": {}}
        self.move_main_box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=25)
        self.move_top_box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=5,
                                             width=self.screen.width / 1.11, height=self.screen.height / 1.686)
        self.move_top_box.set_halign(Gtk.Align.CENTER)
        self.move_top_box.get_style_context().add_class("move_top_box")
        move_bottom_box = ctop_gtk.c2p_box(spacing=5, width=self.screen.width / 1.11, height=self.screen.height / 5.51)
        move_bottom_box.set_halign(Gtk.Align.CENTER)
        move_bottom_box.get_style_context().add_class("move_bottom_box")
        location_box = ctop_gtk.c2p_box(spacing=10)
        steps_grid = Gtk.Grid()
        move_grid_xy = Gtk.Grid()
        move_grid_xy.get_style_context().add_class("move_grid_xy")
        move_box_z = ctop_gtk.c2p_box(style="move_box_z", orientation=Gtk.Orientation.VERTICAL,
                                      spacing=5)  # ,width=self.screen.width/5.714,  height=self.screen.height/2.56)
        home_box = ctop_gtk.c2p_box(spacing=100)
        line_box = ctop_gtk.c2p_box("text_box", self.screen.width / 1.86,
                                    4,
                                    Gtk.Orientation.VERTICAL)
        move_label = ctop_gtk.c2p_label("Move Distance (mm)", "print_label")
        move_label.set_halign(Gtk.Align.START)

        dis_button_labels = ["0.1", "0.5", "1", "10", "25", "50", "100", "..."]

        for button_label in dis_button_labels:
            self.move_buttons["distance"][button_label] = ctop_gtk.Button_new(
                label=button_label, style="steps_button"
            )
            # Store the button with its identifier in the dictionary
            self.button_ids[self.move_buttons["distance"][button_label]] = button_label
            self.move_buttons["distance"][button_label].connect("clicked", self.change_distance, button_label,
                                                                self.move_buttons["distance"][button_label])
        self.x_plus_button = CustomButton("+Y", "right", 203, 104, orientation="horizontal",
                                          command=[self.home_x, lambda: self.move(None, "Y", "+"), self.home_x],style=self.style)
        self.move_buttons["move"]["+Y"] = ctop_gtk.make_shadow(self.x_plus_button)
        self.move_buttons["move"]["-Y"] = ctop_gtk.Button_new(label="-Y", style="move_button_x")
        self.y_plus_button = CustomButton("-X", "top", 104, 203, orientation="vertical",
                                          command=[self.home_y, lambda: self.move(None, "X", "-")],style=self.style)
        self.move_buttons["move"]["-X"] = ctop_gtk.make_shadow(self.y_plus_button)
        self.move_buttons["move"]["+X"] = ctop_gtk.Button_new(label="+X", style="move_button_y")
        self.z_plus_button = CustomButton(["+Z",None,"-Z"], "bottom", 104, 306, orientation="bottom",
                                          command=[lambda: self.move(None, "Z", "+"), lambda: self.move(None, "Z", "-"),
                                                   self.home_z],svg=[None,"main",None],style=self.style)
        self.move_buttons["move"]["Z_buttons"] = ctop_gtk.make_shadow(self.z_plus_button)

        self.move_buttons["move"]["home_xy"] = ctop_gtk.Button_new(label="XY", style="home_button_xy")
        self.move_buttons["move"]["home_x"] = ctop_gtk.Button_new(label="X", style="home_button")
        self.move_buttons["move"]["home_y"] = ctop_gtk.Button_new(label="Y", style="home_button")

        self.move_buttons["move"]["home_all"] = ctop_gtk.Button_new(image_name="main", label="All", style="home_all",
                                                                    position=Gtk.PositionType.LEFT)

        self.move_buttons["move"]["motors_off"] = ctop_gtk.Button_new(label="Motor\n  Off", style="motor_off_button")
        self.move_buttons["move"]["motors_off"].set_valign(Gtk.Align.CENTER)
        self.move_buttons["move"]["motors_off"].set_halign(Gtk.Align.CENTER)

        self.move_buttons["move"]["tools_drop"] = ctop_gtk.Button_new(label="Tools\n Drop", style="tools_drop_button")
        self.move_buttons["move"]["tools_drop"].set_valign(Gtk.Align.CENTER)

        # self.move_buttons["+X"].connect("clicked", self.move, "X", "+")
        # self.move_buttons["-X"].connect("clicked", self.move, "X", "-")
        # self.move_buttons["-X"].connect("clicked", self.move, "Y", "+")
        # self.move_buttons["-X"].connect("clicked", self.move, "Y", "-")
        self.move_buttons["move"]["+X"].connect("clicked", self.move, "X", "+")
        self.move_buttons["move"]["-Y"].connect("clicked", self.move, "Y", "-")
        self.move_buttons["move"]["home_xy"].connect("clicked", self.home_xy)
        self.move_buttons["move"]["home_all"].connect("clicked", self.home)
        self.move_buttons["move"]["tools_drop"].connect("clicked", self.drop_tool)
        self.move_buttons["move"]["motors_off"].connect("clicked", self.motors_off)
        all_buttons = {**self.move_buttons["distance"],
                       **self.move_buttons["move"]}
        self.panel.lock_button.connect("clicked", self.lock_screen,
                                       all_buttons.values())

        steps_grid.attach(self.move_buttons["distance"]["0.1"], 0, 0, 1, 1)
        steps_grid.attach(self.move_buttons["distance"]["0.5"], 1, 0, 1, 1)
        steps_grid.attach(self.move_buttons["distance"]["1"], 2, 0, 1, 1)
        steps_grid.attach(self.move_buttons["distance"]["10"], 3, 0, 1, 1)
        steps_grid.attach(self.move_buttons["distance"]["25"], 0, 1, 1, 1)
        steps_grid.attach(self.move_buttons["distance"]["50"], 1, 1, 1, 1)
        steps_grid.attach(self.move_buttons["distance"]["100"], 2, 1, 1, 1)
        steps_grid.attach(self.move_buttons["distance"]["..."], 3, 1, 1, 1)
        steps_grid.set_halign(Gtk.Align.CENTER)
        steps_grid.set_row_spacing(15)
        steps_grid.set_column_spacing(30)

        move_grid_xy.attach(self.move_buttons["move"]["-X"], 1, 1, 1, 1)
        move_grid_xy.attach(self.move_buttons["move"]["-Y"], 0, 2, 1, 1)
        move_grid_xy.attach(self.move_buttons["move"]["home_xy"], 1, 2, 1, 1)
        move_grid_xy.attach(self.move_buttons["move"]["+Y"], 2, 2, 1, 1)
        # move_grid_xy.attach(self.move_buttons["home_y"], 3, 2, 1, 1)
        move_grid_xy.attach(self.move_buttons["move"]["+X"], 1, 3, 1, 1)
        move_grid_xy.set_row_homogeneous(False)
        move_grid_xy.set_column_homogeneous(False)

        move_box_z.add(self.move_buttons["move"]["home_all"])
        move_box_z.add(self.move_buttons["move"]["Z_buttons"])
        # move_box_z.add(CustomButton("-Z", "top", 104, 203,True))
        # move_box_z.pack_start(self.move_buttons["home_z"], False, False, 0)
        #  move_box_z.add(CustomButton("+Z","top") )

        # Define the labels and add them to the layout
        self.labels_xyz = {
            "pos_x": ctop_gtk.c2p_label("X:?", "location_label"),
            "pos_y": ctop_gtk.c2p_label("Y:?", "location_label"),
            "pos_z": ctop_gtk.c2p_label("Z:?", "location_label")
        }

        for key, label in self.labels_xyz.items():
            label.set_selectable(True)  # Make the label clickable
            label.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)  # Enable mouse click events
            label.connect("button-press-event", self.on_label_xyz_click, key)  # Connect click event to handler
            label.get_style_context().add_class("location_label")

        # Add labels to the layout
        location_box.add(self.labels_xyz["pos_x"])
        location_box.add(self.labels_xyz["pos_y"])
        location_box.add(self.labels_xyz["pos_z"])
        location_box.set_halign(Gtk.Align.CENTER)

        home_box.add(move_grid_xy)
        home_box.add(move_box_z)

        home_box.set_halign(Gtk.Align.CENTER)
        home_box.set_valign(Gtk.Align.CENTER)

        self.move_top_box.add(move_label)
        self.move_top_box.add(line_box)
        self.move_top_box.add(location_box)
        self.move_top_box.add(steps_grid)
        self.move_top_box.add(home_box)

        move_bottom_box.pack_start(self.move_buttons["move"]["motors_off"], False, False, 0)  # Start-aligned
        self.tool_changer_buttons = ToolChangerButtons(self.tool_change_handler,self.style)
        move_bottom_box.pack_start(self.tool_changer_buttons, True, True, 0)  # Center-aligned
        move_bottom_box.pack_end(self.move_buttons["move"]["tools_drop"], False, False, 0)  # End-aligned

        self.move_main_box.add(self.move_top_box)
        self.move_main_box.add(move_bottom_box)
        self.change_distance(None, 10, self.move_buttons["distance"]["10"])
        self.active_move_buttons()
        self.get_xyz_loc_async()     


    def process_update(self, action, data):
        if action == "notify_error":
            self.active_move_buttons()
            return
        elif action == "notify_busy":
            self.handle_move(data)
            return
        elif action != "notify_status_update":
            return
        self.update_labels_xyz(data)
        self.check_axis_homed()

    def handle_move(self,state):
        if state:
            self.deactive_move_buttons()
        else:
            self.active_move_buttons()
        return True
        
    def on_label_xyz_click(self, widget, event, key):
        """Handle label click event for X, Y, Z positions."""
        if event.button == Gdk.BUTTON_PRIMARY:  # Check if the click was a left click
            # Get the current text of the clicked label
            label_text = widget.get_text()
            try:
                # Extract the numeric value from the label
                text = label_text.split(":")[1].strip()
                # Ensure the extracted text is a valid number before opening Keypad
                if not self.is_number(text):
                    self.logger.error(f"Invalid value '{text}' for label {key}")
                    return
                # Open the Keypad and pass the extracted number and key
                axisxyz = self.screen.apiclient.send_request("printer/objects/query?toolhead=axis_maximum")
                keys_list = list(self.labels_xyz.keys())
                index = keys_list.index(key)
                keypad_window = Keypad(self.screen, self.theme_path, lambda value: self.handle_keypad(value, key),min_value=0,max_value=axisxyz['result']['status']['toolhead']['axis_maximum'][index])
                keypad_window.show_keypad(text=text)
            except (IndexError, ValueError) as e:
                self.logger.error(f"Error processing label '{label_text}' for {key}: {str(e)}")

    def handle_keypad(self, value, key):
        """Handle input from the Keypad and perform actions based on the axis."""
        # Perform specific actions based on the axis key
        axis_map = {"pos_x": "X", "pos_y": "Y", "pos_z": "Z"}
        axis = axis_map.get(key)
        if axis:
            self.move_with_location(axis, value)
        else:
            self.logger.error(f"Unrecognized key '{key}'")

    def set_labels_xyz_enabled(self, enabled):
        """
        Enable or disable all labels in labels_xyz.
        :param enabled: True to enable, False to disable
        """
        for label in self.labels_xyz.values():
            label.set_sensitive(enabled)

    def home(self, widget):
        self.screen._ws.klippy.gcode_script(f"G28")

    def home_xy(self, widget=None):
        self.screen._ws.klippy.gcode_script(f"G28 x y")

    def home_x(self, widget=None):
        self.screen._ws.klippy.gcode_script(f"G28 x")

    def home_y(self, widget=None):
        self.screen._ws.klippy.gcode_script(f"G28 y")

    def home_z(self, widget=None):
        self.screen._ws.klippy.gcode_script(f"G28 z")

    def deactive_move_buttons(self):
        for button in self.move_buttons["move"].values():
            button.set_sensitive(False)
        self.x_plus_button.disable_button()
        self.y_plus_button.disable_button()
        self.z_plus_button.disable_button()
        self.tool_changer_buttons.disable_button(self.screen.printer.get_active_extruders())
        self.set_labels_xyz_enabled(False)

    def active_move_buttons(self):
        for button in self.move_buttons["move"].values():
            button.set_sensitive(True)
        self.x_plus_button.enable_button()
        self.y_plus_button.enable_button()
        self.z_plus_button.enable_button()
        if self.screen.printer is not None:
            self.tool_changer_buttons.enable_button(self.screen.printer.get_active_extruders())
        self.set_labels_xyz_enabled(True)

    def check_axis_homed(self):
        try:
            if self.screen.printer is None:
                return True
            # self.tool_changer_buttons.enable_button(self.screen.printer.get_active_extruders())
            # for button in self.move_buttons["move"].values():
            #     button.set_sensitive(True)

            homed_axes = self.screen.printer.get_stat("toolhead", "homed_axes")
            if homed_axes == "xyz":
                self.move_buttons["move"]["home_all"].get_style_context().remove_class(
                    "move_button_active")
                self.move_buttons["move"]["+X"].get_style_context().add_class(
                    "move_button_active")
                self.move_buttons["move"]["-Y"].get_style_context().add_class(
                    "move_button_active")
                self.x_plus_button.change_button_color()
                self.y_plus_button.change_button_color()
                self.z_plus_button.change_button_color()

                self.x_plus_button.deactive_button("home")
                self.y_plus_button.deactive_button("home")
                self.z_plus_button.deactive_button("home")

            else:
                if "xy" in homed_axes:
                    self.move_buttons["move"]["+X"].get_style_context().add_class(
                        "move_button_active")
                    self.move_buttons["move"]["-Y"].get_style_context().add_class(
                        "move_button_active")
                    self.x_plus_button.change_button_color()
                    self.y_plus_button.change_button_color()
                if "x" in homed_axes:
                    self.x_plus_button.deactive_button("home")
                    self.x_plus_button.change_button_color()
                    self.move_buttons["move"]["+X"].get_style_context().add_class(
                        "move_button_active")
                else:
                    self.x_plus_button.change_button_color("home")
                    self.x_plus_button.deactive_button()
                    self.move_buttons["move"]["+X"].get_style_context().remove_class(
                        "move_button_active")
                if "y" in homed_axes:
                    self.y_plus_button.deactive_button("home")
                    self.y_plus_button.change_button_color()
                    self.move_buttons["move"]["-Y"].get_style_context().add_class(
                        "move_button_active")
                else:
                    self.y_plus_button.change_button_color("home")
                    self.y_plus_button.deactive_button()
                    self.move_buttons["move"]["-Y"].get_style_context().remove_class(
                        "move_button_active")
                if "z" in homed_axes:
                    self.z_plus_button.deactive_button("home")
                    self.z_plus_button.change_button_color()
                else:
                    self.z_plus_button.change_button_color("home")
                    self.z_plus_button.deactive_button()

            # self.set_labels_xyz_enabled(True)
        except Exception as e:
            self.logger.error(f"Error checking homed axes: {str(e)}")
        return False

    def update_labels_xyz(self,data):
        # Get the homed axes status from the printer
        if self.screen.printer is None :
            return
        homed_axes = self.screen.printer.get_stat("toolhead", "homed_axes")
        # Update labels for X, Y, Z axes based on their status
        for i, axis in enumerate(("x", "y", "z")):
            if axis not in homed_axes:
                # If the axis is not homed, show a placeholder "?"
                self.labels_xyz[f"pos_{axis}"].set_text(f"{axis.upper()}: ?")
            else:
                if "gcode_move" in data and "gcode_position" in data["gcode_move"]:
                    # Update the corresponding label with the current position
                    self.labels_xyz[f"pos_{axis}"].set_text(
                        f"{axis.upper()}: {data['gcode_move']['gcode_position'][i]:.2f}"
                    )
        return False
                  
    def move(self, widget, axis, direction):
        dist = f"{direction}{self.distance}"
        homed_axes = self.screen.printer.get_stat("toolhead", "homed_axes")
        if axis.lower() not in homed_axes:
                self.logger.info(f"move {homed_axes}: Printer is not homed.")
                PopupNotification(
                    message="Printer is not homed",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=5,
                    tipe="E"
                )
                return
        if axis == "Z":
            speed = 60 * max(1, 10)
        else:
            speed = 60 * max(1, 50)
        self.deactive_move_buttons()
        self.screen._ws.klippy.gcode_script(f"{CtoPGcodes.MOVE_RELATIVE}\n{CtoPGcodes.MOVE} {axis}{dist} F{speed}")
        if self.screen.printer.get_stat("gcode_move", "absolute_coordinates"):
            self.screen._ws.klippy.gcode_script("G90")

    def move_with_location(self, axis, location):
        dist = f"{location}"
        if axis == "Z":
            speed = 60 * max(1, 10)
        else:
            speed = 60 * max(1, 50)

        self.screen._ws.klippy.gcode_script(f"{CtoPGcodes.MOVE_ABSOLUTE}\n{CtoPGcodes.MOVE} {axis}{dist} F{speed}")

    def change_distance(self, widget, distance, button):
        """
        Handle click events for distance buttons and manage UI changes.
        """
        # Store the label of the clicked button
        self.current_button = button
        self.distance = distance
        # Reset the style of all buttons
        for r_button in self.move_buttons["distance"].values():
            style_context = r_button.get_style_context()
            if style_context.has_class("steps_button_pressed"):
                style_context.remove_class("steps_button_pressed")

        # Highlight the clicked button
        button.get_style_context().add_class("steps_button_pressed")
        # If the button is the "..." button, open the Keypad
        if self.button_ids.get(button, "Unknown") == "...":
            # Determine the initial text for the Keypad
            try:
                # Attempt to convert the label to a float
                initial_text = str(float(self.current_button.get_label()))
            except ValueError:
                # If conversion fails, fallback to "0"
                initial_text = "0"
            # Open the Keypad and pass the handler for updating the distance
            keypad_window = Keypad(self.screen, self.theme_path, self.handle_distance,min_value=0, max_value=100)
            keypad_window.show_keypad(text=initial_text)

    def parse_numeric_value(self, value):
        """
        Parse the given value to a float or int based on its format.
        """
        try:
            numeric_value = float(value)
            if numeric_value.is_integer():
                return int(numeric_value)
            return round(numeric_value, 2)
        except ValueError:
            self.logger.error(f"Invalid numeric value: {value}")
            return None

    def handle_distance(self, value):
        """
        Handle the value entered in the Keypad and update the clicked button's label.
        """
        numeric_value = self.parse_numeric_value(value)
        if numeric_value is None:
            return  # Exit if the value is invalid
        if hasattr(self, "current_button") and self.current_button:
            self.current_button.set_label(str(numeric_value))
            self.distance = numeric_value

    def tool_change_handler(self, widget, tool_number):
        homed_axes = self.screen.printer.get_stat("toolhead", "homed_axes")
        if homed_axes == "xyz":
            if tool_number is not None:
                self.screen._ws.klippy.gcode_script("T" + str(tool_number))
            else:
                self.logger.info("tool_change: Please select the tools first.")
                PopupNotification(
                    message="Please select the tools first",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=5,
                    tipe="E"
            )
        else:
            self.logger.info("tool_change: Printer is not homed.")
            PopupNotification(
                message="Printer is not homed",
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                timeout=5,
                tipe="E"
            )
            
    def drop_tool(self, widget):
        self.screen._ws.klippy.gcode_script("cp_tools_drope")

    def motors_off(self, widget):
        homed_axes = self.screen.printer.get_stat("toolhead", "homed_axes")
        if homed_axes == "":
            self.logger.info("motors_off: The motors are off.")
            PopupNotification(
                message="The motors are off",
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                timeout=3,
                tipe="E"
            )
        else:
            def on_yes():
                self.screen._ws.klippy.gcode_script("M18")
                print("Motors disabled.")
                dialog_connection.destroy()
            def on_no():
                dialog_connection.destroy()
                
            dialog_connection = C2PDialog(
                self.screen,
                self.screen,
                "Are you sure you want to disable the motors?",
                theme_path=self.theme_path,
                title="Warning",
                button_names=["Yes", "No"],
                sp_commands=[on_yes, on_no]
            )

    def is_number(self, value):
        """Check if the given value is a valid number."""
        try:
            float(value)  # Try to convert to float
            return True
        except ValueError:
            return False
        
    def get_content(self):
        return self.move_main_box, "Move Panel"
    
    def get_xyz_loc_async(self):
        threading.Thread(target=self.get_xyz_loc, daemon=True).start()

    def get_xyz_loc(self):
        try:
            response = self.screen.apiclient.send_request("printer/objects/query?gcode_move")
            GLib.idle_add(self.handle_get_xyz_loc, response)
        except Exception as e:
            print(f"Error fetching data: {e}")

    def handle_get_xyz_loc(self, dataxyz):
        # Get the homed axes status from the printer
        if self.screen.printer is None :
            return
        homed_axes = self.screen.printer.get_stat("toolhead", "homed_axes")
        # Update labels for X, Y, Z axes based on their status
        for i, axis in enumerate(("x", "y", "z")):
            if axis not in homed_axes:
                # If the axis is not homed, show a placeholder "?"
                self.labels_xyz[f"pos_{axis}"].set_text(f"{axis.upper()}: ?")
            else:
                # # Fetch the current position data from the printer API
                # dataxyz = self.screen.apiclient.send_request("printer/objects/query?gcode_move")
                # Check if the gcode_move and gcode_position exist in the API response
                if isinstance(dataxyz, dict):
                    if "gcode_move" in dataxyz['result']['status'] and "gcode_position" in dataxyz['result']['status'][
                        "gcode_move"]:
                        # Update the corresponding label with the current position
                        self.labels_xyz[f"pos_{axis}"].set_text(
                            f"{axis.upper()}: {dataxyz['result']['status']['gcode_move']['gcode_position'][i]:.2f}"
                        )