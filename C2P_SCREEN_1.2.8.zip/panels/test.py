import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk

class MainWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Modern On/Off Button")
        self.set_default_size(300, 200)

        # Create a Switch
        self.switch = Gtk.Switch()
        self.switch.set_active(False)
        self.switch.connect("notify::active", self.on_switch_toggled)

        # Apply custom CSS
        self.apply_custom_css()

        # Add the Switch to the Window
        self.add(self.switch)

    def on_switch_toggled(self, switch, param):
        state = "On" if switch.get_active() else "Off"
        print(f"Switch is now {state}")

    def apply_custom_css(self):
        # Define the CSS
        css = """
        .switch {
            background-color: #555555;
            border-radius: 20px;
            border: 2px solid #cccccc;
            min-width: 60px;
            min-height: 30px;
        }

        .switch:checked {
            background-color: #4caf50;
            border-color: #4caf50;
        }
        """
        # Apply the CSS
        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(css.encode("utf-8"))
        screen = Gdk.Screen.get_default()
        style_context = Gtk.StyleContext()
        style_context.add_provider_for_screen(
            screen, css_provider, Gtk.STYLE_PROVIDER_PRIORITY_USER
        )

# Run the application
if __name__ == "__main__":
    app = MainWindow()
    app.connect("destroy", Gtk.main_quit)
    app.show_all()
    Gtk.main()
