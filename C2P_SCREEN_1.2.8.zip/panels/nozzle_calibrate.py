from elements.custom_buttons import CustomButton
from library.c2p_gcodes import CtoPGcodes
from library.global_manager import GlobalVariables
from elements.c2p_gtk import CtoPGtk
from elements.popup import PopupNotification
from elements.c2p_dialog import C2PDialog
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk


class NozzleCalibrate(GlobalVariables):
    def __init__(self, screen):
        super().__init__(screen)
        self.screen = screen
        self.logger = self.logger_setup.get_logger("Nozzle_Calibrate_Panel")
        # signal_router.register("move_action", self.handle_state)
        self.logger.info("Nozzle_Calibrate_Panel initialized.")  # Initialization log
        # self.pressed_buttons = []
        # self.pressed_buttons_test = []
        self.prev_state_printer = True
        self.distance = '0.01'
        self.selected_tool = {}
        self.selected_tool['auto'] = "01"
        self.selected_tool['test'] = "01"
        self.ctop_gtk = CtoPGtk(self.screen, self.theme_path)
        self.nozzle_calibrate_main_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,spacing=25)
        top_box = self.ctop_gtk.c2p_box()
        top_box_all = self.ctop_gtk.c2p_box(style="print_control_box", width=self.screen.width / 1.111,
                                        height=self.screen.height / 4.266,orientation=Gtk.Orientation.VERTICAL)
        top_box_all.set_halign(Gtk.Align.CENTER)
        bottom_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,style="print_control_box",width=self.screen.width/1.111,height=self.screen.height/1.975)
        bottom_box.set_halign(Gtk.Align.CENTER)
        tools_box = self.ctop_gtk.c2p_box(style="image_box",width=self.screen.width/1.777,height=self.screen.height/8.533)
        tools_box.set_valign(Gtk.Align.CENTER)
        #tools_box.set_halign(Gtk.Align.CENTER)
        nozzle_control_grid = Gtk.Grid()
        nozzle_control_box = self.ctop_gtk.c2p_box(style="image_box",width=self.screen.width/1.777,height=self.screen.height/2.844,orientation=Gtk.Orientation.VERTICAL)
        nozzle_control_box.set_halign(Gtk.Align.CENTER)

        nozzle_control_box_all = self.ctop_gtk.c2p_box(spacing=20)
        nozzle_control_box_all.set_halign(Gtk.Align.CENTER)
        line_box_top = self.ctop_gtk.c2p_box("text_box", self.screen.width / 1.86,
                                    4,
                                    Gtk.Orientation.VERTICAL)
        line_box_bottom = self.ctop_gtk.c2p_box("text_box", self.screen.width / 1.86,
                                             4,
                                             Gtk.Orientation.VERTICAL)
        nozzle_test_start_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,spacing=50)
        nozzle_test_static_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,style="image_box",width=self.screen.width/5.333,height=self.screen.height/4.740,spacing=25)
        self.start_button = self.ctop_gtk.Button_new("play",label="Start",style="nozzle_calibrate_start_button",scale=1.6)
        self.start_button.set_valign(Gtk.Align.CENTER)
        self.start_button.connect("clicked",self.start_auto_calibrate)
        self.nozzle_test_start_button = self.ctop_gtk.Button_new("play", label="Start", style="nozzle_calibrate_start_button",scale=1.6)
        self.nozzle_test_start_button.connect("clicked",self.start_nozzle_test)
        self.nozzle_test_start_button.set_halign(Gtk.Align.CENTER)
        self.switch_probe_button = self.ctop_gtk.Button_new(label="Switch \n Probe",style="switch_probe_button")
        self.switch_probe_button.connect("clicked", self.select_tool, "calibrate_switch", "auto")
        self.switch_probe_button.set_valign(Gtk.Align.CENTER)
        self.switch_probe_button.set_halign(Gtk.Align.CENTER)
        static_button = self.ctop_gtk.Button_new( label="Static", style="switch_probe_button")
        static_button.connect("clicked", self.save_offset, "Static")
        static_button.set_halign(Gtk.Align.CENTER)

        nozzle_button = self.ctop_gtk.Button_new(label="Nozzle", style="switch_probe_button")
        nozzle_button.connect("clicked", self.save_offset, "Nozzle")
        nozzle_button.set_halign(Gtk.Align.CENTER)


        auto_calibrate_label = self.ctop_gtk.c2p_label("Auto Calibrate","print_label")
        auto_calibrate_label.set_halign(Gtk.Align.START)
        nozzle_test_label = self.ctop_gtk.c2p_label("Nozzle Test","print_label")
        nozzle_test_label.set_halign(Gtk.Align.START)
        tools_label = self.ctop_gtk.c2p_label("Tools", "title-right")
        tools_label.set_halign(Gtk.Align.CENTER)
        auto_calibrate_buttons_labels = ['01', '02', '03', '04']
        tools_name = ['T0_n', 'T1_n', 'T2_n', 'T3_n']
        self.auto_calibrate_buttons = {}
        auto_calibrate_buttons_grid = Gtk.Grid()
        auto_calibrate_buttons_grid.set_halign(Gtk.Align.CENTER)
        auto_calibrate_buttons_grid.set_valign(Gtk.Align.CENTER)
        auto_calibrate_buttons_grid.get_style_context().add_class("z_tune_buttons_box")
        auto_calibrate_buttons_grid.attach(tools_label,0,0,2,1)

        ex_n = 0
        ex_m = 1
        for index, (lbl, name,dev) in enumerate(zip(auto_calibrate_buttons_labels, tools_name,self.screen.printer.get_active_extruders())):

            self.auto_calibrate_buttons[lbl] = self.ctop_gtk.Button_new(label=lbl, style="nozzle_auto_tools_buttons")
            if dev is None:
                self.auto_calibrate_buttons[lbl].set_sensitive(False)
            self.auto_calibrate_buttons[lbl].connect("clicked", self.select_tool, lbl, "auto")
            auto_calibrate_buttons_grid.attach(self.auto_calibrate_buttons[lbl], ex_n, ex_m, 1, 1)
            if not index:
                self.auto_calibrate_buttons[lbl].get_style_context().add_class("nozzle_auto_tools_buttons_pressed")
            if ex_n > 0:
                ex_m += 1
                ex_n = 0
            else:
                ex_n += 1


        self.nozzle_test_buttons = {}
        nozzle_test_buttons_box = self.ctop_gtk.c2p_box()
        nozzle_test_buttons_box.set_halign(Gtk.Align.CENTER)
        nozzle_test_buttons_box.set_valign(Gtk.Align.CENTER)
        nozzle_test_buttons_box.get_style_context().add_class("z_tune_buttons_box")
        tools_name = ['T0', 'T1', 'T2', 'T3']
        for index, (lbl, name,dev) in enumerate(zip(auto_calibrate_buttons_labels, tools_name,self.screen.printer.get_active_extruders())):
            self.nozzle_test_buttons[lbl] = self.ctop_gtk.Button_new(label=lbl, style="nozzle_tools_buttons")
            if dev is None:
                self.nozzle_test_buttons[lbl].set_sensitive(False)
            self.nozzle_test_buttons[lbl].connect("clicked", self.select_tool, lbl, "test")
            nozzle_test_buttons_box.add(self.nozzle_test_buttons[lbl])
            if not index:
                self.nozzle_test_buttons[lbl].get_style_context().add_class("nozzle_auto_tools_buttons_pressed")
        move_z_buttons_labels = ['0.01', '0.05', '0.1', '0.5', '1', '5']
        self.move_z_buttons = {}
        move_z_buttons_grid = Gtk.Grid()
        move_z_buttons_grid.set_row_spacing(20)
        move_z_buttons_grid.set_column_spacing(20)
        move_z_buttons_grid.set_valign(Gtk.Align.CENTER)
        move_z_buttons_grid.set_halign(Gtk.Align.CENTER)
        move_z_buttons_grid.get_style_context().add_class("z_tune_buttons_box")
        ex_n = 0
        ex_m = 0
        for index,lbl in enumerate(move_z_buttons_labels):
            self.move_z_buttons[lbl] = self.ctop_gtk.Button_new(label=lbl, style="nozzle_move_z_buttons")
            self.move_z_buttons[lbl].connect("clicked", self.change_z_value,lbl)
            move_z_buttons_grid.attach(self.move_z_buttons[lbl], ex_n, ex_m, 1, 1)

            if not index:
                self.move_z_buttons[lbl].get_style_context().add_class("nozzle_move_z_buttons_pressed")
            if ex_n > 0:
                ex_m += 1
                ex_n = 0
            else:
                ex_n += 1


        self.z_location = self.ctop_gtk.c2p_label(f"Z: 0","z_location_label")
        self.z_location.set_halign(Gtk.Align.CENTER)
        self.z_plus_button = CustomButton([None,None,None], "bottom", 104, 270, orientation="bottom",svg=["down","extrude-t","up"],
                                          command=[lambda: self.move(None, "Z", "+"), lambda: self.move(None, "Z", "-"),
                                                   None],style=self.style)
        move_z_custom_button = self.ctop_gtk.make_shadow(self.z_plus_button)

        move_z_custom_button.set_valign(Gtk.Align.CENTER)

        nozzle_test_static_box.pack_start(static_button,True,False,0)
        nozzle_test_static_box.pack_start(nozzle_button, True, False, 0)
        nozzle_test_start_box.add(self.nozzle_test_start_button)
        nozzle_test_start_box.add(nozzle_test_static_box)
        nozzle_control_box.pack_start(self.z_location, True, False, 0)
        nozzle_control_box.pack_start(move_z_buttons_grid,True,False,0)
        move_z_buttons_grid.attach(move_z_custom_button, 3, 0, 1, 3)

        nozzle_control_box_all.add(nozzle_control_box)
        nozzle_control_box_all.add(nozzle_test_start_box)

        tools_box.pack_start(self.switch_probe_button, True, False, 0)
        tools_box.pack_start(self.ctop_gtk.create_separator(False), True, False, 0)
        tools_box.add(auto_calibrate_buttons_grid)


        top_box.pack_start(tools_box,True,False,0)
        top_box.pack_start(self.start_button,True,False,0)
        top_box_all.add(auto_calibrate_label)
        top_box_all.add(line_box_top)
        top_box_all.add(top_box)

        bottom_box.add(nozzle_test_label)
        bottom_box.add(line_box_bottom)
        bottom_box.add(nozzle_test_buttons_box)
        bottom_box.add(nozzle_control_box_all)
        self.nozzle_calibrate_main_box.add(top_box_all)
        self.nozzle_calibrate_main_box.add(bottom_box)

    def get_content(self):
        return self.nozzle_calibrate_main_box,"Nozzle Calibrate"




    def select_tool(self,widget,lbl,name):
        if name == "auto":
            for b in self.auto_calibrate_buttons.values():
                b.get_style_context().remove_class("nozzle_auto_tools_buttons_pressed")
            self.switch_probe_button.get_style_context().remove_class("nozzle_auto_tools_buttons_pressed")
        elif name == "test":
            for b in self.nozzle_test_buttons.values():
                b.get_style_context().remove_class("nozzle_auto_tools_buttons_pressed")
        self.selected_tool[name] = lbl
        widget.get_style_context().add_class("nozzle_auto_tools_buttons_pressed")

    def move(self, widget, axis, direction):
        print("---",axis,direction)
        dist = f"{direction}{self.distance}"
        homed_axes = self.screen.printer.get_stat("toolhead", "homed_axes")
        if axis.lower() not in homed_axes:
            #self.logger.info(f"move {homed_axes}: Printer is not homed.")
            PopupNotification(
                message="Printer is not homed.",
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                timeout=5,
                tipe="E"
            )
            return
        if axis == "Z":
            speed = 60 * max(1, 10)
        else:
            speed = 60 * max(1, 50)
        self.screen._ws.klippy.gcode_script(f"{CtoPGcodes.MOVE_RELATIVE}\n{CtoPGcodes.MOVE} {axis}{dist} F{speed}")
        if self.screen.printer.get_stat("gcode_move", "absolute_coordinates"):
            self.screen._ws.klippy.gcode_script("G90")
            
    def change_z_value(self, widget,lbl):
        #self.z_tune_custom_buttons.update_label_low(label)
        self.distance = float(lbl)
        for button in self.move_z_buttons.values():
            button.get_style_context().remove_class("nozzle_move_z_buttons_pressed")
        widget.get_style_context().add_class("nozzle_move_z_buttons_pressed")
        #self.current_value_z_tune = lbl

    def start_auto_calibrate(self,widget):
        def on_yes():
            self.screen._ws.klippy.gcode_script(f"BED_MESH_CLEAR")
            if self.selected_tool['auto'] == "calibrate_switch":
                self.screen._ws.klippy.gcode_script(f"z_switch_calibration T=z")
            elif self.selected_tool['auto'] == "01":
                self.screen._ws.klippy.gcode_script(f"z_switch_calibration T=0")
            elif self.selected_tool['auto'] == "02":
                self.screen._ws.klippy.gcode_script(f"z_switch_calibration T=1")
            elif self.selected_tool['auto'] == "03":
                self.screen._ws.klippy.gcode_script(f"z_switch_calibration T=2")
            elif self.selected_tool['auto'] == "04":
                self.screen._ws.klippy.gcode_script(f"z_switch_calibration T=3")

            dialog_.destroy()

        def on_no():
            dialog_.destroy()

        text = """Are you sure you want to calibrate the nozzle?"""
        dialog_ = C2PDialog(
            self.screen,
            self.screen,
            text,
            theme_path=self.theme_path,
            title="Warning",
            button_names=["Yes", "No"],
            sp_commands=[on_yes, on_no]
        )

    def process_update(self, action, data):
        if "z" in self.screen.printer.get_stat("toolhead", "homed_axes"):
            z_position = self.screen.printer.get_stat("gcode_move", "gcode_position")
            self.z_location.set_text(f"Z: {z_position[2]:.2f}")
        else:
            self.z_location.set_text("?")
        if action == "notify_error":
            return
        elif action == "notify_busy":
            self.handle_state(data)
            return

    def handle_state(self, state):
        if self.prev_state_printer == state :
            return
        self.prev_state_printer = state
        if state:
            self.nozzle_test_start_button.set_sensitive(False)
            self.start_button.set_sensitive(False)
        else:
            self.nozzle_test_start_button.set_sensitive(True)
            self.start_button.set_sensitive(True)

    def start_nozzle_test(self,widget):
        def on_yes():
            self.screen._ws.klippy.gcode_script(f"BED_MESH_CLEAR")
            self.screen._ws.klippy.gcode_script(f"Z_NOZZLE_TEST T={int(self.selected_tool['test'])-1}")
            dialog_.destroy()
        def on_no():
            dialog_.destroy()
        text = """
                By executing this command, the selected tool will lower to 2mm above the surface.
                At this point, you can verify the accuracy of the level by adjusting the height and using an A4 sheet.
                If necessary, you can manually fine-tune the level.
                Please note that this process requires prior knowledge and proper training.
                Do you agree to proceed with this instruction?"""
        dialog_ = C2PDialog(
                            self.screen,
                            self.screen,
                            text,
                            theme_path=self.theme_path,
                            title="Warning",
                            button_names=["Yes", "No"],
                            sp_commands=[on_yes, on_no]
                        )
        
    def save_offset(self,widget,type):
        def on_yes():
            self.screen._ws.klippy.gcode_script(f"SAVE_Z_NOZZLE_TEST TYPE={type} T={int(self.selected_tool['test'])-1}")
            dialog_.destroy()
        def on_no():
            dialog_.destroy()
        if type=='Static':
            text = """With this action, the static value for calculating nozzle offsets will change,
                    which will cause an impact on other tools.
                    Do you agree?"""
        else:
            text = """With this action, only the offset of this tool will be saved at the level you selected.
                    Do you agree?"""
        dialog_ = C2PDialog(
                            self.screen,
                            self.screen,
                            text,
                            theme_path=self.theme_path,
                            title="Warning",
                            button_names=["Yes", "No"],
                            sp_commands=[on_yes, on_no]
                        )

