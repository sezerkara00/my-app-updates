from library.global_manager import GlobalVariables
from elements.c2p_gtk import CtoPGtk
from elements.file_element import FileElement
from panels.bed_mesh_panel import BedMesh
from panels.gcode_calibrate_panel import GcodeCalibratePanel
from panels.nozzle_calibrate import NozzleCalibrate
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
from panels.xy_calibrate_camera import XYCalibrateCamera
from elements.camera_dialog import CameraDialog
from panels.xy_calibrate_manauel import XYCalibrateManuel


class CalibrateMenu(GlobalVariables):
    def __init__(self, screen):
        super().__init__(screen)
        self.screen = screen
        self.ctop_gtk = CtoPGtk(self.screen, self.theme_path)
        self.calibrate_menu_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL)
        self.calibrate_menu_box.set_halign(Gtk.Align.CENTER)
        calibrate_menu_grid = Gtk.Grid()
        calibrate_menu_grid.get_style_context().add_class("calibrate_menu_grid")
        calibrate_menu_grid.set_halign(Gtk.Align.CENTER)
        calibrate_menu_grid.set_valign(Gtk.Align.CENTER)
        calibrate_menu_grid.set_row_spacing(30)
        calibrate_menu_grid.set_column_spacing(25)
        self.file_element = {}
        calibrate_panels = ['Bed Mesh', 'XY Manual Calibrate', 'Calibration Gcodes', 'Nozzle Calibrate', 'XY Camera Calibrate']
        calibrate_images = ["bed-mesh","xy_manual_calibrate","xy_manual_calibrate","nozzle_calibrate","capture"]
        for index, (panel, img_name) in enumerate(zip(calibrate_panels,calibrate_images)):

            self.file_element[panel] = FileElement(
                self.screen, panel,panel_command=lambda x: self.show_calibrate_panel(x),svg=img_name,style=self.style
            )
            if index >2:
                calibrate_menu_grid.attach(self.file_element[panel], index-3, 1, 1, 1)
            else:
                calibrate_menu_grid.attach(self.file_element[panel],index,0,1,1)
        self.calibrate_menu_box.pack_start(calibrate_menu_grid,True,True,0)

    def get_content(self):
        return self.calibrate_menu_box,"Calibrate Panel"
    def show_calibrate_panel(self,panel):
        self.screen.base_panel.pressed_button = 'sub'
        if panel == 'XY Camera Calibrate':
            title="warning"
            massage="""
                To calibrate the XY axes using the camera, you need to select one tool as the reference.\n
                The remaining tools will be calibrated relative to this reference tool.\n
                Please select the tool you want to use as the reference and \n
                confirm your choice by selecting "Yes"
                """
            CameraDialog(self.screen,self.theme_path,self.screen,['Reference-T1','Reference-T2','Reference-T3','Reference-T4'],massage=massage,title=title,yes_command=self.Start_XYCalibrateCamera)
        elif panel == 'Nozzle Calibrate':
            self.refresh_content(NozzleCalibrate(self.screen))
        elif panel == 'Bed Mesh':
            self.refresh_content(BedMesh(self.screen))
        elif panel == 'XY Manual Calibrate':
            self.refresh_content(XYCalibrateManuel(self.screen))
        elif panel == 'Calibration Gcodes':
            self.refresh_content(GcodeCalibratePanel(self.screen))
    def get_file_loc_image(self, fileloc, width=None, height=None):
        if fileloc is None or fileloc == "":
            return None
        width = width if width is not None else self.img_width
        height = height if height is not None else self.img_height
        return self.ctop_gtk.PixbufFromFile(fileloc, width, height)

    def Start_XYCalibrateCamera(self,tools):
        self.refresh_content(XYCalibrateCamera(self.screen,tools))
