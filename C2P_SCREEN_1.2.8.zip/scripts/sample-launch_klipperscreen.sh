#!/bin/bash
# Change XCLIENT and/or display to your destination Xserver (XSDL platform). 
# Example: export DISPLAY=192.168.1.101:0

# Note: You will likely want to reserve a DHCP address or set a static IP of the 
# Xserver client so that your IP does not change and require reconfiguration. 

export XCLIENT=192.168.1.101  # Set your correct X server IP
export DISPLAY=$XCLIENT:0  # Correct display

if [ $XCLIENT == "change_me" ]; then
	echo "launch_klipperscreen.sh for XSDL/XServer Clients has not been configured properly. Please edit this file to point to your XServer Client"
	exit 
fi

# Send script to daemon process so that it does not fail when tty closes.

export PYKLIPPERSCREEN=~/.KlipperScreen-env/bin/python
export PYKLIPPERSCREENPARAM=~/KlipperScreen/screen.py

if [ -f $PYKLIPPERSCREEN ]; then
	echo "Testing $PYKLIPPERSCREEN"
	test -x $PYKLIPPERSCREEN || echo "$PYKLIPPERSCREEN is Not Executable"  
fi

if [ -f $PYKLIPPERSCREENPARAM ]; then
	echo "Testing $PYKLIPPERSCREENPARAM"
	test -f $PYKLIPPERSCREENPARAM || echo "$PYKLIPPERSCREENPARAM is not a file"
fi

case "$1" in
      start)
	      echo -n "Starting Klipper Screen Xclient Daemon .... "
	      setsid "$PYKLIPPERSCREEN" "$PYKLIPPERSCREENPARAM" #>/dev/null 2>&1 < /dev/null &
	      echo "running"
		;;
	stop)
		echo -n "Stopping Klipper Screen Xclient Daemon .... "
		PID=`ps -ef | grep KlipperScreen-env/bin/python | grep -v grep | awk '{print $2}'`
		if [ ! -z "$PID" ]; then
		   kill $PID
		   echo "stopping"
		else
		   echo "No process found to stop"
		fi
	    	;;
	*)
           	echo "Usage: $0 {start|stop}"
            	exit 1
             	;;
esac

