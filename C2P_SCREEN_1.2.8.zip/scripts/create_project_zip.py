import os
import zipfile
from pathlib import Path

def create_project_zip():
    # Göz ardı edilecek klasörler ve dosyalar
    ignore_patterns = [
        '__pycache__',
        '*.pyc',
        'venv',
        'env',
        '.env',
        '.git',
        '.gitignore',
        '.idea',
        '.vscode',
        'node_modules',
        'dist',
        'build',
        '*.egg-info'
    ]

    # Zip dosyası adı
    zip_filename = 'project.zip'
    
    # Proje kök dizini
    project_root = Path(__file__).parent.parent
    
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(project_root):
            # Göz ardı edilecek klasörleri atlama
            dirs[:] = [d for d in dirs if not any(
                ignore in d for ignore in ignore_patterns)]
            
            for file in files:
                # Göz ardı edilecek dosyaları atlama
                if any(ignore in file for ignore in ignore_patterns):
                    continue
                    
                file_path = os.path.join(root, file)
                # Zip dosyasının kendisini dahil etmeme
                if file == zip_filename:
                    continue
                    
                # Dosyayı zipe ekleme
                arcname = os.path.relpath(file_path, project_root)
                zipf.write(file_path, arcname)

if __name__ == '__main__':
    create_project_zip() 