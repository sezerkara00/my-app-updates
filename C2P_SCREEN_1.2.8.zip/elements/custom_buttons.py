import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Rsvg", "2.0")
from gi.repository import Gtk, Gdk, Rsvg, cairo
import math
import os
import cairo

class CustomButton(Gtk.DrawingArea):
    def __init__(self, label=None,button_side=None,width=200, height=90, panel=None,orientation="horizontal",label_up="up",label_low = "low",svg=None,command=None,angle = 0,style="dark"):
        super().__init__()
        self.label = label
        self.svg = svg
        self.style = style
        self.panel = panel
        self.command = command
        self.width = width
        self.label_low=str(label_low)
        self.label_up= str(label_up)
        self.height = height
        self.pressed_x = False
        self.pressed_z = False
        self.pressed_home = False
        self.angle = angle
        self.active_button_rectangle = False
        self.active_button_circle = False
        self.disabled_button = False
        self.button_side = button_side
        self.current_orientation = orientation
        # Set size and enable events
        self.set_size_request(self.width, self.height)
        self.set_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK)

        # Connect signals
        if self.button_side == "top":
            self.connect("draw", self.on_draw_t)
        elif self.button_side == "bottom":
            self.connect("draw", self.on_draw_b)
        elif self.button_side == "right":
            self.connect("draw", self.on_draw_r)
        elif self.button_side == "left":
            self.connect("draw", self.on_draw_l)
        elif self.button_side == "circle_button":
            self.connect("draw", self.draw_just_circle_button)
        elif self.button_side == "rectangle_button":
            self.connect("draw", self.draw_just_rectangle_button)
        elif self.button_side == "fore":
            self.connect("draw", self.on_draw_fore)
        self.connect("button-press-event", self.on_button_press)
        self.connect("button-release-event", self.on_button_release)

    def draw_rectangle_with_rounded_corners(self,ctx, w, h, r_corner, pressed,text_angle,svg=None,label=None,temp=0):
        """Helper function to draw a rectangle with rounded corners."""
        if self.active_button_rectangle:
            if self.disabled_button:
                if self.style == "light":
                    ctx.set_source_rgb(0.827, 0.839, 0.886)
                else:
                    ctx.set_source_rgb(0.329, 0.702, 0.776)
            else:
                if self.style == "light":
                    ctx.set_source_rgb(0.157, 0.318, 0.718)
                else:
                    ctx.set_source_rgb(105 / 255, 224 / 255, 248 / 255)
        else:
            if self.disabled_button:
                if self.style == "light":
                    ctx.set_source_rgb(138/255, 138/255, 138/255) #if change color > css .move_button_x:disabled background
                else:
                    ctx.set_source_rgb(211/255, 211/255, 211/255)
            else:
                if self.style == "light":
                    ctx.set_source_rgb(0.827, 0.839, 0.886)
    
                else:
                    ctx.set_source_rgb(0.333, 0.333, 0.333)

        
        ctx.move_to(0, 0)
        ctx.line_to(w - r_corner, 0)  # Top edge
        ctx.arc_negative(w - r_corner, h / 2, r_corner, -math.pi / 2,
                         math.pi / 2)  # Right edge
        ctx.line_to(r_corner, h)  # Bottom edge
        ctx.arc(r_corner / 5, h - r_corner / 5, r_corner / 5, math.pi / 2,
                math.pi)  # Bottom-left corner
        ctx.line_to(0, r_corner)  # Left edge
        ctx.arc(r_corner / 5, r_corner / 5, r_corner / 5, math.pi,
                3 * math.pi / 2)  # Top-left corner
        ctx.close_path()
        ctx.fill()
        ctx.save()
        if text_angle == math.pi or text_angle == -math.pi:
            # Translate to the desired text position (relative to the rectangle center)
            ctx.translate(w / 2, h / 2)
            # Apply rotation to the text
            ctx.rotate(text_angle)  # Same rotation applied in on_draw_t
            ctx.translate(w/10,-h/2)
        elif  text_angle == math.pi/2:
            # Translate to the desired text position (relative to the rectangle center)
            ctx.translate(w / 2, h / 2)
            # Apply rotation to the text
            ctx.rotate(text_angle)  # Same rotation applied in on_draw_t
            ctx.translate(-w / 5, -h / 28)
        elif text_angle == -math.pi/2:
            # Translate to the desired text position (relative to the rectangle center)
            ctx.translate(w / 2, h / 2)
            # Apply rotation to the text
            ctx.rotate(text_angle)  # Same rotation applied in on_draw_t
            ctx.translate(-w / 5, -h / 1.05)
        if svg is not None:
            self.get_svg(ctx, w/5, h/2,  0.7, svg)
        if label is not None:
            if self.style == "light":
                if self.active_button_rectangle:
                    ctx.set_source_rgb(1, 1,1 )
                else:
                    ctx.set_source_rgb(0, 0, 0)
            else:
                ctx.set_source_rgb(1, 1, 1)  # White color for the text
            ctx.set_font_size(15)


            # Draw text at the rotated position
            text_extents = ctx.text_extents(
                label)  # Get text dimensions for centering
            text_x = -text_extents.width / 2
            text_y = text_extents.height / 2
            if text_angle == 0:
                ctx.move_to(text_x+60, text_y+50)
            elif text_angle > 0 :
                ctx.move_to(text_x+38, text_y+50)
            elif text_angle < 0:
                ctx.move_to(text_x+40, text_y + 50)
            ctx.show_text(label)
        ctx.restore()

    def draw_circle(self, ctx, x, y, circle_radius, pressed, text_angle,
                    label=None,svg="main"):
        """Draw a circle with an optional shadow and an SVG."""

        # Shadow properties
        shadow_layers = 6  # Number of shadow layers for smooth blur
        shadow_opacity = 0.1  # Opacity for the shadow
        shadow_spread = 3  # Spread size for the shadow
        shadow_color = (0, 0, 0)  # Black shadow

        # Step 1: Draw the shadow
        for i in range(shadow_layers):
            ctx.save()
            shadow_radius = circle_radius + shadow_spread + i * 0.5  # Gradually increase shadow size
            ctx.set_source_rgba(*shadow_color, shadow_opacity / (
                        i + 1))  # Semi-transparent black
            ctx.arc(x, y, shadow_radius, 0, 2 * math.pi)
            ctx.fill()
            ctx.restore()

        # Step 2: Draw the main circle
        if self.active_button_circle:
            if self.disabled_button:
                if self.style == "light":
                    ctx.set_source_rgb(0.827, 0.839, 0.886)
                else:
                     ctx.set_source_rgb(85/255, 85/255, 85/255)
            else:
                if self.style == "light":
                    ctx.set_source_rgb(0.157, 0.318, 0.718)

                else:
                    ctx.set_source_rgb(105 / 255, 224 / 255, 248 / 255)
        else:
            if self.disabled_button:
                if self.style == "light":
                    ctx.set_source_rgb(0.827, 0.839, 0.886)
                else:
                    ctx.set_source_rgb(0.267, 0.267, 0.267)
            elif self.panel == "extrude":
                if self.style == "dark":
                    ctx.set_source_rgb(0, 0, 0)
                else:
                    ctx.set_source_rgb(255/255, 255/255, 255/255)
            else:
                if self.style == "light":
                    ctx.set_source_rgb(0.827, 0.839, 0.886)
                else:
                    ctx.set_source_rgb(0.333, 0.333, 0.333)
        ctx.arc(x, y, circle_radius, 0, 2 * math.pi)
        ctx.fill()

        # Step 3: Draw the SVG with rotation
        ctx.save()
        if label is not None:
            if text_angle > 0:
                ctx.translate(x, y)
                ctx.rotate(text_angle)
                te = ctx.text_extents(label)
                ctx.move_to(0,0)
            else:
                te = ctx.text_extents(label)
                ctx.move_to(x-te.width*1.2, y+te.width/1.8)
            if self.style == "dark":
                ctx.set_source_rgb( 0.972, 0.38, 0.38) # White color for the text
            else:
                ctx.set_source_rgb(0.156, 0.318, 0.718)
            ctx.select_font_face("Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
            ctx.set_font_size(23)
            ctx.show_text(label)
        else:
            if text_angle > 0:
                ctx.translate(x, y)
                ctx.rotate(text_angle)

                self.get_svg(ctx, 0, 0, 0.7, svg)
            else:
                self.get_svg(ctx, x, y, 0.7, svg)
        ctx.restore()
    def draw_circle_half(self, ctx, x, y, circle_radius, pressed, text_angle, gap_angle=0.1):

        # Shadow properties
        shadow_layers = 6  # Number of shadow layers for smooth blur
        shadow_opacity = 0.1  # Opacity for the shadow
        shadow_spread = 3  # Spread size for the shadow
        shadow_color = (0, 0, 0)  # Black shadow

        # Step 1: Draw the shadow
        for i in range(shadow_layers):
            ctx.save()
            shadow_radius = circle_radius + shadow_spread + i * 0.5  # Gradually increase shadow size
            ctx.set_source_rgba(*shadow_color, shadow_opacity / (
                    i + 1))  # Semi-transparent black
            ctx.arc(x, y, shadow_radius, 0, 2 * math.pi)
            ctx.fill()
            ctx.restore()
        # Upper half-circle
        upper_start = gap_angle
        upper_end = math.pi - gap_angle

        # Lower half-circle
        lower_start = math.pi + gap_angle
        lower_end = 2 * math.pi - gap_angle

        if self.label_up == "":
            upper_end = math.pi
            upper_start = 0
            lower_start = math.pi
            lower_end = 2 * math.pi

        # Draw the upper half
        ctx.save()
        if self.style == "light":
            ctx.set_source_rgb(0.827, 0.839, 0.886)  # Gray color
        else:
            ctx.set_source_rgb(0.333, 0.333, 0.333)  # Gray color
        ctx.arc(x, y, circle_radius, upper_start, upper_end)  # Draw the upper arc
        ctx.fill()



        ctx.arc(x, y, circle_radius, lower_start, lower_end)  # Draw the lower arc
        ctx.fill()
        ctx.restore()

        # Add "UP" label to the upper half
        ctx.save()
        if self.style == "dark":
            ctx.set_source_rgb(1, 1, 1)  # White text
        else:
            ctx.set_source_rgb(0, 0, 0)  # Gray color
        ctx.select_font_face("Sans", cairo.FontSlant.NORMAL, cairo.FontWeight.BOLD)
        ctx.set_font_size(circle_radius / 3)  # Adjust text size based on circle size

        # Calculate position for "UP" text
        if not self.label_up == "":
            up_text = self.label_up
            up_x = x
            up_y = y - circle_radius / 2  # Position text in the middle of the upper half
            text_extents = ctx.text_extents(up_text)
            ctx.move_to(up_x - text_extents.width / 2, up_y + text_extents.height / 2)
            ctx.show_text(up_text)
        ctx.restore()

        # Add "LOW" label to the lower half
        ctx.save()
        if self.style == "dark":
            ctx.set_source_rgb(1, 1, 1)  # White text
        else:
            ctx.set_source_rgb(0, 0, 0)  # Gray color
        
        ctx.select_font_face("Sans", cairo.FontSlant.NORMAL, cairo.FontWeight.BOLD)
        ctx.set_font_size(circle_radius / 3)  # Adjust text size based on circle size

        # Calculate position for "LOW" text
        low_text = self.label_low
        low_x = x
        low_y = y + circle_radius / 2  # Position text in the middle of the lower half
        text_extents = ctx.text_extents(low_text)
        if not self.label_up == "":
            ctx.move_to(low_x - text_extents.width / 2, low_y + text_extents.height / 2)
            ctx.show_text(low_text)
        else:
            ctx.move_to(low_x - text_extents.width/2 , low_y + -2*text_extents.height + 5)
            ctx.show_text(low_text)
        ctx.restore()
    def draw_just_rectangle_button(self, da, ctx):
        w = da.get_allocated_width()
        h = da.get_allocated_height()
        r_corner = h / 2.01
        if self.angle == math.pi/2 or self.angle == -math.pi/2 :
            r_corner = w / 2.01
            # Step 2: Translate to the center of the rectangle
            ctx.translate(w / 2, h / 2)

            # Step 3: Rotate the context 90 degrees clockwise (π/2 radians)
            ctx.rotate(self.angle)

            # Step 4: Translate back to align correctly
            ctx.translate(-h / 2, -w / 2)
            # Draw the rectangle with rounded corners
            self.draw_rectangle_with_rounded_corners(ctx, h, w, r_corner,
                                                     self.pressed_x, -self.angle,svg=self.svg)
        elif self.angle == math.pi or self.angle == -math.pi:
            ctx.translate(w / 2, h / 2)

            # Step 3: Rotate the context 90 degrees clockwise (π/2 radians)
            ctx.rotate(self.angle)

            # Step 4: Translate back to align correctly
            ctx.translate(-w / 2, -h / 2)
            self.draw_rectangle_with_rounded_corners(ctx, w, h, r_corner,
                                                     self.pressed_x, self.angle,svg=self.svg)
        else:
            self.draw_rectangle_with_rounded_corners(ctx, w, h, r_corner,
                                                     self.pressed_x, 0,svg=self.svg)

    def draw_just_circle_button(self, da, ctx):
        w = da.get_allocated_width()
        h = da.get_allocated_height()
        circle_radius = h / 2.4
        circle_center_x = w / 1.31
        circle_center_y = h / 2

        # Draw the circular button
        self.draw_circle(ctx, circle_center_x, circle_center_y, circle_radius, self.pressed_home, 0)

    def on_draw_r(self, da, ctx):
        """Draw a rectangle with a circular button on the right."""
        w = da.get_allocated_width()
        h = da.get_allocated_height()
        r_corner = h / 2.01
        circle_radius = h / 2.4
        circle_center_x = w / 1.31
        circle_center_y = h / 2

        # Draw the rectangle with rounded corners
        self.draw_rectangle_with_rounded_corners(ctx, w, h, r_corner,
                                            self.pressed_x,0,label=self.label)

        # Draw the circular button
        self.draw_circle(ctx,circle_center_x,circle_center_y,circle_radius,self.pressed_home,0,svg="main")

    def on_draw_l(self, da, ctx):
        """Draw a rectangle with a circular button on the right."""
        w = da.get_allocated_width() / 1.52
        h = da.get_allocated_height()
        r_corner = h / 2.01
        circle_radius = h / 2.4
        circle_center_x = w / 1.31
        circle_center_y = h / 2

        # Draw the rectangle with rounded corners
        self.draw_rectangle_with_rounded_corners(ctx, w, h, r_corner,
                                                 pressed=self.pressed_x, text_angle= 0,svg=self.svg[0])
        ctx.stroke()
        # Draw the circular button
        self.draw_circle_half(ctx, circle_center_x, circle_center_y, circle_radius, self.pressed_home, 0)

        # Step 1: Save the original context
        ctx.save()

        # Step 2: Translate to the center of the rectangle
        ctx.translate(w / 2, h / 2)

        # Step 3: Rotate the context by 180 degrees (π radians)
        ctx.rotate(math.pi)

        # Step 4: Translate back to align correctly
        ctx.translate(-w/0.98 , -h / 2)

        # Draw the rotated rectangle
        self.draw_rectangle_with_rounded_corners(ctx, w, h, r_corner,
                                                pressed= self.pressed_x,text_angle=math.pi,svg=self.svg[2])
        # Restore the original context
        ctx.restore()

    def on_draw_t(self, da, ctx):
        w = da.get_allocated_width()
        h = da.get_allocated_height()
        r_corner = w / 2.01
        circle_radius = w / 2.4

        # Step 1: Save the original context
        ctx.save()

        # Step 2: Translate to the center of the widget
        ctx.translate(w / 2, h / 2)

        # Step 3: Rotate the context 90 degrees clockwise (π/2 radians)
        ctx.rotate(-math.pi / 2)

        # Step 4: Translate back to align correctly
        ctx.translate(-h / 2, -w / 2)

        # Step 5: Draw the rectangle with rounded corners (rotated context)
        self.draw_rectangle_with_rounded_corners(ctx, h, w, r_corner,
                                                 self.pressed_x,math.pi/2,label=self.label)


        # Step 6: Draw the circular button (rotated context)
        circle_center_x = h / 1.31  # Adjusted for rotated width (h becomes width)
        circle_center_y = w / 2  # Adjusted for rotated height (w becomes height)

        # Draw the circular button
        self.draw_circle(ctx, circle_center_x, circle_center_y, circle_radius,
                         self.pressed_home, math.pi/2,svg="main")

        # Step 7: Restore the original context
        ctx.restore()

    def on_draw_b(self, da, ctx):
        w = da.get_allocated_width()
        h = da.get_allocated_height() /1.53
        r_corner = w / 2.01
        circle_radius = w / 2.4

        # Step 1: Save the original context
        ctx.save()

        # Step 2: Translate to the center of the widget
        ctx.translate(w / 2, h / 2)

        # Step 3: Rotate the context 90 degrees clockwise (π/2 radians)
        ctx.rotate(math.pi / 2)

        # Step 4: Translate back to align correctly
        ctx.translate(-h / 2, -w / 2)

        # Step 5: Draw the first rectangle with rounded corners
        self.draw_rectangle_with_rounded_corners(ctx, h, w, r_corner,
                                                 self.pressed_x,math.pi/2,self.svg[0],self.label[0])

        # Step 6: Restore the context for the circle
        ctx.restore()

        # Step 7: Save the context for the circle
        ctx.save()

        # Draw the circular button
        circle_center_x = w / 2  # Adjusted for centered width
        circle_center_y = h/1.31  # Positioned below the first rectangle

        # Draw the circular button
        self.draw_circle(ctx, circle_center_x, circle_center_y, circle_radius,
                         self.pressed_home, -math.pi/2,svg="main",label=self.label[1])
        # Restore context after the circle
        ctx.restore()

        # Step 8: Save context for the second rectangle
        ctx.save()

        # Translate to draw the second rectangle below the circle
        second_rect_x = 0
        second_rect_y = h + 5

        ctx.translate(second_rect_x, second_rect_y)
        # Step 10: Rotate the second rectangle
        ctx.rotate(-math.pi /2)  # Rotate 45 degrees (example)

        # Step 11: Translate back for proper alignment
        ctx.translate(-h / 2, 0)

        # Draw the second rectangle
        self.draw_rectangle_with_rounded_corners(ctx, h, w, r_corner,
                                                 self.pressed_z,-math.pi/2,self.svg[2],self.label[2])

        # Restore the original context
        ctx.restore()
    def on_draw_fore(self, da, ctx):
        w = da.get_allocated_width()/3
        h = da.get_allocated_height() /1.53
        r_corner = w / 2.01
        circle_radius = w / 2.4

        # Step 1: Save the original context
        ctx.save()

        # Step 2: Translate to the center of the widget
        ctx.translate(w / 2, h / 2)

        # Step 3: Rotate the context 90 degrees clockwise (π/2 radians)
        ctx.rotate(math.pi / 2)

        # Step 4: Translate back to align correctly
        ctx.translate(-h / 2, -w / 2)

        # Step 5: Draw the first rectangle with rounded corners
        self.draw_rectangle_with_rounded_corners(ctx, h, w, r_corner,
                                                 self.pressed_x,math.pi/2)

        # Step 6: Restore the context for the circle
        ctx.restore()

        # Step 7: Save the context for the circle
        ctx.save()

        # Draw the circular button
        circle_center_x = w / 2  # Adjusted for centered width
        circle_center_y = h/1.31  # Positioned below the first rectangle

        # Draw the circular button
        self.draw_circle(ctx, circle_center_x, circle_center_y, circle_radius,
                         self.pressed_home, -math.pi/2)
        # Restore context after the circle
        ctx.restore()

        # Step 8: Save context for the second rectangle
        ctx.save()

        # Translate to draw the second rectangle below the circle
        second_rect_x = 0
        second_rect_y = h + 5

        ctx.translate(second_rect_x, second_rect_y)
        # Step 10: Rotate the second rectangle
        ctx.rotate(-math.pi /2)  # Rotate 45 degrees (example)

        # Step 11: Translate back for proper alignment
        ctx.translate(-h / 2, 0)

        # Draw the second rectangle
        self.draw_rectangle_with_rounded_corners(ctx, h, w, r_corner,
                                                 self.pressed_z,-math.pi/2)

        # Restore the original context
        ctx.restore()

        ctx.save()
        w = da.get_allocated_width()
        self.draw_rectangle_with_rounded_corners(ctx, w, h, r_corner,
                                                 self.pressed_x, 0)
        ctx.restore()


    def on_button_press(self, widget, event,ctx=None):
        """Detect which button is clicked."""
        w = self.get_allocated_width()
        h = self.get_allocated_height()
        circle_radius = h / 2.4

        if self.current_orientation == "horizontal":  # on_draw_r
            circle_center_x = w / 1.31
            circle_center_y = h / 2

            # Check if click is inside the circle button
            if (event.x - circle_center_x) ** 2 + (
                    event.y - circle_center_y) ** 2 <= circle_radius ** 2:
                self.pressed_home = True
                self.command[0]()
                print("Circle button pressed (horizontal)")

            # Check if click is inside the rectangle button
            elif 0 <= event.x <= w and 0 <= event.y <= h:
                self.pressed_x = True
                self.command[1]()
                ctx.set_source_rgb(0,0,0)
                print("Rectangle button pressed (horizontal)")
            elif 0 <= event.x <= (126) and 0 <= event.y <= 100:
                self.pressed_x = True
                self.command[2]()
                print("Rectangle button pressed (horizontal)")
        elif self.current_orientation == "horizontal3":
             # Check if click is inside the circle button
            if w/3.365 <= event.x <= (w/1.707) and h/1.704 <= event.y <= h/1.118:
                self.pressed_home = True
                self.command[0]()
                print("Circle button pressed (horizontal)")
            # Check if click is inside the rectangle button
            elif w/1.583 <= event.x <= (w/1.029) and 0 <= event.y <= h/1.04:
                self.pressed_x = True
                self.command[1]()
                print("Rectangle button pressed (horizontal)")
            elif 0 <= event.x <= (w/2.777) and 0 <= event.y <= h/1.04:
                self.pressed_x = True
                self.command[2]()
                print("Rectangle button pressed (horizontal)")

        elif self.current_orientation == "vertical":  # on_draw_t
            # Reverse the rotation of the mouse coordinates
            transformed_x = h - event.y
            transformed_y = event.x

            circle_center_x = h / 1.31  # Adjusted for rotated context
            circle_center_y = w / 2  # Adjusted for rotated context

            # Check if click is inside the circle button
            if (transformed_x - circle_center_x) ** 2 + (
                    transformed_y - circle_center_y) ** 2 <= circle_radius ** 2:
                self.pressed_home = True
                self.command[0]()
                print("Circle button pressed (vertical)")

            # Check if click is inside the rectangle button
            elif 0 <= transformed_x <= h and 0 <= transformed_y <= w:
                self.pressed_x = True
                self.command[1]()
                print("Rectangle button pressed (vertical)")
        elif self.current_orientation == "bottom":

            if 0 <= event.x <= (w/1.072) and (h/1.471) <= event.y <= h:
                self.pressed_z = True
                self.command[0]()
                print("Rectangle button pressed (vertical)")
            elif 0 <= event.x <= (w/1.072) and 0 <= event.y <= h/3.06:
                self.pressed_x = True
                self.command[1]() 
                print("Rectangle button pressed (vertical)")
            elif 0 <= event.x <= (w/1.072) and (h/2.684) <= event.y <= h/1.53:
                self.command[2]()
                self.pressed_home = True
        print("X",event.x,"Y",event.y)
        self.queue_draw()

    def on_button_release(self, widget, event):
        """Release both buttons."""
        self.pressed_x = False
        self.pressed_z = False
        self.pressed_home = False
        self.queue_draw()

    def get_svg(self, ctx, center_x, center_y,  scale, svg):
        # Load the SVG file
        if svg is None:
            return
        home_dir = os.path.expanduser('~')
        svg_path = os.path.join(home_dir, "C2P_SCREEN", "css", self.style,
                                "images", f"{svg}.svg")
        handle = Rsvg.Handle.new_from_file(svg_path)

        # Get SVG dimensions
        svg_dim = handle.get_dimensions()
        svg_width = svg_dim.width
        svg_height = svg_dim.height

        # Calculate position to center the SVG
        scaled_width = svg_width * scale
        scaled_height = svg_height * scale
        translate_x = center_x - scaled_width / 2
        translate_y = center_y - scaled_height / 2

        # Draw the SVG
        ctx.save()
        ctx.translate(translate_x, translate_y)  # Center the SVG
        ctx.scale(scale, scale)  # Scale the SVG
        handle.render_cairo(ctx)
        ctx.restore()
    def change_button_color(self,axis=""):
        # self.disabled_button = False
        if axis == "home":
            self.active_button_circle = True
        else:
            self.active_button_rectangle = True
        self.queue_draw()
        
    def deactive_button(self,axis=""):
        # self.disabled_button = False
        if axis == "home":
            self.active_button_circle = False
        else:
            self.active_button_rectangle = False
        self.queue_draw()

    def disable_button(self):
        self.disabled_button = True
        self.queue_draw()

    def enable_button(self):
        self.disabled_button = False
        self.queue_draw()

    def update_label_low(self,label,pr=""):
        self.label_low = label
        self.queue_draw()

    def update_label_up(self,label,pr=""):
        self.label_up = label
        self.queue_draw()

    def get_label(self):
        return self.label_low
    def update_circle_label(self,tool):
        self.label[1] = tool
        self.queue_draw()