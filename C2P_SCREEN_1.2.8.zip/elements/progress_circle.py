import gi
import cairo
import math

gi.require_version("Gtk", "3.0")
gi.require_version("Rsvg", "2.0")
from gi.repository import Gtk, Rsvg, Gdk,GLib
import os

class ProgressCircle(Gtk.DrawingArea):
    def __init__(self, screen,w=None,h=None,panel="main",label=None, progress=None, target_temp=None, current_temp=None, filament_type=None, side="right",style="light",active=False,park=False,max_temp=None,angle=0,command=None,name=None,filament_color="",css_color=None,nozzle=None):
        super().__init__()
        self.progress = progress
        self.progress_internal = 0
        self.label = label
        self.name = name
        self.nozzle_size = nozzle
        self.park = park
        self.side = side
        self.change_label_color = False
        self.css_color = css_color

        self.active = active
        self.style = style
        self.target_temp = target_temp
        self.current_temp = current_temp
        self.filament_type = filament_type
        self.max_temp = max_temp
        self.panel = panel
        self.filament_color = filament_color
        self.angle = angle
        if self.style == "light":
            self.tool_r,self.tool_g,self.tool_b = 0.156, 0.318, 0.718
        else:
            self.tool_r,self.tool_g,self.tool_b = 0.4118, 0.8784, 0.9725
        self.progress_motion = 0
        self.new_tool_label = None
        self.pressed_home = False
        self.pressed_x = False
        if command and isinstance(command, list) and len(command) > 1:
            self.command = command[1]
            self.command_circle = command[0]
        else:
            self.command = command
            self.command_circle = None

        if self.angle != 0:
            self.set_size_request(w,h)#(150,354)
        elif w is not  None:
            self.set_size_request(w, h)
        else:
            self.set_size_request(screen.width/2.259,screen.height/7.619)#(354,150)
        if self.command is not None:
            self.set_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK)
        self.connect("button-press-event", self.on_button_press)
        self.connect("draw", self.on_draw)
      #  self.connect("button-release-event", self.on_button_release)


    def update_progress(self):
        # Increase progress gradually until it reaches 1.0 (complete circle)
        if self.progress_motion <= self.progress:

            self.progress_motion += 0.01  # Adjust the step for speed (smaller = slower)
            self.queue_draw()  # Request a redraw of the widget
            return True  # Continue the timer
        return False
    def on_draw(self, da, ctx):
            # Save the context before applying transformations
            ctx.save()
            # Get the width and height of the DrawingArea
            w = da.get_allocated_width()
            h = da.get_allocated_height()

            # Call the original drawing logic with updated dimensions
            if self.angle != 0:
                # Step 1: Translate to the center of the canvas
                ctx.translate(w / 2, h / 2)

                # Step 2: Rotate the canvas angle degrees clockwise
                ctx.rotate(self.angle)

                # Step 3: Translate back to ensure proper alignment
                ctx.translate(-h / 2, -w / 2)

                rotated_width = h  # Height becomes width after 90-degree rotation
                rotated_height = w  # Width becomes height after 90-degree rotation
                self.draw_elements(ctx, rotated_width, rotated_height,True)
            else:
                self.draw_elements(ctx, w, h)
            # Restore the context to its original state
            ctx.restore()

    def draw_elements(self, ctx, w, h,rotate_text=False):

        # w = da.get_allocated_width()
        # h = da.get_allocated_height()
        if self.panel == "printing":
            svg_scale = 0.6
            svg_position_y = h/34
            svg_position_x =-w / 40
            r_corner = h / 2.02
            circle_radius = h / 2.46
            small_circle_radius = h / 4.2
        else:
            svg_scale = 0.9
            svg_position_y = h / 60
            svg_position_x = -w / 50
            r_corner = h/2.01
            circle_radius = h/2.4
            small_circle_radius = h/3.2

        if self.style == "light":

            ctx.set_source_rgb(138 / 255, 138 / 255,
                               138 / 255) #not active color
        else:
            ctx.set_source_rgb(211 / 255, 211 / 255,
                               211 / 255)
        if self.active:
            if self.pressed_x:
                ctx.set_source_rgb( self.tool_r,self.tool_g,self.tool_b)

            else:
                if self.css_color is not None:
                    ctx.set_source_rgb(self.css_color[0] / 255, self.css_color[1] / 255,
                                       self.css_color[2] / 255)  # Main color (e.g., light gray)
                else:
                    if self.style == "light":
                        ctx.set_source_rgb(200 / 255, 200 / 255,
                        200 / 255)  # Main color (e.g., light gray)  #active color
                    else:
                        ctx.set_source_rgb(69 / 255, 69 / 255,
                        69 / 255)  # Main color (e.g., light gray)
        # if self.style == "light":
        #     # Draw the main rectangle with the primary color
        #     ctx.set_source_rgb(164 / 255, 164 / 255,
        #                        164 / 255)
        #     if self.active:
        #         ctx.set_source_rgb(220 / 255, 220 / 255,
        #                            220 / 255)

        if self.side == "right":
            # Top edge
            ctx.line_to(w - r_corner, 0)  # Stop before the right edge

            # Right edge (arc)
            ctx.arc_negative(w - r_corner, h / 2, r_corner, -math.pi / 2,
                             math.pi / 2)

            # Bottom edge
            ctx.line_to(r_corner, h)  # Stop before the bottom-left corner

            # Bottom-left corner (arc)
            ctx.arc(r_corner/5, h - r_corner/5, r_corner/5, math.pi / 2, math.pi)

            # Left edge
            ctx.line_to(0, r_corner)  # Up the left side

            # Top-left corner (arc)
            ctx.arc(r_corner/5, r_corner/5, r_corner/5, math.pi, 3 * math.pi / 2)
        else:
            ctx.move_to(r_corner, 0)
            ctx.line_to(w - r_corner, 0)  # Top edge before top-right corner

            # Top-right corner (arc)
            ctx.arc(w - r_corner/5, r_corner/5, r_corner/5, -math.pi / 2, 0)

            # Right edge
            ctx.line_to(w,
                        h - r_corner)  # Right edge before bottom-right corner

            # Bottom-right corner (arc)
            ctx.arc(w - r_corner/5, h - r_corner/5, r_corner/5, 0, math.pi / 2)

            # Bottom edge
            ctx.line_to(r_corner, h)

            # Left edge
            ctx.arc_negative(r_corner, h / 2, r_corner, math.pi / 2,
                             -math.pi / 2)

        ctx.close_path()
        ctx.fill()




        # Draw the main rectangle in a different color
        ctx.set_source_rgb(100 / 255, 100 / 255,
                           100 / 255)
        if self.active:
            ctx.set_source_rgb(76 / 255, 76 / 255,
                               76 / 255)  # Main color (e.g., light gray)
        if self.style == "light":
            # Draw the main rectangle with the primary color
            ctx.set_source_rgb(150 / 255, 150 / 255,
                               150 / 255)

            if self.active:
                ctx.set_source_rgb(192 / 255, 192 / 255,
                                   192 / 255)  # Main color (e.g., light gray)


        #circle1
        if self.panel == "printing":
            ctx.set_line_width(8)
        elif self.panel == "gcode":
            ctx.set_line_width(10)
        else:
             ctx.set_line_width(12)  # Set the desired thickness
        ctx.set_source_rgb(86 / 255, 86 / 255, 86 / 255)
        if self.style == "light":
            ctx.set_source_rgb(0.827, 0.839, 0.886)
        if self.side == "left":
            ctx.arc(w / 4.2, h / 2,  circle_radius, 0, 2 * 3.14)
        else:
            ctx.arc(w / 1.31, h / 2,  circle_radius, 0, 2 * 3.14)
        ctx.stroke()

        # Draw the progress arc1
        if self.style == "light":
            ctx.set_source_rgb(0.157, 0.318, 0.718)
        else:
            ctx.set_source_rgb(105 / 255, 224 / 255,
                           248 / 255)  # circle color blue for showing current temp
        if self.side == "right" and self.angle == 0:
            ctx.arc(w / 1.31, h / 2, circle_radius, -math.pi / 2,
                    -math.pi / 2 + (self.progress_motion * 2 * math.pi))
        elif self.side == "left":
            ctx.arc(w / 4.2, h / 2, circle_radius, -math.pi / 2,
                    -math.pi / 2 + (self.progress_motion * 2 * math.pi))
        if self.angle != 0:
            ctx.arc(w / 1.31, h / 2, circle_radius, 0,
                    0 + (self.progress_motion * 2 * math.pi))
        ctx.stroke()
        if self.filament_type is not None:
            # circle2
            if self.panel == "printing":
                ctx.set_line_width(6)
            elif self.panel == "gcode":
                ctx.set_line_width(7)
            else:
                ctx.set_line_width(8)  # Set the desired thickness
            ctx.set_source_rgb(86 / 255, 86 / 255, 86 / 255)
            if self.style == "light":
                ctx.set_source_rgb(0.827, 0.839, 0.886)
            if self.side == "left":
                ctx.arc(w / 4.2, h / 2, small_circle_radius, 0, 2 * 3.14)
            else:
                ctx.arc(w / 1.31, h / 2, small_circle_radius, 0, 2 * 3.14)
            ctx.stroke()

            ctx.set_source_rgb(self.filament_color[0], self.filament_color[1], self.filament_color[2])
            if self.side == "right" and self.angle == 0:
                ctx.arc(w / 1.31, h / 2, small_circle_radius, -math.pi / 2,
                        -math.pi / 2 + (self.progress_internal * 2 * math.pi))
            elif self.side == "left":
                ctx.arc(w / 4.2, h / 2, small_circle_radius, -math.pi / 2,
                        -math.pi / 2 + (self.progress_internal * 2 * math.pi))
            if self.angle != 0:
                ctx.arc(w / 1.31, h / 2, small_circle_radius, 0,
                        0 + (self.progress_internal * 2 * math.pi))
            ctx.stroke()






        if rotate_text:
            # Center the text rotation around the canvas center
            ctx.translate(w / 2, h / 2)
            ctx.rotate(math.pi/2)

            # Adjust the origin back to normal after rotation
        # ctx.translate(-w / 2, -h / 2)

        # if self.target_temp is not None and self.target_temp != 0 and self.max_temp is not None:
        #     ctx.set_source_rgb(1, 0, 0)  # circle color red for showing target
        #     start_point = -3.14 / 2 +  (self.progress * 2 * 3.14)
        #     end_point = -3.14 / 2 +((self.target_temp/self.max_temp) * 2 * 3.14)
        #     if start_point < end_point:
        #
        #         ctx.arc(w / 2, h / 2, r_corner, start_point,
        #               end_point)
        #     ctx.stroke()
        # Draw the target and current temperatures inside the circle
        ctx.select_font_face("Sans", cairo.FONT_SLANT_NORMAL,
                             cairo.FONT_WEIGHT_BOLD)
        ctx.set_font_size(17) if self.panel == "printing" else ctx.set_font_size(17)

        ctx.set_source_rgb(240/255, 240/255, 240/255)  # text color


        if self.target_temp is not None and self.target_temp !=0 :
            # Draw target temperature
            ctx.set_source_rgb( 0.972, 0.38, 0.38)
            target_text = f"{self.target_temp:.1f}"
            target_extents = ctx.text_extents(target_text)
            if self.side == "right" and not rotate_text:

                ctx.move_to((w - target_extents.width) / 3, h / 2 + 5)
            else:

                ctx.move_to((w - target_extents.width) / 1.14, h / 2 + 5)
            if rotate_text:  # if vertical change label position
                if self.panel == "printing":
                    ctx.move_to(-(w + target_extents.width) / 10, h / 2.4 + 5)
                else:
                    ctx.move_to(-(w - target_extents.width) / 10, h / 2.4 + 5)
            ctx.show_text(target_text)
            ctx.stroke()




            # Draw current temperature below target temperature
            ctx.set_source_rgb(1, 1, 1)
            if self.style == "light":
                ctx.set_source_rgb(0,0,0)
            current_text = f"{self.current_temp:.1f}"
            current_extents = ctx.text_extents(current_text)
            if self.side == "right" and not rotate_text:
                if self.style == "light":
                    self.get_svg(ctx, w, h, 31, 2.8, svg_scale, "temp.svg",mode="light")
                else:
                    self.get_svg(ctx, w, h, 31, 2.8, svg_scale, "temp.svg")
                ctx.move_to((w - current_extents.width) / 8, h / 2 + 5)
            else:
                if self.style == "light":
                    self.get_svg(ctx, w, h, 2, 2.8, svg_scale, "temp.svg",mode="light")
                else:
                    self.get_svg(ctx, w, h, 2, 2.8, svg_scale, "temp.svg")
                ctx.move_to((w - current_extents.width) / 1.49, h / 2 + 5)
            if rotate_text:  # if vertical change label position
                if self.style == "light":
                    self.get_svg(ctx, w, h, -w  / 8,
                             h / 5, svg_scale, "temp.svg",mode="light")
                else:
                    self.get_svg(ctx, w, h, -w  / 8,
                             h / 5, svg_scale, "temp.svg")
                if self.panel == "printing":
                    ctx.move_to(-(w + current_extents.width) / 10, h / 1.3)
                else:
                    ctx.move_to(-(w - current_extents.width) / 10, h / 1.3)
            ctx.show_text(current_text)
            ctx.stroke()

            symbol = "°C"
            target_extents = ctx.text_extents(symbol)
            if self.side == "right" and not rotate_text:

                ctx.move_to((w - target_extents.width) / 2.1, h / 2 + 5)
            else:

                ctx.move_to((w - target_extents.width) / 1.04, h / 2 + 5)
            if rotate_text:  # if vertical change label position

                ctx.move_to((w - target_extents.width) / 8, h / 1.6)
            ctx.show_text(symbol)
            ctx.stroke()
            # line between target and current
            ctx.set_source_rgb(0, 0, 0)
            if self.style == "light":
                ctx.set_source_rgb(1, 1, 1)
            line = "/"
            target_extents = ctx.text_extents(line)
            if self.side == "right" and not rotate_text:

                ctx.move_to((w - target_extents.width) / 3.75, h / 2 + 5)
            else:

                ctx.move_to((w - target_extents.width) / 1.35, h / 2 + 5)
            if rotate_text:  # if vertical change label position
                line = "-------"
                if self.panel == "printing":
                    ctx.move_to(-w / 8, h / 1.8 + 5)
                else:
                    ctx.move_to(-w / 13, h / 1.8 + 5)
            ctx.show_text(line)
            ctx.stroke()
        else:
            ctx.set_font_size(15)
            # Draw current temperature below target temperature
            ctx.set_source_rgb(1, 1, 1)
            if self.style == "light":
                ctx.set_source_rgb(0,0,0)

            current_text = f"{self.current_temp:.1f}°C"
            current_extents = ctx.text_extents(current_text)
            if self.side == "right" and not rotate_text:
                if self.style == "light":
                    self.get_svg(ctx, w, h, 31, 2.8,svg_scale ,"temp.svg",mode="light")
                else:
                    self.get_svg(ctx, w, h, 31, 2.8,svg_scale ,"temp.svg")
                ctx.move_to((w - current_extents.width) / 8, h / 2 +5)
            else:
                if self.style == "light":
                    self.get_svg(ctx, w, h, 2, 2.8, svg_scale, "temp.svg",mode="light")
                else:
                    self.get_svg(ctx, w, h, 2, 2.8, svg_scale, "temp.svg")
                ctx.move_to((w - current_extents.width) / 1.46, h / 2 + 5)
            if rotate_text:#if vertical change label position
                if self.style == "light":
                    self.get_svg(ctx, w, h, svg_position_x, svg_position_y, svg_scale, "temp.svg",mode="light")
                else:
                    self.get_svg(ctx, w, h, svg_position_x, svg_position_y, svg_scale, "temp.svg")
                ctx.move_to(-(w + current_extents.width) / 15, h / 2 +5)
            ctx.show_text(current_text)
            ctx.stroke()
        # Draw the label at the top left of the circle
        if self.change_label_color:
            if self.style == "dark":
                ctx.set_source_rgb( 0.972, 0.38, 0.38)
            else:
                ctx.set_source_rgb(0.156, 0.318, 0.718)
            ctx.set_font_size(15) if self.panel == "printing" else ctx.set_font_size(35)
            te = ctx.text_extents(self.label)
            kat = 1
        else:
            if self.style == "light":
                ctx.set_source_rgb(0,0,0)
            else:
                ctx.set_source_rgb( 240 / 255, 240 / 255, 240 / 255)
            ctx.set_font_size(15) if self.panel == "printing" else ctx.set_font_size(23)
            kat = 0

        if self.side == "left":

            ctx.move_to((w/4.2)-16,
                        (h/2)+6)
            if self.label == "Bed":
                ctx.move_to((w / 6) ,
                            (h / 2) + 6)
        elif self.side == "right":
            ctx.move_to((w/1.31 )-16,
                        (h/2)+6)
            if self.label == "Env":
                ctx.move_to((w / 1.351) - 16,
                            (h / 2) + 6)
        if rotate_text:
            te = ctx.text_extents(self.label)
            ctx.move_to( -w/20 - (te.width / 8 )*kat, -h/1.096+circle_radius+ (te.width / 8 )*kat)

        if self.new_tool_label is not None:
            ctx.move_to(-w / 20, -h / 1.5 )
            ctx.show_text(self.label)
            ctx.move_to(-w / 15, -h/1.036+circle_radius)
            ctx.show_text("-----")
            ctx.set_source_rgb(0, 1, 0)
            ctx.set_font_size(34)
            ctx.move_to(-w / 13, -h / 1.296 + circle_radius)
            ctx.show_text(self.new_tool_label)

        else:
            ctx.show_text(self.label)
        ctx.stroke()

        if self.filament_type  is not None:

            if self.side == "left":

                # Draw the label at the down right of the circle
                ctx.set_source_rgb(1, 1, 1)
                if self.style == "light":
                    ctx.set_source_rgb(0, 0,
                                       0)

                ctx.set_font_size(8) if self.panel == "printing" else ctx.set_font_size(11)

                ctx.move_to(w / 1.8,
                            h / 1.3)
                ctx.show_text("Material: ")
                ctx.set_font_size(12) if self.panel == "printing" else ctx.set_font_size(15)

                ctx.show_text(self.filament_type)
                ctx.move_to(w / 1.8,
                            h / 1.1)
                ctx.set_font_size(11)
                ctx.show_text("Nozzle Diameter: ")
                ctx.set_font_size(15)
                ctx.show_text(self.nozzle_size)
                if self.style == "light":
                    self.get_svg(ctx,w,h,2,1.45,1.3,"material_d.svg",mode="light")
                else:
                    self.get_svg(ctx,w,h,2,1.45,1.3,"material.svg")
                if self.style == "light":
                    self.get_svg(ctx, w, h, 2,1.18, 1.3, "nozzel.dia-light.svg",mode="light")
                else:
                    self.get_svg(ctx, w, h, 2,1.18, 1.3, "nozzel-dia-green.svg")

                ctx.stroke()
                self.draw_active_circle(ctx, w/1.055, h/8.5, 10)
            elif self.side == "right":

                # Draw the label at the down right of the circle
                ctx.set_source_rgb(1, 1, 1)

                if self.style == "light":
                    ctx.set_source_rgb(0, 0,
                                       0)


                ctx.set_font_size(8) if self.panel == "printing" else ctx.set_font_size(11)
                if self.panel == "gcode":
                    ctx.move_to(-w / 6.5,
                                h / 1.3)
                elif self.panel == "printing":
                    ctx.move_to(-w / 6.5,
                                h / 1.06)
                else:
                    ctx.move_to(w / 10.5,
                                h / 1.1)
                    ctx.show_text("Nozzle Diameter: ")
                    ctx.set_font_size(15)
                    ctx.show_text(self.nozzle_size)
                    ctx.move_to(w / 10.5,
                                h / 1.3)
                    ctx.set_font_size(11)
                ctx.show_text("Material: ")


                ctx.set_font_size(11) if self.panel == "printing" else ctx.set_font_size(15)
                ctx.show_text(self.filament_type)
                if rotate_text:
                    if self.panel=="gcode":
                        if self.style == "light":
                            self.get_svg(ctx, w, h, -w / 60, h / 105, 1.1, "material_d.svg",mode="light")
                        else:
                            self.get_svg(ctx, w, h, -w / 60, h / 105, 1.1, "material.svg")
                    elif self.panel == "printing":
                        if self.style == "light":
                            self.get_svg(ctx, w, h, - w / 48, h / 82, 1.1, "material_d.svg",mode="light")
                        else:
                            self.get_svg(ctx, w, h, - w / 48, h / 82, 1.1, "material.svg")
                        ctx.move_to(-w / 6.1,
                                    h / 1.02)
                    else:
                        if self.style == "light":
                            self.get_svg(ctx, w, h, -w /50, h / 85, 1.1, "material_d.svg",mode="light")
                        else:
                            self.get_svg(ctx, w, h, -w /50, h / 85, 1.1, "material.svg")
                        ctx.move_to(-w / 6.1,
                                    h / 1.02)

                else:
                    if self.style == "light":
                        self.get_svg(ctx, w, h, 27.13, 1.17, 1.3, "nozzel.dia-light.svg",mode="light")
                    else:
                        self.get_svg(ctx, w, h, 27.13, 1.17, 1.3, "nozzel-dia-green.svg")
                    if self.style == "light":
                        self.get_svg(ctx, w, h, 27.13, 1.45, 1.3, "material_d.svg",mode="light")
                    else:
                        self.get_svg(ctx, w, h, 27.13, 1.45, 1.3, "material.svg")





                self.draw_active_circle(ctx, w/20, h/8.5, 10)

    def draw_active_circle(self, ctx, x, y, radius):
            if self.angle != 0:
                return

            ctx.set_source_rgb(248/255, 97/255, 97/255)  # Red color
            ctx.arc(x, y, radius, 0,
                    2 * math.pi)  # Use math.pi instead of cairo.PI
            ctx.fill()
            if self.park:
                ctx.set_source_rgb(135/255, 1, 149/255)  # Green color

                ctx.arc(x, y, radius, 0,
                        2 * math.pi)  # Use math.pi instead of cairo.PI
                ctx.fill()
    
    def get_svg(self,ctx,w,h,x,y,scale,svg,mode="dark"):
        home_dir = os.path.expanduser('~')
        svg_path = os.path.join(home_dir, "C2P_SCREEN", "css", mode,
                                "images", svg)
        handle = Rsvg.Handle.new_from_file(svg_path)

        scale = scale  # Scale facto
        ctx.save()
        ctx.translate(w / x, h / y)  # Position the SVG
        ctx.scale(scale, scale)  # Scale the SVG
        handle.render_cairo(ctx)  # Render the SVG
        ctx.restore()

    def set_current_temp(self, current_temp, progress=None,max_temp=None,active=False):
        self.current_temp = current_temp
        self.active = active
        self.max_temp = max_temp
        if progress is not None:
            if self.panel == "gcode":
                self.progress_motion = progress
            else:
                self.progress = progress
                GLib.timeout_add(90, self.update_progress)
        self.queue_draw()

    def set_park_status(self,park):
        self.park = park
        self.queue_draw()
    
    def set_target(self,target):
        self.target_temp = target
        self.queue_draw()
    
    def on_button_press(self, widget, event):
        """Detect which button is clicked."""
        if not self.active:
            return
        w = self.get_allocated_width()
        h = self.get_allocated_height()
        # circle_radius = h / 2.4

        if self.angle==0 and self.side == "right":
            # circle_center_x = w / 1.31
            # circle_center_y = h / 2

            # # Check if click is inside the circle button
            # if (event.x - circle_center_x) ** 2 + (
            #         event.y - circle_center_y) ** 2 <= circle_radius ** 2:
            #     self.pressed_home = True
            #
            #     print("Circle button pressed (horizontal)")

            # Check if click is inside the rectangle button
            if 0 <= event.x <= w and 0 <= event.y <= h:
                self.pressed_x = True
                self.command()
                print("Rectangle button pressed (horizontal)")
        elif self.side == "left":

            # Check if click is inside the rectangle button
            if (w/2.24) <= event.x <= w and 0<= event.y <= h:
                self.pressed_x = True
                self.command()
                print("Rectangle button pressed (horizontal)")
        else:

            if 0 <= event.x <= (w/1.043) and (h/2.12) <= event.y <= h:
                self.pressed_x = True
                self.command()
                print("Rectangle button pressed (vertical)")
            elif 35 <= event.x <= (116) and (
                        23) <= event.y <= 110 and self.command_circle is not None:

                self.pressed_home = True
                self.command_circle()
                print("circle button pressed (vertical)")
        print("X",event.x,"Y",event.y)
        self.queue_draw()
    
    def on_button_release(self, widget=None, event=None):
        """Release both buttons."""
        self.pressed_x = False
        self.pressed_home = False
        self.queue_draw()

    def change_button_color(self,color=None):
        if color is not None:
            self.tool_r,self.tool_g,self.tool_b = color[0],color[1],color[2]
        self.pressed_x = True
        self.queue_draw()

    def update_filament_color(self, color):
        self.filament_color = color
        self.queue_draw()

    def update_filament_type(self, name):
        self.filament_type = name
        self.queue_draw()
    def update_nozzle_size(self, name):
        self.nozzle_size = name
        self.queue_draw()
    def change_tool_number(self,tool_number):
        self.new_tool_label = tool_number
        self.queue_draw()
    def change_label_color_m(self):
        self.change_label_color = True
        self.queue_draw()

    def remove_change_label_color_m(self):
        self.change_label_color = False
        self.queue_draw()
    def update_progress_motion(self):
        self.progress_motion = 0
    def update_internal_circle(self,prog):
        self.progress_internal = prog