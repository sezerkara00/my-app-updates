import gi
import subprocess
import math
from elements.c2p_gtk import CtoPGtk

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk

class PasswordDialog(Gtk.Dialog):
    def __init__(self, screen,theme_path, title,label,command,buttons_labels=None,buttons_command=None,style="dark"):
        super().__init__(title=title, transient_for=screen, flags=0)

        ctop_gtk = CtoPGtk(screen, theme_path)
        self.set_default_size(screen.width / 1.45, screen.height / 3.2)
        self.title = title
        self.set_resizable(False)  # Prevent resizing the window
        self.set_decorated(False)  # Disable window decorations
        self.set_app_paintable(True)
        self.get_style_context().add_class("dialog")
        self.style = style
        self.connect('draw', self.draw)
        screenV = Gdk.Screen.get_default()
        visual = screenV.get_rgba_visual()
        if visual is not None and screenV.is_composited():
            self.set_visual(visual)

        box = self.get_content_area()
        label_g = Gtk.Label(label=label)
        border_box = ctop_gtk.c2p_box("dialog_box_margin", 450, 1,
                                      Gtk.Orientation.VERTICAL)



        box.pack_start(label_g, False, False, 5)
        box.add(border_box)
        self.entry = Gtk.Entry()
        self.entry .set_halign(Gtk.Align.CENTER)
        self.entry .set_valign(Gtk.Align.CENTER)
        self.entry.set_invisible_char("•")
        self.entry.get_style_context().add_class("entry")
        self.entry.connect("button-press-event", command)
        box.pack_start(self.entry, True, False, 5)
        if buttons_labels is not None:
            buttons_box = ctop_gtk.c2p_box()
            buttons_box.set_halign(Gtk.Align.END)
            buttons_box.set_valign(Gtk.Align.END)
            buttons = {}
            for b_label, b_command in zip(buttons_labels,buttons_command):
                 buttons[b_label] = ctop_gtk.Button_new(label=b_label,style="dialog_button")
                 buttons[b_label].connect("clicked",b_command)
                 buttons_box.pack_start(buttons[b_label], False, False, 10)
            box.pack_start(buttons_box,True,True,0)
        self.show_all()

    def draw(self, widget, context):
        # Widget dimensions
        allocation = self.get_allocation()
        width, height = allocation.width, allocation.height

        # Border and corner settings
        border_width = 5
        corner_radius = 20

        if self.style == "dark":
            background_color = (0.2588, 0.2588, 0.2588)  # Light gray with transparency
        else:
            background_color = (238/255, 241/255, 247/255) # Light gray with transparency

        # Fill the background with a rounded rectangle
        self.draw_rounded_rectangle(context, border_width, corner_radius,
                                    width, height, background_color, fill=True)

    def draw_rounded_rectangle(self, context, border_width, radius, width,
                               height, color, fill):
        # Set color
        context.set_source_rgba(*color)

        # Adjust for border width
        inset = border_width / 2

        # Draw rounded rectangle
        context.new_path()
        context.arc(radius + inset, radius + inset, radius, math.pi,
                    1.5 * math.pi)  # Top-left corner
        context.arc(width - radius - inset, radius + inset, radius,
                    1.5 * math.pi, 0)  # Top-right corner
        context.arc(width - radius - inset, height - radius - inset, radius, 0,
                    0.5 * math.pi)  # Bottom-right corner
        context.arc(radius + inset, height - radius - inset, radius,
                    0.5 * math.pi, math.pi)  # Bottom-left corner
        context.close_path()

        if fill:
            context.fill()
        else:
            context.set_line_width(border_width)
            context.stroke()

    def get_entry_text(self):
        return self.entry.get_text()

    def set_entry_text(self,text):
        return self.entry.set_text(text)