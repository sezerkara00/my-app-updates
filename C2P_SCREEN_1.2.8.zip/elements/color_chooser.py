import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
from elements.c2p_gtk import CtoPGtk

class ColorChooserWidget(Gtk.ColorButton):
    def __init__(self,command):
        super().__init__(title="Color Chooser")
        self.command = command
        self.get_style_context().add_class(
            "main_box")
        
        self.connect('color-set', self.on_color_activated)


    def on_color_activated(self, widget):
        color = widget.get_rgba()
        r = int(color.red * 255)
        g = int(color.green * 255)
        b = int(color.blue * 255)
        rgb_color = f"RGB ({r}, {g}, {b})"
        print(rgb_color)
        hex_color = f"#{self.rgb2hex(r, g, b)}"
        self.command(r,g,b)
        print(hex_color)
        self.set_title(f"{rgb_color}  {hex_color}")


    def rgb2hex(self, r, g, b):
        def rgb(c):
            if c < 0: return 0
            if c > 255: return 255
            return c

        r = rgb(r)
        g = rgb(g)
        b = rgb(b)

        val = "%02x%02x%02x" % (r, g, b)
        return (val.upper())

