import gi

gi.require_version("Gtk", "3.0")  # Use GTK 3
from gi.repository import Gtk, Gdk, GLib
from elements.c2p_gtk import CtoPGtk
import re
import textwrap


class PopupNotification(Gtk.Window):
    # Keep track of the active popup
    current_popup = None

    def __init__(self, message, screen, them_path, show_button=False, timeout=None, tipe="E"):
        """Create and display a popup notification."""
        # Close any existing popup before showing a new one
        if PopupNotification.current_popup:
            PopupNotification.current_popup.close_immediately()

        super().__init__(title="Notification", transient_for=screen, modal=True, destroy_with_parent=True)

        # Set this instance as the active popup
        PopupNotification.current_popup = self

        ctopgtk = CtoPGtk(screen, them_path)
        self.set_default_size(700, 150)
        self.set_resizable(False)
        self.set_decorated(False)  # Remove title bar
        self.set_modal(show_button)

        # Get the default screen and RGBA visual for transparency
        screen_n = Gdk.Screen.get_default()
        visual = screen_n.get_rgba_visual()
        if visual and screen_n.is_composited():
            self.set_visual(visual)

        if not isinstance(message, list):
            message = re.sub(r'\s+', ' ', message).strip()
            lines = message.split('\n')
            formatted_lines = []
            for line in lines:
                formatted_lines.extend(textwrap.fill(line, width=80,
                                                     break_long_words=False, break_on_hyphens=False).split('\n'))
            self.message = '\n'.join(formatted_lines)
        else:
            self.message = '\n'.join(message) if isinstance(message, list) else message

        self.connect("realize", self.move_to_top_center)

        # Apply styling based on the message type
        if tipe == "E":
            self.get_style_context().add_class("popup_error")
        elif tipe == "w" or tipe == "W":
            self.get_style_context().add_class("popup_warning")
        elif tipe in ("C", "S"):
            self.get_style_context().add_class("popup_correct")

        # Create a box layout
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        self.add(box)

        # Create and add message label
        self.label = Gtk.Label(label=self.message)
        self.label.set_line_wrap(True)
        self.label.set_justify(Gtk.Justification.LEFT)
        self.label.set_halign(Gtk.Align.CENTER)
        self.label.get_style_context().add_class("message_label")
        box.pack_start(self.label, True, True, 0)

        # Close button (optional)
        if show_button:
            close_button = ctopgtk.Button_new(image_name="error-dark", style="popup_button", scale=1.1)
            close_button.set_halign(Gtk.Align.END)
            close_button.set_valign(Gtk.Align.START)
            close_button.connect("clicked", self.on_close_clicked)
            box.pack_end(close_button, False, False, 0)

        # Auto-close after timeout if no button is shown
        if timeout and not show_button:
            GLib.timeout_add_seconds(timeout, self.fade_out_and_close)

        self.show_all()
        self.get_window().set_cursor(Gdk.Cursor.new_for_display(Gdk.Display.get_default(), Gdk.CursorType.BLANK_CURSOR))

    def is_visible(self):
        """Check if the popup is currently visible."""
        return self.get_visible()

    def fade_out_and_close(self):
        """Create a fade-out effect by incrementally decreasing opacity, then close."""

        def decrement_opacity():
            current_opacity = self.get_opacity()
            if current_opacity > 0.0:
                self.set_opacity(max(current_opacity - 0.1, 0.0))
                return True
            else:
                self.close_immediately()
                return False

        # Start the fade-out effect
        GLib.timeout_add(50, decrement_opacity)

    def close_immediately(self):
        """Close the popup immediately and remove it from the tracker."""
        if PopupNotification.current_popup == self:
            PopupNotification.current_popup = None  # Reset the tracker
        self.destroy()

    def on_close_clicked(self, button=None):
        """Handle close button click with fade-out effect."""
        self.fade_out_and_close()
        return False

    def move_to_top_center(self, *args):
        """Position the popup at the top-center of the screen."""
        screen = self.get_screen()
        monitor = screen.get_monitor_geometry(screen.get_primary_monitor())
        window_width, window_height = self.get_size()
        x = monitor.x + (monitor.width - window_width) // 2  # Center horizontally
        y = monitor.y + 10  # Slight padding from the top
        self.move(x, y)

    def dismiss(self):
        """Explicitly close the popup."""
        self.close_immediately()