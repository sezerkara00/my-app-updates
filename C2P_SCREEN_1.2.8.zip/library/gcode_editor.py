import gi
import os
import re
from itertools import islice
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Pango, GLib, Gdk, GdkPixbuf




class GcodeEditor:
    def __init__(self, screen, file_name,home_dir,tipe=None):
        self.file_name = file_name
        self.show_create = False
        if tipe is not None:
            self.path = os.path.join(home_dir, 'printer_data', 'printer_gcode', file_name)
        else:
            self.path = os.path.join(home_dir, 'printer_data', 'gcodes', file_name)
        self.tools_extruder = {
            "T0":"extruder",
            "T1":"extruder1",
            "T2":"extruder2",
            "T3":"extruder3"
        }
        # self.start_point = 0
        # self.i = 0
        # self.start_count = 0
        self.lines_total = 100
        # self.first_lines_total = 0
        # self.old_lines_total = 0
        self.zero_or_one_val = 0
        self.line_number = 1
        self.start_page = []
        self.start = 0
        self.end = 0
        self.val = 0
        # self.lines = []
        # self.prev_start_point = 0
        # self.next_start_point = 0
        # self.last_val = 0
        # self.fark = 0
        # self.state = True
        # self.prev_state = False
        # self.next_state = False
        # self.lines_per_chunk = 100
        # self.current_line = 0
        self.combos = {}
        self.menu = {}
        self.old_replace_texts = []
        self.gcode_tools = {}
        self.gcode_tools_temperatures = {}
        # self.i = 0
        # new_tools = ["T0","T1","T2","T3"]
        # used_tools = []
        # n = 0

    def show_gcode_file(self):
        path = self.path
        if not os.path.exists(path):
            print(f"File not found: {path}")
            return
        with open(path, 'r') as file:
            found_m_command = False
            extracted_lines = []
            for line in file:
                if line.startswith("M") and not found_m_command:
                    found_m_command = True
                    continue
                if found_m_command:
                    extracted_lines.append(line.strip())
                    if len(extracted_lines) == self.lines_total:
                        break

        return extracted_lines
    
    def pars_gcode(self):
        tools = []
        extruder = []
        temp = []
        bed_temp = 0
        lines = self.show_gcode_file()
        try:
            for line in lines:
                if line.startswith("M104"):
                    parts = line.split()
                    t_value = None
                    s_value = None
                    for part in parts:
                        if part.startswith("T"):
                            t_value = part
                        if part.startswith("S"):
                            s_value = part[1:]
                    if s_value is not None and s_value != "0":
                        if t_value in self.tools_extruder:
                            ex_value = self.tools_extruder[t_value]
                            if ex_value:
                                tools.append(t_value)
                                extruder.append(ex_value)
                                temp.append(s_value)
                if line.startswith("M140"):
                    part_bed = line.split()[1]
                    bed_temp = part_bed[1:]
        except Exception as e:
            print(e)
            return tools,extruder, temp, bed_temp,self.tools_extruder

        return tools,extruder, temp, bed_temp,self.tools_extruder

    def process_file(self,file_path, new_tools, new_temps, new_bed_temp):

        with open(file_path, 'r') as file:
            print("111")
            lines = file.readlines()
            print("222")

        # Prepare a list to store modified lines
        modified_lines = []
        total_lines = len(lines)
        i = 0

        for line in lines:
            i += 1
            percentage = (i / total_lines) * 100
            if i % (total_lines // 5) == 0 or i == total_lines:
                GLib.idle_add(self.update_progress, percentage,
                              f"Now it is replacing, please wait...\n      {percentage:.2f}%")

            new_parts = []
            if 'T' in line and not line.startswith(";"):
                parts = line.split()
                if 'T0' in parts and 'T0' in new_tools:
                    if 'T0' == new_tools['T0'] or new_tools['T0'] == 'Tool select':
                        new_parts = ['S' + new_temps['T0'] if part.startswith("S") else part for part in parts]
                    else:
                        new_parts = [
                            new_tools['T0'] if part.startswith("T") else 'S' + new_temps['T0'] if part.startswith(
                                "S") else part for part in parts]
                elif 'T1' in parts and 'T1' in new_tools:
                    if 'T1' == new_tools['T1'] or new_tools['T1'] == 'Tool select':
                        new_parts = ['S' + new_temps['T1'] if part.startswith("S") else part for part in parts]
                    else:
                        new_parts = [
                            new_tools['T1'] if part.startswith("T") else 'S' + new_temps['T1'] if part.startswith(
                                "S") else part for part in parts]
                elif 'T2' in parts and 'T2' in new_tools:
                    if 'T2' == new_tools['T2'] or new_tools['T2'] == 'Tool select':
                        new_parts = ['S' + new_temps['T2'] if part.startswith("S") else part for part in parts]
                    else:
                        new_parts = [
                            new_tools['T2'] if part.startswith("T") else 'S' + new_temps['T2'] if part.startswith(
                                "S") else part for part in parts]
                elif 'T3' in parts and 'T3' in new_tools:
                    if 'T3' == new_tools['T3'] or new_tools['T3'] == 'Tool select':
                        new_parts = ['S' + new_temps['T3'] if part.startswith("S") else part for part in parts]
                    else:
                        new_parts = [
                            new_tools['T3'] if part.startswith("T") else 'S' + new_temps['T3'] if part.startswith(
                                "S") else part for part in parts]

                if new_parts:
                    new_line = ' '.join(new_parts) + '\n'
                    modified_lines.append(new_line)
                else:
                    modified_lines.append(line)
            elif line.startswith("M140") or line.startswith("M190"):
                parts = line.split()
                new_parts = ['S' + new_bed_temp if part.startswith("S") else part for part in parts]
                new_line = ' '.join(new_parts) + '\n'
                modified_lines.append(new_line)
            else:
                modified_lines.append(line)

        # Write the modified lines back to the file
        with open(file_path, 'w') as file:
            print("333")
            file.writelines(modified_lines)

    def replace_in_file(self, file_path, search_text, replace_text, temp, new_temp, bed_temp, new_bed_temp):
        bed_temp_changed = bed_temp != new_bed_temp
        temp_changed = temp != new_temp

        search_text_pattern = rf'\b{search_text}\b(?!;)'
        new_search_text = replace_text + ';'

        with open(file_path, 'r') as file, open(file_path + '.tmp', 'w') as temp_file:
            for line in file:
                if bed_temp_changed:
                    line = line.replace(f'M140 S{bed_temp}', f'M140 S{new_bed_temp}')
                    line = line.replace(f'M190 S{bed_temp}', f'M190 S{new_bed_temp}')
                if temp_changed:
                    line = line.replace(f'S{temp} {search_text}', f'S{new_temp} {search_text}')
                line = re.sub(search_text_pattern, new_search_text, line)
                temp_file.write(line)

        # Replace the original file with the modified file
        os.replace(file_path + '.tmp', file_path)

        self.old_replace_texts.append(replace_text)

        if self.old_replace_texts and self.i == len(self.tools):
            # Open file again for final pass to remove semicolons
            with open(file_path, 'r') as file, open(file_path + '.tmp', 'w') as temp_file:
                for line in file:
                    for replace in self.old_replace_texts:
                        line = line.replace(f'{replace};', replace)
                    temp_file.write(line)
            os.replace(file_path + '.tmp', file_path)





        #self.Dialog_new()
            # new_bed_temp = self.bed_temp_button.get_label()
            # new_temp = self.labels["gcode_tools_temperatures"][tool].get_label()
            # if t in ['T0', 'T1', 'T2', 'T3']:
            #     self.replace_in_file(self.path, tool, t, temp, new_temp, self.bed_temp, new_bed_temp)
            # else:
            #     self.replace_in_file(self.path, tool, tool, temp, new_temp, self.bed_temp, new_bed_temp)
        #self.close_dialog()
        #self._screen.show_popup_message('Successful replacing', 'C', 5)

          # t1 = self.combos['T1'].get_label()
          # self.replace_in_file('/home/ddt-arge/2-Shape-Box.gcode', 'T0', t0)
          # t2 = self.combos['T0'].get_label()
          # self.replace_in_file('/home/ddt-arge/2-Shape-Box.gcode', 'T0', t0)
          # t3 = self.combos['T0'].get_label()
          # self.replace_in_file('/home/ddt-arge/2-Shape-Box.gcode', 'T0', t0)