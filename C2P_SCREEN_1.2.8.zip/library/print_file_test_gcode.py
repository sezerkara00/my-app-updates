import os
import logging
import time

class PrintFileLocal:
    def __init__(self, folder_name="printer_gcode"):
        self.folder_path = os.path.join(os.path.expanduser("~"), "printer_data", folder_name)
        self.thumbnail_path = os.path.join(self.folder_path, ".thumbs")
        self.files_other = {}  
        self.filelist_other = []  
        # self.refresh_interval = 10

    def scan_folder(self):
        if not os.path.exists(self.folder_path):
            logging.warning(f"Folder '{self.folder_path}' does not exist.")
            return

        new_files = []
        removed_files = self.filelist_other.copy()

        for file_name in os.listdir(self.folder_path):
            file_path = os.path.join(self.folder_path, file_name)

            if not file_name.lower().endswith('.gcode'):
                continue

            if os.path.isfile(file_path):  
                file_stat = os.stat(file_path)
                metadata = self.extract_or_append_metadata(file_path)
                file_info = {
                    "name": file_name,
                    "size": file_stat.st_size,
                    "modified": file_stat.st_mtime,
                    "estimated_time": metadata["estimated_time"],
                    "layer_height": metadata["layer_height"],
                    "object_height": metadata["object_height"],
                    "first_layer_height": metadata["first_layer_height"],
                    "gcode_start_byte": metadata["gcode_start_byte"] ,
                    "gcode_end_byte": metadata["gcode_end_byte"] ,
                    "thumbnails": self.get_thumbnail_location(file_name)
                }
                
                if file_name not in self.files_other:
                    new_files.append(file_name)
                
                self.files_other[file_name] = file_info

                if file_name in removed_files:
                    removed_files.remove(file_name)

        for file_name in removed_files:
            del self.files_other[file_name]
            self.filelist_other.remove(file_name)

        self.filelist_other.extend(new_files)

        logging.info(f"Scanned folder: {self.folder_path}")
        logging.info(f"Total files found: {len(self.filelist_other)}")

    def start_get_file(self):
        self.scan_folder()
        return True

    def get_files(self):
        return self.files_other

    def get_thumbnail_location(self, filename, small=False):
        thumbnails_path = os.path.join(self.folder_path, ".thumbs")
        if not os.path.exists(thumbnails_path):
            return None 
        if filename.endswith(".gcode"):
            filename = filename[:-6]  # remove `.gcode`
        thumbnail_files = [
            f for f in os.listdir(thumbnails_path)
            if f.startswith(filename) and f.endswith(".png") 
        ]
        if not thumbnail_files:
            return None
        thumbnail_files.sort(key=lambda x: int(x.split('-')[-1].split('x')[0]), reverse=True)
        if small:
            thumb_file = thumbnail_files[-1] 
        else:
            thumb_file = thumbnail_files[0] 
        thumbnail_path = os.path.join(thumbnails_path, thumb_file)
        if os.path.exists(thumbnail_path):
            return ['file', thumbnail_path]

        return None

    def extract_or_append_metadata(slef,file_path):
        metadata_keys = ["estimated_time", "layer_height", "object_height", "first_layer_height"]
        metadata = {key: None for key in metadata_keys}
        buffer_size = 1024 
        gcode_start_byte = None
        gcode_end_byte = None
        file_size = os.path.getsize(file_path)
        try:
            with open(file_path, "rb") as f:
                f.seek(-buffer_size, os.SEEK_END)
                lines = f.read().decode(errors="ignore").splitlines()
                for line in lines:
                    for key in metadata_keys:
                        if line.startswith(f"; {key}:"):
                            value = line.split(":")[1].strip()
                            if value.replace('.', '', 1).isdigit():  
                                metadata[key] = float(value) if '.' in value else int(value)
                            else:
                                metadata[key] = value

                missing_metadata = [f"; {key}: None" for key in metadata_keys if metadata[key] is None]
                if missing_metadata:
                    with open(file_path, "a") as f:
                        f.write("\n" + "\n".join(missing_metadata) + "\n")
                    logging.info(f"Added missing metadata: {missing_metadata}")

                f.seek(0)
                byte_position = 0
                while byte_position < file_size:
                    data = f.read(8192)
                    if not data:
                        break
                    lines = data.decode(errors="ignore").splitlines()
                    for line in lines:
                        if line.strip() and (line.strip().startswith("G") or line.strip().startswith("M")):
                            gcode_start_byte = byte_position
                            break
                    if gcode_start_byte is not None:
                        break
                    byte_position += len(data)
                f.seek(max(0, file_size - buffer_size), os.SEEK_SET)
                data = f.read().decode(errors="ignore").splitlines()
                for line in reversed(data):
                    if line.strip() and (line.strip().startswith("G") or line.strip().startswith("M")):
                        gcode_end_byte = file_size - len("\n".join(data[data.index(line):]))  # محاسبه موقعیت بایت
                        break

        except Exception as e:
            logging.error(f"Error extracting metadata from {file_path}: {e}")

        metadata["gcode_start_byte"] = gcode_start_byte
        metadata["gcode_end_byte"] = gcode_end_byte

        return metadata

