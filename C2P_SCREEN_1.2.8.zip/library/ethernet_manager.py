import subprocess
import re
import threading
from threading import Thread
from queue import Queue
import gi
import socket
import netifaces
import contextlib
import uuid
from library import NetworkManager

gi.require_version("Gtk", "3.0")
from gi.repository import GLib
import os
import dbus
from dbus.mainloop.glib import DBusGMainLoop

class WifiManagerff:
    networks_in_supplicant = []
    connected = False
    _stop_loop = False
    def __init__(self):
        self.connected_ssid = None
        self.event = threading.Event()
        self.network_interfaces = netifaces.interfaces()
        self.networks = {}
        self.wireless_interfaces = [
            iface for iface in self.network_interfaces if iface.startswith('w')]
        interface = self.wireless_interfaces[0]
        self.queue = Queue()
        self._callbacks = {
            "connected": [],
            "connecting_status": [],
            "scan_results": [],
            "popup": [],
        }
        ks_socket_file = "/tmp/.KS_wpa_supplicant"
        if os.path.exists(ks_socket_file):
            os.remove(ks_socket_file)
        print(interface)

        self.soc = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        self.soc.bind(ks_socket_file)
        self.soc.connect(f"/var/run/wpa_supplicant/{interface}")

        self.wpa_thread = WpaSocket(self, self.queue, self.callback)
        self.wpa_thread.start()
        self.wpa_cli("ATTACH", False)
        self.wpa_cli("SCAN", False)
        GLib.idle_add(self.read_wpa_supplicant)
        self.timeout = GLib.timeout_add_seconds(180, self.rescan)


    def callback(self, cb_type, msg):
        if cb_type in self._callbacks:
            for cb in self._callbacks[cb_type]:
                GLib.idle_add(cb, msg)
    def connect(self, ssid):
        netid = None
        for nid, net in self.supplicant_networks.items():
            if net['ssid'] == ssid:
                netid = nid
                break

        if netid is None:

            return False


        self.callback("connecting_status", f"Attempting to connect to {ssid}")
        self.wpa_cli(f"SELECT_NETWORK {netid}")
        self.save_wpa_conf()

    def delete_network(self, ssid):
        netid = None
        for i in list(self.supplicant_networks):
            if self.supplicant_networks[i]['ssid'] == ssid:
                netid = i
                break

        if netid is None:

            return
        self.wpa_cli(f"REMOVE_NETWORK {netid}")

        for netid in list(self.supplicant_networks):
            if self.supplicant_networks[netid]['ssid'] == ssid:
                del self.supplicant_networks[netid]
                break

        self.save_wpa_conf()

    def get_connected_ssid(self):
        return self.connected_ssid

    def get_current_wifi(self):
        con_ssid = os.popen("sudo iwgetid -r").read().strip()
        con_bssid = os.popen("sudo iwgetid -r -a").read().strip()
        # wpa_cli status output is unstable use it as backup only
        status = self.wpa_cli("STATUS").split('\n')
        variables = {}
        for line in status:
            arr = line.split('=')
            variables[arr[0]] = "=".join(arr[1:])
        prev_ssid = self.connected_ssid

        if con_ssid != "":
            self.connected = True
            self.connected_ssid = con_ssid
            for ssid, val in self.networks.items():
                self.networks[ssid]['connected'] = ssid == con_ssid
            if prev_ssid != self.connected_ssid:
                for cb in self._callbacks['connected']:
                    args = self.connected_ssid, prev_ssid
                    GLib.idle_add(cb, *args)
            return [con_ssid, con_bssid]
        elif "ssid" in variables and "bssid" in variables:
            self.connected = True
            self.connected_ssid = variables['ssid']
            for ssid, val in self.networks.items():
                self.networks[ssid]['connected'] = ssid == variables['ssid']
            if prev_ssid != self.connected_ssid:
                for cb in self._callbacks['connected']:
                    args = self.connected_ssid, prev_ssid
                    GLib.idle_add(cb, *args)
            return [variables['ssid'], variables['bssid']]
        else:

            self.connected = False
            self.connected_ssid = None
            for ssid, val in self.networks.items():
                self.networks[ssid]['connected'] = False
            if prev_ssid != self.connected_ssid:
                for cb in self._callbacks['connected']:
                    args = self.connected_ssid, prev_ssid
                    GLib.idle_add(cb, *args)
            return None

    def get_current_wifi_idle_add(self):
        self.get_current_wifi()
        return False

    def get_network_info(self, ssid=None, mac=None):
        if ssid is not None and ssid in self.networks:
            return self.networks[ssid]
        if mac is not None and ssid is None:
            for net in self.networks:
                if mac == net['mac']:
                    return net
        return {}

    def get_networks(self):
        return list(self.networks)

    def get_supplicant_networks(self):
        return self.supplicant_networks

    def read_wpa_supplicant(self):
        results = self.wpa_cli("LIST_NETWORKS").split('\n')
        results.pop(0)
        self.supplicant_networks = {}
        self.networks_in_supplicant = []
        for net in [n.split('\t') for n in results]:
            self.supplicant_networks[net[0]] = {
                "ssid": net[1],
                "bssid": net[2],
                "flags": net[3] if len(net) == 4 else ""
            }
            self.networks_in_supplicant.append(self.supplicant_networks[net[0]])

    def rescan(self):
        self.wpa_cli("SCAN", False)

    def save_wpa_conf(self):

        self.wpa_cli("SAVE_CONFIG")

    def scan_results(self):
        new_networks = []
        deleted_networks = list(self.networks)

        results = self.wpa_cli("SCAN_RESULTS").split('\n')
        results.pop(0)

        aps = []
        for res in results:
            match = re.match("^([a-f0-9:]+)\\s+([0-9]+)\\s+([\\-0-9]+)\\s+(\\S+)\\s+(.+)?", res)
            if match:
                net = {
                    "mac": match[1],
                    "channel": WifiChannels.lookup(match[2])[1],
                    "connected": False,
                    "configured": False,
                    "frequency": match[2],
                    "flags": match[4],
                    "signal_level_dBm": match[3],
                    "ssid": match[5]
                }

                if "WPA2" in net['flags']:
                    net['encryption'] = "WPA2"
                elif "WPA" in net['flags']:
                    net['encryption'] = "WPA"
                elif "WEP" in net['flags']:
                    net['encryption'] = "WEP"
                else:
                    net['encryption'] = "off"

                aps.append(net)

        cur_info = self.get_current_wifi()
        self.networks = {}
        for ap in aps:
            self.networks[ap['ssid']] = ap
            if cur_info is not None and cur_info[0] == ap['ssid'] and cur_info[1].lower() == ap['mac'].lower():
                self.networks[ap['ssid']]['connected'] = True

        for net in list(self.networks):
            if net in deleted_networks:
                deleted_networks.remove(net)
            else:
                new_networks.append(net)
        if new_networks or deleted_networks:
            for cb in self._callbacks['scan_results']:
                args = new_networks, deleted_networks
                GLib.idle_add(cb, *args)

    def wpa_cli(self, command, wait=True):
        if wait is False:
            self.wpa_thread.skip_command()
        self.soc.send(command.encode())
        if wait is True:
            return self.queue.get()

    def wpa_cli_batch(self, commands):
        for cmd in commands:
            self.wpa_cli(cmd)

class WpaSocket(Thread):
    def __init__(self, wm, queue, callback):
        super().__init__()

        self.queue = queue
        self.callback = callback
        self.soc = wm.soc
        self._stop_loop = False
        self.skip_commands = 0
        self.wm = wm

    def run(self):

        while self._stop_loop is False:
            try:
                msg = self.soc.recv(4096).decode().strip()
            except Exception as e:
                # TODO: Socket error
                continue
            if msg.startswith("<"):
                if "CTRL-EVENT-SCAN-RESULTS" in msg:
                    GLib.idle_add(self.wm.scan_results)
                elif "CTRL-EVENT-DISCONNECTED" in msg:
                    self.callback("connecting_status", msg)
                    match = re.match('<3>CTRL-EVENT-DISCONNECTED bssid=(\\S+) reason=3 locally_generated=1', msg)
                    if match:
                        for net in self.wm.networks:
                            if self.wm.networks[net]['mac'] == match[1]:
                                self.wm.networks[net]['connected'] = False
                                break
                elif "Trying to associate" in msg or "CTRL-EVENT-REGDOM-CHANGE" in msg:
                    self.callback("connecting_status", msg)
                elif "CTRL-EVENT-CONNECTED" in msg:
                    GLib.idle_add(self.wm.get_current_wifi_idle_add)
                    self.callback("connecting_status", msg)
            elif self.skip_commands > 0:
                self.skip_commands = self.skip_commands - 1
            else:
                self.queue.put(msg)


    def skip_command(self):
        self.skip_commands = self.skip_commands + 1


class WifiChannels:
    @staticmethod
    def lookup(freq):
        if freq == "2412":
            return "2.4", "1"
        if freq == "2417":
            return "2.4", "2"
        if freq == "2422":
            return "2.4", "3"
        if freq == "2427":
            return "2.4", "4"
        if freq == "2432":
            return "2.4", "5"
        if freq == "2437":
            return "2.4", "6"
        if freq == "2442":
            return "2.4", "7"
        if freq == "2447":
            return "2.4", "8"
        if freq == "2452":
            return "2.4", "9"
        if freq == "2457":
            return "2.4", "10"
        if freq == "2462":
            return "2.4", "11"
        if freq == "2467":
            return "2.4", "12"
        if freq == "2472":
            return "2.4", "13"
        if freq == "2484":
            return "2.4", "14"
        if freq == "5035":
            return "5", "7"
        if freq == "5040":
            return "5", "8"
        if freq == "5045":
            return "5", "9"
        if freq == "5055":
            return "5", "11"
        if freq == "5060":
            return "5", "12"
        if freq == "5080":
            return "5", "16"
        if freq == "5170":
            return "5", "34"
        if freq == "5180":
            return "5", "36"
        if freq == "5190":
            return "5", "38"
        if freq == "5200":
            return "5", "40"
        if freq == "5210":
            return "5", "42"
        if freq == "5220":
            return "5", "44"
        if freq == "5230":
            return "5", "46"
        if freq == "5240":
            return "5", "48"
        if freq == "5260":
            return "5", "52"
        if freq == "5280":
            return "5", "56"
        if freq == "5300":
            return "5", "60"
        if freq == "5320":
            return "5", "64"
        if freq == "5500":
            return "5", "100"
        if freq == "5520":
            return "5", "104"
        if freq == "5540":
            return "5", "108"
        if freq == "5560":
            return "5", "112"
        if freq == "5580":
            return "5", "116"
        if freq == "5600":
            return "5", "120"
        if freq == "5620":
            return "5", "124"
        if freq == "5640":
            return "5", "128"
        if freq == "5660":
            return "5", "132"
        if freq == "5680":
            return "5", "136"
        if freq == "5700":
            return "5", "140"
        if freq == "5720":
            return "5", "144"
        if freq == "5745":
            return "5", "149"
        if freq == "5765":
            return "5", "153"
        if freq == "5785":
            return "5", "157"
        if freq == "5805":
            return "5", "161"
        if freq == "5825":
            return "5", "165"
        if freq == "4915":
            return "5", "183"
        if freq == "4920":
            return "5", "184"
        if freq == "4925":
            return "5", "185"
        if freq == "4935":
            return "5", "187"
        if freq == "4940":
            return "5", "188"
        if freq == "4945":
            return "5", "189"
        if freq == "4960":
            return "5", "192"
        if freq == "4980":
            return "5", "196"
        return None

class LANManager:
    def __init__(self):

        pass

    def is_lan_connected(self,interface='eth0'):
        try:
            # Run the `ifconfig <interface>` command and capture the output
            result = subprocess.run(['ifconfig', interface],
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, text=True)

            # Check if the interface has an "inet" address, indicating it's connected
            if 'inet ' in result.stdout:
                return True
            else:
                return False
        except subprocess.CalledProcessError as e:
            print(f"Error occurred: {e}")
            return False
class WifiManager:
    networks_in_supplicant = []

    def __init__(self):
        super().__init__()
        DBusGMainLoop(set_as_default=True)
        self._callbacks = {
            "connected": [],
            "connecting_status": [],
            "scan_results": [],
            "popup": [],
        }
        self.connected = False
        self.connected_ssid = None
        self.network_interfaces = netifaces.interfaces()
        self.wireless_interfaces = [
            iface for iface in self.network_interfaces if iface.startswith('w')]
        
        # Initialize these attributes
        self.wifi_dev = None
        self.initialized = False
        self.interface_name = None
        
        if self.wireless_interfaces == []:
            print("No wireless interfaces found")
            return
            
        try:
            interface = self.wireless_interfaces[0]
            self.interface_name = interface
            self.known_networks = {}  # List of known connections
            self.visible_networks = {}  # List of visible access points
            self.ssid_by_path = {}
            self.path_by_ssid = {}
            self.hidden_ssid_index = 0

            self.wifi_dev = NetworkManager.NetworkManager.GetDeviceByIpIface(interface)
            self.wifi_dev.OnAccessPointAdded(self._ap_added)
            self.wifi_dev.OnAccessPointRemoved(self._ap_removed)
            self.wifi_dev.OnStateChanged(self._ap_state_changed)

            for ap in self.wifi_dev.GetAccessPoints():
                self._add_ap(ap)
            self._update_known_connections()
            self.initialized = True
        except Exception as e:
            print(f"Error initializing WiFi manager: {e}")
            self.initialized = False

    def disconnect(self):
        try:
            self.wifi_dev.Disconnect()
            print("Network Disconnected")
        except dbus.exceptions.DBusException as e:
            print("Error when disconnect", e)

    def _update_known_connections(self):
        self.known_networks = {}
        for con in NetworkManager.Settings.ListConnections():
            settings = con.GetSettings()
            if "802-11-wireless" in settings:
                ssid = settings["802-11-wireless"]['ssid']
                self.known_networks[ssid] = con

    def _ap_added(self, nm, interface, signal, access_point):
        with contextlib.suppress(NetworkManager.ObjectVanished):
            ssid = self._add_ap(access_point)
            for cb in self._callbacks['scan_results']:
                args = (cb, [ssid], [])
                GLib.idle_add(*args)

    def _ap_removed(self, dev, interface, signal, access_point):
        path = access_point.object_path
        if path in self.ssid_by_path:
            ssid = self.ssid_by_path[path]
            self._remove_ap(path)
            for cb in self._callbacks['scan_results']:
                args = (cb, [ssid], [])
                GLib.idle_add(*args)

    def _ap_state_changed(self, nm, interface, signal, old_state, new_state, reason):
        msg = ""
        if new_state in (NetworkManager.NM_DEVICE_STATE_UNKNOWN, NetworkManager.NM_DEVICE_STATE_REASON_UNKNOWN):
            msg = "State is unknown"
        elif new_state == NetworkManager.NM_DEVICE_STATE_UNMANAGED:
            msg = "Error: Not managed by NetworkManager"
        elif new_state == NetworkManager.NM_DEVICE_STATE_UNAVAILABLE:
            msg = "Error: Not available for use:\nReasons may include the wireless switched off, missing firmware, etc."
        elif new_state == NetworkManager.NM_DEVICE_STATE_DISCONNECTED:
            msg = "Currently disconnected"
        elif new_state == NetworkManager.NM_DEVICE_STATE_PREPARE:
            msg = "Preparing the connection to the network"
        elif new_state == NetworkManager.NM_DEVICE_STATE_CONFIG:
            msg = "Connecting to the requested network..."
        elif new_state == NetworkManager.NM_DEVICE_STATE_NEED_AUTH:
            msg = "Authorizing"
        elif new_state == NetworkManager.NM_DEVICE_STATE_IP_CONFIG:
            msg = "Requesting IP addresses and routing information"
        elif new_state == NetworkManager.NM_DEVICE_STATE_IP_CHECK:
            msg = "Checking whether further action is required for the requested network connection"
        elif new_state == NetworkManager.NM_DEVICE_STATE_SECONDARIES:
            msg = "Waiting for a secondary connection (like a VPN)"
        elif new_state == NetworkManager.NM_DEVICE_STATE_ACTIVATED:
            msg = "Connected"
        elif new_state == NetworkManager.NM_DEVICE_STATE_DEACTIVATING:
            msg = "A disconnection from the current network connection was requested"
        elif new_state == NetworkManager.NM_DEVICE_STATE_FAILED:
            msg = "Failed to connect to the requested network"
            self.callback("popup", msg)
        elif new_state == NetworkManager.NM_DEVICE_STATE_REASON_DEPENDENCY_FAILED:
            msg = "A dependency of the connection failed"
        elif new_state == NetworkManager.NM_DEVICE_STATE_REASON_CARRIER:
            msg = ""
        else:
            print(f"State {new_state}")
        if msg != "":
            self.callback("connecting_status", msg)

        if new_state == NetworkManager.NM_DEVICE_STATE_ACTIVATED:
            self.connected = True
            for cb in self._callbacks['connected']:
                args = (cb, self.get_connected_ssid(), None)
                GLib.idle_add(*args)
        else:
            self.connected = False

    def _ap_prop_changed(self, ap, interface, signal, properties):
        pass

    def _add_ap(self, ap):
        ssid = ap.Ssid
        if ssid == "":
            ssid = ("Hidden") + f" {self.hidden_ssid_index}"
            self.hidden_ssid_index += 1
        self.ssid_by_path[ap.object_path] = ssid
        self.path_by_ssid[ssid] = ap.object_path
        self.visible_networks[ap.object_path] = ap
        return ssid

    def _remove_ap(self, path):
        self.ssid_by_path.pop(path, None)
        self.visible_networks.pop(path, None)

    def add_callback(self, name, callback):
        if name in self._callbacks and callback not in self._callbacks[name]:
            self._callbacks[name].append(callback)

    def callback(self, cb_type, msg):
        if cb_type in self._callbacks:
            for cb in self._callbacks[cb_type]:
                GLib.idle_add(cb, msg)

    def add_network(self, ssid, psk):
        aps = self._visible_networks_by_ssid()
        if ssid in aps:
            ap = aps[ssid]
        new_connection = {
            '802-11-wireless': {
                'mode': 'infrastructure',
                'security': '802-11-wireless-security',
                'ssid': ssid
            },
            '802-11-wireless-security': {
                'auth-alg': 'open',
                'key-mgmt': 'wpa-psk',
                'psk': psk
            },
            'connection': {
                'id': ssid,
                'type': '802-11-wireless',
                'uuid': str(uuid.uuid4())
            },
            'ipv4': {
                'method': 'auto'
            },
            'ipv6': {
                'method': 'auto'
            }
        }
        try:
            NetworkManager.Settings.AddConnection(new_connection)
        except dbus.exceptions.DBusException as e:
            return False

        self._update_known_connections()
        return True

    def connect(self, ssid):
        if not self.initialized:
            print("WiFi manager not initialized")
            return False
            
        if ssid in self.known_networks:
            conn = self.known_networks[ssid]
            with contextlib.suppress(NetworkManager.ObjectVanished):
                msg = f"Connecting to: {ssid}"
                self.callback("connecting_status", msg)
                NetworkManager.NetworkManager.ActivateConnection(conn, self.wifi_dev, "/")

    def delete_network(self, ssid):
        for ssid in self.known_networks:
            con = self.known_networks[ssid]
            if con.GetSettings()['connection']['id'] == ssid:
                con.Delete()
        self._update_known_connections()

    def get_connected_ssid(self):
        try:
            if not self.initialized or not self.wifi_dev:
                return None
            ap = self.wifi_dev.SpecificDevice().ActiveAccessPoint
            return ap.Ssid if ap else None
        except Exception as e:
            print(f"Error getting connected SSID: {e}")
            return None

    def _get_connected_ap(self):
        return self.wifi_dev.SpecificDevice().ActiveAccessPoint

    def _visible_networks_by_ssid(self):
        aps = self.wifi_dev.GetAccessPoints()
        ret = {}
        for ap in aps:
            with contextlib.suppress(NetworkManager.ObjectVanished):
                ret[ap.Ssid] = ap
        return ret

    def get_network_info(self, ssid):
        netinfo = {}
        if ssid in self.known_networks:
            con = self.known_networks[ssid]
            with contextlib.suppress(NetworkManager.ObjectVanished):
                settings = con.GetSettings()
                if settings and '802-11-wireless' in settings:
                    netinfo.update({
                        "ssid": settings['802-11-wireless']['ssid'],
                        "connected": self.get_connected_ssid() == ssid
                    })

                    connected_ap = self._get_connected_ap()
                    if connected_ap:
                        signal_level = str(connected_ap.Strength) if hasattr(connected_ap, 'Strength') else 'Unknown'
                        netinfo["signal_level_dBm"] = signal_level
                        print(f" Signal Level for {ssid}: {signal_level} dBm")
                    else:
                        print(f"No connected AP found for {ssid}")

                return netinfo
        try:
            path = self.path_by_ssid[ssid]
            aps = self.visible_networks
            if path in aps:
                ap = aps[path]
                with contextlib.suppress(NetworkManager.ObjectVanished):
                    netinfo.update({
                        "mac": ap.HwAddress,
                        "channel": WifiChannels.lookup(str(ap.Frequency))[1],
                        "configured": ssid in self.known_networks,
                        "frequency": str(ap.Frequency),
                        "flags": ap.Flags,
                        "ssid": ssid,
                        "connected": self._get_connected_ap() == ap,
                        "encryption": self._get_encryption(ap.RsnFlags),
                        "signal_level_dBm": str(ap.Strength)
                    })
            return netinfo
        except:
            print(f"No path found for {ssid}")
            return None

    @staticmethod
    def _get_encryption(flags):
        encryption = ""
        if (flags & NetworkManager.NM_802_11_AP_SEC_PAIR_WEP40 or
                flags & NetworkManager.NM_802_11_AP_SEC_PAIR_WEP104 or
                flags & NetworkManager.NM_802_11_AP_SEC_GROUP_WEP40 or
                flags & NetworkManager.NM_802_11_AP_SEC_GROUP_WEP104):
            encryption += "WEP "
        if (flags & NetworkManager.NM_802_11_AP_SEC_PAIR_TKIP or
                flags & NetworkManager.NM_802_11_AP_SEC_GROUP_TKIP):
            encryption += "TKIP "
        if (flags & NetworkManager.NM_802_11_AP_SEC_PAIR_CCMP or
                flags & NetworkManager.NM_802_11_AP_SEC_GROUP_CCMP):
            encryption += "AES "
        if flags & NetworkManager.NM_802_11_AP_SEC_KEY_MGMT_PSK:
            encryption += "WPA-PSK "
        if flags & NetworkManager.NM_802_11_AP_SEC_KEY_MGMT_802_1X:
            encryption += "802.1x "
        return encryption.strip()
######control
    def get_networks(self):
        if not self.initialized:
            return []
        ssid_set = set(self.ssid_by_path.values())
        print("Unique SSID by Path:", ssid_set)
        return list(ssid_set)
    def get_known_networks(self):
        known_set = set(self.known_networks.keys())
        print("Unique Known Networks:", known_set)
        return list(known_set)

    def get_supplicant_networks(self):
        return {ssid: {"ssid": ssid} for ssid in self.known_networks.keys()}

    def rescan(self):
        if not self.initialized or not self.wifi_dev:
            return
        try:
            self.wifi_dev.RequestScan({})
        except dbus.exceptions.DBusException as e:
            print(f"Error during rescan: {e}")

    def is_wifi_connected(self):
        try:
            # Execute the iwgetid command to get the current Wi-Fi SSID
            wifi_name = subprocess.check_output(
                ["iwgetid", "-r"]).decode().strip()
            if wifi_name:
                # print(f"Connected to Wi-Fi network: {wifi_name}")
                return True
            else:
                # print("Not connected to any Wi-Fi network.")
                return False
        except subprocess.CalledProcessError:
            return False


    def get_active_ethernet_device(self):
        try:
            # Get active connections
            result = subprocess.run(
                ['nmcli', '-t', '-f', 'NAME,TYPE,DEVICE', 'connection', 'show'],
                capture_output=True, text=True, check=True
            )

            # Split output into lines
            connections = result.stdout.strip().split('\n')

            # Check each connection
            for line in connections:
                # -t parameters are separated by ':'
                fields = line.split(':')
                if len(fields) >= 2:
                    name, conn_type, device = fields[0], fields[1], fields[2]

                    # Find Ethernet connection (802-3-ethernet type and eth0'a connected)
                    if device == 'eth0' or device == 'eno1' or device == 'end0' or conn_type == '802-3-ethernet':
                        return name,conn_type,device

            return None


        except subprocess.CalledProcessError  as e:
            print(f"❌ Error: {e}")
            return None


    def get_active_wifi_device(self):
        try:
            # get active connections with nmcli
            result = subprocess.run(
                ['nmcli', '-t', '-f', 'NAME,TYPE,DEVICE', 'connection', 'show'],
                capture_output=True, text=True, check=True
            )

            # split output into lines
            connections = result.stdout.strip().split('\n')

            # check each connection
            for line in connections:
                # -t parameters are separated by ':'
                fields = line.split(':')
                if len(fields) >= 2:
                    name, conn_type, device = fields[0], fields[1], fields[2]

                    # find ethernet connection (802-3-ethernet type and eth0'a connected)
                    if conn_type == 'wifi' or conn_type == '802-11-wireless' :
                        return name,conn_type,device

            return None

        except subprocess.CalledProcessError  as e:
            print(f"❌ Error: {e}")
            return None


    def set_manual_ip_address(self,connection_name,ip_cidr,gateway_ip):
                    # Set the IP addresses
        subprocess.run([
                "nmcli", "con", "mod", connection_name,
                "ipv4.addresses", ip_cidr,
                "ipv4.gateway", gateway_ip,
                "ipv4.dns", gateway_ip,
                "ipv4.method", "manual"
        ], check=True)

            # Connect to the network
        subprocess.run(["nmcli", "con", "down", connection_name], check=True)
        subprocess.run(["nmcli", "con", "up", connection_name], check=True)


    def set_static_ip_wlan(self,device):
        subprocess.run(["sudo", "ifconfig", device, "0.0.0.0"])
        subprocess.run(["sudo", "dhclient", device])
        # Get IP info
        result = subprocess.run(["ifconfig", device], capture_output=True, text=True)
        return result

    def close_wifi_connection(self):
        result = subprocess.run(["nmcli", "radio", "wifi", "off"], capture_output=True)
        return result.returncode == 0  

    def open_wifi_connection(self):
        result = subprocess.run(["nmcli", "radio", "wifi", "on"], capture_output=True)
        return result.returncode == 0 
    

    def new_rescan(self):
        try:
            subprocess.run(["sudo", "nmcli", "device", "wifi", "rescan"], check=True)
            ssids=subprocess.check_output(["sudo", "nmcli", "-t", "-f", "SSID", "device", "wifi", "list"]).decode().strip().split("\n")
            ssids = [ssid for ssid in ssids if ssid.strip() != ""]
            return ssids
        except Exception as e:
            print(f"❌ Error: {e}")
            return []