import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk

from elements.c2p_gtk import CtoPGtk  # Assuming this exists
from library.notification_logger import NotificationLogger

class ShowLogNotificationDialog(Gtk.Box):
    MAX_VISIBLE_LOGS = 10  # Max log entries visible before scrolling

    def __init__(self, screen, theme_path, log_entries):
        """
        A dialog to show log notifications with scrolling support.

        Args:
            screen (Gtk.Window): The parent window.
            theme_path (str): Path for themes.
            log_entries (list or dict): List of log messages or dictionary containing log messages.
        """
        super().__init__(orientation=Gtk.Orientation.VERTICAL)

        self.ctop_gtk = CtoPGtk(screen, theme_path)
        self.screen = screen
        self.theme_path = theme_path

        # Main content area
        content_area = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,
                                             width=screen.width / 1.45,
                                             height=screen.height / 3.2,
                                             style="dialog")
        content_area.set_valign(Gtk.Align.CENTER)
        content_area.set_halign(Gtk.Align.CENTER)

        # Info box
        box_info = self.ctop_gtk.c2p_box("dialog_box_info")
        image_info = self.ctop_gtk.Image("info-dialog")
        box_info.pack_start(image_info, False, False, 0)

        # Title label
        title_label = self.ctop_gtk.c2p_label("Notification Logs", "message_label")  # Changed title
        box_info.pack_start(title_label, False, False, 0)
        # Separator line
        border_box = self.ctop_gtk.c2p_box("dialog_box_margin", 400, 1,
                                           Gtk.Orientation.VERTICAL)
        border_box.set_vexpand(False)

        # Create a scrolled window
        self.scrolled_window = self.ctop_gtk.ScrolledWindow(style="scrolled_window")
        self.scrolled_window.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.scrolled_window.set_min_content_height(400)  # Set a fixed height
        self.scrolled_window.set_min_content_width(600)

        # Create a log box container
        self.log_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,
                                             spacing=5)
        self.log_box.set_halign(Gtk.Align.START)
        self.log_box.set_valign(Gtk.Align.START)

        if isinstance(log_entries, dict):
            log_entries = list(log_entries.values())

        self.populate_logs(log_entries)

        # Add the log box to the scrolled window
        self.scrolled_window.add_with_viewport(self.log_box)

        # Box for buttons
        buttons_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
        buttons_box.set_halign(Gtk.Align.END)
        buttons_box.set_valign(Gtk.Align.END)
        buttons_box.set_margin_end(20)
        buttons_box.set_margin_bottom(10)
        # Cancel button
        back_button = self.ctop_gtk.Button_new(label="Back", style="dialog_button")
        back_button.connect("clicked", self.on_back_clicked)

        # Apply button
        clear_button = self.ctop_gtk.Button_new(label="Clear", style="dialog_button")
        clear_button.connect("clicked", self.on_apply_clicked)

        # Add buttons to box
        buttons_box.pack_end(back_button, False, False, 30)
        buttons_box.pack_end(clear_button, False, False, 30)

        # Attach elements to the dialog layout
        content_area.pack_start(box_info, False, False, 0)
        content_area.pack_start(border_box, False, False, 0)
        content_area.pack_start(self.scrolled_window, True, True, 0)
        content_area.pack_end(buttons_box, False, False, 0)
        self.pack_start(content_area, True, True, 0)
        # Show all elements
        self.show_back_dialog()

    def populate_logs(self, log_entries):
        """
        Populate the log box with log entries.

        Args:
            log_entries (list): List of log messages.
        """
        for log in log_entries:
            # Ana kart container'ı
            card_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,
                                             style="log-card")
            card_box.set_margin_start(15)
            card_box.set_margin_end(15)
            card_box.set_halign(Gtk.Align.FILL)
            card_box.set_hexpand(True)

            # Log mesajını parçalara ayır (tarih | hata türü | mesaj)
            date, type, message = log.split(" | ")

            # Tarih için box
            date_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
            date_box.set_halign(Gtk.Align.START)
            date_label = self.ctop_gtk.c2p_label(date, "log-date-text")
            date_box.pack_start(date_label, False, False, 0)

            # Tip için box ve stil belirleme
            type_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
            type_box.set_halign(Gtk.Align.START)

            # Tipe göre stil seçimi
            type_style = "log-error-text"  # Varsayılan stil
            if type.upper() == "ERROR":
                type_style = "log-error-text"
            elif type.upper() == "WARNING":
                type_style = "log-warning-text"
            elif type.upper() == "SUCCESS":
                type_style = "log-success-text"

            type_label = self.ctop_gtk.c2p_label(type, type_style)
            type_box.pack_start(type_label, False, False, 0)

            # Mesaj için box
            message_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
            message_box.set_halign(Gtk.Align.FILL)
            message_box.set_hexpand(True)
            message_label = self.ctop_gtk.c2p_label(message, "log-message-text")
            message_label.set_line_wrap(True)
            message_label.set_xalign(0)  # Sol hizalama
            message_label.set_hexpand(True)
            message_box.pack_start(message_label, True, True, 0)

            # Kartın içine elemanları yerleştir
            card_box.pack_start(date_box, False, False, 5)
            card_box.pack_start(type_box, False, False, 5)
            card_box.pack_start(message_box, True, True, 5)

            # Ana log box'a kartı ekle
            self.log_box.pack_start(card_box, False, True, 5)

            # Kartlar arası ayraç
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.get_style_context().add_class("scrolled_window")
            self.log_box.pack_start(separator, False, True, 5)

        if len(log_entries) > self.MAX_VISIBLE_LOGS:
            self.scrolled_window.set_vexpand(True)
        else:
            self.scrolled_window.set_vexpand(False)

        self.log_box.show_all()

    def update_logs(self, new_logs):
        """
        Update the log entries dynamically.

        Args:
            new_logs (list or dict): New log messages.
        """
        for child in self.log_box.get_children():
            self.log_box.remove(child)  # Clear previous logs

        if isinstance(new_logs, dict):
            new_logs = list(new_logs.values())

        self.populate_logs(new_logs)

    def on_back_clicked(self, button):
        """Close the dialog when the back button is clicked."""
        self.dialog_window.destroy()

    def on_apply_clicked(self, button):
        """Clear all logs and update the notification count."""
        logger = NotificationLogger()
        logger.clear_logs()
        logger.reset_log_count()
        self.update_logs([])


    def show_back_dialog(self):
        # Create window
        self.dialog_window = Gtk.Window(title="Notification Logs")
        self.dialog_window.set_transient_for(self.screen)
        self.dialog_window.set_modal(True)
        self.dialog_window.set_decorated(False)
        self.dialog_window.set_resizable(False)
        self.dialog_window.get_style_context().add_class("power_panel")
        self.dialog_window.set_default_size(self.screen.width, self.screen.height)

        # RGBA visual settings
        screen = Gdk.Screen.get_default()
        visual = screen.get_rgba_visual()
        if visual is not None and screen.is_composited():
            self.dialog_window.set_visual(visual)

            # Add box to window
        self.dialog_window.add(self)
        self.dialog_window.show_all()