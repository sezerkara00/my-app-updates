from elements.c2p_gtk import CtoPGtk
from gi.repository import Gtk, GLib, Gdk
import os

from elements.keyboard import VirtualKeyboard
from elements.keypad import Keypad
from elements.password_dialog import PasswordDialog
from elements.popup import PopupNotification
from library.global_manager import GlobalVariables



class LockPanel(Gtk.Window):

    def __init__(self, screen, theme_path):
        super().__init__(title="Power Panel")
        self.screen = screen
        self.theme_path = theme_path
        self.set_default_size(800, 1280)
        self.set_resizable(False)  # Prevent resizing the window
        self.set_decorated(False)  # Disable window decorations
        self.get_style_context().add_class("power_panel")
        self.style = GlobalVariables.get_style()


        self.ctop_gtk = CtoPGtk(screen,theme_path)
        screenV = Gdk.Screen.get_default()
        visual = screenV.get_rgba_visual()
        if visual is not None and screenV.is_composited():
            self.set_visual(visual)
        self.lock_button = self.ctop_gtk.Button_new("lock-big", label="Screen Locked", style="power_buttons", scale=3)
        self.lock_button.connect("clicked", self.on_screen_click, screen, theme_path)
        self.lock_button.set_halign(Gtk.Align.CENTER)
        self.lock_button.set_valign(Gtk.Align.CENTER)
        self.add(self.lock_button)
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
       # self.connect("button-press-event", self.on_screen_click)
        self.show_all()

    def on_screen_click(self,widget,screen,theme_path):
        self.dialog_password = PasswordDialog(screen, theme_path, title=f"🔑 Connect to Screen",
                                              label=f"🔐 Enter password for connect to screen:",
                                              command=lambda a, b: self.show_keyboard(a, b),
                                              buttons_labels=["Unlock","Cancel"],style=self.style,
                                              buttons_command=[lambda a: self.on_correct_password(a),lambda a: self.close_pass_word_dialog(a)])


    def close_pass_word_dialog(self,widget):
        self.dialog_password.destroy()
    # def connect_to_screen(self,widget):
    #     if  self.dialog_password.get_entry_text() == "1234":
    #         self.dialog_password.destroy()
    #         self.lock_button.set_image(self.ctop_gtk.Image("unlock"))
    #         self.lock_button.set_label("unlock")
    #         GLib.timeout_add(2000, self.delayed_destroy)
    #     else:
    #         PopupNotification(
    #             message=f"The password is wrong",
    #             screen=self.screen,
    #             them_path=self.theme_path,
    #             show_button=False,
    #             timeout=5,
    #             tipe='E'
    #         )
    def show_keyboard(self,widget=None,event=None):
       keypad =  Keypad(self.screen, self.theme_path,  self.on_edit_changed)
       keypad.show_keypad(widget,"")

    def on_edit_changed(self, entrytext):
        self.dialog_password.set_entry_text(str(int(entrytext)))

    def on_correct_password(self,widget):
        if self.dialog_password.get_entry_text() == "1234":
            self.dialog_password.destroy()
            self.lock_button.set_label("unlocking..")

            # Initialize animation parameters
            self.animation_counter = 0
            # List of image names you want to alternate between; replace "image1" and "image2" with your actual image identifiers.
            self.animation_images = ["lock-big", "unlock"]

            # Start the animation timer: every 200ms, call animate_button
            self.animation_id = GLib.timeout_add(200, self.animate_button)

            # After 2 seconds (2000ms), stop the animation and then destroy the dialog
            GLib.timeout_add(2000, self.stop_animation_and_destroy)

    def animate_button(self):
        # Toggle between two images based on animation_counter
        image_to_show = self.animation_images[self.animation_counter % 2]
        self.lock_button.set_image(self.ctop_gtk.Image(image_to_show))
        self.animation_counter += 1
        return True  # Returning True keeps the timer running

    def stop_animation_and_destroy(self):
        # Stop the animation timer
        GLib.source_remove(self.animation_id)
        # Now destroy the dialog (or perform any other final action)
        self.destroy()
        return False  # Returning