
from library.global_manager import GlobalVariables


from elements.c2p_gtk import CtoPGtk
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
import os


class Print_panel(GlobalVariables):

    def __init__(self,screen):

        self.img_width = 50
        self.img_height = 50
        self.file_image = None
        self.ctopgtk = CtoPGtk
        self.screen = screen

        # self.old_printfile = OldPrintfile()
        # self.dict_file_old = self.old_printfile._GetPintInfo(1)
        # self.keys1 = list(self.dict_file_old.keys())


        #self.add_file(self.keys1[0])

    def add_file(self, filepath):
        filename = os.path.basename(filepath)
        if filename.startswith("."):
            return
        self.image_load(filepath)
        print("")

    def show_last_printed_file(self):

        files = list(self.dict_file_old.keys())
        image = self.image_load(files[0])
        if image is not None:
            for child in self.image_box.get_children():
                self.image_box.remove(child)
            info = self.mainp.get_file_info(files[0])
            time = info["estimated_time"]
            hours = time // 3600
            minutes = (time % 3600) // 60
            formatted_time = self.ctop_gtk.c2p_label(f"Time : {int(hours)}h.{int(minutes)}m", "info_label")

            extruder_temp = self.ctop_gtk.c2p_label(f'First Layer Temp : {info["first_layer_extr_temp"]}', "info_label")

            bed_temp = self.ctop_gtk.c2p_label(f'Bed Temp : {info["first_layer_bed_temp"]}', "info_label")

            filament_total = self.ctop_gtk.c2p_label(f'Filament : {info["filament_total"]}', "info_label")

            layers_count = self.ctop_gtk.c2p_label(f'Layers : {info["object_height"] / info["layer_height"]:.0f}',
                                                   "info_label")

            info_box = self.ctop_gtk.c2p_box(spacing=15, orientation=Gtk.Orientation.VERTICAL)
            info_box.set_valign(Gtk.Align.CENTER)

            info_box.add(formatted_time)
            info_box.add(extruder_temp)
            info_box.add(bed_temp)
            info_box.add(filament_total)
            info_box.add(layers_count)
            for child in info_box.get_children():
                child.set_halign(Gtk.Align.START)
            self.image_box.pack_start(image, True, True, 0)
            self.image_box.pack_start(info_box, True, True, 0)

            self.image_box.show_all()
            return False
        else:
            return True

    def get_file_image(self, filename, width=None, height=None, small=False):
        if self.screen is None:
            return None
        loc = self.screen.get_thumbnail_location(filename, small)
        if loc is None:
            return None
        width = width if width is not None else self.img_width
        height = height if height is not None else self.img_height
        if loc[0] == "file":
            return self.ctop_gtk.PixbufFromFile(loc[1], width, height)
        if loc[0] == "http":
            return self.ctop_gtk.PixbufFromHttp(loc[1], width, height)
        return None

    def image_load(self, filepath):
        pixbuf = self.get_file_image(filepath, width=150, height=150)
        # Check if pixbuf is None
        if pixbuf is not None:

            file_image = (Gtk.Image.new_from_pixbuf(pixbuf))
            return file_image

        else:
            return None