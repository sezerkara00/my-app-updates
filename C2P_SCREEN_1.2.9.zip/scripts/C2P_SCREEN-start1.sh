#!/bin/bash
# Start the X server if not already running

echo "Starting X server..."
/usr/bin/X :0 &

# Set DISPLAY environment variable
export DISPLAY=:0

sleep 0.3


echo "Starting xcompmgr..."
/usr/bin/xcompmgr  &


# Start the GUI application
echo "Starting C2P_SCREEN..."
/home/pi/.KlipperScreen-env/bin/python /home/pi/C2P_SCREEN/main_screen.py


