import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GdkPixbuf, Gdk
from elements.c2p_gtk import CtoPGtk
import os
import re
import math
import textwrap
from functools import partial

class C2PDialog(Gtk.Window):
    def __init__(self, screen, parent, message,style=None, restart=False, confirm=False,tipe="error",button_names=None,title="info",image_name = None,theme_path = None, commands= None,sp_commands = None,check_disable_button=None):
        super().__init__(title="Error")
        self.ctop_gtk = CtoPGtk(screen,theme_path)
        self.set_default_size(screen.width, screen.height)
        self.control_count = 1
        self.set_decorated(False)
        self.set_modal(True)
        self.sp_commands = sp_commands
        self._check_disable_button = check_disable_button
        # Add a property to store the current button state
        self._buttons_disabled = False
       # self.set_app_paintable(True)
        self.get_style_context().add_class("power_panel")
        #self.connect('draw', self.draw)
        # Get the default screen and RGBA visual
        screen = Gdk.Screen.get_default()
        visual = screen.get_rgba_visual()
        # Split the string into words
        if not isinstance(message, list):
            message =  re.sub(r'\s+', ' ', message).strip()
            self.message = textwrap.fill(message, width=40, break_long_words=True, break_on_hyphens=False)
            rows = self.message.split("\n")
        else:
            self.message = message
            rows = message

        # Create ScrolledWindow
        print(f"Rows: {len(rows)}")
        scrolled_window = None
        # if len(rows) > 8:
        #     scrolled_window = Gtk.ScrolledWindow()
        #     # scrolled_window.get_style_context().add_class("scrolled_window")
        #     scrolled_window.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        #     scrolled_window.set_min_content_height(250)  # Set a fixed height
        if len(rows) > 8:
            scrolled_window = self.ctop_gtk.ScrolledWindow(style="scrolled_window")
            scrolled_window.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            scrolled_window.set_min_content_height(250)  # Set a fixed height
            scrolled_window.set_min_content_width(500)

        self.screen =screen

        self.content_grid = Gtk.Grid()

        self.content_grid.set_halign(Gtk.Align.CENTER)
        self.content_grid.set_valign(Gtk.Align.CENTER)
        self.content_grid.set_row_spacing(125)
        self.content_grid.set_column_spacing(40)
        print(f"Composited: {screen.is_composited()}")
        print(f"RGBA Visual: {screen.get_rgba_visual()}")
        if visual is not None and screen.is_composited():
            self.set_visual(visual)
        # Add a content area to the dialog

        content_area = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,width=800/1.45,height=1280/3.2,style="dialog")
        content_area.set_valign(Gtk.Align.CENTER)
        content_area.set_halign(Gtk.Align.CENTER)


        # Create a label with the error message

        if tipe != "control":
            self.message_label = self.ctop_gtk.c2p_label(self.message)
            if len(rows) > 8:
                self.message_label.get_style_context().add_class(
                    "message_label_with_scroll")
            else:
                self.message_label.get_style_context().remove_class(
                    "message_label_with_scroll")
                self.message_label.get_style_context().add_class(
                    "message_label")
            self.message_label.set_halign(Gtk.Align.CENTER)
            self.message_label.set_justify(Gtk.Justification.CENTER)  # Çok satırlı metinler için
            self.message_label.set_xalign(0)  # 0.0 = sola, 1.0 = sağa, 0.5 = ortala
            if scrolled_window:
                scrolled_window.add(self.message_label)
                self.content_grid.attach(scrolled_window, 0, 0, 1, 1)
            else:
                self.content_grid.attach(self.message_label, 0, 0, 1, 1)
        else:
            self.control_label = []
            self.control_image = []
            self.control_grid = Gtk.Grid()
            self.control_grid.set_column_spacing(20)
            for i, msg in enumerate(self.message):
                label = self.ctop_gtk.c2p_label(msg, "message_label")
                label.set_halign(Gtk.Align.START)
                self.control_label.append(label)
                if i == 0:
                    ellipse_image = self.ctop_gtk.Image("wait-dark", 20, 20)

                else:
                    ellipse_image = self.ctop_gtk.Image("Ellipse-dark", 20, 20)
                ellipse_image.get_style_context().add_class(
                    "message_label")
                self.control_image.append(ellipse_image)
                self.control_grid.attach(ellipse_image, 0, i, 1, 1)
                self.control_grid.attach(label, 1, i, 1, 1)
            self.content_grid.attach(self.control_grid, 0, 0, 1, 1)
            
            self.image_box = None
            if image_name is not None:
                self.image_box = self.ctop_gtk.c2p_box(style="image_box_dialog", width=150, height=200)
                dialog_image = self.ctop_gtk.Image(image_name, 100, 100)
                self.image_box.pack_start(dialog_image, True, True, 0)
                self.content_grid.attach(self.image_box, 1, 0, 1, 1)
                
                


        box_info = self.ctop_gtk.c2p_box("dialog_box_info")
        image_motion = Gtk.Image()
        image_info = self.ctop_gtk.Image("info-dialog")
        label =Gtk.Label(title)
        label.get_style_context().add_class("dialog_title")
        box_info.add(image_info)
        box_info.add(label)

        # For GIFs, use Gtk.Image with animation
        # pixbuf_motion = GdkPixbuf.PixbufAnimation.new_from_file(os.path.join(os.path.expanduser('~'), 'C2P_SCREEN', 'css','dark',
        #              'images','waiting.gif'))
        # image_motion.set_from_animation(pixbuf_motion)
        border_box = self.ctop_gtk.c2p_box("dialog_box_margin", 450, 1,
                                          Gtk.Orientation.VERTICAL)
        border_box.set_vexpand(False)

        #message_box = self.ctop_gtk.c2p_box()
        #message_box.add(self.message_label)
        #image_info = self.ctop_gtk.Image("info")

        content_area.add(box_info)
        content_area.add(border_box)
        content_area.add(self.content_grid)

        if button_names is not None:
            buttons = {}
            self.buttons_box = self.ctop_gtk.c2p_box()
            self.buttons_box.set_halign(Gtk.Align.CENTER)
            self.buttons_box.set_valign(Gtk.Align.END)
            resp = ""
            for i , button_name in enumerate(button_names):
                if commands is not None:
                    buttons[button_name] = self.ctop_gtk.Button_new(label=button_name,style="dialog_button")
                    buttons[button_name].connect("clicked",commands()[i])
                else:
                    if i == 0:
                        resp = "ok"
                        buttons[button_name] = self.ctop_gtk.Button_new(label=button_name,style="dialog_button")
                    elif i == 1:
                        resp = "cancel"
                        buttons[button_name] = self.ctop_gtk.Button_new(label=button_name,style="dialog_button")
                    elif i == 2:
                        resp = "apply"
                        buttons[button_name] = self.ctop_gtk.Button_new(label=button_name,style="dialog_button")
                    buttons[button_name].connect("clicked",self.on_response,resp)
                    buttons[button_name].get_style_context().add_class(
                         "dialog_button")
                    self.buttons_box.pack_start(buttons[button_name],True,True,0)
            #buttons_box.set_halign(Gtk.Align.CENTER)
            self.content_grid.attach(self.buttons_box,0,1,2,1)

            #  content_area.add(image_motion)
        #content_area.set_halign(Gtk.Align.CENTER)
       # self.ok_button = self.add_button(Gtk.STOCK_OK, Gtk.ResponseType.OK)

        # ok_button = self.add_button("Yes",
        #                                                Gtk.ResponseType.OK)
        # ok_button.set_valign(Gtk.Align.CENTER)
        # ok_button.get_style_context().add_class(
        #     "dialog_button")
        #
        # cancel_button = self.add_button("Cancel",
        #                             Gtk.ResponseType.CANCEL)
        # cancel_button.set_valign(Gtk.Align.CENTER)
        # cancel_button.get_style_context().add_class(
        #     "dialog_button")
       # self.connect("response", self.on_response)
        self.add(content_area)
        self.check_disable_button_function()
        # Show all widgets in the dialog
        self.show_all()

       # ok_button.set_visible(confirm)
        #cancel_button.set_visible(confirm)
    def update_error_message(self, new_message, show_button=False):
        self.message_label.set_text(new_message)
        #self.firmware_restart_button.set_visible(show_button)

    @property
    def check_disable_button(self):
        return self._check_disable_button

    @check_disable_button.setter
    def check_disable_button(self, value):
        self._check_disable_button = value
        # Automatically update button states when the value changes
        self.check_disable_button_function()

    def check_disable_button_function(self):
        if self.check_disable_button is None:
            return
            
        should_disable = self.check_disable_button
        if should_disable != self._buttons_disabled:
            self._buttons_disabled = should_disable
            for button in self.buttons_box.get_children():
                button.set_sensitive(not should_disable)
                if should_disable:
                    button.get_style_context().add_class("dialog_button_disabled")
                else:
                    button.get_style_context().remove_class("dialog_button_disabled")

    def draw(self, widget, context):
        # Widget dimensions
        allocation = self.get_allocation()
        width, height = allocation.width, allocation.height

        # Border and corner settings
        border_width = 5
        corner_radius = 20

        background_color = (128/255, 128/255, 128/255, 0.5)  # Light gray with transparency

        # Fill the background with a rounded rectangle
        self.draw_rounded_rectangle(context, border_width, corner_radius,
                                    width, height, background_color, fill=True)

        # Draw the border around the rounded rectangle
        # self.draw_rounded_rectangle(context, border_width, corner_radius,
        #                             width, height, border_color, fill=False)

    def draw_rounded_rectangle(self, context, border_width, radius, width,
                               height, color, fill):
        # Set color
        context.set_source_rgba(*color)

        # Adjust for border width
        inset = border_width / 2

        # Draw rounded rectangle
        context.new_path()
        context.arc(radius + inset, radius + inset, radius, math.pi,
                    1.5 * math.pi)  # Top-left corner
        context.arc(width - radius - inset, radius + inset, radius,
                    1.5 * math.pi, 0)  # Top-right corner
        context.arc(width - radius - inset, height - radius - inset, radius, 0,
                    0.5 * math.pi)  # Bottom-right corner
        context.arc(radius + inset, height - radius - inset, radius,
                    0.5 * math.pi, math.pi)  # Bottom-left corner
        context.close_path()

        if fill:
            context.fill()
        else:
            context.set_line_width(border_width)
            context.stroke()

    def on_destroy(self):
        self.destroy()
        
    def on_response(self,widget,response_id):
        if response_id == 'ok':
            if self.sp_commands is not None:
                self.sp_commands[0]()
            print("OK button pressed!")
            # Perform your action here
        elif response_id == "cancel":
            print("Cancel button pressed!")
            if self.sp_commands is not None:
                self.sp_commands[1]()
        elif response_id == "apply":
            print("Apply button pressed!")
            if self.sp_commands is not None:
                self.sp_commands[2]()
            # Perform any cancel-specific action here
        # self.destroy()
    
    def update_control_message(self, index):
        """
        Update the control grid to reflect the current state of messages.
        :param index: The index of the current "wait" message.
        """
        # Reset all labels and images in the grid
        for i, label in enumerate(self.control_label):
            # Reset styles for all labels
            label.get_style_context().remove_class("message_label_blue")
            label.get_style_context().remove_class("message_label_green")

            # Apply styles based on the current state
            if i < index:
                # Mark previous labels as "green"
                label.get_style_context().add_class("message_label_green")
            elif i == index:
                # Mark the current label as "blue" (wait)
                label.get_style_context().add_class("message_label_blue")

        # Remove all images from the grid
        for child in self.control_grid.get_children():
            self.control_grid.remove(child)

        # Rebuild the grid with updated images
        for i in range(len(self.control_image)):
            if i < index:
                # Create "green" image for completed steps
                new_image = self.ctop_gtk.Image("green-dark", 20, 20)
                new_image.get_style_context().add_class("message_label")
            elif i == index:
                # Create "wait" image for the current step
                new_image = self.ctop_gtk.Image("wait-dark", 20, 20)
                new_image.get_style_context().add_class("message_label")
            else:
                # Create default image for pending steps
                new_image = self.ctop_gtk.Image("Ellipse-dark", 20, 20)
                new_image.get_style_context().add_class("message_label")

            # Update the image in the control_image list
            self.control_image[i] = new_image

            # Attach the image to the grid
            self.control_grid.attach(new_image, 0, i, 1, 1)
            self.control_grid.attach(self.control_label[i], 1, i, 1, 1)

        # Refresh the grid to apply changes
        self.control_grid.show_all()

    def update_image(self, new_image_name):
        if self.content_grid is None:
            return 

        if self.image_box is not None:
            self.content_grid.remove(self.image_box)
            self.image_box.destroy()
            self.image_box = None

        if new_image_name:
            self.image_box = self.ctop_gtk.c2p_box(style="image_box_dialog", width=150, height=150)
            dialog_image = self.ctop_gtk.Image(new_image_name, width=150, height=150)
            self.image_box.pack_start(dialog_image, True, True, 0)
            self.content_grid.attach(self.image_box, 1, 0, 1, 1)
            self.image_box.show_all()

        self.content_grid.show_all()