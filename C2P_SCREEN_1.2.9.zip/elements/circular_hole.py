from select import select

import cairo
import math
import gi
gi.require_version("Gtk", "3.0")

from gi.repository import Gtk

class Make_Hole(Gtk.DrawingArea):
    def __init__(self,style):
        super().__init__()
        self.set_size_request(100, 100)
        self.hole_position_x=0
        self.connect("draw", self.on_draw)
        self.style = style
    def draw_header_with_hole(self,cr, _width, _height):
        """
        Draws a header with a circular hole at the bottom center using Cairo.

        Parameters:
            cr (cairo.Context): The Cairo drawing context.
            width (int): The width of the drawing area.
            height (int): The height of the drawing area.
        """
        # Fill the base rectangle first
        width, height = _width, _height
        r_cutout = 50  # Radius of the circular hole
        corner_radius = 25  # Radius of the rounded corners
        cr.new_path()

        # Dynamically set the X position of the hole
        if self.hole_position_x == 0:
            self.hole_position_x = width / 2

        center_x = self.hole_position_x  # X-coordinate of the hole's center
        center_y = 0  # Y-coordinate of the hole (always at the top in this case)
        cr.move_to(0, 0)

        # Top edge, stopping before the circular cutout
        cr.line_to(center_x - r_cutout - 21, 0)

        # Arc for the rounded corner before the cutout
        cr.arc(center_x - r_cutout - 21, corner_radius, corner_radius, math.pi,
               -3 * math.pi / 2)

        # Draw the circular cutout (dynamic position based on center_x)
        cr.arc(center_x, center_y, r_cutout, 3*math.pi/2, 2 * math.pi)

        # Arc for the rounded corner after the cutout
        cr.arc(center_x + r_cutout + 21, corner_radius, corner_radius, math.pi,
               3 * math.pi / 2)

        # Continue the line from the corner to the top-right corner
        cr.line_to(width , 0)

        # Top-right corner


        # Right edge
        cr.line_to(width, height)

        # Bottom edge
        cr.line_to(0, height)

        # Left edge
        cr.line_to(0, corner_radius)

        # Close the path and fill
        cr.close_path()
        cr.set_source_rgb(0.27, 0.27, 0.27)  # Gray background color
        if self.style == "light":
            cr.set_source_rgb(220/255, 220/255, 220/255)
        cr.fill()

        # Draw the circular cutout to clear the area (dynamic position)
        cr.set_source_rgb(0.145, 0.145, 0.145)  # Background color for the hole
        if self.style == "light":
            cr.set_source_rgb(0.9373, 0.9529, 1.0)
        cr.arc(center_x, center_y, r_cutout, 0, 2 * math.pi)
        cr.fill()
    def on_draw(self, widget, cr):
        width = widget.get_allocated_width()
        height = widget.get_allocated_height()
        # Call the function to draw the header with a hole
        self.draw_header_with_hole(cr, width, height)


    def on_button_clicked(self, button, source_button):
        # Get button position
        allocation = source_button.get_allocation()
        self.hole_position_x = allocation.x + allocation.width / 2


        # Redraw the drawing area
        self.queue_draw()
