import gi
# Import and set up the GTK library

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk,GLib,Gdk
from elements.c2p_gtk import CtoPGtk

class VirtualKeyboard(Gtk.Window):
    def __init__(self, screen, theme_path, text="",live_callback=None, final_callback=None):
        # Initialize the VirtualKeyboard class with specific configurations
        super().__init__(title="Virtual Keyboard")
        self.set_default_size(screen.width, screen.height)
        self.set_resizable(False)  # Prevent resizing the window
        self.set_decorated(False)  # Disable window decorations
        self.get_style_context().add_class("power_panel")  # Apply CSS styling
        screen = Gdk.Screen.get_default()
        visual = screen.get_rgba_visual()
        if visual is not None and screen.is_composited():
            self.set_visual(visual)
        self.timer_id = None
        # Text send modes and callback setup
        self.live_callback = live_callback  # Callback function for text send actions
        self.final_callback = final_callback
        self.current_word = text  # Temporary buffer for managing word send mode

        # Initialize the CtoPGtk helper and layout variables
        self.ctopgtk = CtoPGtk(screen, theme_path)
        self.is_uppercase = False  # Flag to toggle uppercase
        self.show_numbers = False  # Flag to toggle numeric keyboard
        
        # Main container box for the keyboard layout
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        main_box.set_size_request(500, 200)
        main_box.get_style_context().add_class("main_box")
        main_box.set_halign(Gtk.Align.CENTER)
        main_box.set_valign(Gtk.Align.CENTER)

        self.add(main_box)

        # Entry field and close button
        self.entry = Gtk.Entry()  # Input field for text entry
        self.entry.get_style_context().add_class("entry")
        self.entry.set_text(self.current_word)
        entry_box = self.ctopgtk.c2p_box()
        close_button = self.ctopgtk.Button_new("close_keypad", style="keyboard_close_button", scale=0.66)
        close_button.connect("clicked", self.close_keyboard)  # Close button callback
        entry_box.pack_start(self.entry, True, True, 5)
        entry_box.pack_start(close_button, False, True, 5)

        main_box.pack_start(entry_box, False, True, 5)

        # Keyboard grid for buttons
        self.keyboard_grid = Gtk.Grid(column_spacing=5, row_spacing=5)
        main_box.pack_start(self.keyboard_grid, True, True, 5)
        self.set_modal(True)  # Make it modal to block interactions with the parent window
     #   self.set_transient_for(screen)  # Make it behave like a dialog
        self.update_keyboard()  # Generate the initial keyboard layout

    def update_keyboard(self):
        """Update the keyboard layout based on the current state."""
        # Clear any existing buttons in the grid
        for child in self.keyboard_grid.get_children():
            self.keyboard_grid.remove(child)

        # Define keyboard layouts
        if self.show_numbers:
            # Numeric layout
            keys = [
                ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
                ["-", "/", ":", ";", "(", ")", "$", "&", "@", "\""],
                ["#", "%", "*", "+", "=", "_", ".", ",", "?", "del",],
                ["ABC", "space",  "enter"]
            ]
        else:
            # Alphabet layout
            keys = [
                ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
                ["A", "S", "D", "F", "G", "H", "J", "K", "L"],
                ["up", "Z", "X", "C", "V", "B", "N", "M", "123", "del"],
                ["123", "space", "enter"]
            ]

        # Toggle lowercase layout if needed
        if not self.is_uppercase and not self.show_numbers:
            keys = [[key.lower() for key in row] for row in keys]

        # Add buttons dynamically to the grid
        for row_idx, row in enumerate(keys):
            for col_idx, key in enumerate(row):
                if key == "space":
                    button = self.ctopgtk.Button_new(label=key, style="keyboard_button")
                    self.keyboard_grid.attach(button, col_idx, row_idx, 8, 1)  # Span multiple columns
                elif key == "enter":
                    button = self.ctopgtk.Button_new("enter_keyboard", style="keyboard_button", scale=0.66)
                    self.keyboard_grid.attach(button, 9, row_idx, 1, 1)
                elif key == "del":
                    button = self.ctopgtk.Button_new("delete_keyboard", style="keyboard_button", scale=0.66)
                    self.keyboard_grid.attach(button, col_idx, row_idx, 1, 1)
                elif key == "up":
                    button = self.ctopgtk.Button_new("up_keyboard", style="keyboard_button", scale=0.66)
                    self.keyboard_grid.attach(button, col_idx, row_idx, 1, 1)
                else:
                    button = self.ctopgtk.Button_new(label=key, style="keyboard_button")
                    self.keyboard_grid.attach(button, col_idx, row_idx, 1, 1)

                # Connect button to key press handler
                button.connect("clicked", self.on_key_pressed, key)
        self.show_all()

    def on_key_pressed(self, widget, key):
        """Handle key press events."""
        if key == "space":
            self.entry.set_text(self.entry.get_text() + " ")
            self.current_word += " "
        elif key == "del":
            self.entry.set_text(self.entry.get_text()[:-1])  # Remove last character
            self.current_word = self.current_word[:-1]
        elif key == "enter":
            if self.final_callback:
                self.final_callback(self.entry.get_text())  # 🔹 Final callback (Enter)
            self.close_keyboard(None)
            return
        elif key == "up":
            self.is_uppercase = not self.is_uppercase  # Toggle uppercase
            self.update_keyboard()
        elif key == "123":
            self.show_numbers = True  # Switch to numeric keyboard
            self.update_keyboard()
        elif key == "ABC":
            self.show_numbers = False  # Switch to alphabet keyboard
            self.update_keyboard()
        else:
            self.entry.set_text(self.entry.get_text() + key)  # Append character to text
            self.current_word += key
        self.reset_timer()

    def reset_timer(self):
        """Reset the inactivity timer."""
        if self.timer_id is not None:
            GLib.source_remove(self.timer_id) 
        self.timer_id = GLib.timeout_add(500, self.on_inactivity_timeout)

    def on_inactivity_timeout(self):
        """Handle timeout after inactivity."""
        if self.live_callback:
            self.live_callback(self.entry.get_text())
        self.timer_id = None
        return False
    
    def close_keyboard(self, widget):
        """Close the virtual keyboard."""
        if self.timer_id is not None:
            GLib.source_remove(self.timer_id)
        self.destroy()

