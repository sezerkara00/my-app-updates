import datetime

class NotificationLogger:
    _log_entries = {}  # Dictionary to store logs (key: timestamp+msg, value: log entry)
    _log_count = 0  # Persistent count of logs

    def __init__(self):
        """Initialize logger without resetting logs or count."""
        pass  # Ensures logs and count persist across instances

    def add_log(self, msg, msg_type="INFO"):
        """
        Add a new log entry to the list.

        Args:
            msg (str): The message to be logged.
            msg_type (str): The type of the message (INFO, ERROR, WARNING, SUCCESS).
        """
        msg_type = msg_type.upper()
        msg_type = {
            'E': "ERROR",
            'S': "SUCCESS",
            'C': "SUCCESS",
            'W': "WARNING"
        }.get(msg_type, "UNKNOWN")  # Default to UNKNOWN if invalid type

        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_key = f"{timestamp}"  # Unique key to prevent duplicates
        
        if log_key not in self._log_entries:
            self._log_entries[log_key] = f"{timestamp} | {msg_type} | {msg}"
            NotificationLogger._log_count += 1  # Increase count only if a new log is added

    def get_logs(self, limit=None):
        """
        Retrieve stored log entries.

        Args:
            limit (int, optional): Number of last log entries to return. Default: all logs.

        Returns:
            list: The requested log entries.
        """
        log_list = list(self._log_entries.values())  # Convert dictionary values to list
        if limit is None or limit > len(log_list):
            return log_list  # Return all logs if no limit is specified
        return log_list[-limit:]  # Return only the last 'limit' logs

    def get_log_count(self):
        """
        Get the total count of log messages.

        Returns:
            int: Number of log messages.
        """
        return NotificationLogger._log_count  # Returns persistent count

    def clear_logs(self):
        """
        Clear all stored logs but keep the log count.
        """
        self._log_entries.clear()  # Clears all logs

    def reset_log_count(self):
        """
        Reset only the log count without affecting stored logs.
        """
        NotificationLogger._log_count = 0  # Reset count without clearing logs
