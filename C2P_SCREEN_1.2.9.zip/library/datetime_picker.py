from datetime import datetime
import pytz
import subprocess
from library.c2p_config import C2PConfig, ConfigKeys


class DateTimePicker:

    def __init__(self, config=None):
        self.timezone_groups = {}
        self.config = config

    def get_timezone_list(self):
        important_timezones_other = {
            "Africa": {
                "Abidjan": "Africa/Abidjan",  # UTC±00:00
                "Lagos": "Africa/Lagos",  # UTC+01:00
                "Johannesburg": "Africa/Johannesburg",  # UTC+02:00
                "Nairobi": "Africa/Nairobi",  # UTC+03:00
            },
            "Australia_Oceania": {
                "Perth": "Australia/Perth",  # UTC+08:00
                "Adelaide": "Australia/Adelaide",  # UTC+09:30
                "Sydney": "Australia/Sydney",  # UTC+10:00
                "Auckland": "Pacific/Auckland",  # UTC+12:00
            },
            "Pacific_Islands": {
                "Guadalcanal": "Pacific/Guadalcanal",  # UTC+11:00
                "Tongatapu": "Pacific/Tongatapu",  # UTC+13:00
                "Kiritimati": "Pacific/Kiritimati",  # UTC+14:00
            },
            "Special_Zones": {
                "Reykjavik": "Atlantic/Reykjavik",  # UTC±00:00 (İceland )
                "Fernando_de_Noronha": "America/Noronha",  # UTC-02:00
                "Kathmandu": "Asia/Kathmandu",  # UTC+05:45 ( Nepal)
            }
        }

        # Get all timezones and filter by continent
        filtered_timezones = [tz for tz in pytz.all_timezones if
                              any(continent in tz for continent in ["Europe", "America", "Asia"])]

        # Add important cities from other regions
        for region, cities in important_timezones_other.items():
            for city_name, tz_path in cities.items():
                if tz_path not in filtered_timezones:
                    filtered_timezones.append(tz_path)

        # Group cities by UTC offset and remove continent prefixes
        self.timezone_groups = {}
        for tz in filtered_timezones:
            try:
                # Get UTC offset for this timezone
                offset = datetime.now(pytz.timezone(tz)).strftime('%z')
                city = tz.split('/')[-1].replace('_', ' ')  # Remove continent prefix and underscores
                # Limit city name length to 8 characters
                if len(city) > 8:
                    city = city[:8]

                if offset not in self.timezone_groups:
                    self.timezone_groups[offset] = []
                self.timezone_groups[offset].append((city, tz))
            except Exception as e:
                print(f"Error processing timezone {tz}: {e}")

        # Sort groups by UTC offset and create final list
        timezone_list = []
        for offset in sorted(self.timezone_groups.keys()):
            cities = sorted(self.timezone_groups[offset])  # Sort cities within same offset
            # Group cities in threes
            for i in range(0, len(cities), 3):
                group = cities[i:i + 3]
                utc_hours = int(offset[0:3])  # Get hours including sign
                utc_minutes = int(offset[3:5])  # Get minutes
                utc_str = f"{'+' if utc_hours >= 0 else ''}{utc_hours:02d}:{utc_minutes:02d}"

                # Combine UTC with cities, using shorter format
                display_name = f"{utc_str}|{'/'.join(city for city, _ in group)}"
                timezone_list.append((display_name, group[0][1]))

        return timezone_list

    def get_timezone_groups(self):
        return self.timezone_groups

    def change_timezone(self):
        current_timezone = self.get_current_timezone()
        self.config.update_sub_value(ConfigKeys.TIMEZONE, None, current_timezone)

    def get_current_timezone(self):
        current_timezone = subprocess.check_output(["timedatectl", "show", "--property=Timezone"]).decode().strip()
        current_timezone = current_timezone.split('=')[1]
        return current_timezone

    def get_timezone_country(self):
        country = self.get_current_timezone().split("/")[1]
        return country

    def set_new_datetime(self, new_datetime):
        subprocess.run(["sudo", "timedatectl", "set-time", new_datetime], check=True)

    def set_new_timezone(self, new_timezone):
        subprocess.run(["sudo", "timedatectl", "set-timezone", new_timezone], check=True)

    def set_new_ntp(self, new_ntp):
        subprocess.run(["sudo", "timedatectl", "set-ntp", new_ntp], check=True)

    def set_new_timezone_config(self, new_timezone):
        self.config.update_sub_value(ConfigKeys.TIMEZONE, None, new_timezone)

    def get_ntp_value(self):
        return self.config.get_value(ConfigKeys.NTP)

    def set_new_ntp_config(self, new_ntp):
        self.config.update_sub_value(ConfigKeys.NTP, None, new_ntp)

    def get_timezone_index(self):
        return self.config.get_value(ConfigKeys.TIMEZONE_INDEX)

    def set_timezone_index(self, new_index):
        self.config.update_sub_value(ConfigKeys.TIMEZONE_INDEX, None, new_index)