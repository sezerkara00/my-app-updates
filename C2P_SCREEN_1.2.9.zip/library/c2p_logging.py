import os
import logging
from logging.handlers import TimedRotatingFileHandler

# Get the user's home directory path
home_dir = os.path.expanduser('~')
# Define the log file path within the user's home directory
log_filename = os.path.join(home_dir, 'printer_data', 'logs', 'c2p_screen.log')

class LoggerSetup:
    def __init__(self, interval=1, backup_count=5):
        """
        Initializes the LoggerSetup class with specified interval and backup count.
        
        Parameters:
            interval (int): Number of intervals (in days) after which a new log file is created.
            backup_count (int): Maximum number of backup files to keep; older files are deleted.
        """
        self.interval = interval  # Interval for rotating the log file (default is 1 day)
        self.backup_count = backup_count  # Maximum number of backup files to retain

    def get_logger(self, class_name):
        """
        Creates and returns a logger for a specific class with time-based rotating file handling.

        Parameters:
            class_name (str): Name of the class or component that will use this logger.

        Returns:
            logging.Logger: Configured logger for the specified class.
        """
        # Create a logger with the name of the class
        logger = logging.getLogger(class_name)
        logger.setLevel(logging.INFO)  # Set default logging level to INFO
        
        # Set up a TimedRotatingFileHandler to create a new log file every midnight
        handler = TimedRotatingFileHandler(
            log_filename, when="midnight", interval=self.interval, backupCount=self.backup_count
        )
        handler.suffix = "%Y-%m-%d_%H-%M"  # Adds timestamp suffix to the log file name
        
        # Define the log format including timestamp, log level, logger name, and message
        formatter = logging.Formatter(
            "%(asctime)s - %(levelname)s - %(name)s - %(message)s", 
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        handler.setFormatter(formatter)  # Attach the formatter to the handler

        # Add the handler to the logger if it's not already attached
        if not logger.hasHandlers():
            logger.addHandler(handler)
        
        return logger  # Return the configured logger

"""
# Example usage:
# Initialize the LoggerSetup
logger_setup = LoggerSetup(interval=1, backup_count=5)

# Get a logger instance for a specific class (e.g., "MyClass")
logger = logger_setup.get_logger("MyClass")

# Log some messages to test.py
logger.info("This is an info message from MyClass.")
logger.warning("This is a warning message from MyClass.")
logger.error("This is an error message from MyClass.")

"""