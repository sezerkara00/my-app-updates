import os
import pyudev
import subprocess
import threading
import shutil


class USBMonitorThread(threading.Thread):
    def __init__(self, main, mount_point, sudo_password):
        super().__init__()
        self.main = main
        self.mount_point = mount_point
        self.sudo_password = sudo_password
        self.is_usb = False

    def run(self):
        context = pyudev.Context()
        monitor = pyudev.Monitor.from_netlink(context)
        monitor.filter_by(subsystem='block', device_type='disk')
        existing_devices = [device for device in context.list_devices(subsystem='block', DEVTYPE='disk') if
                            'ID_USB_DRIVER' in device]
        for device in existing_devices:
            self.mount_usb(device.device_node)
        for device in iter(monitor.poll, None):
            if 'ID_USB_DRIVER' in device:
                action = device.action
                device_path = device.device_node
                if action == 'add':
                    print("USB drive inserted.")
                    self.mount_usb(device_path)
                elif action == 'remove':
                    print("USB drive removed.")
                    if self.is_mounted():
                        self.unmount_usb()

    def mount_usb(self, device_path):
        if not os.path.exists(self.mount_point):
            print(f"Error: Mount point '{self.mount_point}' does not exist.")
            return

        if self.is_mounted():
            self.unmount_usb()

        command = ['sudo', '-S', 'mount', device_path + '1', self.mount_point]
        try:
            subprocess.run(command, input=self.sudo_password.encode(), check=True)
            # ScreenPanel._screen.show_popup_message(_("USB drive mounted successfully"),"C",2)
            print("USB drive mounted successfully.")
            self.is_mounted()
            self.main.usb_PrintFile.start_background_update()
        except subprocess.CalledProcessError as e:
            print(f"Error: {e}")

    def unmount_usb(self):
        if not self.is_mounted():
            print(f"Error: Volume '{self.mount_point}' is not mounted.")
            return

        command = ['sudo', '-S', 'umount', self.mount_point]

        try:
            subprocess.run(command, input=self.sudo_password.encode(), check=True)
            self.is_mounted()
            self.main.usb_PrintFile.reset_filelist()
            print("USB drive unmounted successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Error: {e}")

    def is_mounted(self):
        command = ['mount']
        output = subprocess.check_output(command).decode('utf-8')
        mount_point = self.mount_point.rstrip('/')
        self.is_usb = any(mount_point in line for line in output.splitlines())
        return self.is_usb
        # return self.mount_point in output
        
    def get_is_usb(self):
        return self.is_usb

    def copyFromUSbToStroage(self, storagepath, source_path, filename):
        try:
            destination_path = os.path.join(storagepath, filename)
            # source_path  = os.path.join(self.mount_point, filename)
            shutil.copy(source_path, destination_path)
            return True
        except:
            return False