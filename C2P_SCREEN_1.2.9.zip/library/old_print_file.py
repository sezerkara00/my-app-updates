# All file add by payam
# 2.29.2024
import logging
import json
import os

home_dir = os.path.expanduser('~')

fileconfig = os.path.join(home_dir, 'printer_data', 'printer_gcode',
                          'config.json')


class OldPrintfile:
    filename = None
    printstate = None
    jobstate = None
    printduration = 0

    def __init__(self):
        super().__init__()
        self.filenameconfig = fileconfig

    def initialvaluse(self):
        self.filename = ""
        self.printstate = ""
        self.jobstate = ""
        self.printduration = 0

    def _SavePintInfo(self):
        if self.printstate == 'Printing':
            infoDict = {}
            if self.filename == "MANUAL XY CALIBRATION":
                return
            infoDict[self.filename] = {'jobstate': self.jobstate,
                                       'printduration': self.format_time(
                                           self.printduration)}
            self.__update_and_save(infoDict)
            self.printstate = ''

    def format_time(self, seconds):
        seconds = int(round(seconds))
        if seconds < 60:
            return f"{seconds}S"
        elif seconds < 3600:
            minutes = seconds // 60
            return f"{minutes}m"
        else:
            hours = seconds // 3600
            remaining_minutes = (seconds % 3600) // 60
            return f"{hours}h:{remaining_minutes:02}m"

    def _GetPintInfo(self, countfile):
        if countfile >= 10:
            countfile = 10
        cntdict = self.__count_dicts()
        if cntdict == 0:
            return {}
        if countfile > cntdict:
            countfile = cntdict
        return self.__read_json(countfile)

    def __write_json(self, data):
        with open(self.filenameconfig, 'w') as file:
            json.dump(data, file)

    def __read_json(self, num_dicts_to_read):
        loaded_dicts = {}
        loaded_dicts_h = {}
        count = 0
        try:
            if os.path.exists(self.filenameconfig):
                with open(self.filenameconfig, 'r') as file:
                    for line in file:
                        data = json.loads(line)
                        if isinstance(data, dict):
                            loaded_dicts_h.update(data)
                            loaded_dicts = {k: loaded_dicts_h[k] for k in
                                            list(loaded_dicts_h)[
                                            :num_dicts_to_read]}
                            # count += 1
                            # if count == num_dicts_to_read:
                            break
            return loaded_dicts
        except:
            return {}

    def __count_dicts(self):
        count = 0
        try:
            if os.path.exists(self.filenameconfig):
                with open(self.filenameconfig, 'r') as file:
                    loaded_dicts = json.load(file)
                    if isinstance(loaded_dicts, dict):
                        count = len(loaded_dicts)
            else:
                # If file doesn't exist, create it
                with open(self.filenameconfig, 'w') as file:
                    json.dump({}, file)
            return count
        except:
            return 0

    def __update_and_save(self, new_dict):
        cntdict = self.__count_dicts()
        if cntdict >= 10:
            cntdict = 10
        existing_data = self.__read_json(cntdict)
        if len(existing_data) == 0 or cntdict == 0:
            existing_data = new_dict
            self.__write_json(existing_data)
        elif list(new_dict.keys())[0] in existing_data:
            del existing_data[list(new_dict.keys())[0]]
            merge_dicts = {**new_dict, **existing_data}
            self.__write_json(merge_dicts)
        else:
            merge_dicts = {**new_dict, **existing_data}
            self.__write_json(merge_dicts)

    def _setFileName(self, filename):
        self.filename = filename

    def _getFileName(self):
        return self.filename

    def _setPrintState(self, printstate):
        self.printstate = printstate

    def _getPrintState(self):
        return self.printstate

    def _setJobState(self, jobstate):
        self.jobstate = jobstate

    def _getJobState(self):
        return self.jobstate

    def _setPrintDuration(self, printduration):
        self.printduration = printduration

    def _getPrintDuration(self):
        return self.printduration
