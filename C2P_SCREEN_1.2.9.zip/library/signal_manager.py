from blinker import Signal

# Event bus for managing signals
# This acts as the central hub for sending and receiving signals across the application
event_bus = Signal()

class SignalRouter:
    """
    SignalRouter is a utility class for routing signals to the appropriate handlers 
    based on the action specified in the signal's payload.
    """
    def __init__(self):
        # Dictionary to store routes (action -> list of callback functions)
        self.routes = {}

    def register(self, action, callback):
        """
        Register a callback for a specific action.

        Args:
            action (str): The name of the action to listen for.
            callback (callable): The function to call when the action is triggered.
        """
        if action not in self.routes:
            self.routes[action] = []  # Initialize the list of callbacks for this action
        self.routes[action].append(callback)  # Add the callback to the list

    def route(self, sender, **kwargs):
        """
        Route the signal to the appropriate handler based on the action.

        Args:
            sender (str): The origin of the signal.
            **kwargs: Additional data sent with the signal.
        """
        action = kwargs.get('action')  # Extract 'action' from the signal's payload
        if action and action in self.routes:
            # If the action exists in the routes, execute all associated callbacks
            for callback in self.routes[action]:
                callback(sender, **kwargs)

# Create a global instance of the signal router
# This instance will be used to register and route signals throughout the application
signal_router = SignalRouter()
