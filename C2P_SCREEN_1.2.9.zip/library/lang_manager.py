import os
import locale
import gettext
import configparser
from library.c2p_logging import home_dir
from library.global_manager import GlobalVariables

class LangManager(GlobalVariables):
    do_not_edit_line = "#~# --- Do not edit below this line. This section is auto generated --- #~#"
    do_not_edit_prefix = "#~#"

    def __init__(self):
        super().__init__()
        self.langs = {}
        self.lang = None
        self.logger = self.logger_setup.get_logger("LangManager")
        self.config = configparser.ConfigParser()

        # Define config path
        config_path = os.path.join(home_dir, "printer_data", "config", "C2P_SCREEN.conf")
        cleaned_config = self.separate_saved_config(config_path)
        config_string = ''.join([line for line in cleaned_config if line.strip()])

        self.config.read_string(config_string)
        try:
            self.language = self.config.get('main', 'language')
            self.logger.info(f"Language setting: {self.language}")
        except (
            configparser.NoSectionError, configparser.NoOptionError) as e:
            msg = f"Error reading language setting: {config_path}\n{e}"
            self.logger.exception(msg)

        self.create_translations()

    def create_translations(self):
        # Initialize translations directory
        self.logger = self.logger_setup.get_logger("LangManager")
        lang_path = os.path.join(home_dir, "C2P_SCREEN", "library", "languages")
        self.lang_list = [d for d in os.listdir(lang_path) if not os.path.isfile(os.path.join(lang_path, d))]
        self.lang_list.sort()

        # Create translation objects for each language
        for lng in self.lang_list:
            self.langs[lng] = gettext.translation(
                'KlipperScreen',
                localedir=lang_path,
                languages=[lng],
                fallback=True
            )


        self.logger.debug(f"Selected lang: {self.language} OS lang: {locale.getlocale()[0]}")
        self.install_language(self.language)

    def install_language(self, lang):
        # Use system language if no specific language is set
        if lang is None or lang == "system_lang":
            for language in self.lang_list:
                if locale.getlocale()[0].startswith(language):
                    self.logger.debug("Using system lang")
                    lang = language

        # Default to English if specified language not found
        if lang not in self.lang_list:
            self.logger.error(f"lang: {lang} not found")
            self.logger.info(f"Available lang list {self.lang_list}")
            lang = "en"

        # Set the selected language
        self.logger.info(f"Using lang {lang}")
        self.langs[lang].install()
        self.lang = self.langs[lang]

    def separate_saved_config(self, config_path):
        user_def = []
        saved_def = []
        found_saved = False
        if not os.path.exists(config_path):
            return ["", None]
        with open(config_path) as file:
            for line in file:
                line = line.replace('\n', '')
                if line == self.do_not_edit_line:
                    found_saved = True
                    saved_def = []
                    continue
                if found_saved is False:
                    user_def.append(line.replace('\n', ''))
                elif line.startswith(self.do_not_edit_prefix):
                    saved_def.append(line[(len(self.do_not_edit_prefix) + 1):])
        return ["\n".join(user_def), None if saved_def is None else "\n".join(saved_def)]

    def get_lang(self):
        # Return the translation object for the environment to use
        return self.lang
