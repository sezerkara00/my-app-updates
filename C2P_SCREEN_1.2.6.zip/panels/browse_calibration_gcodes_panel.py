from elements.c2p_gtk import CtoPGtk
from elements.file_element import FileElement
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
from library.global_manager import GlobalVariables
import os

class BrowsGCodes(GlobalVariables):
    def __init__(self, screen):
        super().__init__(screen)
        self.screen = screen
        self.ctop_gtk = CtoPGtk(self.screen, self.theme_path)
        self.browse_gcode_calibrate_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL)
        self.browse_gcode_calibrate_box.set_valign(Gtk.Align.CENTER)
        calibrate_menu_grid = Gtk.Grid()
        calibrate_menu_grid.get_style_context().add_class("calibrate_menu_grid")
        calibrate_menu_grid.set_halign(Gtk.Align.CENTER)
        calibrate_menu_grid.set_valign(Gtk.Align.CENTER)
        calibrate_menu_grid.set_row_spacing(30)
        calibrate_menu_grid.set_column_spacing(50)
        gcode_files = []
        gcode_files_images = {
            "temp": (
                    os.path.expanduser("~/") +
                    "printer_data/printer_gcode/.thumbs/Temperature_Test-300x300"),
            "fan": (
                    os.path.expanduser("~/") +
                    "printer_data/printer_gcode/.thumbs/Fan_Test-300x300"),
            "rotation_distance": (
                    os.path.expanduser("~/") +
                    "printer_data/printer_gcode/.thumbs/Extrusion_Test-300x300"),
            "bed_mesh": (
                    os.path.expanduser("~/") +
                    "printer_data/printer_gcode/.thumbs/Bed_Mesh_Test-300x300")}

        filepaths = os.path.join(self.home_dir, "printer_data", "gcodes",).replace("\\\\", "\\")
        for filename in os.listdir(filepaths):
            if filename.lower().endswith('.gcode'):
                gcode_files.append(filename)

        self.file_element = {}
        for index, (gcode_file, img_name) in enumerate(zip(gcode_files,gcode_files_images.values())):
            self.file_element[gcode_file] = FileElement(
                self.screen, gcode_file,panel_command=lambda x: self.show_gcode_file(x),svg=img_name,style=self.style
            )
            if index >2:
                calibrate_menu_grid.attach(self.file_element[gcode_file], index-3, 1, 1, 1)
            else:
                calibrate_menu_grid.attach(self.file_element[gcode_file],index,0,1,1)
        self.browse_gcode_calibrate_box.pack_start(calibrate_menu_grid,True,True,0)
    def get_content(self):
        return self.browse_gcode_calibrate_box, "Calibration Panel"
    def show_gcode_file(self,file):
        pass
