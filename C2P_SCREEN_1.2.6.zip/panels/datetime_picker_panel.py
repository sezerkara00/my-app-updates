import gi
import time
from gi.repository import Gtk, Gdk, GLib
from elements.c2p_gtk import CtoPGtk
import subprocess

gi.require_version("Gtk", "3.0")
import ntplib
from library.c2p_config import C2PConfig, ConfigKeys
from elements.c2p_gtk import CtoPGtk
from elements.c2p_dialog import C2PDialog
from elements.custom_combo_box import CustomComboBox
from datetime import datetime
import pytz
from library.datetime_picker import DateTimePicker


class DateTime_Picker_Panel(Gtk.Box):
    def __init__(self, screen, theme_path):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.screen = screen
        self.theme_path = theme_path
        self.ctop_gtk = CtoPGtk(screen, theme_path)
        self.config = C2PConfig(screen)
        self.config.read_c2p_config()
        self.base_panel = screen.base_panel
        dt_picker = DateTimePicker(config=self.config)
        self.timezone_value = dt_picker.get_timezone_index()
        # Read NTP status from config
        ntp_value = dt_picker.get_ntp_value()
        self.using_auto_time = (ntp_value == "True")  # String comparison
        self.timezone_index = dt_picker.get_timezone_index()
        # Main content area
        content_area = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,
                                             width=screen.width / 1.45,
                                             height=screen.height / 3.2,
                                             style="dialog")
        content_area.set_valign(Gtk.Align.CENTER)
        content_area.set_halign(Gtk.Align.CENTER)

        # Info box for the top section
        box_info = self.ctop_gtk.c2p_box("dialog_box_info")

        # Info icon
        image_info = self.ctop_gtk.Image("info-dialog")
        box_info.pack_start(image_info, False, False, 0)

        # Title label
        title_label = self.ctop_gtk.c2p_label("Please select the date and time", "message_label")
        box_info.pack_start(title_label, False, False, 0)

        # Separator line
        border_box = self.ctop_gtk.c2p_box("dialog_box_margin", 400, 1,
                                           Gtk.Orientation.VERTICAL)
        border_box.set_vexpand(False)

        # Upper box for internet time switch
        auto_time_label = self.ctop_gtk.c2p_label("Timezones", "label")
        upper_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
        upper_box.set_halign(Gtk.Align.START)
        upper_box.set_valign(Gtk.Align.CENTER)
        upper_box.set_margin_top(10)
        upper_box.set_margin_bottom(10)
        upper_box.set_margin_start(10)
        upper_box.set_margin_end(10)
        upper_box.set_spacing(10)

        # Internet time switch
        self.auto_time_switch = Gtk.Switch()
        self.auto_time_switch.get_style_context().add_class("custom-switch")
        self.auto_time_switch.set_active(self.using_auto_time)
        self.auto_time_switch.connect("notify::active", self.on_switch_activated)
        timezone_list = dt_picker.get_timezone_list()
        timezone_groups = dt_picker.get_timezone_groups()
        # Create timezone combo box with smaller fixed width
        self.timezone_combo = Gtk.ComboBoxText()
        self.timezone_combo.set_halign(Gtk.Align.START)
        self.timezone_combo.set_valign(Gtk.Align.START)
        self.timezone_combo.set_size_request(300, 40)  # Reduced width, fixed height
        self.timezone_combo.get_style_context().add_class("timezone-combo")

        for display_name, tz in timezone_list:
            self.timezone_combo.append_text(display_name)

        # Store the mapping of display names to actual timezones
        self.timezone_mapping = {display_name: tz for display_name, tz in timezone_list}

        # Set active timezone
        try:
            # Get the current timezone from dt_picker
            current_timezone = dt_picker.get_current_timezone()

            # Find the index of the current timezone in the list
            for i, (display_name, tz) in enumerate(timezone_list):
                if tz == current_timezone:
                    self.timezone_combo.set_active(i)
                    self.selected_timezone = tz
                    break
            else:  # If not found, set to first timezone
                self.timezone_combo.set_active(0)
                self.selected_timezone = timezone_list[0][1]

        except Exception as e:
            print(f"Error setting current timezone: {e}")
            self.timezone_combo.set_active(0)
            self.selected_timezone = timezone_list[0][1]  # Use first timezone as default

        self.timezone_combo.connect("changed", self.on_timezone_changed)

        # Add label and widgets to upper box with spacing
        upper_box.pack_start(auto_time_label, False, False, 0)
        upper_box.pack_start(self.auto_time_switch, False, False, 10)
        upper_box.pack_start(self.timezone_combo, False, False, 0)

        # Box for time selection
        date_time_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
        date_time_box.set_halign(Gtk.Align.CENTER)
        date_time_box.set_valign(Gtk.Align.CENTER)
        date_time_box.set_margin_top(20)
        date_time_box.set_margin_bottom(20)
        date_time_box.set_margin_start(20)
        date_time_box.set_margin_end(20)
        date_time_box.set_spacing(20)

        # Hour widget
        hour_vbox = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        hour_label = self.ctop_gtk.c2p_label("Hour", "label")
        hour_label.set_halign(Gtk.Align.CENTER)

        hour_adj = Gtk.Adjustment(value=int(time.strftime("%H")),
                                  lower=0, upper=23, step_increment=1)
        self.hour_spin = Gtk.SpinButton()
        self.hour_spin.set_adjustment(hour_adj)
        self.hour_spin.set_numeric(True)
        self.hour_spin.set_wrap(True)
        self.hour_spin.set_value(int(time.strftime("%H")))
        self.hour_spin.set_size_request(150, 75)  # Width and height

        hour_vbox.pack_start(hour_label, False, False, 0)
        hour_vbox.pack_start(self.hour_spin, False, False, 0)
        date_time_box.pack_start(hour_vbox, True, True, 0)

        # Minute widget
        minute_vbox = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        minute_label = self.ctop_gtk.c2p_label("Minute", "label")
        minute_label.set_halign(Gtk.Align.CENTER)

        minute_adj = Gtk.Adjustment(value=int(time.strftime("%M")),
                                    lower=0, upper=59, step_increment=1)
        self.minute_spin = Gtk.SpinButton()
        self.minute_spin.set_adjustment(minute_adj)
        self.minute_spin.set_numeric(True)
        self.minute_spin.set_wrap(True)
        self.minute_spin.set_value(int(time.strftime("%M")))
        self.minute_spin.set_size_request(150, 75)  # Width and height

        minute_vbox.pack_start(minute_label, False, False, 0)
        minute_vbox.pack_start(self.minute_spin, False, False, 0)
        date_time_box.pack_start(minute_vbox, True, True, 0)

        # Box for day, month, year
        day_month_year_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
        day_month_year_box.set_halign(Gtk.Align.CENTER)
        day_month_year_box.set_valign(Gtk.Align.CENTER)
        day_month_year_box.set_margin_top(20)
        day_month_year_box.set_margin_bottom(20)
        day_month_year_box.set_margin_start(20)
        day_month_year_box.set_margin_end(20)
        day_month_year_box.set_spacing(20)

        # Day widget
        day_vbox = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        day_label = self.ctop_gtk.c2p_label("Day", "label")
        day_label.set_halign(Gtk.Align.CENTER)

        day_adj = Gtk.Adjustment(value=int(time.strftime("%d")),
                                 lower=1, upper=31, step_increment=1)
        self.day_spin = Gtk.SpinButton()
        self.day_spin.set_adjustment(day_adj)
        self.day_spin.set_numeric(True)
        self.day_spin.set_wrap(True)
        self.day_spin.set_value(int(time.strftime("%d")))
        self.day_spin.set_size_request(100, 50)  # Width and height

        day_vbox.pack_start(day_label, False, False, 0)
        day_vbox.pack_start(self.day_spin, False, False, 0)
        day_month_year_box.pack_start(day_vbox, True, True, 0)

        # Month widget
        month_vbox = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        month_label = self.ctop_gtk.c2p_label("Month", "label")
        month_label.set_halign(Gtk.Align.CENTER)

        month_adj = Gtk.Adjustment(value=int(time.strftime("%m")),
                                   lower=1, upper=12, step_increment=1)
        self.month_spin = Gtk.SpinButton()
        self.month_spin.set_adjustment(month_adj)
        self.month_spin.set_numeric(True)
        self.month_spin.set_wrap(True)
        self.month_spin.set_value(int(time.strftime("%m")))
        self.month_spin.set_size_request(100, 50)  # Width and height

        month_vbox.pack_start(month_label, False, False, 0)
        month_vbox.pack_start(self.month_spin, False, False, 0)
        day_month_year_box.pack_start(month_vbox, True, True, 0)

        # Year widget
        year_vbox = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        year_label = self.ctop_gtk.c2p_label("Year", "label")
        year_label.set_halign(Gtk.Align.CENTER)

        year_adj = Gtk.Adjustment(value=int(time.strftime("%Y")),
                                  lower=2000, upper=2099, step_increment=1)
        self.year_spin = Gtk.SpinButton()
        self.year_spin.set_adjustment(year_adj)
        self.year_spin.set_numeric(True)
        self.year_spin.set_wrap(True)
        self.year_spin.set_value(int(time.strftime("%Y")))
        self.year_spin.set_size_request(100, 50)  # Width and height

        year_vbox.pack_start(year_label, False, False, 0)
        year_vbox.pack_start(self.year_spin, False, False, 0)
        day_month_year_box.pack_start(year_vbox, True, True, 0)

        # Box for buttons
        buttons_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
        buttons_box.set_halign(Gtk.Align.END)
        buttons_box.set_valign(Gtk.Align.END)
        buttons_box.set_margin_end(20)
        buttons_box.set_margin_bottom(10)

        # Cancel button
        cancel_button = self.ctop_gtk.Button_new(label="Cancel", style="dialog_button")
        cancel_button.connect("clicked", self.on_cancel_clicked)

        # Apply button
        apply_button = self.ctop_gtk.Button_new(label="Apply", style="dialog_button")
        apply_button.connect("clicked", self.on_apply_clicked)

        # Add buttons to box
        buttons_box.pack_end(apply_button, False, False, 30)
        buttons_box.pack_end(cancel_button, False, False, 30)

        # Add elements to content area
        content_area.pack_start(box_info, False, False, 0)
        content_area.pack_start(border_box, False, False, 0)
        content_area.pack_start(upper_box, False, False, 0)
        content_area.pack_start(date_time_box, True, True, 0)
        content_area.pack_start(day_month_year_box, True, True, 0)
        content_area.pack_end(buttons_box, False, False, 0)

        # Add content to main box
        self.pack_start(content_area, True, True, 0)

        # Set initial state of SpinButtons
        self.update_spinbuttons_state(not self.using_auto_time)

        # Create and show window
        self.show_back_dialog()

    def show_back_dialog(self):
        # Create window
        self.dialog_window = Gtk.Window(title="Date Time Settings")
        self.dialog_window.set_transient_for(self.screen)
        self.dialog_window.set_modal(True)
        self.dialog_window.set_decorated(False)
        self.dialog_window.set_resizable(False)
        self.dialog_window.get_style_context().add_class("power_panel")
        self.dialog_window.set_default_size(self.screen.width, self.screen.height)

        # RGBA visual settings
        screen = Gdk.Screen.get_default()
        visual = screen.get_rgba_visual()
        if visual is not None and screen.is_composited():
            self.dialog_window.set_visual(visual)

            # Add box to window
        self.dialog_window.add(self)
        self.dialog_window.show_all()

    def on_apply_clicked(self, widget):
        dt_picker = DateTimePicker(config=self.config)
        try:
            if hasattr(self, 'selected_timezone') and self.selected_timezone and self.auto_time_switch.get_active():
                try:
                    # Get the current active index before making changes
                    new_timezone_index = self.timezone_combo.get_active()

                    dt_picker.set_new_timezone(self.selected_timezone)
                    dt_picker.set_new_timezone_config(self.selected_timezone)
                    # Update the timezone index in config
                    dt_picker.set_timezone_index(new_timezone_index)

                    self.base_panel.current_timezone = dt_picker.get_current_timezone()
                    timezone = pytz.timezone(self.selected_timezone)
                    current_time = datetime.now(timezone)
                    self.base_panel.clock_label.set_text(current_time.strftime("%H:%M"))

                except subprocess.CalledProcessError as e:
                    print(f"Error setting timezone: {e}")
                    return

            if self.auto_time_switch.get_active():
                # Internet time active
                dt_picker.set_new_ntp("True")
                dt_picker.set_new_ntp_config("True")
                self.using_auto_time = True

                # Close dialog on success
                self.dialog_window.destroy()
            if not self.auto_time_switch.get_active():
                # Manual time setting
                dt_picker.set_new_ntp("False")
                dt_picker.set_new_ntp_config("False")
                # Set manual time
                hour, minute, day, month, year = self.get_date_time()
                new_datetime = f"{year}-{month:02d}-{day:02d} {hour:02d}:{minute:02d}:00"
                dt_picker.set_new_datetime(new_datetime)

                # Close dialog on success
                self.dialog_window.destroy()
        except subprocess.CalledProcessError as e:
            print(f"Error occurred: {e}")

    def on_cancel_clicked(self, widget):
        # When cancelled
        self.dialog_window.destroy()

    def update_spinbuttons_state(self, sensitive):
        """Update active/passive state of SpinButtons and timezone combo"""
        # SpinButtons are enabled in manual mode (when sensitive is True)
        self.hour_spin.set_sensitive(sensitive)
        self.minute_spin.set_sensitive(sensitive)
        self.day_spin.set_sensitive(sensitive)
        self.month_spin.set_sensitive(sensitive)
        self.year_spin.set_sensitive(sensitive)

        # Timezone combo is enabled in auto mode (when sensitive is False)
        self.timezone_combo.set_sensitive(not sensitive)  # Inverse of other controls

    def on_switch_activated(self, switch, gparam):
        if switch.get_active():
            # Internet time active
            self.using_auto_time = True
            self.update_spinbuttons_state(False)

        else:
            # Manual time setting active
            self.using_auto_time = False
            self.update_spinbuttons_state(True)

    def get_date_time(self):
        return (self.hour_spin.get_value_as_int(),
                self.minute_spin.get_value_as_int(),
                self.day_spin.get_value_as_int(),
                self.month_spin.get_value_as_int(),
                self.year_spin.get_value_as_int())

    def on_timezone_changed(self, combo):
        active_index = combo.get_active()
        if active_index <= 0:  # If placeholder is selected
            return

        display_name = combo.get_active_text()
        self.selected_timezone = self.timezone_mapping[display_name]