from operator import index

from elements.keyboard import VirtualKeyboard
from elements.keypad import Keypad
from elements.popup import PopupNotification
from elements.progress_circle import ProgressCircle
from library.c2p_config import C2PConfig, ConfigKeys
from library.gcode_editor import GcodeEditor
from library.global_manager import GlobalVariables
from elements.c2p_gtk import CtoPGtk
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
import math

import os
from library.xy_print_file import XYPrint
from panels.browse_calibration_gcodes_panel import BrowsGCodes
from panels.internal_storage_panel import InternalStorage_panel_main
from panels.printing_main_panel import Printing_panel


class GcodeCalibratePanel(GlobalVariables):

    def __init__(self, screen,filename=None):
        super().__init__(screen)
        self.ctop_gtk = CtoPGtk(screen,self.theme_path)
        self.temp = {}
        self.selected_tool = None
        self.device_name = None
        self.file_name =None
        self.new_temps = None
        self.main_gcode_calibrate = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=50)
        self.main_gcode_calibrate.set_halign(Gtk.Align.CENTER)
        top_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, style="print_control_box",
                                      width=self.screen.width / 1.111, height=self.screen.height / 2.723)
        self.image_box = self.ctop_gtk.c2p_box(width=self.screen.width / 1.49, height=self.screen.height / 3.459, style="image_box_gcode_calibrate")
        self.image_box.set_halign(Gtk.Align.CENTER)
        file_box_all = self.ctop_gtk.c2p_box()
        file_box_all.set_halign(Gtk.Align.CENTER)
        file_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL)
        file_box.set_halign(Gtk.Align.CENTER)
        line_box_top = self.ctop_gtk.c2p_box("text_box", self.screen.width / 1.86,
                                        4,
                                        Gtk.Orientation.VERTICAL)
        self.bed_env_box = self.ctop_gtk.c2p_box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=30)
        tools_grid = Gtk.Grid()
        tools_grid.set_halign(Gtk.Align.CENTER)
        tools_grid.set_column_spacing(30)
        tools_grid.set_row_spacing(20)

        pixbuf = self.ctop_gtk.Image("picture", 150, 150)

        top_box_label = self.ctop_gtk.Label("Please Select Your File","print_label")
        browse_button = self.ctop_gtk.Button_new(label="Browse",style="browse_gcode_calibrate")
        browse_button.connect("clicked",self.brows_files)
        info_button = self.ctop_gtk.Button_new("info",label="Info",position=Gtk.PositionType.LEFT,style="browse_gcode_calibrate")
        info_button.connect("clicked", self.get_info)
        print_button = self.ctop_gtk.Button_new("print_xy",label="Print",style="print_gcode_calibrate")
        print_button.connect("clicked", self.print)


        self.tools, self.extruders, self.temps, self.bed_temp, self.tool_extruder = ["T0"],["extruder"],["200"],70,{}
        self.temps.append(self.bed_temp)
        self.new_temps = self.temps
        self.show_temp_circles(tools_grid)
        self.update_temp()
        for dev,prog,tool in zip(self.screen.printer.get_active_extruders(),self.progress_devices,['T0','T1','T2','T3']):
            if dev  is not None:
                self.selected_tool = tool
                prog.change_label_color_m()
                break
        self.image_box.pack_start(pixbuf,True,True,0)
        file_box.add(browse_button)
        file_box.add(info_button)
        file_box.add(print_button)
        file_box_all.add(self.image_box)
        file_box_all.add(file_box)
        top_box.add(top_box_label)
        top_box.add(line_box_top)
        top_box.add(file_box_all)
        self.main_gcode_calibrate.add(top_box)
        self.main_gcode_calibrate.add(tools_grid)

    def get_content(self):
        return self.main_gcode_calibrate,"Gcode Calibrate"
    def show_temp_circles(self,temp_progress_grid):
        for child in temp_progress_grid.get_children():
            temp_progress_grid.remove(child)

        self.progress_circle1 = ProgressCircle(self.screen,
            label="01",
            progress=0,w=150,h=264,

            current_temp=0,angle=-math.pi / 2,panel="gcode",
            filament_type=self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,"extruder"),
            style=self.style,active=False,filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder")),command=[lambda: self.select_tool(tool="T0",prog = self.progress_circle1),lambda: self.get_object_name(name="extruder")])
        self.progress_circle2 = ProgressCircle(self.screen,
            label="02",
            progress=0,w=150,h=264,

            current_temp=0,angle=-math.pi / 2,panel="gcode",
            filament_type=self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,"extruder1"),style=self.style,active=False,filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder1")),command=[lambda: self.select_tool(tool="T1",prog = self.progress_circle2),lambda: self.get_object_name(name="extruder1")])
        self.progress_circle3 = ProgressCircle(self.screen,
            label="03",
            progress=0,w=150,h=284,

            current_temp=0,angle=-math.pi / 2,panel="gcode",
            filament_type=self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,"extruder2"),style=self.style,filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder2")),command=[lambda: self.select_tool(tool="T2",prog = self.progress_circle3),lambda: self.get_object_name(name="extruder2")])
        self.progress_circle4 = ProgressCircle(self.screen,
            label="04",
            progress=0,w=150,h=284,

            current_temp=0,angle=-math.pi / 2,panel="gcode",
            filament_type=self.screen.config_file.get_value(ConfigKeys.FILAMENT_NAME,"extruder3"),style=self.style,active=False,filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder3")),command=[lambda: self.select_tool(tool="T3",prog = self.progress_circle4),lambda: self.get_object_name(name="extruder3")])
        self.progress_bed = ProgressCircle(self.screen,label="Bed",panel="gcode", progress=0,w=330,h=160,

                                           current_temp=0,side="left",style=self.style,command=lambda: self.get_object_name(name="heater_bed"))
        self.progress_env = ProgressCircle(self.screen,label="Env", progress=0,w=330,h=160,

                                           current_temp=0,style=self.style,active=False,command=lambda: self.get_object_name(name="heater_generic Env_heater"))
        self.progress_devices = [
            self.progress_circle1,self.progress_circle2,self.progress_circle3,self.progress_circle4,self.progress_bed,self.progress_env
        ]

        self.bed_env_box.add(self.progress_bed)
        self.bed_env_box.add(self.progress_env)

        temp_progress_grid.attach(self.progress_circle1, 0, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle2, 1, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle3, 2, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle4, 3, 1, 1, 1)
        temp_progress_grid.attach(self.bed_env_box, 0, 2, 4, 1)
        temp_progress_grid.show_all()



    def update_temp(self, value=None, tool_number=None):
        index = 0
        for device, progress in zip(
                self.screen.printer.get_active_extruders() + self.screen.printer.get_heaters(), self.progress_devices,
        ):

            if device is None:
                continue
            self.temp[device] = self.screen.printer.get_dev_stat(device, "temperature")


            # if self.screen.printer.get_dev_stat(
            #         switch, "state") == "PRESSED":  # Show tool is in park
            #     progress.set_park_status(True)
            # elif self.screen.printer.get_dev_stat(switch, "state") == "RELEASED":
            #     progress.set_park_status(False)
            if "temperature_sensor" not in device:
                max_temp = self.screen.printer.get_dev_stat(device,
                                                            "max_temp")
                min_temp = self.screen.printer.get_dev_stat(device,
                                                            "min_extrude_temp")

                if value is None:
                    if "extruder" in device:
                         progress.set_current_temp(200,
                                              200 / max_temp, max_temp, True)
                    else:
                        progress.set_current_temp(70,
                                                  70 / max_temp, max_temp, True)
                else:
                    if self.device_name in self.tool_extruder[self.selected_tool] and self.device_name == device:
                        print(self.tool_extruder[self.selected_tool])
                        progress.set_current_temp(value,
                                                  value / max_temp, max_temp, True)
                        self.new_temps[0]=str(int(value))
                    elif self.device_name=="heater_bed" and self.device_name == device:
                        progress.set_current_temp(value,
                                                  value / max_temp, max_temp, True)
                        self.new_temps[1] = str(int(value))  #for append heater bed temp
                    print(self.new_temps)


    def get_object_name(self, widget=None, name=None):
        self.show_keypad(widget, name)

    def show_keypad(self, widget=None, type=None):
        # Determine the initial value for the keypad
        if type in self.screen.printer.get_active_extruders() + self.screen.printer.get_heaters():
            for progress, device in zip(self.progress_devices,
                                        self.screen.printer.get_active_extruders() + self.screen.printer.get_heaters()):
                if device != type:
                    progress.on_button_release()
                else:
                    self.keypad_value = self.screen.printer.get_dev_stat(device, "target")
                    self.device_name = device
        elif widget:  # Read from widget label
            label_text = widget.get_label()
            try:
                # Try to parse the label as a number
                self.keypad_value = float(label_text)

            except (ValueError, TypeError):
                # If parsing fails, set the default value to 0
                self.keypad_value = 0
        else:
            self.keypad_value = 0  # Default value if none of the conditions match

        # Create a new Keypad instance and use lambda to pass the value directly to handle_keypad
        keypad_window = Keypad(
            self.screen,
            self.theme_path,
            lambda value: self.handle_keypad(value, widget, type)
        )
        keypad_window.show_keypad(text=self.keypad_value)

    def handle_keypad(self, value, widget, type):
        """
        Handle the value returned from the Keypad and update UI or state accordingly.
        """

        self.update_temp(value)
        # Optionally update the label of the widget
        if widget:
            try:
                if isinstance(value, str) and "%" in value:
                    # If the value contains '%', leave it as is
                    widget.set_label(value)
                else:
                    numeric_value = float(value)
                    # Check if the value is an integer
                    if numeric_value.is_integer():
                        # If the value is an integer, set it without decimals
                        widget.set_label(f"{int(numeric_value)}")

                    else:
                        # If the value is a float, format it with 2 decimal places
                        widget.set_label(f"{numeric_value:.2f}")
            except ValueError:
                # Handle non-numeric value gracefully
                widget.set_label("0")

    def parse_rgb_string_safe(self,rgb_string):
        try:
            r, g, b = map(float, rgb_string.split(","))
            return [r, g, b]
        except (ValueError, TypeError) as e:
            print("Invalid RGB string format:", e)
            return None
    def print(self,widget):
            filepaths = os.path.join(self.home_dir, "printer_data", "printer_gcode",self.file_name ).replace("\\\\", "\\")
            XYPrint().replace_tools(filepaths, self.tools, [self.selected_tool],self.new_temps[:-1],  self.new_temps[-1])
            print(self.tools, [self.selected_tool],self.new_temps[:-1],  self.new_temps[-1:])
            if self.file_name is None:
                PopupNotification(
                    message="Please Select File.",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=5,
                    tipe="E"
                )
                return
            if self.screen.printer.evaluate_state()[0] == 'ready':
                self.screen._ws.klippy.gcode_script(
                    "SDCARD_PRINT_PATH PATH=" + filepaths)
                self.refresh_content(Printing_panel(self.screen, self.file_name, self), printing_panel=True)
    def get_info(self,widget):
        pass
    def brows_files(self,widget):
        self.refresh_content(InternalStorage_panel_main(self.screen,self,"calibrate_gcodes"))
    def show_selected_print_file(self,file_name,image=None):
        #files = list(self.dict_file_old.keys())
      #  image = self.image_load(files[0])
            self.tools, self.extruders, self.temps, self.bed_temp, self.tool_extruder = GcodeEditor(self.screen, file_name,
                                                                                                    self.home_dir,
                                                                                                    tipe="printer_gcode").pars_gcode()
            self.file_name = file_name
            self.file_image = image
            for child in self.image_box.get_children():
                self.image_box.remove(child)
            info = self.screen.files.get_file_info(file_name)
            print(info)
            if "estimated_time" in info and info["estimated_time"] != "None":
                time = int(info["estimated_time"])
                hours = time // 3600
                minutes = (time % 3600) // 60
                formatted_time = self.ctop_gtk.c2p_label(f"Time : {int(hours)}h.{int(minutes)}m", "info_label")
            else:
                formatted_time = self.ctop_gtk.c2p_label(f"Time : none", "info_label")

            if "first_layer_extr_temp" in info and info["first_layer_extr_temp"] != "None":
                 extruder_temp = self.ctop_gtk.c2p_label(f'First Layer Temp : {info["first_layer_extr_temp"]}', "info_label")
            else:
                 extruder_temp = self.ctop_gtk.c2p_label(f'First Layer Temp : none', "info_label")

            if "first_layer_bed_temp" in info and info["first_layer_bed_temp"] != "None":
                bed_temp = self.ctop_gtk.c2p_label(f'Bed Temp : {info["first_layer_bed_temp"]}', "info_label")
            else:
                bed_temp = self.ctop_gtk.c2p_label(f'Bed Temp : none', "info_label")

            if "filament_total" in info and info["filament_total"] != "None":
                filament_total = self.ctop_gtk.c2p_label(f'Filament : {info["filament_total"]}', "info_label")
            else:
                filament_total = self.ctop_gtk.c2p_label(f'Filament : none', "info_label")

            if "object_height" in info and info["object_height"] != "None":
                layers_count = self.ctop_gtk.c2p_label(f'Layers : {info["object_height"] / info["layer_height"]:.0f}',
                                                   "info_label")
            else:
                layers_count = self.ctop_gtk.c2p_label(f'Layers : none',
                                                   "info_label")
            info_box = self.ctop_gtk.c2p_box(spacing=15, orientation=Gtk.Orientation.VERTICAL)
            info_box.set_valign(Gtk.Align.CENTER)

            info_box.add(formatted_time)
            info_box.add(extruder_temp)
            info_box.add(bed_temp)
            info_box.add(filament_total)
            info_box.add(layers_count)
            for child in info_box.get_children():
                child.set_halign(Gtk.Align.START)

            file_image = Gtk.Image.new_from_pixbuf(image)
            self.image_box.pack_start(file_image, True, True, 0)
            self.image_box.pack_start(info_box, True, True, 0)

            self.image_box.show_all()
    def select_tool(self,tool,prog):
        for progress in self.progress_devices:
            progress.remove_change_label_color_m()
        prog.change_label_color_m()
        self.selected_tool = tool
