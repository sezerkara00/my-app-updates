import gi
from gi.repository import Gtk, Gdk, GLib
from elements.c2p_gtk import CtoPGtk
import subprocess
gi.require_version("Gtk", "3.0")
from library.c2p_config import C2PConfig, ConfigKeys
from elements.c2p_gtk import CtoPGtk
from elements.keypad import Keypad
from elements.c2p_dialog import C2PDialog
import ipaddress
import netifaces
import time
from library.ethernet_manager import WifiManager
from elements.popup import PopupNotification
import threading
class IPAdressDialogPanel(Gtk.Box):
    def __init__(self, screen, theme_path, type, network_panel=None):

        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.screen = screen
        self.theme_path = theme_path
        self.ctop_gtk = CtoPGtk(screen, theme_path)
        self.config = C2PConfig(screen)
        self.config.read_c2p_config()

        self.type = type
        self.network_panel = network_panel
        self.wifi_manager = WifiManager()  # WifiManager örneği oluştur
        # Get IP Address
        wlan_ip,lan_ip = self.get_ip_addresses()
        interfaces = self.get_interfaces()

        static_ip = self.config.get_value(ConfigKeys.STATIC_IP)
        server_ip = self.config.get_value(ConfigKeys.SERVER_IP)
        mask_ip = self.config.get_value(ConfigKeys.MASK_IP)
          
        # Main content area
        content_area = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, 
                                            width=screen.width/1.45,
                                            height=screen.height/3.2,
                                            style="dialog")
        content_area.set_valign(Gtk.Align.CENTER)
        content_area.set_halign(Gtk.Align.CENTER)

        # Info box for the top section
        box_info = self.ctop_gtk.c2p_box("dialog_box_info")
        
        # Info icon
        image_info = self.ctop_gtk.Image("ip-address-light")
        box_info.pack_start(image_info, False, False, 0)

        # Title label
        if self.type == "wlan":
            title_label = self.ctop_gtk.c2p_label("Please select the WLAN IP address", "message_label")
        else:
            title_label = self.ctop_gtk.c2p_label("Please select the LAN IP address", "message_label")
        box_info.pack_start(title_label, False, False, 0)
        
        # Separator line
        border_box = self.ctop_gtk.c2p_box("dialog_box_margin", 400, 1,
                                          Gtk.Orientation.VERTICAL)
        border_box.set_vexpand(False)
        
        
        # Box for time selection
        ip_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL)
        ip_box.set_halign(Gtk.Align.CENTER)
        ip_box.set_valign(Gtk.Align.CENTER)
        ip_box.set_margin_top(20)
        ip_box.set_margin_bottom(20)
        ip_box.set_margin_start(20)
        ip_box.set_margin_end(20)
        ip_box.set_spacing(20)

        # Static IP widget
        static_ip_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        # Create a fixed-width container for the label
        label_container = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
        label_container.set_size_request(100, -1)  # Fixed width for label container
        static_ip_label = self.ctop_gtk.c2p_label("Static IP", "label")
        static_ip_label.set_halign(Gtk.Align.START)
        label_container.pack_start(static_ip_label, False, False, 0)
        
        # Create a fixed-width container for the button
        button_container = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
        button_container.set_size_request(200, -1)  # Fixed width for button container
        if self.type == "wlan":
            self.static_ip_button = self.ctop_gtk.Button_new(label=wlan_ip,style="ip_address_dialog_button")
        else:
            self.static_ip_button = self.ctop_gtk.Button_new(label=static_ip,style="ip_address_dialog_button")
        self.static_ip_button.connect("clicked", self.show_keypad,"static")
        self.static_ip_button.set_size_request(150, 75)
        button_container.pack_start(self.static_ip_button, True, False, 0)
        
        static_ip_box.pack_start(label_container, False, False, 0)
        static_ip_box.pack_start(button_container, True, False, 0)
        ip_box.pack_start(static_ip_box, True, True, 0)

        # Server IP widget
        server_ip_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        label_container = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
        label_container.set_size_request(100, -1)
        server_ip_label = self.ctop_gtk.c2p_label("Server IP", "label")
        server_ip_label.set_halign(Gtk.Align.START)
        label_container.pack_start(server_ip_label, False, False, 0)
        
        button_container = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
        button_container.set_size_request(200, -1)
        if self.type == "wlan":
            try:
                interface_id = self.get_interface_by_connected_ssid()
                if interface_id:
                    server_ip = self.get_default_gateway(interface_id)
                    if server_ip:
                        self.server_ip_button = self.ctop_gtk.Button_new(label=server_ip, style="ip_address_dialog_button")
                    else:
                            server_ip = ".".join(wlan_ip.split(".")[:3]) + ".1"
                            self.server_ip_button = self.ctop_gtk.Button_new(label=server_ip, style="ip_address_dialog_button")
                else:
                    server_ip = ".".join(wlan_ip.split(".")[:3]) + ".1"
                    self.server_ip_button = self.ctop_gtk.Button_new(label=server_ip, style="ip_address_dialog_button")
            except Exception as e:
                print(f"❌ Error setting server IP: {e}")
                server_ip = ".".join(wlan_ip.split(".")[:3]) + ".1"
                self.server_ip_button = self.ctop_gtk.Button_new(label=server_ip, style="ip_address_dialog_button")
        else:
            self.server_ip_button = self.ctop_gtk.Button_new(label=server_ip, style="ip_address_dialog_button")
        self.server_ip_button.set_size_request(150, 75)
        self.server_ip_button.connect("clicked", self.show_keypad,"server")
        button_container.pack_start(self.server_ip_button, True, False, 0)
        
        server_ip_box.pack_start(label_container, False, False, 0)
        server_ip_box.pack_start(button_container, True, False, 0)
        ip_box.pack_start(server_ip_box, True, True, 0)

        # Mask IP widget
        mask_ip_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        label_container = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
        label_container.set_size_request(100, -1)
        mask_ip_label = self.ctop_gtk.c2p_label("Mask IP", "label")
        mask_ip_label.set_halign(Gtk.Align.START)
        label_container.pack_start(mask_ip_label, False, False, 0)
        
        button_container = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
        button_container.set_size_request(200, -1)
        self.mask_ip_button = self.ctop_gtk.Button_new(label=mask_ip,style="ip_address_dialog_button")
        self.mask_ip_button.set_size_request(150, 75)
        self.mask_ip_button.connect("clicked", self.show_keypad,"mask")
        button_container.pack_start(self.mask_ip_button, True, False, 0)
        
        mask_ip_box.pack_start(label_container, False, False, 0)
        mask_ip_box.pack_start(button_container, True, False, 0)
        ip_box.pack_start(mask_ip_box, True, True, 0)

        # Box for buttons
        buttons_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL)
        buttons_box.set_halign(Gtk.Align.CENTER)
        buttons_box.set_valign(Gtk.Align.CENTER)
        buttons_box.set_margin_bottom(10)
        
        # Cancel button
        cancel_button = self.ctop_gtk.Button_new(label="Cancel", style="ip_address_dialog_cancel_button")
        cancel_button.connect("clicked", self.on_cancel_clicked)
        
        # Apply button
        set_button = self.ctop_gtk.Button_new(label="SET", style="ip_address_dialog_apply_button")
        set_button.connect("clicked", self.on_set_clicked)
        
        # Add buttons to box
        buttons_box.pack_end(cancel_button, False, False, 20)
        buttons_box.pack_end(set_button, False, False, 20)
        
        # Add elements to content area
        content_area.pack_start(box_info, False, False, 0)
        content_area.pack_start(border_box, False, False, 0)
        content_area.pack_start(ip_box, True, True, 0)
        content_area.pack_end(buttons_box, False, False, 0)


        
        # Add content to main box
        self.pack_start(content_area, True, True, 0)
        

        # Create and show window
        self.show_back_dialog()
        self.dialog=None

        
    def show_back_dialog(self):
        # Create window
        self.dialog_window = Gtk.Window(title="IP Address Settings")
        self.dialog_window.set_transient_for(self.screen)
        self.dialog_window.set_modal(True)
        self.dialog_window.set_decorated(False)
        self.dialog_window.set_resizable(False)
        self.dialog_window.get_style_context().add_class("power_panel")
        self.dialog_window.set_default_size(self.screen.width, self.screen.height)
        
        # Set window to appear below loading dialog
        self.dialog_window.set_keep_below(True)

        # RGBA visual settings
        screen = Gdk.Screen.get_default()
        visual = screen.get_rgba_visual()
        if visual is not None and screen.is_composited():
            self.dialog_window.set_visual(visual) 

        # Add box to window
        self.dialog_window.add(self)            
        self.dialog_window.show_all()
     


    def on_set_clicked(self, widget=None):
        static_ip = self.static_ip_button.get_label()
        server_ip = self.server_ip_button.get_label()
        mask_ip = self.mask_ip_button.get_label()


        if self.check_ip_address(static_ip, server_ip, mask_ip):
            if self.type == "wlan":
                new_dialog=self.loading_dialog(static_ip)
                threading.Thread(target=self.set_static_ip_wlan, args=(static_ip,server_ip,mask_ip), daemon=True).start()
                # self.set_static_ip_wlan(static_ip,server_ip,mask_ip) 

                if self.network_panel:
                    self.network_panel.wlan_ip_button.set_label(static_ip)
            else:
                new_dialog=self.loading_dialog(static_ip)
                threading.Thread(target=self.set_ip_address, args=(static_ip, server_ip, mask_ip), daemon=True).start()
                # self.set_ip_address(static_ip, server_ip, mask_ip)
                self.config.update_sub_value(ConfigKeys.STATIC_IP, None, static_ip)
                self.config.update_sub_value(ConfigKeys.SERVER_IP, None, server_ip)
                self.config.update_sub_value(ConfigKeys.MASK_IP, None, mask_ip)
                self.config.update_sub_value(ConfigKeys.LAN_MANUAL, None, "True")
                if self.network_panel:
                    self.network_panel.lan_ip_button.set_label(static_ip)
                PopupNotification(
                    message=f"IP address changed: {static_ip}/{mask_ip}/{server_ip}",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=2,
                    tipe="S"
                )
        self.dialog_window.destroy()

    def on_cancel_clicked(self,widget=None):
        self.dialog_window.destroy()

    def get_ip_addresses(self):
        from panels.network_panel import NetWorkPanel
        nm = NetWorkPanel(self.screen)
        return nm.get_ip_addresses()
    
    def show_keypad(self, widget=None, type=None):
        # Get the current value based on the button type
        current_value = ""
        if type == "static":
            current_value = self.static_ip_button.get_label()
        elif type == "server":
            current_value = self.server_ip_button.get_label()
        elif type == "mask":
            current_value = self.mask_ip_button.get_label()

        keypad_window = Keypad(
            self.screen,
            self.theme_path,
            lambda value: self.handle_keypad(value, widget, type),
            type="ip"
        )
        keypad_window.show_keypad(text=current_value)

    def handle_keypad(self, value, widget=None, name=None):
        """
        Handle the value returned from the Keypad and update UI or state accordingly.
        """
        value = str(value)
        if name == "static":
            self.static_ip_button.set_label(value)
        elif name == "server":
            self.server_ip_button.set_label(value)
        elif name == "mask":
            self.mask_ip_button.set_label(value)
         
    def check_ip_address(self, static_ip, server_ip, mask_ip):
        try:
            # Check if any field is empty
            if not static_ip or not server_ip or not mask_ip:
                PopupNotification(
                    message="All IP fields must be filled!",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=True,
                    timeout=5,
                    tipe="E"
                )
                return False

            # IP format checks
            try:
                ip_static = ipaddress.IPv4Address(static_ip)  # Specifically check for IPv4
                ip_server = ipaddress.IPv4Address(server_ip)  # Specifically check for IPv4
                ip_mask = ipaddress.IPv4Address(mask_ip)
            except ipaddress.AddressValueError:
                PopupNotification(
                    message="IP addresses must be in IPv4 format!",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=True,
                    timeout=5,
                    tipe="E"
                )
                return False


            # Convert netmask to CIDR
            cidr = ipaddress.IPv4Network(f"0.0.0.0/{mask_ip}").prefixlen

            # Create networks
            static_network = ipaddress.IPv4Network(f"{static_ip}/{cidr}", strict=False)
            server_network = ipaddress.IPv4Network(f"{server_ip}/{cidr}", strict=False)

            # Are they the same IP?
            if static_ip == server_ip:
                PopupNotification(
                    message="Static IP and Server IP cannot be the same",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=True,
                    timeout=5,
                    tipe="E"
                )
                return False

            # Are they on the same network?
            if static_network.network_address != server_network.network_address:
                PopupNotification(
                    message="Static IP and Server IP are not on the same network",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=True,
                    timeout=5,
                    tipe="E"
                )
                return False

            # Check if both IPs are private
            if not ip_static.is_private:
                PopupNotification(
                    message="Static IP must be a private IP address",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=True,
                    timeout=5,
                    tipe="E"
                )
                
                return False
            
            if not ip_server.is_private:
                PopupNotification(
                    message="Server IP must be a private IP address",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=True,
                    timeout=5,
                    tipe="E"
                )
                return False

            # Is the static IP the network address?
            if ip_static == static_network.network_address:
                PopupNotification(
                    message="Static IP cannot be the network address",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=True,
                    timeout=5,
                    tipe="E"
                )
                return False

            # Is the static IP broadcast address?
            if ip_static == static_network.broadcast_address:
                PopupNotification(
                    message="Static IP cannot be the broadcast address",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=True,
                    timeout=5,
                    tipe="E"
                )
                return False

            # Is the server IP the network address?
            if ip_server == server_network.network_address:
                PopupNotification(
                    message="Server IP cannot be the network address",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=True,
                    timeout=5,
                    tipe="E"
                )
                return False

            # Is the server IP broadcast address?
            if ip_server == server_network.broadcast_address:
                PopupNotification(
                    message="Server IP cannot be the broadcast address",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=True,
                    timeout=5,
                    tipe="E"
                )
                return False

            print("✔️ All IP addresses are valid and consistent.")
            return True


        except ValueError as e:
            print("❌ Invalid IP address or netmask:", e)
            PopupNotification(
                message=f"Invalid IP address or netmask: {e}",
                screen=self.screen,
                them_path=self.theme_path,
                show_button=True,
                timeout=5,
                tipe="E"
            )
            return False
        
    # def get_active_ethernet_device(self):
    #     try:
    #         # nmcli komutuyla aktif bağlantıları al
    #         result = subprocess.run(
    #             ['nmcli', '-t', '-f', 'NAME,TYPE,DEVICE', 'connection', 'show'], 
    #             capture_output=True, text=True, check=True
    #         )
            
    #         # Çıktıyı satırlara ayır
    #         connections = result.stdout.strip().split('\n')
            
    #         # Her bağlantıyı kontrol et
    #         for line in connections:
    #             # -t parametresi ile alanlar ':' ile ayrılıyor
    #             fields = line.split(':')
    #             if len(fields) >= 2:
    #                 name, conn_type, device = fields[0], fields[1], fields[2]
                    
    #                 # Ethernet bağlantısını bul (802-3-ethernet tipinde ve eth0'a bağlı)
    #                 if device == 'eth0' or device == 'eno1' or device == 'end0' or conn_type == '802-3-ethernet':
    #                     return name,conn_type,device

    #         return None
        
        
    #     except subprocess.CalledProcessError  as e:
    #         print(f"❌ Hata: {e}")
    #         return None
        
    # def get_active_wifi_device(self):
    #     try:
    #         # nmcli komutuyla aktif bağlantıları al
    #         result = subprocess.run(
    #             ['nmcli', '-t', '-f', 'NAME,TYPE,DEVICE', 'connection', 'show'], 
    #             capture_output=True, text=True, check=True
    #         )
            
    #         # Çıktıyı satırlara ayır
    #         connections = result.stdout.strip().split('\n')
            
    #         # Her bağlantıyı kontrol et
    #         for line in connections:
    #             # -t parametresi ile alanlar ':' ile ayrılıyor
    #             fields = line.split(':')
    #             if len(fields) >= 2:
    #                 name, conn_type, device = fields[0], fields[1], fields[2]
                    
    #                 # Ethernet bağlantısını bul (802-3-ethernet tipinde ve eth0'a bağlı)
    #                 if conn_type == 'wifi' or conn_type == '802-11-wireless' :
    #                     return name

    #         return None
        
        
    #     except subprocess.CalledProcessError  as e:
    #         print(f"❌ Hata: {e}")
    #         return None


    def set_ip_address(self, static_ip, gateway_ip, mask_ip):
        try:

            # Find the WiFi connection (starts with  wlan/wifi)
            connection_name,conn_type,device = self.wifi_manager.get_active_ethernet_device()
            if not connection_name:
                print("❌ No active Ethernet connection found")
                self.screen.show_Msg_Popup("No active Ethernet connection found", type="E", time=5)
                return False
            

            # Calculate CIDR
            cidr = ipaddress.IPv4Network(f"0.0.0.0/{mask_ip}").prefixlen
            ip_cidr = f"{static_ip}/{cidr}"
            print(connection_name)
            print("------------------------")

            # Set the IP addresses
            self.wifi_manager.set_manual_ip_address(connection_name,ip_cidr,gateway_ip)
            print(f"✔️ WiFi IP address set to: {ip_cidr}")
            self.window_dialog.update_control_message(1)

            self.window_dialog.update_control_message(2)
            time.sleep(1)
            self.window_dialog.destroy()

            return True

        except subprocess.CalledProcessError as e:
            error_msg = f"Failed to set WiFi IP: {str(e)}"
            PopupNotification(
                message=error_msg,
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                    timeout=0,
                    tipe="E"
                )
            print(f"❌ Error: {error_msg}")
            self.window_dialog.destroy()
            return False 

    def set_static_ip_wlan(self, static_ip, server_ip, mask_ip):

        try:

            connection_name,conn_type,device = self.wifi_manager.get_active_wifi_device()
            if not connection_name:
                print("❌ No active WiFi connection found")
                PopupNotification(
                    message="No active WiFi connection found",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=0,
                    tipe="E"
                )
                return False

            # Calculate CIDR
            cidr = ipaddress.IPv4Network(f"0.0.0.0/{mask_ip}").prefixlen
            ip_cidr = f"{static_ip}/{cidr}"


            self.wifi_manager.set_manual_ip_address(connection_name,ip_cidr,server_ip)
            PopupNotification(
                message=f"WiFi IP successfully set to {static_ip}",
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                timeout=2,
                tipe="S"
            )
            print(f"✔️ WiFi IP address set to: {ip_cidr}")
            self.window_dialog.update_control_message(1)
            self.window_dialog.update_control_message(2)
            self.config.update_sub_value(ConfigKeys.WLAN_MANUAL,None, "True")
            time.sleep(1)
            self.window_dialog.destroy()

            return True

        except subprocess.CalledProcessError as e:
            error_msg = f"Failed to set WiFi IP: {str(e)}"
            PopupNotification(
                message=error_msg,
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                    timeout=0,
                    tipe="E"
                )
            # self.screen.show_Msg_Popup(error_msg, type="E", time=5)
            print(f"❌ Error: {error_msg}")
            self.window_dialog.destroy()
            return False

    def get_interfaces(self):
        interfaces = netifaces.interfaces()
        return interfaces


    
    def get_interface_by_connected_ssid(self):
        try:
            # Get connected SSID
            ssid = subprocess.check_output(["iwgetid", "-r"]).decode().strip()
            if not ssid:
                print("❌ No connected SSID found")
                return None

            # Get device information
            result = subprocess.check_output(
                ["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device"]
            ).decode().splitlines()

            # Find matching wifi device
            for line in result:
                try:
                    device, dev_type, state, connection = line.split(":")
                    if dev_type == "wifi" and state == "connected" and connection == ssid:
                        return device
                except ValueError:
                    continue

            print("❌ No matching wifi interface found")
            return None
        
        except subprocess.CalledProcessError as e:
            print(f"❌ Error getting interface: {e}")
            return None
        except Exception as e:
            print(f"❌ Unexpected error: {e}")
            return None
    
    def get_default_gateway(self, interface_id):
        try:
            # Check if interface_id is None or empty
            if not interface_id:
                print("❌ Warning: Invalid interface ID")
                return None
            
            # Get default gateway from route
            route_cmd = subprocess.run(['ip', 'route', 'show', 'default'], 
                                     capture_output=True, text=True, check=True)
            
            if not route_cmd.stdout.strip():
                print("❌ No route information available")
                return None
            
            line_route_cmd = route_cmd.stdout.strip().split("\n")
            default_gateway = None
            
            for line in line_route_cmd:
                if interface_id in line:
                    parts = line.split()
                    if len(parts) > 2:
                        default_gateway = parts[2]
                        break
                
            if default_gateway is None:
                print(f"❌ No default gateway found for interface: {interface_id}")
            
            return default_gateway
        
        except subprocess.CalledProcessError as e:
            print(f"❌ Error getting default gateway: {e}")
            return None
        except Exception as e:
            print(f"❌ Unexpected error getting default gateway: {e}")
            return None

    def loading_dialog(self,ip_address):
        def close_dialog():
            self.window_dialog.destroy()

        self.window_dialog = C2PDialog(
            self.screen,
            self.screen,
            ["Ip Address Changed please wait","set ip adress:"+ip_address], None,
            False, True, tipe="control",
            theme_path=self.theme_path,
            button_names=["Close"],
            title="Ip Address Change warning",
            sp_commands=[close_dialog]
        )

        # Set window to appear above other windows
        self.window_dialog.set_keep_above(True)
        return self.window_dialog