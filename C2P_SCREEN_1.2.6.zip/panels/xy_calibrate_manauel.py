import math,os
from elements.keypad import Keypad
from elements.progress_circle import ProgressCircle
from library.global_manager import GlobalVariables
from elements.c2p_gtk import CtoPGtk
from elements.move_tool_changer_bottons import ToolChangerButtons
from elements.popup import PopupNotification
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
from library.xy_print_file import XYPrint
from library.c2p_files_manager import c2p
from elements.c2p_dialog import C2PDialog


class XYCalibrateManuel(GlobalVariables):
    def __init__(self, screen):
        super().__init__(screen)
        ctop_gtk = CtoPGtk(self.screen, self.theme_path)
        self.temp = {}
        self.current_temp_tools = [220,220,220,220]
        self.max_temp_tools = [300,300,300,300]
        self.min_temp_tools = [170,170,170,170]
        self.pressed_tools = []
        self.select_xy_offset = 0
        home_path = os.path.expanduser("~")
        imagefilepath = os.path.join(home_path, "printer_data", "printer_gcode", ".thumbs", "xyCalibrate-400x300.png")
        self.xy_calibrate_manuel_main_box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,spacing=40)
        top_grid = Gtk.Grid()
        top_grid.set_column_spacing(20)
        top_grid.set_row_spacing(20)
        top_grid.set_halign(Gtk.Align.CENTER)
        tools_grid = Gtk.Grid()
        tools_grid.set_column_spacing(53)
        tools_grid.set_halign(Gtk.Align.CENTER)
        set_manual_box_all = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,style="print_control_box",width=self.screen.width/1.1428,height=self.screen.height/5.039)
        set_manual_box_all.set_halign(Gtk.Align.CENTER)
        set_manual_box = ctop_gtk.c2p_box(spacing=30)
        set_manual_box.set_halign(Gtk.Align.CENTER)
        set_xy_box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,spacing=20)
        select_tool_top_box_all = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,style="print_control_box",width=self.screen.width/2.285,height=self.screen.height/20.333)
        select_tool_bottom_box_all = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,style="print_control_box",width=self.screen.width/2.285,height=self.screen.height/20.333)
        select_tool_top_box = ctop_gtk.c2p_box()
        select_tool_top_box.set_halign(Gtk.Align.CENTER)
        select_tool_bottom_box = ctop_gtk.c2p_box()
        select_tool_bottom_box.set_halign(Gtk.Align.CENTER)
        right_image_box = ctop_gtk.c2p_box(style="right_image_box")
        select_tool_set_grid = Gtk.Grid()
        select_tool_set_grid.set_column_spacing(20)

        line_box_top = ctop_gtk.c2p_box("text_box", self.screen.width / 1.86,
                                    4,
                                    Gtk.Orientation.VERTICAL)
        line_box_center = ctop_gtk.c2p_box("text_box", self.screen.width / 1.86,
                                    4,
                                    Gtk.Orientation.VERTICAL)
        line_box_bottom = ctop_gtk.c2p_box("text_box", self.screen.width / 1.86,
                                    4,
                                    Gtk.Orientation.VERTICAL)
        x_box = ctop_gtk.c2p_box(style="image_box",width=self.screen.width/2.666,height=self.screen.height/21.333)
        y_box = ctop_gtk.c2p_box(style="image_box",width=self.screen.width/2.666,height=self.screen.height/21.333)

        tools_button_labels = ["01", "02", "03", "04"]
        self.top_tool_buttons = {}
        for lbl, active_device in zip(tools_button_labels,self.screen.printer.get_active_extruders()):
            self.top_tool_buttons[lbl] = ctop_gtk.Button_new(label=lbl, style="nozzle_auto_tools_buttons")
            self.top_tool_buttons[lbl].connect('clicked', self.select_tool,"top",lbl)
            if active_device is None:
                self.top_tool_buttons[lbl].set_sensitive(False)
            select_tool_top_box.add(self.top_tool_buttons[lbl])

        self.bottom_tool_buttons = {}
        for lbl, active_device in zip(tools_button_labels, self.screen.printer.get_active_extruders()):
            self.bottom_tool_buttons[lbl] = ctop_gtk.Button_new(label=lbl, style="nozzle_auto_tools_buttons")
            self.bottom_tool_buttons[lbl].connect('clicked', self.select_tool, "bottom",lbl)
            if active_device is None:
                self.bottom_tool_buttons[lbl].set_sensitive(False)
            select_tool_bottom_box.add(self.bottom_tool_buttons[lbl])
        print_button = ctop_gtk.Button_new()
        print_button.set_halign(Gtk.Align.CENTER)

        self.set_tool_buttons = {}
        n=0
        m=0
        flg_active = True
        for index, (lbl,active_device) in enumerate(zip(tools_button_labels, self.screen.printer.get_active_extruders())):
            self.set_tool_buttons[lbl] = ctop_gtk.Button_new(label=lbl, style="nozzle_auto_tools_buttons")
            self.set_tool_buttons[lbl].connect('clicked', self.select_tool, "set_xy",index)
            if n > 1:
                m += 1
                n = 0
            n += 1
            select_tool_set_grid.attach(self.set_tool_buttons[lbl], n, m, 1, 1)
            if active_device is None:
                self.set_tool_buttons[lbl].set_sensitive(False)
                continue
            if flg_active:
                self.select_xy_offset = index
                self.set_tool_buttons[lbl].get_style_context().add_class("nozzle_auto_tools_buttons_pressed")
                flg_active = False
            
        setxy_button =  ctop_gtk.Button_new(label="Set x&y", style="nozzle_auto_tools_buttons")
        setxy_button.connect('clicked', self.set_xy_offset_func)
        select_tool_set_grid.attach(setxy_button, 1, m+1, 2, 1)
        print_button = ctop_gtk.Button_new("print_xy",label="Print",style="xy_calibrate_print_button",position=Gtk.PositionType.LEFT)
        print_button.connect('clicked', self.xy_print)
        print_button.set_halign(Gtk.Align.CENTER)
        x_label = ctop_gtk.c2p_label("X:",style="print_label")
        y_label = ctop_gtk.c2p_label("Y:",style="print_label")
        self.x_value_label = ctop_gtk.c2p_label("X:", style="print_label")
        self.y_value_label = ctop_gtk.c2p_label("Y:", style="print_label")
        self.entry_x = Gtk.Entry()  # Input field for text entry
        self.entry_x.get_style_context().add_class("entry_xu_manauel")
        self.entry_x.connect("button-press-event", self.on_xy_offset_clicked,"x")
        self.entry_y = Gtk.Entry()  # Input field for text entry
        self.entry_y.get_style_context().add_class("entry_xu_manauel")
        self.entry_y.connect("button-press-event", self.on_xy_offset_clicked,"y")
        select_tool_label_top = ctop_gtk.c2p_label("Select Tool 1","print_label")
        select_tool_label_top.set_halign(Gtk.Align.START)
        select_tool_label_bottom = ctop_gtk.c2p_label("Select Tool 2","print_label")
        select_tool_label_bottom.set_halign(Gtk.Align.START)
        set_manuel_label = ctop_gtk.c2p_label("Set Manual X & Y Coordinates","print_label")
        set_manuel_label.set_halign(Gtk.Align.START)
        self.show_temp_circles(tools_grid)
        # right_image = ctop_gtk.PixbufFromFile("picture",100,100)
        pixbuf = ctop_gtk.pixbuf_from_file_circular(imagefilepath,240,240)
        right_image = Gtk.Image.new_from_pixbuf(pixbuf)
        right_image_box.pack_start(right_image,False,False,0)
        top_grid.attach(right_image_box,1,0,1,2)
        x_box.add(x_label)
        x_box.add(self.entry_x)
        y_box.add(y_label)
        y_box.add(self.entry_y)
        set_xy_box.add(x_box)
        set_xy_box.add(y_box)
        set_manual_box.pack_start(set_xy_box,False,False,0)
        set_manual_box.pack_start(select_tool_set_grid,False,True,0)
        select_tool_top_box_all.add(select_tool_label_top)
        select_tool_top_box_all.add(line_box_top)
        select_tool_top_box_all.add(select_tool_top_box)
        select_tool_bottom_box_all.add(select_tool_label_bottom)
        select_tool_bottom_box_all.add(line_box_center)
        select_tool_bottom_box_all.add(select_tool_bottom_box)
        top_grid.attach(select_tool_top_box_all,0,0,1,1)
        top_grid.attach(select_tool_bottom_box_all, 0, 1, 1, 1)
        set_manual_box_all.add(set_manuel_label)
        set_manual_box_all.add(line_box_bottom)

        set_manual_box_all.add(set_manual_box)
        self.xy_calibrate_manuel_main_box.add(top_grid)
        self.xy_calibrate_manuel_main_box.add(tools_grid)
        self.xy_calibrate_manuel_main_box.add(print_button)
        self.xy_calibrate_manuel_main_box.add(set_manual_box_all)
        self.c2p_func_h = c2p(self.screen)
        self.get_show_xy_offset(self.select_xy_offset)
    
    def get_content(self):
        return self.xy_calibrate_manuel_main_box,"XYM Calibrate"
    
    def show_temp_circles(self, temp_progress_grid):
        for child in temp_progress_grid.get_children():
            temp_progress_grid.remove(child)
        self.progress_circle1 = ProgressCircle(self.screen, panel="gcode",w=128,h=265,
                                               name="extruder",
                                               label="01",
                                               progress=0,

                                               current_temp=0,

                                               style=self.style,
                                               active=False,
                                            #    css_color=[128,255,255,255],
                                               angle=-math.pi / 2,
                                               command=lambda: self.get_object_name(name="extruder"))

        self.progress_circle2 = ProgressCircle(self.screen, panel="gcode",w=128,h=265,
                                               name="extruder1",
                                               label="02",
                                               progress=0,

                                               current_temp=0,

                                               style=self.style, active=False,
                                               angle=-math.pi / 2,
                                               command=lambda: self.get_object_name(name="extruder1"))
        self.progress_circle3 = ProgressCircle(self.screen, panel="gcode",w=128,h=265,
                                               name="extruder2",
                                               label="03",
                                               progress=0,

                                               current_temp=0,

                                               style=self.style, active=False,
                                               angle=-math.pi / 2,
                                               command=lambda: self.get_object_name(name="extruder2"))
        self.progress_circle4 = ProgressCircle(self.screen, panel="gcode",w=128,h=265,
                                               name="extruder3",
                                               label="04",
                                               progress=0,

                                               current_temp=0,

                                               style=self.style, active=False,
                                               angle=-math.pi / 2,
                                               command=lambda: self.get_object_name(name="extruder3"))

        self.progress_devices = [
            self.progress_circle1, self.progress_circle2,
            self.progress_circle3, self.progress_circle4

        ]


        temp_progress_grid.attach(self.progress_circle1, 0, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle2, 1, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle3, 2, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle4, 3, 1, 1, 1)
        temp_progress_grid.show_all()

    def process_update(self, action, data):
           if action != "notify_status_update":
            return
           self.update_temp(data)

    def update_temp(self,data):
        for index, (device, progress) in enumerate(zip(
                self.screen.printer.get_origin_extruders(), self.progress_devices
            )):
            if device is None:
                continue
            self.temp[device] = self.screen.printer.get_dev_stat(device, "temperature")
            target = self.screen.printer.get_dev_stat(device, "target")
            progress.set_target(target)
            if "temperature_sensor" not in device:
                max_temp = self.screen.printer.get_dev_stat(device,
                                                            "max_temp")
                min_temp = self.screen.printer.get_dev_stat(device,
                                                            "min_extrude_temp")
                self.max_temp_tools[index] = max_temp
                self.min_temp_tools[index] = min_temp
                if self.temp[device] is not None:
                    progress.set_current_temp(self.current_temp_tools[index],
                                              self.current_temp_tools[index] / max_temp, max_temp, True)

    def get_object_name(self, widget=None, name=None):
        self.show_keypad(widget, name)

    def show_keypad(self, widget=None, type=None):
        # Determine the initial value for the keypad
        indexselect = None
        if type in self.screen.printer.get_active_extruders() + self.screen.printer.get_heaters():
            for index, (progress, device) in enumerate(zip(
                    self.progress_devices,
                    self.screen.printer.get_active_extruders() + self.screen.printer.get_heaters()
                )):
                if device == type:
                    indexselect = index
                    break
        if indexselect is None:
            return
        keypad_value = self.current_temp_tools[indexselect]
        # Create a new Keypad instance and use lambda to pass the value directly to handle_keypad
        keypad_window = Keypad(
            self.screen,
            self.theme_path,
            lambda value: self.handle_keypad(value, widget, indexselect),
            min_value = self.min_temp_tools[indexselect],
            max_value = self.max_temp_tools[indexselect]
        )
        keypad_window.show_keypad(text=keypad_value)
    
    def handle_keypad(self, value, widget, indexselect):
        """
        Handle the value returned from the Keypad and update UI or state accordingly.
        """
        self.current_temp_tools[indexselect] = value
        self.update_temp(None)

    def select_tool(self,widget,tip,lbl):
        tools_button_labels = ["01", "02", "03", "04"]
        if tip == "top":
            for b,progress,t_number in zip(self.top_tool_buttons.values(),self.progress_devices,tools_button_labels):
                if t_number == lbl :
                    if len(self.pressed_tools) == 4:
                        self.pressed_tools[0].on_button_release()
                        self.pressed_tools[2].on_button_release()
                        self.pressed_tools = []
                        for a_button in self.bottom_tool_buttons.values():
                            a_button.get_style_context().remove_class("xy_calibrate_button_bottom_pressed")
                    self.pressed_tools.append(progress)
                    self.pressed_tools.append("top")
                    if self.style == "light":
                        progress.change_button_color(color=[246/255, 68/255, 193/255])
                    else:
                        progress.change_button_color(color=[246/255, 68/255, 193/255])
                # elif len(self.pressed_tools) > 3:
                #     self.pressed_tools = []
                else:
                    if "bottom" not in self.pressed_tools:
                        progress.on_button_release()
                b.get_style_context().remove_class("xy_calibrate_button_pressed")
            widget.get_style_context().add_class("xy_calibrate_button_pressed")
        elif tip == "bottom":
            for b,progress,t_number in zip(self.bottom_tool_buttons.values(),self.progress_devices,tools_button_labels):
                if t_number == lbl :
                    if len(self.pressed_tools) == 4:
                        self.pressed_tools[0].on_button_release()
                        self.pressed_tools[2].on_button_release()
                        self.pressed_tools = []
                        for a_button in self.top_tool_buttons.values():
                            a_button.get_style_context().remove_class("xy_calibrate_button_pressed")

                    self.pressed_tools.append(progress)
                    self.pressed_tools.append("bottom")
                    progress.change_button_color(color=[216/255, 216/255, 67/255])
                else:
                    if "top" not in self.pressed_tools:
                        progress.on_button_release()
                # else:
                #     progress.on_button_release()
                b.get_style_context().remove_class("xy_calibrate_button_bottom_pressed")
            widget.get_style_context().add_class("xy_calibrate_button_bottom_pressed")
        elif tip == "set_xy":
            for b in self.set_tool_buttons.values():
                b.get_style_context().remove_class("nozzle_auto_tools_buttons_pressed")
            self.select_xy_offset = lbl
            widget.get_style_context().add_class("nozzle_auto_tools_buttons_pressed")
            self.get_show_xy_offset(self.select_xy_offset)

    def on_xy_offset_clicked(self, widget,event, tipe):
        keypad_value = 0
        if tipe == "x":
            keypad_value = float(self.entry_x.get_text())
            # VirtualKeyboard(self.screen, self.theme_path, self.x_value_label.get_text(), self.on_search_changed)
        elif tipe == "y":
            keypad_value = float(self.entry_y.get_text())
            # VirtualKeyboard(self.screen, self.theme_path, self.y_value_label.get_text(), self.on_search_changed)

        keypad_window = Keypad(
            self.screen,
            self.theme_path,
            lambda value: self.handle_xy_offset_keypad(value, widget, tipe),
            min_value = 0,
            max_value = 50
        )
        keypad_window.show_keypad(text=keypad_value)
        self.tipe = tipe

    def handle_xy_offset_keypad(self, value, widget, type):
        if type == "x":
            self.entry_x.set_text(str(value))
        elif type == "y":
            self.entry_y.set_text(str(value))

    def get_show_xy_offset(self,index):
        xyOffset = self.c2p_func_h.get_xy_offset(index)
        self.entry_x.set_text(str(xyOffset[0]))
        self.entry_y.set_text(str(xyOffset[1]))

    def set_xy_offset_func(self, widget):
        x_value = float(self.entry_x.get_text())
        y_value = float(self.entry_y.get_text())
        vstr = f"CP_XY_SAVE_OFFSET " + "T=" + str(self.select_xy_offset) + " X=" + str(x_value) + " Y=" + str(y_value)
        self.screen._ws.klippy.gcode_script(vstr)
        GLib.timeout_add(100, self.update_xy_offset)

    def update_xy_offset(self):
        self.c2p_func_h = c2p(self.screen)
        self.get_show_xy_offset(self.select_xy_offset)
        return False

    def xy_print(self,widget):
        xyprint = XYPrint()
        def on_yes():
            start_print()
            dialog.destroy()

        def on_no():
            dialog.destroy()

        def start_print():
            # filename = xyprint.Get_Print_File()
            if self.screen.printer.evaluate_state()[0] == 'ready':
                state = make_xy_print()
                if state:
                    filename = xyprint.Get_Print_File()
                    # logging.info(f"Starting print: {filename}")
                    # print("SDCARD_PRINT_PATH PATH=" + filename)
                    # SDCARD_PRINT_PATH
                    # filename="/home/pi/printer_data/printer_gcode/_XY_Calibrate.gcode"
                    self.screen._ws.klippy.gcode_script(
                        "SDCARD_PRINT_PATH PATH=" + filename)
                   # self.refresh_content(Printing_panel(self.screen, filename, self))
                else:
                    self.show_error("Unable to change the file!")
            else:
                self.show_error("Please wait to finish print")

        def make_xy_print():
            selected_tools = []
            selected_temps = []
            for index, b in enumerate(self.top_tool_buttons.values()):
                style_context = b.get_style_context()
                if "xy_calibrate_button_pressed" in style_context.list_classes():
                    selected_tools.append(f"T{index}")
                    temp_value = self.current_temp_tools[index]
                    # Ensure temperature formatting
                    if isinstance(temp_value, float) and temp_value.is_integer():  # If it's like 220.0, convert to 220 (int)
                        temp_value = int(temp_value)
                    elif isinstance(temp_value, float):
                        temp_value = round(temp_value, 1)  # Keep one decimal place
                    selected_temps.append(temp_value)

            for index, b in enumerate(self.bottom_tool_buttons.values()):
                style_context = b.get_style_context()
                if "xy_calibrate_button_bottom_pressed" in style_context.list_classes():
                    selected_tools.append(f"T{index}")
                    temp_value = self.current_temp_tools[index]
                    # Ensure temperature formatting
                    if isinstance(temp_value, float) and temp_value.is_integer():
                        temp_value = int(temp_value)
                    elif isinstance(temp_value, float):
                        temp_value = round(temp_value, 1)  # Keep one decimal place
                    selected_temps.append(temp_value)

            if len(selected_tools) < 2 or selected_tools[0] == selected_tools[1]:
                PopupNotification(
                    message="The tools must be selected correctly",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=5,
                    tipe="E"
                )
                return False
            filename = xyprint.Get_Print_File()
            # filename="/home/pi/printer_data/printer_gcode/_XY_Calibrate.gcode"
            toolsold = xyprint.Get_Tools(filename)
            return xyprint.replace_tools(filename,toolsold,selected_tools,selected_temps,70)
        
        dialog = C2PDialog(
            self.screen,
            self.screen,
            "Are you sure you want to print XY calibrate file?",
            theme_path=self.theme_path,
            title="Warning",
            button_names=["Yes", "No"],
            sp_commands=[on_yes, on_no]
        )
        
    def show_error(self,text):
        PopupNotification(
                    message=text,
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=5,
                    tipe="E"
                )
        
        



