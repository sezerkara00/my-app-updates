from elements.c2p_dialog import C2PDialog
from elements.keyboard import VirtualKeyboard
from elements.password_dialog import PasswordDialog
from elements.popup import PopupNotification
from library.ethernet_manager import WifiManager,WifiManagerff
from library.global_manager import GlobalVariables
from elements.c2p_gtk import CtoPGtk
from elements.keypad import Keypad
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
from panels.ip_adress_dialog_panel import IPAdressDialogPanel
import netifaces
import time
import subprocess
from library.c2p_config import C2PConfig, ConfigKeys
import ipaddress
from panels.emergency_panel import EmergencyPanel
import threading
class NetWorkPanel(GlobalVariables):

    def __init__(self, screen):
        super().__init__(screen)
        self.ctop_gtk = CtoPGtk(screen,self.theme_path)
        self.screen.base_panel.update_title("Network Panel")
        self.wifi_manager = WifiManager()
        self.network_buttons = {}
        self.connected = ""
        self.search_index = 0
        self.config = C2PConfig(screen)
        self.config.read_c2p_config()
        self.style = self.get_style()
        # Get IP Address
        self.wlan_ip,self.lan_ip = self.get_ip_addresses()
        self.main_network_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,spacing=20)
        self.main_network_box.set_halign(Gtk.Align.CENTER)
        top_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=5,
                                             width=self.screen.width / 1.111, height=self.screen.height / 5.565,style="print_control_box")
        bottom_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=5,
                                             width=self.screen.width / 1.111, height=self.screen.height / 1.708,style="print_control_box")
        line_box_top = self.ctop_gtk.c2p_box("text_box", self.screen.width / 1.86,
                                        4,
                                        Gtk.Orientation.VERTICAL)
        line_box_bottom = self.ctop_gtk.c2p_box("text_box", self.screen.width / 1.86,
                                           4,
                                           Gtk.Orientation.VERTICAL)
        ip_box = self.ctop_gtk.c2p_box()
        ip_box.set_halign(Gtk.Align.CENTER)
        ip_address_box= self.ctop_gtk.c2p_box()
        wlan_ip_box = self.ctop_gtk.c2p_box()
        wlan_ip_box.set_halign(Gtk.Align.CENTER)
        wlan_ip_address_box = self.ctop_gtk.c2p_box(spacing=70)

        switch_box = self.ctop_gtk.c2p_box(style="switch_box_network",spacing=10)

        ssid_box = self.ctop_gtk.c2p_box("image_box",width=self.screen.width / 1.322, height=self.screen.height / 2.876)
        ssid_box.set_halign(Gtk.Align.CENTER)
        ssid_scroll_all = Gtk.ScrolledWindow()
        ssid_scroll_all.set_hexpand(True)
        ssid_scroll_all.set_vexpand(False)
        ssid_scroll_all.get_style_context().add_class("scrolled_window")

        self.ssid_grid = Gtk.Grid()
        self.ssid_grid.set_row_spacing(15)
        self.ssid_grid.get_style_context().add_class("ssid_grid")

        lan_label = self.ctop_gtk.c2p_label("LAN","print_label")
        wlan_label = self.ctop_gtk.c2p_label("WLAN","print_label")
        ip_address_label  = self.ctop_gtk.c2p_label("IP Address:", "print_label")
        wlan_ip_address_label = self.ctop_gtk.c2p_label("IP Address:", "print_label")

        # Set initial states
        set_lan_manual =self.config.get_value(ConfigKeys.LAN_MANUAL)
        set_wlan_manual =self.config.get_value(ConfigKeys.WLAN_MANUAL)
        self.manual_ip_active = True if set_lan_manual == "True" else False # Manual IP starts active
        self.wlan_manual_ip_active = True if set_wlan_manual == "True" else False  # WLAN Manual IP starts active

        

        self.wlan_ip_button = self.ctop_gtk.Button_new(label=self.wlan_ip, style="ip_address_button")
        self.wlan_ip_button.connect("clicked",self.show_wlan_ip_dialog)


        # WLAN buttons
        if self.wlan_manual_ip_active:
            self.wlan_manual_ip = self.ctop_gtk.Button_new(label="Manual IP", style="manual_ip_button_pressed")
            self.wlan_auto_ip = self.ctop_gtk.Button_new(label="Auto IP", style="manual_ip_button")
            self.wlan_ip_button.set_sensitive(True)
        else:
            self.wlan_manual_ip = self.ctop_gtk.Button_new(label="Manual IP", style="manual_ip_button")
            self.wlan_auto_ip = self.ctop_gtk.Button_new(label="Auto IP", style="manual_ip_button_pressed")
            self.wlan_ip_button.set_sensitive(False)
        self.wlan_manual_ip.connect("clicked", self.toggle_wlan_ip_mode)
        self.wlan_auto_ip.connect("clicked", self.show_yes_no_dialog_wlan)
        self.wlan_auto_ip.set_sensitive(False)

        # Check if wifi interface exists and set button states
        if self.wifi_manager.wireless_interfaces == []:
            self.wlan_manual_ip.set_sensitive(False)
            self.wlan_auto_ip.set_sensitive(False)
            self.wlan_ip_button.set_sensitive(False)
            self.wlan_manual_ip = self.ctop_gtk.Button_new(label="Manual IP", style="manual_ip_button")
            self.wlan_auto_ip = self.ctop_gtk.Button_new(label="Auto IP", style="manual_ip_button")
            self.wlan_ip_button.set_label("")



        # LAN buttons
        if self.manual_ip_active:
            self.manual_ip = self.ctop_gtk.Button_new(label="Manual IP", style="manual_ip_button_pressed")
            self.auto_ip = self.ctop_gtk.Button_new(label="Auto IP", style="manual_ip_button")

            self.lan_ip_button = self.ctop_gtk.Button_new(label=self.lan_ip,style="ip_address_button")
            self.lan_ip_button.set_sensitive(True)
        else:
            self.manual_ip = self.ctop_gtk.Button_new(label="Manual IP", style="manual_ip_button")
            self.auto_ip = self.ctop_gtk.Button_new(label="Auto IP", style="manual_ip_button_pressed")
            self.auto_ip.set_sensitive(True)

            self.lan_ip_button = self.ctop_gtk.Button_new(label=self.lan_ip,style="ip_address_button")
            self.lan_ip_button.set_sensitive(False)

        if not self.wifi_manager.get_connected_ssid():
                self.wlan_manual_ip = self.ctop_gtk.Button_new(label="Manual IP", style="manual_ip_button")
                self.wlan_auto_ip = self.ctop_gtk.Button_new(label="Auto IP", style="manual_ip_button")

            

        self.lan_ip_button.connect("clicked",self.show_network_dialog)
        self.manual_ip.connect("clicked", self.toggle_lan_ip_mode)
        self.auto_ip.connect("clicked", self.show_yes_no_dialog)
        lan_refresh_button = self.ctop_gtk.Button_new("restart",style="lan_restart_button",scale=.66)
        lan_refresh_button.connect("clicked",self.on_lan_refresh_button)
        # lan_refresh_button.connect("clicked",self.show_emergency_dialog)
        self.wlan_refresh_button = self.ctop_gtk.Button_new("restart", style="wlan_restart_button",scale=.66)
        self.wlan_refresh_button.connect("clicked", self.rescan_networks,True) 

        #wlan_refresh_button.connect("clicked",self.restart_page)
        self.wlan_refresh_button.set_valign(Gtk.Align.CENTER)
        self.wlan_refresh_button.set_halign(Gtk.Align.END)
        self.switch = Gtk.Switch()
        self.switch.get_style_context().add_class("custom-switch")



        self.scan_networks()


        ip_address_box.add(ip_address_label)
        ip_address_box.add(self.lan_ip_button)
        ip_address_box.add(lan_refresh_button)
        ip_box.add(self.manual_ip)
        ip_box.add(self.auto_ip)
        wlan_ip_address_box.add(wlan_ip_address_label)
        wlan_ip_address_box.pack_start(self.wlan_ip_button, False, False, 0)
        wlan_ip_box.add(self.wlan_manual_ip)
        wlan_ip_box.add(self.wlan_auto_ip)
        switch_box.pack_start(wlan_label,False,False,0)
        switch_box.pack_start(self.wlan_refresh_button,True,True,0)
        switch_box.pack_start(self.switch,False,False,0)
        ssid_box.add(ssid_scroll_all)
        ssid_scroll_all.add(self.ssid_grid)
        top_box.add(lan_label)
        top_box.add(line_box_top)
        top_box.add(ip_box)
        top_box.add(ip_address_box)



        bottom_box.add(switch_box)
        bottom_box.add(line_box_bottom)
        bottom_box.add(wlan_ip_box)
        bottom_box.add(wlan_ip_address_box)
        bottom_box.add(ssid_box)
        if self.config.get_value(ConfigKeys.WLAN_SWITCH) == "True":
                self.switch.set_active(True)
                self.wlan_refresh_button.set_sensitive(True)
        else:
                self.switch.set_active(False)
                self.on_switch_toggled(self.switch,None)
                self.on_switch_toggled(self.switch,None)
                self.wlan_refresh_button.set_sensitive(False)
        self.switch.connect("notify::active", self.on_switch_toggled)
        self.switch.set_valign(Gtk.Align.CENTER)



        self.main_network_box.add(top_box)
        self.main_network_box.add(bottom_box)

    def get_content(self):
        return self.main_network_box,"Network Panel"
    
    # def restart_page(self,widget):
    #     self.scan_networks()
    #     self.refresh_content(NetWorkPanel(self.screen))



    def on_switch_toggled(self, switch, param):
        if self.config.get_value(ConfigKeys.WLAN_SWITCH) == "True":
            self.config.update_sub_value(ConfigKeys.WLAN_SWITCH,None, "False")  
        else:
            self.config.update_sub_value(ConfigKeys.WLAN_SWITCH,None, "True")
        
        new_state = int(switch.get_active())
        if new_state == 1:
            # Turn on WiFi
            self.loading_dialog = self.create_loading_dialog("Opening WiFi")
            self.open_wifi_connection()
            self.loading_dialog.update_control_message(1)
            # Enable buttons when wifi is turned on
            self.wlan_manual_ip.set_sensitive(True)
            self.wlan_auto_ip.set_sensitive(True)
            self.wlan_ip_button.set_sensitive(True)
            self.wlan_refresh_button.set_sensitive(True)
            if self.wlan_manual_ip_active:
                self.wlan_manual_ip.get_style_context().add_class("manual_ip_button_pressed")
                self.wlan_auto_ip.get_style_context().add_class("manual_ip_button")
            else:
                self.wlan_auto_ip.get_style_context().add_class("manual_ip_button_pressed")
                self.wlan_manual_ip.get_style_context().add_class("manual_ip_button")
                
            # Add delay to allow WiFi to initialize
            GLib.timeout_add(1000, self._refresh_after_wifi_on)

        elif new_state == 0:
            self.wlan_refresh_button.set_sensitive(False)
            # Clear grid immediately when turning off
            for ch in self.ssid_grid.get_children():
                self.ssid_grid.remove(ch)
            self.wlan_ip_button.set_label("")
            self.close_wifi_connection()
            
            # Disable buttons when wifi is turned off
            self.wlan_manual_ip.set_sensitive(False)
            self.wlan_auto_ip.set_sensitive(False) 
            self.wlan_ip_button.set_sensitive(False)
            self.clear_wlan_button_style()

    def _refresh_after_wifi_on(self):
        """Helper method to refresh WiFi after turning on"""       
        # Add slight delay before full refresh
        time.sleep(1)
        self.loading_dialog.update_control_message(2)
        self.loading_dialog.destroy()
        # self.clear_wlan_button_style()
        # if self.wlan_manual_ip_active:
        #     self.wlan_manual_ip.get_style_context().add_class("manual_ip_button_pressed")
        # else:
        #     self.wlan_auto_ip.get_style_context().add_class("manual_ip_button_pressed")
        # self.rescan_networks(popup=True)
        GLib.idle_add(self.refresh_content, NetWorkPanel(self.screen))

        return False # Don't repeat the timeout

    def make_ssid_box(self,network):
        box_all = self.ctop_gtk.c2p_box()
        status = self.wifi_manager.get_network_info(network)


        box = self.ctop_gtk.c2p_box(width=self.screen.width / 1.777, height=self.screen.height / 14.222,style="layer_box")
        signal_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,style="ssid_grid")
        if len(network) > 14:
            network_short = network[:14]
            network_short = network_short + "..."
        else:
            network_short = network
        try:
            if "signal_level_dBm" in status:
                signal_level= int(status["signal_level_dBm"])
            else:
                signal_level = 90
        except:
            signal_level = 90
        if signal_level >= 80:
            signal_image = self.ctop_gtk.Image("signal-full")
            signal_label = self.ctop_gtk.c2p_label("Excellent", "title-right")
            network_label = self.ctop_gtk.c2p_label(network_short, "print_label")
            if self.wifi_manager.get_connected_ssid() == network:
                signal_image = self.ctop_gtk.Image("signal-full1")


        elif 60 <= signal_level < 80:
            signal_image = self.ctop_gtk.Image("signal-medium")
            signal_label = self.ctop_gtk.c2p_label("    Good    ", "title-right")
            network_label = self.ctop_gtk.c2p_label(network_short ,"print_label")
            if self.wifi_manager.get_connected_ssid() == network:
                signal_image = self.ctop_gtk.Image("signal-medium1")

        else:
            signal_image = self.ctop_gtk.Image("signal-low")
            signal_label = self.ctop_gtk.c2p_label("    Low     ", "title-right")
            network_label = self.ctop_gtk.c2p_label(network_short, "print_label")
            if self.wifi_manager.get_connected_ssid() == network:
                signal_image = self.ctop_gtk.Image("signal-low1")

       # if network in self.wifi_manager.get_known_networks():

        if (self.connected == "" and self.wifi_manager.get_connected_ssid()==network) or (self.connected and self.wifi_manager.get_connected_ssid()==network):
            self.wlan_auto_ip.set_sensitive(True)
            box.get_style_context().add_class("layer_box_pressed")
            network_label.get_style_context().add_class("white_color")
            signal_label.get_style_context().add_class("white_color")

            connect_button = self.ctop_gtk.Button_new("close_keypad", style="bed_mesh_points_button")
            connect_button.connect("clicked", self.show_connect_dialog, network, "disconnect")
        else:
            connect_button = self.ctop_gtk.Button_new("Right", style="bed_mesh_points_button")
            connect_button.connect("clicked", self.show_connect_dialog, network)




        # else:
        #     connect_button = self.ctop_gtk.Button_new("Right", style="bed_mesh_points_button")
        #     connect_button.connect("clicked", self.show_connect_dialog, network)

        signal_box.add(signal_image)
        signal_box.add(signal_label)
        box.pack_start(network_label,True,True,0)
        box.pack_start(self.ctop_gtk.create_separator(False),False,False,0)
        box.pack_start(signal_box,False,False,0)
        box_all.add(box)
        box_all.add(connect_button)
        return box_all

    def show_connect_dialog(self, widget,network,tipe=None):
        if tipe == "disconnect":
            self.connected = False
            self.show_disconnect_dialog(network)
            self.wlan_auto_ip.set_sensitive(False)
            self.wlan_ip_button.set_sensitive(False)
            self.clear_wlan_button_style()
            self.scan_networks()
            return
        else:
            self.wlan_auto_ip.set_sensitive(True)
            self.wlan_ip_button.set_sensitive(True)
        if network in self.wifi_manager.get_known_networks():
            self.wifi_manager.connect(network)
            self.connected = True
            self.wlan_auto_ip.set_sensitive(True)
            self.wlan_ip_button.set_sensitive(True)
            self.refresh_wifi_ip_address()
            self.clear_wlan_button_style()
            self.wlan_manual_ip.get_style_context().remove_class("manual_ip_button")
            self.wlan_manual_ip.get_style_context().add_class("manual_ip_button_pressed")

            # self.wlan_ip_button.set_label(self.get_ip_addresses()[0])

            GLib.timeout_add_seconds(1,self.scan_networks)
            return
        tree_iter = network
        if tree_iter is None:
            return
        ssid = tree_iter
        self.dialog_password = PasswordDialog(self.screen,self.theme_path,style=self.style,title=f"🔑 Connect to {ssid}",label=f"🔐 Enter password for {ssid}:",command=lambda a ,b: self.show_keyboard(a,b),buttons_labels=["Connect","Cancel"],buttons_command=[lambda a : self.connect_to_wifi(None,network),lambda a: self.close_pass_word_dialog(a)])

    def show_disconnect_dialog(self,network):
        def close_dialog():
            self.refresh_wifi_ip_address()
            self.scan_networks()
            dialog.destroy()
            GLib.idle_add(self.refresh_content, NetWorkPanel(self.screen))

        def disconnect_network():
            self.wifi_manager.disconnect()
            # self.refresh_wifi_ip_address()
            # self.scan_networks()
            dialog.destroy()
            self.config.update_sub_value(ConfigKeys.WLAN_MANUAL,None, "True")
            time.sleep(1)
            self.rescan_networks()
            # self.refresh_content(NetWorkPanel(self.screen))

            

        def forget_network():
            self.wifi_manager.delete_network(network)
            self.wlan_ip_button.set_label("")
            dialog.destroy()
            # self.refresh_wifi_ip_address()
            # self.scan_networks()
            self.config.update_sub_value(ConfigKeys.WLAN_MANUAL,None, "True")
            time.sleep(1)
            GLib.idle_add(self.refresh_content, NetWorkPanel(self.screen))

        text = "Are you sure disconnect?"
        dialog=C2PDialog(
                            self.screen,
                            self.screen,
                            text,
                            theme_path=self.theme_path,
                            title="Warning",
                            button_names=["Disconnect", "Forget", "Cancel"],
                            sp_commands=[disconnect_network,forget_network, close_dialog]
                        )


    def show_keyboard(self,widget=None,event=None):
        VirtualKeyboard(self.screen, self.theme_path, '', self.on_edit_changed)

    def on_edit_changed(self, entrytext):
        self.dialog_password.set_entry_text(entrytext)
    def connect_to_wifi(self,widget=None,ssid=None):
            if ssid is None:
                return


            WifiManager().add_network(ssid, self.dialog_password.get_entry_text())
            if self.wifi_manager.get_connected_ssid() == ssid:
                self.dialog_password.destroy()
                self.connected = True
                self.refresh_wifi_ip_address()
                time.sleep(1)
                self.chang_wlan_ip()
                GLib.idle_add(self.refresh_content, NetWorkPanel(self.screen))

                PopupNotification(
                    message=f"Connected to {ssid}",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=5,
                    tipe='C'
                )

            else:
                PopupNotification(
                    message=f"The password is wrong",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=5,
                    tipe='E'
                )

            self.dialog_password.destroy()
            GLib.idle_add(self.scan_networks)

    def close_pass_word_dialog(self,widget):
        self.dialog_password.destroy()




    def scan_networks(self, widget=None):
        # if not self.wifi_manager.get_connected_ssid():
        #     self.wlan_ip_button.set_label("")
        #     self.wlan_ip_button.set_sensitive(False)

        # if self.wifi_manager.wireless_interfaces == []:
        #     self.wlan_manual_ip.set_sensitive(False)
        #     self.wlan_auto_ip.set_sensitive(False)
        #     self.wlan_ip_button.set_sensitive(False)
        #     return
        for ch in self.ssid_grid.get_children():
            self.ssid_grid.remove(ch)
 

        wifi_networks = self.wifi_manager.get_networks()
        if not wifi_networks:
            print("No Wi-Fi networks found!")
            return
        self.make_network_buttons(wifi_networks)

        # if self.wifi_manager.get_connected_ssid():
        #     self.refresh_wifi_ip_address()                


        print(f" Updated Wi-Fi list: {wifi_networks}")
        
        GLib.timeout_add(300, self.refresh_wifi_ip_address)

    

    
    def rescan_networks(self, widget=None, popup=False):
        """Scans for WiFi networks in a background thread to prevent UI freezes"""
        # Clear existing network list
        for ch in self.ssid_grid.get_children():
            self.ssid_grid.remove(ch)
        
        self.popup = None
        self.scan_start_time = time.time()
        
        # Show scanning popup if requested
        if popup:
            self.popup = PopupNotification(
                message="Scanning for networks...",
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                tipe='w',
                timeout=None
            )
            self.popup.show()

        # Background scanning thread
        def scan():
            try:
                ssids = self.wifi_manager.new_rescan()
            except Exception as e:
                print(f"❌ Scan error: {e}")
                ssids = []

            # Update UI in main thread when scan completes
            def update_ui():
                # Ensure popup stays visible for at least 1 second
                elapsed_time = time.time() - self.scan_start_time
                if elapsed_time < 1.0:
                    time.sleep(1.0 - elapsed_time)
                    
                if self.popup:
                    self.popup.destroy()
                
                if ssids:
                    wifi_networks = list(set(ssids))
                    self.make_network_buttons(wifi_networks)
                    print(f"Updated Wi-Fi list: {wifi_networks}")
                    GLib.timeout_add(1000, self.refresh_wifi_ip_address)
                return False

            GLib.idle_add(update_ui)

        threading.Thread(target=scan).start()
        



    def make_network_buttons(self,wifi_networks):
        self.network_buttons = {}
        for n, network in enumerate(wifi_networks):
            print(network)
            self.network_buttons[network] = self.make_ssid_box(network)
            self.ssid_grid.attach(self.network_buttons[network], 0, n, 1, 1)

        self.ssid_grid.show_all()

    def get_ip_addresses(self):
        interfaces = netifaces.interfaces()
        lan_ip = None
        wifi_ip = None
        for interface in interfaces:
            addrs = netifaces.ifaddresses(interface)
            if netifaces.AF_INET in addrs:
                ip = addrs[netifaces.AF_INET][0]['addr']
                if interface.startswith("wl"):
                    wifi_ip = ip
                elif interface.startswith("eth") or interface.startswith("eno"):
                    lan_ip = ip
        return wifi_ip, lan_ip
    def refresh_wifi_ip_address(self):
        wlan_ip,_ = self.get_ip_addresses()
        if wlan_ip is None:
            wlan_ip = "00.00.0.0"
            self.wlan_ip_button.set_sensitive(False)
            if self.connected :
                self.wlan_ip_button.set_sensitive(True)
                search_animation = ["🔍 Searching.   ", "🔍 Searching..  ", "🔍 Searching... ", "🔍 Searching...."]
                self.wlan_ip_button.set_label(search_animation[self.search_index])
                self.search_index = (self.search_index + 1) % len(search_animation)
                if self.wifi_manager.get_connected_ssid():
                    wlan_ip,_ = self.get_ip_addresses()
                    return True

                return True
        self.wlan_ip_button.set_label(wlan_ip)
        return False
    def toggle_lan_ip_mode(self, widget):
        # Only toggle if clicking the inactive button
        if (widget == self.manual_ip and not self.manual_ip_active) or \
           (widget == self.auto_ip and self.manual_ip_active):
            self.manual_ip_active = not self.manual_ip_active
            
            if self.manual_ip_active:
                # Manual IP active
                self.manual_ip.get_style_context().remove_class("manual_ip_button")
                self.auto_ip.get_style_context().remove_class("manual_ip_button_pressed")
                self.manual_ip.get_style_context().add_class("manual_ip_button_pressed")
                self.auto_ip.get_style_context().add_class("manual_ip_button")
                self.lan_ip_button.set_sensitive(True)
                # Auto IP active



    def show_yes_no_dialog(self,widget):
                def on_yes():
                    dialog.destroy()
                    self.config.update_sub_value(ConfigKeys.LAN_MANUAL,None, "False")
                    self.change_lan_ip()
                    self.toggle_lan_ip_mode(widget)


                def on_no():
                    dialog.destroy()
                    self.toggle_lan_ip_mode(widget)
                    self.auto_ip.get_style_context().remove_class("manual_ip_button_pressed")
                    self.manual_ip.get_style_context().remove_class("manual_ip_button")
                    self.auto_ip.get_style_context().add_class("manual_ip_button")
                    self.manual_ip.get_style_context().add_class("manual_ip_button_pressed")
                    self.lan_ip_button.set_sensitive(True)
                    



                self.auto_ip.get_style_context().remove_class("manual_ip_button")
                self.manual_ip.get_style_context().remove_class("manual_ip_button_pressed")
                self.auto_ip.get_style_context().add_class("manual_ip_button_pressed")
                self.manual_ip.get_style_context().add_class("manual_ip_button")
                self.lan_ip_button.set_sensitive(False)
                dialog = C2PDialog(
                    self.screen,
                    self.screen,
                    "Are you sure you want to change the LAN IP address?",
                    theme_path=self.theme_path,
                    title="Warning",
                    button_names=["Yes", "No"],
                            sp_commands=[on_yes, on_no]
                        )



    def show_yes_no_dialog_wlan(self,widget):
                def on_change_auto_clicked():
                    dialog.destroy()
                                    # Auto IP active
                    self.wlan_auto_ip.get_style_context().remove_class("manual_ip_button")
                    self.wlan_manual_ip.get_style_context().remove_class("manual_ip_button_pressed")
                    self.wlan_auto_ip.get_style_context().add_class("manual_ip_button_pressed")
                    self.wlan_manual_ip.get_style_context().add_class("manual_ip_button")
                    self.wlan_ip_button.set_sensitive(False)
                    self.config.update_sub_value(ConfigKeys.WLAN_MANUAL,None, "False")
                    self.chang_wlan_ip()
                    self.toggle_wlan_ip_mode(widget)

                    GLib.timeout_add(1000, self.refresh_wifi_ip_address)


                def on_change_auto_clicked_no():
                    dialog.destroy()
                    self.toggle_wlan_ip_mode(widget)
                                    # Auto IP active
                    self.wlan_auto_ip.get_style_context().remove_class("manual_ip_button_pressed")
                    self.wlan_manual_ip.get_style_context().remove_class("manual_ip_button")
                    self.wlan_auto_ip.get_style_context().add_class("manual_ip_button")
                    self.wlan_manual_ip.get_style_context().add_class("manual_ip_button_pressed")
                    self.wlan_ip_button.set_sensitive(True)


                dialog = C2PDialog(
                    self.screen,
                    self.screen,
                    "Are you sure you want to change the WLAN IP address?",
                    theme_path=self.theme_path,
                    title="Warning",
                    button_names=["Yes", "No"],
                            sp_commands=[on_change_auto_clicked, on_change_auto_clicked_no]
                        )


    def toggle_wlan_ip_mode(self, widget):
        # Only toggle if clicking the inactive button
        if (widget == self.wlan_manual_ip and not self.wlan_manual_ip_active) or \
           (widget == self.wlan_auto_ip and self.wlan_manual_ip_active):
            self.wlan_manual_ip_active = not self.wlan_manual_ip_active
            
            if self.wlan_manual_ip_active:
                # Manual IP active
                self.wlan_manual_ip.get_style_context().remove_class("manual_ip_button")
                self.wlan_auto_ip.get_style_context().remove_class("manual_ip_button_pressed")
                self.wlan_manual_ip.get_style_context().add_class("manual_ip_button_pressed")
                self.wlan_auto_ip.get_style_context().add_class("manual_ip_button")
                self.wlan_ip_button.set_sensitive(True)




    def on_lan_refresh_button(self,widget=None):
            self.lan_ip_button.set_label(self.get_ip_addresses()[1])
            PopupNotification(
                    message=f"LAN IP address set to {self.get_ip_addresses()[1]}",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=1,
                    tipe="S")

    def show_network_dialog(self,widget=None,screen=None,type=None):
        IPAdressDialogPanel(self.screen,self.theme_path,type,self)

    def show_wlan_ip_dialog(self,widget=None,screen=None,type=None):
        IPAdressDialogPanel(self.screen,self.theme_path,"wlan",self)

    def show_emergency_dialog(self,widget=None,screen=None,type=None):
        EmergencyPanel(self.screen,self.theme_path)

    def get_interface_by_connected_ssid(self):
        try:
            ssid = subprocess.check_output(["iwgetid", "-r"]).decode().strip()
            if not ssid:
                return None

            result = subprocess.check_output(
                ["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device"]
            ).decode().splitlines()

            for line in result:
                device, dev_type, state, connection = line.split(":")
                if dev_type == "wifi" and state == "connected" and connection == ssid:
                    return device
            return None
        except Exception as e:
            print("Error:", e)
            return None

    def cidr_to_netmask(self,cidr):
        return str(ipaddress.IPv4Network(f"0.0.0.0/{cidr}").netmask)

    def chang_wlan_ip(self):
        interface = self.get_interface_by_connected_ssid()
        connection_name, conn_type, device = self.wifi_manager.get_active_wifi_device()

        if not interface:
            print("Wi-Fi connection not found.")
            return

        # 1. Loading dialog göster
        loading_dialog = self.create_loading_dialog(ip_address="Manual_IP")
        loading_dialog.show()

        # 2. Ağ işlemleri ayrı thread'de çalışsın, GUI donmasın
        def do_network_change():
            try:
                subprocess.run([
                    "sudo", "nmcli", "connection", "modify", connection_name,
                    "ipv4.method", "auto",
                    "ipv4.addresses", "", "ipv4.gateway", "", "ipv4.dns", ""
                ], check=True)

                subprocess.run(["sudo", "dhclient", "-r", interface], check=True)
                subprocess.run(["sudo", "dhclient", interface], check=True)

                subprocess.run(["sudo", "nmcli", "connection", "down", connection_name], check=True)
                subprocess.run(["sudo", "nmcli", "connection", "up", connection_name], check=True)

                result = subprocess.run(["ip", "-4", "addr", "show", interface], capture_output=True, text=True)
                output = result.stdout

                ip_address = None
                netmask = None
                broadcast = None

                for line in output.splitlines():
                    line = line.strip()
                    if line.startswith("inet "):
                        parts = line.split()
                        ip_cidr = parts[1]
                        ip_address = ip_cidr.split('/')[0]
                        cidr = ip_cidr.split('/')[1]
                        netmask = self.cidr_to_netmask(cidr)
                        if "brd" in parts:
                            broadcast_index = parts.index("brd") + 1
                            broadcast = parts[broadcast_index]
                        break

                print(f"IP Adresi: {ip_address}")
                print(f"Netmask: {netmask}")
                print(f"Broadcast: {broadcast}")

                GLib.idle_add(self.refresh_wifi_ip_address)
                GLib.idle_add(loading_dialog.update_control_message,2)
                time.sleep(1)
                

            finally:
                # 3. İşlem bitince dialog kapat
                GLib.idle_add(loading_dialog.destroy)
        GLib.idle_add(loading_dialog.update_control_message,1)
        threading.Thread(target=do_network_change).start()

    def set_static_ip_wlan(self, static_ip, gateway_ip, mask_ip):
    

        try:
            # Get the name of the active WiFi connection
            connection_name,conn_type,device = self.wifi_manager.get_active_wifi_device()

            # Calculate CIDR
            cidr = ipaddress.IPv4Network(f"0.0.0.0/{mask_ip}").prefixlen
            ip_cidr = f"{static_ip}/{cidr}"


            self.wifi_manager.set_manual_ip_address(connection_name,ip_cidr,gateway_ip)
            
            PopupNotification(
                    message=f"WiFi IP successfully set to {static_ip}",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=2,
                    tipe="I"
                )

            # Add more detailed logging
            print(f"Setting static IP with:")
            print(f"Connection: {connection_name}")
            print(f"IP/CIDR: {ip_cidr}")

            
            return True

        except subprocess.CalledProcessError as e:
            error_msg = f"Failed to set WiFi IP: {str(e)}"
            PopupNotification(
                    message=error_msg,
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=True,
                    timeout=5,
                    tipe="E"
                )
            print(f"❌ Error: {error_msg}")
            return False

    def change_lan_ip(self):
        connection_name,conn_type,device = self.wifi_manager.get_active_ethernet_device()
        if device:
            # Change IP address to 0.0.0.0
            # self.ethernet_manager.set_static_ip_wlan(device)
            # Get IP info
            try:    
                result = self.wifi_manager.set_static_ip_wlan(device)
                PopupNotification(
                    message=f"Successfully to set Wifi IP",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=2,
                    tipe="S"
                )
            except subprocess.CalledProcessError as e:
                error_msg = f"Failed to set WiFi IP: {str(e)}"
                self.screen.show_Msg_Popup(error_msg, type="E", time=5)
                print(f"❌ Error: {error_msg}")
                return False 

        else:
            PopupNotification(
                    message="No active Ethernet connection found",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=True,
                    timeout=5,
                    tipe="E"
                )
            return
        # Get IP info
        output = result.stdout
        print(output)
        ip_address = None
        netmask = None
        broadcast = None

        # Check output line by line
        for line in output.splitlines():
            if 'inet ' in line:
                # Get IP address
                ip_address = line.split()[1]
            if 'netmask' in line:
                # Get netmask
                netmask = line.split()[3]
            if 'broadcast' in line:
                # Get broadcast
                broadcast = ip_address.split('.')[0] + '.' + ip_address.split('.')[1] + '.' + ip_address.split('.')[2] + '.1'
        # Print IP, netmask and broadcast
        print(f"IP Adresi: {ip_address}")
        print(f"Netmask: {netmask}")
        print(f"Broadcast: {broadcast}")
                    # Calculate CIDR
        cidr = ipaddress.IPv4Network(f"0.0.0.0/{netmask}").prefixlen
        ip_cidr = f"{ip_address}/{cidr}"

        self.config.update_sub_value(ConfigKeys.STATIC_IP, None, ip_address)
        self.config.update_sub_value(ConfigKeys.SERVER_IP, None, broadcast)
        self.config.update_sub_value(ConfigKeys.MASK_IP, None, netmask)

        self.wifi_manager.set_manual_ip_address(connection_name,ip_cidr,broadcast)

        
        self.on_lan_refresh_button()

        # Update GUI button
        


    # def set_ip_address(self, static_ip, gateway_ip, mask_ip, interfaces):


    #     try:
            
    #         # Find the WiFi connection (starts with  wlan/wifi)
    #         connection_name = self.wifi_manager.get_active_ethernet_device()[0]
    #         if not connection_name:
    #             print("❌ No active Ethernet connection found")
    #             self.screen.show_Msg_Popup("No active Ethernet connection found", type="E", time=5)
    #             return False
            

    #         # Calculate CIDR
    #         cidr = ipaddress.IPv4Network(f"0.0.0.0/{mask_ip}").prefixlen
    #         ip_cidr = f"{static_ip}/{cidr}"

    #         # Set the IP addresses
    #         subprocess.run([
    #             "nmcli", "con", "mod", connection_name,
    #             "ipv4.addresses", ip_cidr,
    #             "ipv4.gateway", gateway_ip,
    #             "ipv4.dns", gateway_ip,
    #             "ipv4.method", "manual"
    #         ], check=True)

    #         # Connect to the network 
    #         subprocess.run(["nmcli", "con", "down", connection_name], check=True)
    #         subprocess.run(["nmcli", "con", "up", connection_name], check=True)

    #         self.screen.show_Msg_Popup(f"WiFi IP successfully set to {static_ip}", type="I", time=5)
    #         print(f"✔️ WiFi IP address set to: {ip_cidr}")

    #         return True

    #     except subprocess.CalledProcessError as e:
    #         error_msg = f"Failed to set WiFi IP: {str(e)}"
    #         self.screen.show_Msg_Popup(error_msg, type="E", time=5)
    #         print(f"❌ Error: {error_msg}")
    #         return False 
    

    def create_loading_dialog(self, ip_address):
        def close_dialog():
            self.window_dialog.destroy()

        if ip_address=="Manual_IP":
            self.window_dialog = C2PDialog(
            self.screen,
            self.screen,
            ["Manual IP waiting", " Please wait..."], None,
            False, True, tipe="control",
            theme_path=self.theme_path,
            button_names=["Close"],
            title="Manual IP",
            sp_commands=[close_dialog]
        )
        else:
            self.window_dialog = C2PDialog(
                self.screen,
                self.screen,
                ["Wifi connection waiting", " Please wait..."], None,
                False, True, tipe="control",
                theme_path=self.theme_path,
            button_names=["Close"],
            title="Wifi Connection",
            sp_commands=[close_dialog]
        )
        return self.window_dialog

    def show_loading_dialog(self):
        def close_dialog():
            self.dialog.destroy()

        self.dialog = C2PDialog(
                    self.screen,
                    self.screen,
                    message="Wifi connection successfully",
                    theme_path=self.theme_path,
                    title="Wifi Connection",
                    tipe="control",
                    button_names=["Close"],
                    sp_commands=[close_dialog]
                        )


    # def get_active_ethernet_device(self):
    #     try:
    #         # Get active connections
    #         result = subprocess.run(
    #             ['nmcli', '-t', '-f', 'NAME,TYPE,DEVICE', 'connection', 'show'], 
    #             capture_output=True, text=True, check=True
    #         )
            
    #         # Split output into lines
    #         connections = result.stdout.strip().split('\n')
            
    #         # Check each connection
    #         for line in connections:
    #             # -t parameters are separated by ':'
    #             fields = line.split(':')
    #             if len(fields) >= 2:
    #                 name, conn_type, device = fields[0], fields[1], fields[2]
                    
    #                 # Find Ethernet connection (802-3-ethernet type and eth0'a connected)
    #                 if device == 'eth0' or device == 'eno1' or device == 'end0' or conn_type == '802-3-ethernet':
    #                     return name,conn_type,device

    #         return None
        
        
    #     except subprocess.CalledProcessError  as e:
    #         print(f"❌ Hata: {e}")
    #         return None


    # def loading_dialog(self,ip_address):
    #         def close_dialog():
    #             self.window_dialog.destroy()

    #         self.window_dialog = C2PDialog(
    #         self.screen,
    #         self.screen,
    #         ["Ip Address Changed please wait","set ip adress:"+ip_address], None,
    #         False, True, tipe="control",
    #         theme_path=self.theme_path,
    #         button_names=["Close"],
    #         title="Ip Address Change warning",
    #         sp_commands=[close_dialog]
    #     )
    #         return self.window_dialog


    def open_wifi_connection(self):
        try:
            self.wifi_manager.open_wifi_connection()
            self.loading_dialog.update_control_message(1)
            GLib.timeout_add(1000, self._refresh_after_wifi_on)
        except Exception as e:
            print(f"❌ Error: {e}")
            return False
        

    def close_wifi_connection(self):
        try:
            
            self.wifi_manager.close_wifi_connection()
            PopupNotification(
                    message=f"WiFi connection closed",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=2,
                    tipe='S'
                )
        except Exception as e:
            PopupNotification(
                    message=f"WiFi connection closed",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=5,
                    tipe='E'
                )

    # def _refresh_after_wifi_off(self):
    #     time.sleep(1)
    #     self.loading_dialog2.update_control_message(2)
    #     self.loading_dialog2.destroy()
    #     self.refresh_content(NetWorkPanel(self.screen))
    #     self.refresh_content(NetWorkPanel(self.screen))
    


    def clear_wlan_button_style(self):
        self.wlan_manual_ip.get_style_context().remove_class("manual_ip_button_pressed")
        self.wlan_manual_ip.get_style_context().remove_class("manual_ip_button")
        self.wlan_auto_ip.get_style_context().remove_class("manual_ip_button")
        self.wlan_auto_ip.get_style_context().remove_class("manual_ip_button_pressed")


        self.wlan_manual_ip.get_style_context().add_class("manual_ip_button")
        self.wlan_auto_ip.get_style_context().add_class("manual_ip_button")
