from library.global_manager import GlobalVariables
from library.c2p_gcodes import CtoPGcodes
from elements.c2p_gtk import CtoPGtk
from elements.keypad import Keypad
from elements.custom_buttons import CustomButton
from elements.move_tool_changer_bottons import ToolChangerButtons
from elements.c2p_dialog import C2PDialog
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_gtk3agg import FigureCanvasGTK3Agg as FigureCanvas
from matplotlib import cm
from elements.c2p_dialog import C2PDialog
from elements.popup import PopupNotification

class BedMesh(GlobalVariables):

    def __init__(self, screen):
        super().__init__(screen)
        self.screen = screen
        self.profiles = {}
        self.selectplot = 3 #3d
        self.selectbeshcount=4
        self.prev_state_printer = False
        ctop_gtk = CtoPGtk(self.screen,self.theme_path)
        self.main_bed_mesh_box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        top_box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,style="print_control_box",width=self.screen.width/1.111,height=self.screen.height/1.684,spacing=40)
        top_box.set_halign(Gtk.Align.CENTER)
        bottom_box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,style="print_control_box",width=self.screen.width/1.111,height=self.screen.height/5.62,spacing=10)
        bottom_box.set_halign(Gtk.Align.CENTER)
        front_view_box = ctop_gtk.c2p_box(style="front_view_box",width=self.screen.width/1.176,height=self.screen.height/12.8)
        front_view_box.set_halign(Gtk.Align.CENTER)
        points_box = ctop_gtk.c2p_box()
        points_box.set_halign(Gtk.Align.CENTER)
        points_box.set_valign(Gtk.Align.CENTER)

        points_button_labels = ["2x2","3x3","4x4","5x5","6x6","7x7"]
        self.points_buttons = {}
        for index,lbl in enumerate(points_button_labels):
            self.points_buttons[lbl] = ctop_gtk.Button_new(label=lbl,style="bed_mesh_points_button")
            self.points_buttons[lbl].connect('clicked',self.select_size,None)
            if index == (self.selectbeshcount-2):
                self.points_buttons[lbl].get_style_context().add_class("bed_mesh_points_button_pressed")
            points_box.add(self.points_buttons[lbl])

        front_view_button = ctop_gtk.Button_new(label="Front View",style="front_view_button")
        front_view_button.connect("clicked", self.on_change_view)
        
        tow_d_button = ctop_gtk.Button_new(label="2D",style="nozzle_tools_buttons")
        tow_d_button.set_halign(Gtk.Align.END)

        three_d_button = ctop_gtk.Button_new(label="3D",style="nozzle_tools_buttons")
        three_d_button.get_style_context().add_class("nozzle_tools_buttons_pressed")
        three_d_button.set_halign(Gtk.Align.END)
        tow_d_button.connect("clicked", self.select_view, "2", three_d_button)
        three_d_button.connect("clicked", self.select_view,"3",tow_d_button)
        
        button_box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)  # Horizontal layout
        # Create two buttons
        calibrate_button = ctop_gtk.Button_new(label="Start Bed Mesh", style="bed_mesh_calibrate_button")
        calibrate_button.connect("clicked", self.start_bed_mesh)
        # load_mesh_button = ctop_gtk.Button_new(label="Load Mesh", style="bed_mesh_calibrate_button")
        calibrate_button.set_halign(Gtk.Align.CENTER)
        # load_mesh_button.set_halign(Gtk.Align.CENTER)
        # Add buttons to the horizontal box
        button_box.add(calibrate_button)
        # button_box.add(load_mesh_button)
        button_box.set_halign(Gtk.Align.CENTER)

        self.range_label = ctop_gtk.c2p_label("Range: Not exist bed mesh","bed_mesh_rang_label")
        self.range_label.set_halign(Gtk.Align.CENTER)

        # Create a right panel for the plot canvas
        self.figure = plt.figure(figsize=(4, 3),facecolor='gray')  # Create a matplotlib figure
        self.ax = self.figure.add_subplot(111, projection='3d')  # Add a 3D subplot
        # Remove unnecessary margins and make the plot fill the figure
        self.figure.subplots_adjust(left=0, right=1, top=1, bottom=0)
        self.canvas = FigureCanvas(self.figure)  # Create a GTK canvas from the matplotlib figure
        self.canvas.set_size_request(630, 430)
        self.canvas.set_halign(Gtk.Align.CENTER)

        front_view_box.pack_start(front_view_button,False,False,0)
        front_view_box.pack_start(tow_d_button,True,True,0)
        front_view_box.add(three_d_button)
        top_box.add(front_view_box)
        top_box.add(self.range_label)
        top_box.pack_start(self.canvas,False,False,0)
        bottom_box.add(button_box)
        bottom_box.add(points_box)

        self.main_bed_mesh_box.add(top_box)
        self.main_bed_mesh_box.add(bottom_box)
        self.get_getdata_mesh("meshprofile",False)
        # GLib.idle_add(self.get_getdata_mesh("meshprofile",False))

    def process_update(self, action, data):
        if action == "notify_error":
            return
        elif action == "notify_busy":
            self.handle_move(data)
            return
        
    def handle_move(self,state):
        if self.prev_state_printer == state :
            return
        self.prev_state_printer = state
        if not state:
            self.get_getdata_mesh("default",True)

    def get_getdata_mesh(self,profile,typeCheck):
        active_state = self.load_meshes(profile)
        if self.profiles:
            if (typeCheck and active_state) or (not typeCheck):
                x = np.linspace(self.profiles['mesh_params']['min_x'], self.profiles['mesh_params']['max_x'], self.profiles['mesh_params']['x_count'])
                y = np.linspace(self.profiles['mesh_params']['min_y'], self.profiles['mesh_params']['max_x'], self.profiles['mesh_params']['y_count'])
                self.X, self.Y = np.meshgrid(x, y)
                self.Z = self.profiles['points']
                self.Z = np.flipud(self.Z)
                self.view_angles = [(35, -90)]
                self.current_view_index = 0
                self.select_size(None, self.profiles['mesh_params']['x_count'])
                self.plot_3d()
                self.update_range_label()
        if (typeCheck and not active_state):
            PopupNotification(
                    message="Failed to check Bed Mesh",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=0,
                    tipe="E"
                )
        return False

    def plot_3d(self):
        """Plot the data in 3D."""
        self.ax.clear()
        self.ax.set_facecolor('black')

        z_min, z_max = np.min(self.Z), np.max(self.Z)
        norm = plt.Normalize(vmin=z_min, vmax=z_max)
        colors = cm.coolwarm(norm(self.Z))

        # Plot the 3D surface
        surface = self.ax.plot_surface(
            self.X, self.Y, self.Z,
            facecolors=colors,
            rstride=1, cstride=1,
            alpha=1,  # Transparency of the surface
            edgecolor='none',
            antialiased=True
        )

        # Add a color bar to the plot
        if not hasattr(self, 'color_bar') or not self.color_bar:
            self.color_bar = self.figure.colorbar(
                cm.ScalarMappable(norm=norm, cmap=cm.coolwarm),
                ax=self.ax, shrink=0.6, aspect=10, pad=0.1
            )
            self.color_bar.set_label("Height Difference (mm)", color='white')
            self.color_bar.ax.tick_params(colors='white')

        # Set transparency for X, Y, Z axis panes
        self.ax.xaxis.set_pane_color((1.0, 1.0, 1.0, 0.1))
        self.ax.yaxis.set_pane_color((1.0, 1.0, 1.0, 0.1))
        self.ax.zaxis.set_pane_color((1.0, 1.0, 1.0, 0.1))

        # Make the axis lines semi-transparent
        self.ax.xaxis.line.set_color((0.0, 0.0, 0.0, 0.1))
        self.ax.yaxis.line.set_color((0.0, 0.0, 0.0, 0.1))
        self.ax.zaxis.line.set_color((0.0, 0.0, 0.0, 0.1))

        # Configure axis limits and ticks
        self.ax.set_xticks([])
        self.ax.set_yticks([])
        self.ax.set_zticks([])
        self.ax.set_zlim(z_min, z_max)

        # Set the default view angle
        elev, azim = self.view_angles[0]
        self.ax.view_init(elev=elev, azim=azim)
        self.ax.mouse_init(rotate_btn=1, zoom_btn=3)
        
        # Refresh the GTK canvas
        self.canvas.draw()

    def plot_2d(self):
            """Plot the data in 2D."""
            self.ax.clear()
            self.ax.set_facecolor('white')

            z_min, z_max = np.min(self.Z), np.max(self.Z)
            norm = plt.Normalize(vmin=z_min, vmax=z_max)

            # Flatten the arrays for plotting
            x_flat = self.X.flatten()
            y_flat = self.Y.flatten()
            z_flat = self.Z.flatten()

            # self.Z = np.rot90(self.Z, k=3)
            self.Z = self.Z[::-1]
            self.X = np.rot90(self.X, k=3)
            self.Y = np.rot90(self.Y, k=3)

            # Calculate colors for each point
            colors = cm.coolwarm(norm(z_flat))
            self.ax.scatter(x_flat, y_flat, color=colors, s=100)
            for i in range(self.Z.shape[0]):
                for j in range(self.Z.shape[1]):
                    x, y, z = self.X[i, j], self.Y[i, j], self.Z[i, j]
                    self.ax.text(x, y+12, 0, f"{z:.2f}", color='black', fontsize=8, ha='center', va='bottom')

            # Set limits and hide axes
            self.ax.set_xlim(np.min(self.X), np.max(self.X))
            self.ax.set_ylim(np.min(self.Y), np.max(self.Y))
            self.ax.set_xticks([])
            self.ax.set_yticks([])
            self.ax.set_zticks([])
            self.ax.view_init(elev=90, azim=-90)
            self.ax.mouse_init(rotate_btn=None, zoom_btn=None)
            
            # Refresh the GTK canvas
            # GLib.idle_add(
            self.canvas.draw()

    def get_content(self):
        return self.main_bed_mesh_box,"Bed Mesh"

    def select_size(self,widget,selectnumber):
        for index,b in enumerate(self.points_buttons.values()):
            b.get_style_context().remove_class("bed_mesh_points_button_pressed")
            if selectnumber is not None and index==selectnumber-2:
                b.get_style_context().add_class("bed_mesh_points_button_pressed")
            if widget is not None and widget==b:
                self.selectbeshcount = index+2
        if widget is not None:
            widget.get_style_context().add_class("bed_mesh_points_button_pressed")

    def select_view(self,widget,tipe,b):
        if tipe == "2" and self.selectplot != 2:
            self.selectplot = 2
            # print("2d")
            b.get_style_context().remove_class("nozzle_tools_buttons_pressed")
            widget.get_style_context().add_class("nozzle_tools_buttons_pressed")
            self.plot_2d()
        elif tipe == "3" and self.selectplot != 3:
            self.selectplot = 3
            # print("3d")
            b.get_style_context().remove_class("nozzle_tools_buttons_pressed")
            widget.get_style_context().add_class("nozzle_tools_buttons_pressed")
            self.plot_3d()

    def on_change_view(self, widget):
        """Change the 3D view angle."""
        if self.selectplot != 3:
            return
        self.plot_3d()

    def update_range_label(self):
        """Update the range label with the minimum and maximum Z values."""
        z_min, z_max = np.min(self.Z), np.max(self.Z)
        self.range_label.set_text(f"Range: {(z_max-z_min):.4f} mm")

    def start_bed_mesh(self,widget):
        def on_yes():
            self.screen._ws.klippy.gcode_script(f"CP_START_BEDMESH_CHECK probe_count={self.selectbeshcount}")
            dialog.destroy()
        def on_no():
            dialog.destroy()
            
        dialog = C2PDialog(
            self.screen,
            self.screen,
            "Are you sure you want to Start BED MESH?",
            theme_path=self.theme_path,
            title="info",
            button_names=["Yes", "No"],
            sp_commands=[on_yes, on_no]
        )

    def load_meshes(self,profilename):
        bm = self.screen.printer.get_stat("bed_mesh")
        self.profiles={}
        profiles = self.screen.printer.get_stat("bed_mesh", "profiles")
        if profiles and isinstance(profiles, dict) and profilename in profiles:
            self.profiles = profiles[profilename]
        if bm['profile_name'] == profilename:
            return True
        return False



