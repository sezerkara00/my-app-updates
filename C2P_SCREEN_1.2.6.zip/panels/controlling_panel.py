import re
import logging
from library.global_manager import GlobalVariables
from elements.c2p_dialog import C2PDialog
from gi.repository import GLib

class ControllingPanel(GlobalVariables):
    CntrDialog = None  # Shared dialog instance

    def __init__(self, screen, them_path):
        super().__init__(screen)
        self.screen = screen
        self.them_path = them_path
        self.indexMsg = None
        self.MaxindexMsg = None
        self._cancel_called = False

    def check_ControlBox(self, data):
        """
        Check and handle ControlBox based on the provided data.
        :param data: Input string containing control box commands.
        """
        try:
            self.dic_ControlData = self.parse_TRG_data(data)
            if self.dic_ControlData is None:
                logging.warning("Control data could not be parsed.")
                return

            control_type = self.dic_ControlData.get("TYPE")
            if control_type == "CREATE":
                self._handle_create()
            elif control_type == "CLOSE":
                self._handle_close()
            elif control_type == "NEXT":
                self._handle_next(data)
            else:
                logging.warning(f"Unknown control type: {control_type}")
        except Exception as e:
            logging.error(f"Error in check_ControlBox: {e}")

    def _handle_create(self):
        """Handle creation of a new control box."""
        try:
            output_Msg_array = re.findall(r"'(.*?)'", self.dic_ControlData["MSG"])
            self.MaxindexMsg = len(output_Msg_array)

            if self.CntrDialog:
                self.CntrDialog.on_destroy()
            buttonname=None
            commandname=None
            if "PRE-PRINT" in self.dic_ControlData["HEAD"]:
                buttonname=["Cancel Print", "Close"]
                def close_dialog():
                    self.CntrDialog.destroy()
                commandname=[self.preInit_cancel,close_dialog]

            self.CntrDialog = C2PDialog(
                self.screen,
                self.screen,
                output_Msg_array,
                tipe="control",
                title=self.dic_ControlData["HEAD"],
                theme_path=self.them_path,
                button_names = buttonname,
                sp_commands=commandname
            )
            logging.info("Control box created successfully.")
        except KeyError as e:
            logging.error(f"Missing key in control data during create: {e}")
        except Exception as e:
            logging.error(f"Error while handling CREATE: {e}")
    def _handle_close(self):
        """Handle closing of the control box."""
        try:
            if self.CntrDialog:
                self.CntrDialog.on_destroy()
                self.CntrDialog = None
                logging.info("Control box closed successfully.")
            else:
                logging.warning("No control box to close.")
        except Exception as e:
            logging.error(f"Error while handling CLOSE: {e}")

    def _handle_next(self, data):
        """Handle advancing to the next message in the control box."""
        try:
            self.next_Msg(self.dic_ControlData["TYPE"], data)
        except ValueError as e:
            logging.error(f"Invalid data for NEXT: {e}")
        except Exception as e:
            logging.error(f"Error while handling NEXT: {e}")

    def check_ControlBox_finish(self):
        """
        Check if all messages have been processed and close the control box if finished.
        :return: True if the control box is finished, False otherwise.
        """
        try:
            if self.indexMsg is not None and (self.indexMsg + 1) >= self.MaxindexMsg:
                self.indexMsg = None
                self.MaxindexMsg = None
                if self.CntrDialog:
                    self.CntrDialog.on_destroy()
                    self.CntrDialog = None
                logging.info("All messages processed. Control box closed.")
                return True
            elif self.indexMsg is None and self.MaxindexMsg ==1:
                if self.CntrDialog:
                    self.CntrDialog.on_destroy()
                    self.CntrDialog = None
                logging.info("All messages processed. Control box closed.")
                return True
            return False
        except Exception as e:
            logging.error(f"Error in check_ControlBox_finish: {e}")
            return False

    def next_Msg(self, type, data):
        """
        Update the control box to the next message.
        :param type: Type of operation (e.g., "NEXT").
        :param data: Data string for processing.
        """
        try:
            if self.CntrDialog is None:
                raise ValueError("Control box is not initialized.")

            datanext = self.parse_TRG_data(data)
            if datanext and "ID" in datanext:
                self.indexMsg = datanext["ID"]
                self.CntrDialog.update_control_message(datanext["ID"])
                if "homing" in datanext["MSG"].lower():
                    self.CntrDialog.update_image("homing")
                elif "heat up bed" in datanext["MSG"].lower():
                    self.CntrDialog.update_image("bedheat")
                elif "heat up nozzle" in datanext["MSG"].lower():
                    self.CntrDialog.update_image("nozzleheat")
                elif "bed mesh" in datanext["MSG"].lower():
                    self.CntrDialog.update_image("bedmesh")
                logging.info(f"Control box updated to message ID: {datanext['ID']}")
            else:
                raise ValueError("Invalid data provided for next_Msg.")
        except Exception as e:
            logging.error(f"Error in next_Msg: {e}")

    def parse_TRG_data(self, data):
        try:
            # Check if the string starts with "TRG:"
            if data.startswith("TRG:"):
                # Remove "TRG:" and trim any extra spaces
                data = data[4:].strip()
                # Split the data using equals signs or commas
                pattern = r"(\w+)=\[(.*?)\]|\b(\w+)=(\S+)"
                matches = re.findall(pattern, data)
                # Dictionary to store parsed data
                parsed_data = {}
                for match in matches:
                    key = match[0] or match[2]  # Extract the key
                    value = match[1] or match[3]  # Extract the value

                    # If the value is enclosed in brackets, convert it to a list
                    if value.startswith("[") and value.endswith("]"):
                        value = value.strip("[]").split(", ")
                    elif value.isdigit():  # Convert numeric values to int
                        value = int(value)
                    parsed_data[key] = value
                return parsed_data
            return None
        except Exception as e:
            logging.error(f"Error parsing TRG data: {e}")
            return None
        
    def preInit_cancel(self):
        if hasattr(self, '_cancel_called') and self._cancel_called:
            return
        self._cancel_called = True
        try:
            active_panel = self.get_current_page()
            if hasattr(active_panel, 'handle_printer'):
                try:
                    GLib.idle_add(active_panel.handle_printer,"ControllingPanel" ,"CANCEL_PRINT")
                except Exception as e:
                    print(f"Error calling process_update: {e}")
            self._handle_close()
            self._cancel_called = False
        finally:
            self._cancel_called = False
            


