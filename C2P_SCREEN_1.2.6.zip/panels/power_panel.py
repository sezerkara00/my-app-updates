from elements.c2p_gtk import CtoPGtk
from gi.repository import Gtk, GLib, Gdk
import os
from elements.c2p_dialog import C2PDialog

from panels.lock_panel import LockPanel


class PowerPanel(Gtk.Window):

    def __init__(self, screen, theme_path):
        super().__init__(title="Power Panel")
        self.set_default_size(800, 1280)
        self.set_resizable(False)  # Prevent resizing the window
        self.set_decorated(False)
        self.get_style_context().add_class("power_panel")
        # Store screen and theme_path references
        self.screen = screen
        self.theme_path = theme_path

        ctop_gtk = CtoPGtk(screen,theme_path)
        screenV = Gdk.Screen.get_default()
        visual = screenV.get_rgba_visual()
        if visual is not None and screenV.is_composited():
            self.set_visual(visual)

        power_off_button = ctop_gtk.Button_new("power",label="Power Off",style="power_buttons",scale=3)
        power_off_button.connect("clicked",self.power_off_printer_dialog)
        restart_button = ctop_gtk.Button_new("restart",label="restart",style="power_buttons",scale=3)
        restart_button.connect("clicked", self.show_restart_dialog)
        restart_print_button = ctop_gtk.Button_new("restart-print",label="Restart Print",style="power_buttons",scale=3)
        restart_print_button.connect("clicked", self.show_print_restart_dialog)
        lock_button = ctop_gtk.Button_new("lock-big",label="Lock",style="power_buttons",scale=3)
        lock_button.connect("clicked", self.lock_a,screen,theme_path)
        box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,spacing=30)
        box.set_halign(Gtk.Align.CENTER)
        box.set_valign(Gtk.Align.CENTER)
        box.add(power_off_button)
        box.add(restart_button)
        box.add(restart_print_button)
        box.add(lock_button)
        self.add(box)
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.connect("button-press-event", self.on_screen_click)
        self.show_all()


    def on_screen_click(self, widget, event):
        self.close()
    def power_off_printer(self,widget):
        os.system("systemctl poweroff")

    def restart_printer(self,widget):
        os.system("systemctl reboot")

    def print_restart_a(self,widget):
        pass

    def lock_a(self,widget,screen,theme_path):
        self.destroy()
        LockPanel(screen,theme_path)

    def show_restart_dialog(self,widget):
        def on_Yes_clicked():
            self.restart_printer(widget)
            dialog.destroy()
        def on_Cancel_clicked():
            dialog.destroy()
            
        dialog=C2PDialog(
                            self.screen,
                            self.screen,
                            "Are you sure you want to restart the printer?",
                            theme_path=self.theme_path,
                            title="Warning",
                            button_names=["Yes", "Cancel"],
                            sp_commands=[on_Yes_clicked,on_Cancel_clicked]
                        )
        dialog.show()

    def show_print_restart_dialog(self,widget):
        def on_Yes_clicked():
            self.print_restart_a(widget)
            dialog.destroy()
        def on_Cancel_clicked():
            dialog.destroy()
            
        dialog=C2PDialog(
                            self.screen,
                            self.screen,
                            "Are you sure you want to restart the printer?",
                            theme_path=self.theme_path,
                            title="Warning",
                            button_names=["Yes", "Cancel"],
                            sp_commands=[on_Yes_clicked,on_Cancel_clicked]
                        )
        dialog.show()

    def power_off_printer_dialog(self,widget):
        def on_Yes_clicked():
            self.power_off_printer(widget)
            dialog.destroy()
        def on_Cancel_clicked():
            dialog.destroy()
            
        dialog=C2PDialog(
                            self.screen,
                            self.screen,
                            "Are you sure you want to power off the printer?",
                            theme_path=self.theme_path,
                            title="Warning",
                            button_names=["Yes", "Cancel"],
                            sp_commands=[on_Yes_clicked,on_Cancel_clicked]
                        )
        dialog.show()
