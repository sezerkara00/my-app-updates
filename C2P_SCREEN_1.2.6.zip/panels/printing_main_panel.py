from library.global_manager import GlobalVariables
from library.c2p_config import ConfigKeys
from elements.c2p_gtk import CtoPGtk
from elements.printing_element import PrintingElement
from elements.progress_circle import ProgressCircle
from elements.c2p_dialog import C2PDialog

# from library.signal_manager import signal_router
from panels.printing_settings import PrintingSettings
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
import math, contextlib

class Printing_panel(GlobalVariables):

    def __init__(self, screen,filename, panel,print_tools=None):
        super().__init__(screen)
        self.logger = self.logger_setup.get_logger("printing_panel")
        self.logger.info("printing_panel initialized.")  # Initialization log
        self.screen = screen
        self.file_name = filename
        self.prev_state_printer=True
        if self.screen.print_state != "cancelling":
            self.screen.print_state = ""
        self.confirmation_counter = 0
        self.temp = {}
        self.progress_devices = []
        self.file_metadata = self.screen.files.get_file_info(filename)
        if self.file_metadata['estimated_time'] != "None":
            estimated_time = self.format_time(self.file_metadata['estimated_time'])
        else:
            estimated_time = "none"
        elapsed_time = self.format_time(self.screen.printer.get_stat("print_stats")["print_duration"])
        self.current_layer = 0
        if "layer_height" in self.file_metadata and self.file_metadata['layer_height'] != "None":
            self.layer_height = self.file_metadata["layer_height"]
        else:
            self.layer_height = "none"
        if "object_height" in self.file_metadata and self.file_metadata['object_height'] != "None":
            self.total_layers = round((self.file_metadata["object_height"] - self.file_metadata["first_layer_height"]) / self.layer_height) + 1
            layers = f'{self.total_layers:.0f}'
        else:
            layers = "none"
        self.ctop_gtk = CtoPGtk(screen, self.theme_path)
        self.current_extruder = None
        self.printing_main_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,spacing=50)
        file_image = self.image_load(filename)
        self.printing_element = PrintingElement(screen,filename,file_image,self.theme_path,style=self.style)
        self.printing_element.set_halign(Gtk.Align.CENTER)
        printing_progress_grid = Gtk.Grid()
        printing_progress_grid.set_halign(Gtk.Align.CENTER)
        printing_progress_grid.set_column_spacing(20)
        printing_info_box = self.ctop_gtk.c2p_box(style="print_control_box",width=self.screen.width/1.111,height=self.screen.height/8.5333)
        printing_info_box.set_halign(Gtk.Align.CENTER)
        control_buttons = self.ctop_gtk.c2p_box(spacing=50)
        control_buttons.set_halign(Gtk.Align.CENTER)
        file_name_box = self.ctop_gtk.c2p_box(style="print_control_box",width=self.screen.width/1.333,height=self.screen.height/21.333)
        file_name_box.set_halign(Gtk.Align.CENTER)
        self.start_stop_box = self.ctop_gtk.c2p_box()
        self.start_stop_box.set_halign(Gtk.Align.CENTER)
        self.start_stop_box.set_valign(Gtk.Align.END)

        self.settings_button = self.ctop_gtk.Button_new(label="Settings",style="printing_control_buttons")
        self.delete_obj_button = self.ctop_gtk.Button_new(label="Delete Object", style="printing_control_buttons")
        self.visual_button = self.ctop_gtk.Button_new(label="Visualisation", style="printing_control_buttons")

        self.settings_button.connect("clicked",self.show_settings_panel)

        printing_info_box.pack_start(self.create_section("Layer", layers,True), True, True, 0)
        printing_info_box.pack_start(self.ctop_gtk.create_separator(False), False, False, 0)
        printing_info_box.pack_start(self.create_section("Elapsed Time", elapsed_time,True), True, True, 0)
        printing_info_box.pack_start(self.ctop_gtk.create_separator(False), False, False, 0)
        printing_info_box.pack_start(self.create_section("Remaining Time", estimated_time), True, True, 0)

        control_buttons.add(self.settings_button)
        control_buttons.add(self.delete_obj_button)
        control_buttons.add(self.visual_button)
        if len(filename)>50:
            filename = filename[:25]+"..."+filename[-25:]
        file_name_label = self.ctop_gtk.c2p_label(filename,style="title-center")
        file_name_label.set_hexpand(True)
        file_name_label.set_halign(Gtk.Align.CENTER)
        file_name_box.add(file_name_label)

        self.start_print_button = self.ctop_gtk.Button_new("pause", style="printing_play_stop")
        self.start_print_button.get_style_context().add_class("print_pagination_buttons_pressed")
        self.stop_print_button = self.ctop_gtk.Button_new("stop", style="printing_play_stop",scale=.6)

        # Create the restart button (hidden by default)
        self.restart_button = self.ctop_gtk.Button_new("refresh", style="printing_play_stop", scale=0.8)

        self.start_stop_box.add(self.start_print_button)
        self.start_stop_box.add(self.stop_print_button)
        # start_stop_box.add(self.restart_button)

        self.start_print_button.connect("clicked",self.resume)
        self.stop_print_button.connect("clicked",self.stop_printing)
        self.restart_button.connect("clicked", self.restart_printing)
        overlay = Gtk.Overlay()
        overlay.add(self.printing_element)
        overlay.add_overlay(self.start_stop_box)
        self.show_temp_circles(printing_progress_grid)
        self.printing_main_box.add(file_name_box)
        self.printing_main_box.add(overlay)
        self.printing_main_box.add(printing_progress_grid)
        self.printing_main_box.add(printing_info_box)
        self.printing_main_box.add(control_buttons)

        GLib.timeout_add_seconds(30, self.update_filament_level)
    def parse_print_tools(self):
            if self.screen.base_panel.c2p_print_tools is None:
                return
            variable = self.screen.printer.get_origin_extruders()
            for i, dev in enumerate(variable):
                if str(i) not in self.screen.base_panel.c2p_print_tools["tools_print"]:
                    variable[i] = None
            return variable

    def get_content(self):
        return self.printing_main_box,"Print Panel"

    def show_temp_circles(self, temp_progress_grid):
        for child in temp_progress_grid.get_children():
            temp_progress_grid.remove(child)
        self.progress_circle1 = ProgressCircle(self.screen, panel="printing",w=100,h=214,
                                               name="extruder",
                                               label="01",
                                               progress=0,

                                               current_temp=0,

                                               style=self.style,
                                               active=False,
                                               angle=-math.pi / 2,filament_type="PLA",filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder")))
        self.progress_circle2 = ProgressCircle(self.screen, panel="printing",w=100,h=214,
                                               name="extruder1",
                                               label="02",
                                               progress=0,

                                               current_temp=0,

                                               style=self.style, active=False,
                                               angle=-math.pi / 2,  filament_type="ABS",filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder1")))
        self.progress_circle3 = ProgressCircle(self.screen, panel="printing",w=100,h=214,
                                               name="extruder2",
                                               label="03",
                                               progress=0,

                                               current_temp=0,

                                               style=self.style, active=False,
                                               angle=-math.pi / 2,filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder2")))
        self.progress_circle4 = ProgressCircle(self.screen, panel="printing",w=100,h=214,
                                               name="extruder3",
                                               label="04",
                                               progress=0,

                                               current_temp=0,

                                               style=self.style, active=False,
                                               angle=-math.pi / 2,filament_color=self.parse_rgb_string_safe(self.screen.config_file.get_value(ConfigKeys.FILAMENT_COLOR,"extruder3")))
        self.progress_bed = ProgressCircle(self.screen, panel="printing",w=100,h=214,
                                           name="heater_bed", label="Bed",
                                           progress=0,

                                           current_temp=0,
                                           style=self.style, active=False,angle=-math.pi / 2)
        self.progress_env = ProgressCircle(self.screen, panel="printing",w=100,h=214,
                                           label="Env",
                                           name="heater_generic Env_heater",
                                           progress=0,

                                           current_temp=0, style=self.style,
                                           active=False,angle=-math.pi / 2)
        self.progress_devices = [
            self.progress_circle1, self.progress_circle2,
            self.progress_circle3, self.progress_circle4, self.progress_bed, self.progress_env

        ]


        temp_progress_grid.attach(self.progress_circle1, 0, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle2, 1, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle3, 2, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle4, 3, 1, 1, 1)
        temp_progress_grid.attach(self.progress_bed, 4, 1, 1, 1)
        temp_progress_grid.attach(self.progress_env, 5, 1, 1, 1)
        temp_progress_grid.show_all()
        self.update_filament_level()
    def parse_rgb_string_safe(self, rgb_string):
        try:
            r, g, b = map(float, rgb_string.split(","))
            return [r, g, b]
        except (ValueError, TypeError) as e:
            print("Invalid RGB string format:", e)
            return None

    def handle_printer(self, action, data):
        if action == "ControllingPanel" and data=="CANCEL_PRINT":
            self.cancel_print()

    def process_update(self, action, data):
        if action == "notify_error":
            # self.active_move_buttons()
            return
        elif action == "notify_busy":
            self.handle_state(data)
            return
        elif action != "notify_status_update":
            return
        self.update_temp(data)
        printing_progress=(max(self.screen.printer.get_stat('virtual_sdcard', 'file_position') -
            self.file_metadata['gcode_start_byte'], 0) / (self.file_metadata['gcode_end_byte'] -
                                                        self.file_metadata['gcode_start_byte']))
        self.printing_element.update_printing_progress(printing_progress)
        elapsed_time = self.format_time(self.screen.printer.get_stat("print_stats")["total_duration"])
        if hasattr(self, 'value_labels'):
            self.value_labels["Elapsed Time"].set_text(elapsed_time)
        self.state_check()
        self.extruder_check(data)
        self.current_z_and_filament_mm(data)

    def handle_state(self, state):
        if self.prev_state_printer == state :
            return
        self.prev_state_printer = state
        if not state:
            self.printing_element.stop_loading()
            if self.screen.print_state == "cancelled" or self.screen.print_state =="error" or self.screen.print_state == "complete":
                self.show_restart_button()
                self.disable_all_Print_buttons()
                self.screen.base_panel.buttons_panel_change(True)
                self.screen.base_panel.pressed_button = 'cancel'
        
    def update_temp(self,data):
        if self.screen.base_panel.c2p_print_tools is None:
            return

        for device, progress in zip(
               self.parse_print_tools() + self.screen.printer.get_heaters(), self.progress_devices,
                ):
            if device is None:
                continue

            self.temp[device] = self.screen.printer.get_dev_stat(device, "temperature")
            target = self.screen.printer.get_dev_stat(device, "target")
            progress.set_target(target)
            # if self.screen.printer.get_dev_stat(
            #         switch, "state") == "PRESSED":  # Show tool is in park
            #     progress.set_park_status(True)
            # elif self.screen.printer.get_dev_stat(switch, "state") == "RELEASED":
            #     progress.set_park_status(False)
            if "temperature_sensor" not in device:
                max_temp = self.screen.printer.get_dev_stat(device,
                                                            "max_temp")
                min_temp = self.screen.printer.get_dev_stat(device,
                                                            "min_extrude_temp")
                if self.temp[device] is not None:
                    progress.set_current_temp(self.temp[device],
                                              self.temp[device] / max_temp, max_temp, True)

    def current_z_and_filament_mm(self, data):
        if "virtual_sdcard" in data and self.layer_height is not None and self.total_layers is not None:
            virtual_sdcard_stats  = self.screen.printer.get_stat("virtual_sdcard")
            current_z = virtual_sdcard_stats.get("current_z", None)
            if current_z is not None:
                currentlayer = round(current_z / self.layer_height)
                if self.current_layer != currentlayer:
                    if self.confirmation_counter >= 2:
                        if hasattr(self, 'value_labels'):
                            text = f'{currentlayer:.0f} / {self.total_layers:.0f}'
                            self.value_labels["Layer"].set_text(text)
                        self.current_layer = currentlayer
                        self.confirmation_counter = 0
                    else:
                        self.confirmation_counter += 1
            ####
            current_tool = virtual_sdcard_stats.get("current_tool", None)
            if current_tool is not None:
                tool_filament = self.screen.printer.get_stat("virtual_sdcard")["current_tool"]

                pass
   
    def create_section(self, title, value,glob=False):
        # Vertical box for title and value
        vbox = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, style="printing_section_box",spacing=10)
        vbox.set_homogeneous(False)
        vbox.set_halign(Gtk.Align.CENTER)
        vbox.set_valign(Gtk.Align.CENTER)

        # Title label
        title_label = Gtk.Label(label=title)
        title_label.set_justify(Gtk.Justification.CENTER)

        vbox.pack_start(title_label, False, False, 0)
        vbox.pack_start(self.ctop_gtk.create_separator(horizontal=True), False, False, 0)
        # Value label
        value_label = Gtk.Label(label=value)
        value_label.set_justify(Gtk.Justification.CENTER)

        vbox.pack_start(value_label, False, False, 0)
        if glob:
            if not hasattr(self, 'value_labels'):
                self.value_labels = {}
            self.value_labels[title] = value_label
        return vbox

    def stop_printing(self,widget):
        def close_dialog():
            dialog_stop.destroy()
        def confirm():
            self.cancel_print()
            dialog_stop.destroy()
        dialog_stop = C2PDialog( self.screen, self.screen,
                                             "Are you sure you want to cancel the print?",theme_path=self.theme_path,title="Warning",
                                             button_names=["Yes","No"],sp_commands=[confirm,close_dialog])




    def cancel_print(self):
        self.screen._ws.klippy.gcode_script(f"M315")
        self.screen._ws.klippy.print_cancel()
        self.set_state("cancelling")
        self.screen.print_state = "cancelling"
        self.disable_all_Print_buttons()
        self.printing_element.start_loading()


    def disable_all_Print_buttons(self):
        self.start_print_button.set_sensitive(False)
        self.stop_print_button.set_sensitive(False)
        self.settings_button.set_sensitive(False)
        self.visual_button.set_sensitive(False)
        self.delete_obj_button.set_sensitive(False)

    def restart_printing(self,widget):
        def reprint():
            self.screen._ws.klippy.print_start(self.file_name)
            self.refresh_content(Printing_panel(self.screen, self.file_name, self), printing_panel=True)
            dialog_restart.destroy()

        def close_dialog():
            dialog_restart.destroy()
        dialog_restart = C2PDialog(self.screen, self.screen,
                                             "Do you want to confirm reprinting this file?",theme_path=self.theme_path,title="Warning",
                                             button_names=["Yes","No"],sp_commands=[reprint,close_dialog])




    def resume(self, widget):
        # self.printing_element.start_loading()
        # self.set_state("pausing")

        def resume_print():
            self.screen._ws.klippy.print_resume()
            dialog.destroy()
        def go_to_home():
            self.screen._ws.klippy.gcode_script(f"G28 x y")
            self.screen._ws.klippy.print_resume()
            dialog.destroy()
        def close_dialog():
            dialog.destroy()
        # if self.screen.print_state == "printing":
        #
        if self.screen.print_state != "paused":
            self.screen.print_state = "pausing"
            self.screen._ws.klippy.print_pause()
        elif self.screen.print_state == "paused":
            dialog = C2PDialog(self.screen, self.screen,
                                       "Do you want to home X and Y before resuming?", theme_path=self.theme_path,
                                       title="Warning",
                                       button_names=["Yes", "No","Cancel"], sp_commands=[go_to_home,resume_print, close_dialog])



    def image_load(self, filepath):
        loc = self.screen.files.get_file_image(filepath)
        pixbuf = None
        if loc[0] == "file":
            pixbuf = self.ctop_gtk.PixbufFromFile(loc[1], 250, 250)
        if loc[0] == "http":
            pixbuf = self.ctop_gtk.PixbufFromHttp(loc[1], 250, 250)
        # Check if pixbuf is None
        if pixbuf is not None:
            # file_image = (Gtk.Image.new_from_pixbuf(pixbuf))
            return pixbuf
        else:
            return "picture"

    def show_settings_panel(self, settings):
        self.screen.base_panel.pressed_button = 'sub'
        self.refresh_content(PrintingSettings(self.screen,self))
        # self.refresh_content(PrintingSettings(self.screen,self).main_printing_settings_box)

    def state_check(self):
        ps = self.screen.printer.get_stat("print_stats")
        if 'state' not in ps or ps['state'] == self.screen.print_state:
            return True
        if ps['state'] == "printing":
            if self.screen.print_state == "cancelling":
                self.set_state("cancelling")
                self.disable_all_Print_buttons()
                self.printing_element.start_loading()
                return
            elif self.screen.print_state == "pausing":
                self.set_state("pausing")
                self.printing_element.start_loading()
                return
        self.printing_element.stop_loading()
        self.printing_element.stop_text_animation()
        if ps['state'] == "printing":
            self.start_print_button.set_image(self.ctop_gtk.Image("pause", 50, 50))
            self.printing_element.start_text_animation()
            self.set_state("printing")
        elif ps['state'] == "complete":
            self.set_state("complete")
        elif ps['state'] == "error":
            self.set_state("error")
        elif ps['state'] == "cancelled":
            self.set_state("cancelled")
        elif ps['state'] == "paused":
            self.start_print_button.set_image(self.ctop_gtk.Image("play", 50, 50))
            self.set_state("paused")
        elif ps['state'] == "standby":
            self.set_state("standby")
        return True

    def set_state(self, state):
        if self.screen.print_state != state:
            self.logger.debug(f"Changing job_status state from '{self.screen.print_state}' to '{state}'")
        self.screen.print_state = state
        self.printing_element.update_printing_state(self.screen.print_state)

    # Function to show restart button and disable others
    def show_restart_button(self):
        # Disable other buttons
        self.start_print_button.hide()
        self.stop_print_button.hide()

        # Add restart button if not already added
        if self.restart_button.get_parent() is None:
            self.start_stop_box.add(self.restart_button)
        self.restart_button.show()

    # Function to re-enable start/stop buttons and hide restart button
    def show_start_stop_buttons(self):
        # Enable other buttons
        self.start_print_button.show()
        self.stop_print_button.show()

        # Hide restart button and remove it from the box
        self.restart_button.hide()
        if self.restart_button.get_parent():
            self.start_stop_box.remove(self.restart_button)

    def extruder_check(self,data):
        with contextlib.suppress(KeyError):
            extruder = self.screen.printer.get_stat("toolhead", "extruder")
            if extruder != self.current_extruder:
                if self.current_extruder is None:
                    for progress in self.progress_devices:
                        if progress.name == extruder:
                            progress.change_button_color()
                            self.current_extruder = extruder
                else:
                    for progress, device in zip(self.progress_devices,
                                                self.screen.printer.get_active_extruders()):
                        if device != extruder:
                            progress.on_button_release()
                        else:
                            progress.change_button_color()
                            self.current_extruder = device

    def filament_mm_to_g(self,length_mm, diameter_mm=1.75, density_g_cm3=1.24):
        radius = diameter_mm / 2
        volume_mm3 = math.pi * (radius ** 2) * length_mm  # in mm³
        volume_cm3 = volume_mm3 / 1000  # convert to cm³
        weight_g = volume_cm3 * density_g_cm3
        return round(weight_g, 2)
    def update_filament_level(self):
        f_level = self.screen.printer.get_stat("virtual_sdcard","filaments_used")
        for dev,prog in zip(self.screen.printer.get_active_extruders(),self.progress_devices):
            if dev  is not None:


                f_used = self.screen.config_file.get_value(ConfigKeys.FILAMENT_USED, dev, default="0")
                f_total = self.screen.config_file.get_value(ConfigKeys.FILAMENT_TOTAL, dev, default="0")
                current_filament = float(f_total) - float(f_used)
                if  dev in f_level:
                    n_f_level = self.filament_mm_to_g(f_level[dev])
                    current_dev = self.screen.printer.get_stat("toolhead", dev)
                    if dev == current_dev:
                        self.screen.config_file.update_sub_value(ConfigKeys.FILAMENT_USED, dev,float(f_used)+n_f_level )
                else:
                    n_f_level = 0
                prog.update_internal_circle((current_filament - n_f_level) / float(f_total))
        return True