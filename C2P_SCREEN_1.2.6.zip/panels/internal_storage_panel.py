from library.global_manager import GlobalVariables
from elements.c2p_gtk import CtoPGtk
from elements.file_element import FileElement
from elements.keyboard import VirtualKeyboard
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
from datetime import datetime
from elements.c2p_dialog import C2PDialog
import logging
import shutil, os, threading
from panels.gcode_editor_panel import GcodeEditorPanel
from elements.popup import PopupNotification

# from library.print_files_usb import PrintFilesUSB

class InternalStorage_panel_main(GlobalVariables):

    def __init__(self, screen, panel,current_selected_button="internal_storage"):
        super().__init__(screen)
        self.ctop_gtk = CtoPGtk(screen, self.theme_path)
        self.current_selected_button = current_selected_button
        self.entrytext_current = None
        self.files_per_page = 6
        self.screen = screen
        self.panel = panel
        self.current_page = 0  # Start at the first page
        self.current_total_pages = []
        self.start_page = 0
        self.end_page = 5
        self.internal_main_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=30)
        self.pagination_container = self.ctop_gtk.c2p_box(spacing=10)
        self.pagination_container.set_halign(Gtk.Align.CENTER)
        self.files_grid = Gtk.Grid()
        self.files_grid.set_halign(Gtk.Align.CENTER)
        self.files_grid.set_row_spacing(15)
        self.files_grid.set_column_spacing(30)
        control_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, width=screen.width / 1.111,
                                            height=screen.height / 9.166, style="print_control_box")
        control_box.set_halign(Gtk.Align.CENTER)
        control_box_top = self.ctop_gtk.c2p_box(spacing=230)
        control_box_bottom = self.ctop_gtk.c2p_box(spacing=30)
        control_box_top.set_halign(Gtk.Align.CENTER)
        control_box_bottom.set_halign(Gtk.Align.CENTER)

        # Define buttons
        self.internal_storage_button = self.ctop_gtk.Button_new(label="Internal Storage",
                                                                style="internal_storage_button")
        if self.current_selected_button == "internal_storage":
            self.internal_storage_button.get_style_context().add_class("print_name_button_selected")
        self.usb_storage_button = self.ctop_gtk.Button_new(label="USB Storage", style="internal_storage_button")
        if self.current_selected_button == "usb_storage":
            self.usb_storage_button.get_style_context().add_class("print_name_button_selected")
        # Add styles and connect signals
        self.internal_storage_button.connect("clicked", self.on_toggle_button_clicked, "internal_storage")
        self.usb_storage_button.connect("clicked", self.on_toggle_button_clicked, "usb_storage")
        self.set_active_button(self.current_selected_button)
        self.set_source(self.current_selected_button)
        ######################
        sortdir = "date_desc"
        sortdir = sortdir.split('_')
        if sortdir[0] not in ["name", "date"] or sortdir[1] not in ["asc", "desc"]:
            sortdir = ["name", "asc"]
        self.sort_current = [sortdir[0], 0 if sortdir[1] == "asc" else 1]
        # Create buttons with default icons
        self.name_button = self.ctop_gtk.Button_new(
            image_name="up" if self.sort_current[0] == "name" and self.sort_current[1] == 0 else "down" if
            self.sort_current[0] == "name" else None,
            label="Name",
            position=Gtk.PositionType.RIGHT,
            style="print_name_button",
            scale=0.6
        )
        self.date_button = self.ctop_gtk.Button_new(
            image_name="up_date" if self.sort_current[0] == "date" and self.sort_current[1] == 0 else "down_date" if
            self.sort_current[0] == "date" else None,
            label="Date",
            position=Gtk.PositionType.RIGHT,
            style="print_name_button",
            scale=0.6
        )
        self.date_button.get_style_context().add_class("print_name_button_selected")
        self.name_button.connect("clicked", self.change_sort, "name")
        self.date_button.connect("clicked", self.change_sort, "date")

        self.search_entry = Gtk.Entry()
        self.search_entry.set_placeholder_text("Search...")
        self.search_entry.get_style_context().add_class("print_entry_search")
        self.search_entry.set_editable(False)
        self.search_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.PRIMARY, None)
        self.search_entry.connect("button-press-event", self.on_search_clicked)
        self.search_entry.connect("focus-out-event", self.on_focus_out)


        # self.search_entry.connect("changed", self.on_search_changed)

        refresh_button = self.ctop_gtk.Button_new(image_name="refresh_date", style="print_refresh", scale=.66)
        refresh_button.connect("clicked", self.on_refresh_clicked)

        control_box_top.add(self.internal_storage_button)
        control_box_top.add(self.usb_storage_button)
        control_box_bottom.add(self.name_button)
        control_box_bottom.add(self.date_button)
        control_box_bottom.add(self.search_entry)
        control_box_bottom.add(refresh_button)

        control_box.add(control_box_top)
        control_box.add(control_box_bottom)

        self.navigation_box = self.ctop_gtk.c2p_box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.navigation_box.set_halign(Gtk.Align.CENTER)
        self.navigation_box.set_margin_bottom(10)

        self.internal_main_box.add(control_box)
        self.internal_main_box.add(self.files_grid)
        self.internal_main_box.add(self.navigation_box)
        self.on_search_changed(self.search_entry.get_text())
        self.render_files()

    def on_focus_out(self, widget, event):
        print("exit")
        window = self.screen.get_window()
        if window:
            window.set_cursor(Gdk.Cursor.new_for_display(Gdk.Display.get_default(), Gdk.CursorType.BLANK_CURSOR))
    def change_sort(self, widget, key):
        if self.sort_current[0] == key:
            self.sort_current[1] = (self.sort_current[1] + 1) % 2
        else:
            self.sort_current = [key, 0]
        if self.current_selected_button == "internal_storage":
            self.screen.files.sort_file(self.sort_current)
        elif self.current_selected_button == "usb_storage":
            self.screen.usb_PrintFile.sort_file(self.sort_current)

        self.update_sort_buttons()
        self.reset_pagination()
        self.render_files()
        if key == "name":
            self.name_button.get_style_context().add_class("print_name_button_selected")
            self.date_button.get_style_context().remove_class("print_name_button_selected")
        else:
            self.date_button.get_style_context().add_class("print_name_button_selected")
            self.name_button.get_style_context().remove_class("print_name_button_selected")

    def update_sort_buttons(self):
        self.name_button.set_image(
            self.ctop_gtk.Image(
                "up_date" if self.sort_current[0] == "name" and self.sort_current[1] == 0 else
                "down_date" if self.sort_current[0] == "name" else None, scale=0.6
            )
        )
        self.date_button.set_image(
            self.ctop_gtk.Image(
                "up_date" if self.sort_current[0] == "date" and self.sort_current[1] == 0 else
                "down_date" if self.sort_current[0] == "date" else None, scale=0.6
            )
        )

    def on_search_changed(self, entrytext):
        """
        Handle changes in the search entry and filter files.
        """
        # search_text = entrytext #entry.get_text()  # Get the current text in the search entry
        if(self.entrytext_current is None or self.entrytext_current != entrytext):
            self.search_entry.set_text(entrytext)
            if self.current_selected_button == "internal_storage":
                self.screen.files.search_files(entrytext)
                self.screen.files.sort_file(self.sort_current)
            elif self.current_selected_button == "usb_storage":
                self.screen.usb_PrintFile.search_files(entrytext)
                self.screen.usb_PrintFile.sort_file(self.sort_current)
            self.reset_pagination()
            self.render_files()
            self.entrytext_current = entrytext


    def on_search_clicked(self, widget, event):
        window = self.screen.get_window()
        if window:
            window.set_cursor(Gdk.Cursor.new_for_display(Gdk.Display.get_default(), Gdk.CursorType.BLANK_CURSOR))
        print("Pointer hidden")

        if event.button == 1:
            virtual_keyboard = VirtualKeyboard(self.screen,self.theme_path,self.search_entry.get_text(),self.on_search_changed)
            # virtual_keyboard.close_keyboard(None)
            # virtual_keyboard.show_all()

    def reset_pagination(self):
        """
        Resets pagination variables: current_page, start_page, and end_page.
        """
        self.current_page = 0
        self.start_page = 0
        total_pages = ((self.get_len_Filelist()) + self.files_per_page - 1) // self.files_per_page
        self.end_page = min(5, total_pages)

    def render_files(self):
        # Clear only necessary widgets
        self.files_grid.foreach(lambda widget: self.files_grid.remove(widget))
        # Get the files for the current page
        start_index = self.current_page * self.files_per_page
        end_index = start_index + self.files_per_page
        # Handle both list and dictionary cases
        try:
            filelisttemp = self.get_Filelist()
            files_to_display = self.get_paginated_data(filelisttemp, start_index, end_index)
        except (TypeError, ValueError) as e:
            # logging.error(f"Error during pagination: {str(e)}")
            return

        # Render files
        for i, filename in enumerate(files_to_display):
            if self.current_selected_button == "internal_storage":
                labels = ["Select", "edit", "delete"]
                commands = [self.select_file, self.edit_file, self.delete_file]
                file_info = self.screen.files.files.get(filename, {})
                image = self.image_load(filename)
            elif  self.current_selected_button == "calibrate_gcodes" :
                labels = ["Select"]
                commands = [self.select_file_gcode_calibrate]
                file_info = {filename:""}
                image = self.image_load(filename)
            else:
                # labels = ["Copy"]
                labels = ["Copy"]
                commands = [self.copy_to_internal]
                image = self.ctop_gtk.Image(image_name="info", scale=0.6)
                file_info = filename
                filename = file_info.get('filename', '')
                thumbnails = file_info.get('thumbnails', '')
                image = self.get_file_loc_image(thumbnails, width=190, height=190)


            file_size = file_info.get('size', 0)
            file_time = file_info.get('estimated_time', 0)
            file_time_formatted = f"Time : {file_time // 3600}h.{(file_time % 3600) // 60}m" if file_time else None
            file_modified = datetime.fromtimestamp(file_info.get('modified', 0)).strftime('%Y-%m-%d %H:%M')

            file_element = FileElement(
                self.screen, filename, file_modified, file_time_formatted,
                self.format_size(file_size), image, self.theme_path,
                button_labels=labels,
                commands=commands,panel_command=lambda x,y: self.select_file(None,x,y),style=self.style
            )
            self.files_grid.attach(file_element, i % 3, i // 3, 1, 1)

        # Add placeholders if necessary
        for i in range(len(files_to_display), self.files_per_page):
            placeholder = Gtk.Box()
            placeholder.set_size_request(225, 375)
            self.files_grid.attach(placeholder, i % 3, i // 3, 1, 1)

        self.files_grid.show_all()
        self.render_pagination()

    def render_pagination(self):
        # Clear navigation box
        for child in self.navigation_box.get_children():
            self.navigation_box.remove(child)

        self.current_total_pages.clear()

        # Calculate total pages
        total_pages = ((self.get_len_Filelist()) + self.files_per_page - 1) // self.files_per_page

        # Reset start_page and end_page if total_pages is reduced
        if self.end_page > total_pages:
            self.end_page = total_pages
        if self.start_page >= total_pages:
            self.start_page = max(0, total_pages - 5)

        # Populate current_total_pages
        for p in range(total_pages):
            self.current_total_pages.append(p)

        # Back button
        back_button = self.ctop_gtk.Button_new("print-left", style="print_pagination_buttons")
        back_button.set_sensitive(self.current_page > 0)
        back_button.connect("clicked", self.go_to_page, self.current_page - 1, "back")
        self.navigation_box.pack_start(back_button, False, False, 5)
        # Numbered page buttons
        for page in self.current_total_pages[self.start_page:self.end_page]:
            page_button = self.ctop_gtk.Button_new(label=str(page + 1), style="print_pagination_buttons")
            page_button.connect("clicked", self.go_to_page, page, "page_button")
            self.navigation_box.pack_start(page_button, False, False, 5)
            if self.current_page == page:
                page_button.get_style_context().add_class("print_pagination_buttons_pressed")

        # Next button
        next_button = self.ctop_gtk.Button_new("print-right", style="print_pagination_buttons")
        next_button.set_sensitive(self.current_page < total_pages - 1)
        next_button.connect("clicked", self.go_to_page, self.current_page + 1, "next")
        self.navigation_box.pack_start(next_button, False, False, 5)
        # Show navigation box
        self.navigation_box.show_all()

    def go_to_page(self, widget, page, button):
        if self.current_page == page :
            self.render_files()
            return
        total_pages = ((self.get_len_Filelist()) + self.files_per_page - 1) // self.files_per_page
        # Check if the requested page is within valid range
        if 0 <= page < total_pages:
            self.current_page = page
            # Logic for next button
            if button == "next" and page >= self.end_page:
                if self.end_page < total_pages:
                    self.start_page += 1
                    self.end_page += 1
            # Logic for back button
            elif button == "back" and page < self.start_page:
                if self.start_page > 0:
                    self.start_page -= 1
                    self.end_page -= 1
            # Render files after updating pages
            self.render_files()

    def get_file_image(self, filename, width=None, height=None, small=False):
        if self.screen is None:
            return None
        loc = self.screen.files.get_thumbnail_location(filename, small)
        if loc is None:
            return None
        width = width if width is not None else self.img_width
        height = height if height is not None else self.img_height
        if loc[0] == "file":
            return self.ctop_gtk.PixbufFromFile(loc[1], width, height)
        if loc[0] == "http":
            return self.ctop_gtk.PixbufFromHttp(loc[1], width, height)
        return None

    def get_file_loc_image(self, fileloc, width=None, height=None):
        if fileloc is None or fileloc == "":
            return None
        width = width if width is not None else self.img_width
        height = height if height is not None else self.img_height
        return self.ctop_gtk.PixbufFromFile(fileloc, width, height)

    def image_load(self, filepath):
        pixbuf = self.get_file_image(filepath, width=200, height=200)
        # Check if pixbuf is None
        if pixbuf is not None:
            # file_image = (Gtk.Image.new_from_pixbuf(pixbuf))
            return pixbuf
        else:
            return "picture"

    def delete_file(self, widget, file_name, image):
        def confirm():
            try:
                self.screen.files.delete_file(file_name)
                self.screen.files.refresh_files_with_callback(self.on_refresh_callback)
                print("delete")
                self.render_files()
                self.go_to_page(self,page=self.current_page,button="page_button")
                PopupNotification(
                    message=f"File '{file_name}' deleted successfully!",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=2,
                    tipe="S"
                )
            except Exception as e:
                print(e)
                PopupNotification(
                    message=f"Error deleting file '{file_name}': {e}",
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=2,
                    tipe="E"
                    )
            dialog_delete.destroy()
        def close_dialog():
            dialog_delete.destroy()
        dialog_delete = C2PDialog(self.screen, self.screen,
                                    "Are you sure you want to delete this file?",theme_path=self.theme_path,title="Warning",
                                             button_names=["Yes","No"],sp_commands=[confirm,close_dialog])




    def select_file(self, widget, file_name, image):
        print("select")
        self.panel.show_selected_print_file(file_name, image)
        self.refresh_content(self.panel)

    def edit_file(self, widget=None, file_name=None, image=None):
        self.screen.base_panel.pressed_button = 'sub'
        self.refresh_content(GcodeEditorPanel(self.screen,file_name))

    def select_file_gcode_calibrate(self, widget, file_name, image):
        print("select")
        self.panel.show_selected_print_file(file_name, image)
        self.refresh_content(self.panel)
    def copy_to_internal(self, widget, file_name, image):

        def confirm():
            self.find_and_copy_file(file_name, self.get_Filelist(), self.screen.files.gcodes_path)

            print("copy_to_internal")
            dialog_copy.destroy()

        def close_dialog():
            dialog_copy.destroy()

        dialog_copy = C2PDialog(self.screen, self.screen,
                                "Are you sure you want to copy this file to internal storage?",
                                theme_path=self.theme_path, title="Warning",
                                button_names=["Yes", "No"], sp_commands=[confirm, close_dialog])





    def find_and_copy_file(self, filename, fileslist, destination_path):
        """
        Find a file in the given list and copy it to the specified destination path.

        Args:
            filename (str): The name of the file to find.
            fileslist (list): The list of file dictionaries.
            destination_path (str): The destination folder to copy the file to.

        Returns:
            str: The new file path if the copy was successful.
            None: If the file was not found or the copy failed.
        """

        file_data = next((file for file in fileslist if file['filename'] == filename), None)
        
        if file_data is None:
            self.screen.show_Msg_Popup(msg=f"File '{filename}' not found in the list.", time=5, type='r')
            print(f"File '{filename}' not found in the list.")
            return None

        source_path = file_data['path']
        destination_file_path = os.path.join(destination_path, os.path.basename(file_data['filename']))

        dialog_ = C2PDialog(self.screen, self.screen, "Transferring file to internal storage, please wait...",
                            theme_path=self.theme_path, title="File Transfer")
        dialog_.show_all()

        def copy_operation():
            try:
                shutil.copy(source_path, destination_file_path)
                GLib.idle_add(lambda: self.screen.show_Msg_Popup(
                    msg=f"File is copied successfully!", time=5, type='S'
                    ))
            except Exception as e:
                GLib.idle_add(lambda: self.screen.show_Msg_Popup(msg=f"Error copying file '{filename}': {e}", time=0, type='E'))
                print(f"Error copying file '{filename}': {e}")
            finally:
                GLib.idle_add(dialog_.destroy)

        threading.Thread(target=copy_operation, daemon=True).start()

    def on_refresh_clicked(self, widget=None):
        self.entrytext_current = None
        if self.current_selected_button == "internal_storage":
            self.screen.files.refresh_files_with_callback(self.on_refresh_callback)
            self.go_to_page(self,page=self.current_page,button="page_button")
        elif self.current_selected_button == "usb_storage":
            self.on_search_changed(self.search_entry.get_text())

    def on_refresh_callback(self):
        if self.current_selected_button == "internal_storage":
            self.screen.files.sort_file(self.sort_current)
        elif self.current_selected_button == "usb_storage":
            self.screen.usb_PrintFile.sort_file(self.sort_current)
        self.on_search_changed(self.search_entry.get_text())

    def on_toggle_button_clicked(self, button, source):
        """Handle toggle button clicks."""
        self.set_source(source)
        self.set_active_button(source)
        self.entrytext_current = None
        self.on_search_changed(self.search_entry.get_text())
        logging.info(f"Handle toggle button clicks: {source}")
        print(f"Handle toggle button clicks: {source}")
        if source == "internal_storage":
            self.internal_storage_button.get_style_context().add_class("print_name_button_selected")
            self.usb_storage_button.get_style_context().remove_class("print_name_button_selected")
        elif source == "usb_storage":
            self.usb_storage_button.get_style_context().add_class("print_name_button_selected")
            self.internal_storage_button.get_style_context().remove_class("print_name_button_selected")
        # self.on_refresh_clicked()

    def set_active_button(self, source):
        """Set the active button based on the source."""
        if source == "internal_storage":
            self.internal_storage_button.get_style_context().add_class("print_pagination_buttons_pressed")
            self.usb_storage_button.get_style_context().remove_class("print_pagination_buttons_pressed")
        elif source == "usb_storage":
            self.usb_storage_button.get_style_context().add_class("print_pagination_buttons_pressed")
            self.internal_storage_button.get_style_context().remove_class("print_pagination_buttons_pressed")

    def set_source(self, source):
        self.current_selected_button = source

    def get_Filelist(self):
        if self.current_selected_button == "internal_storage":
            return self.screen.files.filelist
        elif self.current_selected_button == "usb_storage":
            return self.screen.usb_PrintFile.get_filelist()
        elif self.current_selected_button == "calibrate_gcodes":
            return self.get_calibrate_gcodes()

    def get_paginated_data(self, data, start_index, end_index):
        """
        Returns paginated data based on its type (list or dict).
        """
        # if isinstance(data, list):  # Direct list case
        return data[start_index:end_index]
        # elif isinstance(data, dict):  # Dictionary case, accessing 'files'
        #     if 'gcodes' in data and 'files' in data['gcodes']:
        #         return data['gcodes']['files'][start_index:end_index]
        #     else:
        #         raise ValueError("Invalid dictionary structure for filelist.")
        # else:
        #     raise TypeError("Unsupported data type for pagination. Must be list or dict.")

    def get_len_Filelist(self):
        if self.current_selected_button == "internal_storage":
            return len(self.screen.files.filelist)
        elif self.current_selected_button == "usb_storage":
            return len(self.screen.usb_PrintFile.get_filelist())
        elif self.current_selected_button == "calibrate_gcodes":
            return len(self.get_calibrate_gcodes())

    @staticmethod
    def format_size(size):
        size = float(size)
        suffixes = ["kB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"]
        for i, suffix in enumerate(suffixes, start=2):
            unit = 1024 ** i
            if size < unit:
                return f"{(1024 * size / unit):.1f} {suffix}"
            
    def get_content(self):
        return self.internal_main_box,"Storage Panel"
    def get_calibrate_gcodes(self):
        gcode_files = []
        gcode_files_images = {
            "temp": (
                    os.path.expanduser("~/") +
                    "printer_data/printer_gcode/.thumbs/Temperature_Test-300x300"),
            "fan": (
                    os.path.expanduser("~/") +
                    "printer_data/printer_gcode/.thumbs/Fan_Test-300x300"),
            "rotation_distance": (
                    os.path.expanduser("~/") +
                    "printer_data/printer_gcode/.thumbs/Extrusion_Test-300x300"),
            "bed_mesh": (
                    os.path.expanduser("~/") +
                    "printer_data/printer_gcode/.thumbs/Bed_Mesh_Test-300x300")}

        filepaths = os.path.join(self.home_dir, "printer_data", "printer_gcode", ).replace("\\\\", "\\")
        for filename in os.listdir(filepaths):
            if filename.lower().endswith('.gcode'):
                gcode_files.append(filename)
        return gcode_files