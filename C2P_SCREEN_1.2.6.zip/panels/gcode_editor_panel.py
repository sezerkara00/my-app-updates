import os,math,copy
from elements.keyboard import VirtualKeyboard
from elements.keypad import Keypad
from elements.progress_circle import ProgressCircle
from library.gcode_editor import GcodeEditor
from library.global_manager import GlobalVariables
from elements.c2p_gtk import CtoPGtk
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
from elements.material_select import FilamentSelectionModal
from elements.popup import PopupNotification
from elements.c2p_dialog import C2PDialog
from library.xy_print_file import XYPrint

class GcodeEditorPanel(GlobalVariables):

    def __init__(self, screen,file_name):
        super().__init__(screen)
        ctop_gtk = CtoPGtk(screen,self.theme_path)
        self.layer_col = 0
        self.layer_row = 0
        self.num_layers = []
        self.file_name = file_name
        # self.temp = {}
        self.tools_numbers = {
            "T1":"01",
            "T2":"02",
            "T3":"03",
            "T4":"04"
        }
        self.selected_density = None
        self.selected_tool = None
        self.device_name =None
        self.keypad_value = None
        self.main_gcode_calibrate_box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        self.main_gcode_calibrate_box.set_halign(Gtk.Align.CENTER)
        center_box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, style="print_control_box",
                                      width=self.screen.width / 1.111, height=self.screen.height / 3.221,spacing=15)
        bottom_box = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL, style="print_control_box",
                                      width=self.screen.width / 1.111, height=self.screen.height / 12.8,spacing=5)
        save_box = ctop_gtk.c2p_box(spacing=20)
        select_layer_box = ctop_gtk.c2p_box( width=self.screen.width / 1.6, height=self.screen.height / 18.285, style="select_layer_box_editor")
        select_layer_box_all = ctop_gtk.c2p_box(spacing=10)
        select_layer_box_all.set_halign(Gtk.Align.CENTER)
        layers_box = ctop_gtk.c2p_box(width=self.screen.width / 1.28, height=self.screen.height / 6.4, style="image_box", spacing=10)
        layers_box.set_halign(Gtk.Align.CENTER)
        layers_box.set_valign(Gtk.Align.CENTER)
        self.bed_env_box = ctop_gtk.c2p_box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=40)
        tools_grid = Gtk.Grid()
        tools_grid.set_column_spacing(35)
        tools_grid.set_row_spacing(12)
        tools_grid.set_halign(Gtk.Align.CENTER)
        tools_grid.set_valign(Gtk.Align.CENTER)
        self.layers_grid = Gtk.Grid()
        self.layers_grid.set_halign(Gtk.Align.CENTER)
        self.layers_grid.set_column_spacing(18)
        self.layers_grid.set_row_spacing(15)
        self.layers_grid.get_style_context().add_class("layers_grid")

        scroll_layer = ctop_gtk.ScrolledWindow()
        scroll_layer.set_hexpand(True)
        scroll_layer.add(self.layers_grid)
        line_box_bottom = ctop_gtk.c2p_box("text_box", self.screen.width / 1.86,
                                        4,
                                        Gtk.Orientation.VERTICAL)
        line_box_center = ctop_gtk.c2p_box("text_box", self.screen.width / 1.86,
                                           4,
                                           Gtk.Orientation.VERTICAL)

        editor_label = ctop_gtk.c2p_label("Editor","print_label")
        editor_label.set_halign(Gtk.Align.START)
        add_pause = ctop_gtk.c2p_label("Add Pause","print_label")
        add_pause.set_halign(Gtk.Align.START)
        new_file_label = ctop_gtk.c2p_label("New File Name","print_label")
        new_file_label.set_halign(Gtk.Align.START)
        select_layer_label = ctop_gtk.c2p_label("Select Layer","print_label")
        add_button = ctop_gtk.Button_new(label="ADD",style="gcode_editor_add_button")

        add_button.connect("clicked",self.add_layer)
        self.value_button = ctop_gtk.Button_new(label="1",style="value_button_editor")
        self.value_button.connect("clicked", self.set_layer_value)
        self.value_button.set_halign(Gtk.Align.END)
        save_button = ctop_gtk.Button_new(label="Save",style="save_button_editor")
        save_button.connect("clicked", self.save_clicked)
        self.file_name_button = ctop_gtk.Button_new(label="File Name...", style="file_name_button_editor")
        self.file_name_button.connect("clicked", self.rename_clicked)
        self._tools,self._extruder, self._temps, self._bed_temp,_ = GcodeEditor(screen, file_name, self.home_dir).pars_gcode()
        self._next_tools = copy.deepcopy(self._tools)
        self._next_temps = copy.deepcopy(self._temps)
        self._next_bed_temp = copy.deepcopy(self._bed_temp)
        self.show_temp_circles(tools_grid)


        layers_box.add(scroll_layer)
        select_layer_box.pack_start(select_layer_label,False,False,0)
        select_layer_box.pack_start(self.value_button,True,True,0)
        select_layer_box_all.add(select_layer_box)
        select_layer_box_all.add(add_button)



        center_box.add(add_pause)
        center_box.add(line_box_center)
        center_box.add(select_layer_box_all)
        center_box.add(layers_box)

        save_box.add(self.file_name_button)
        save_box.add(save_button)
        bottom_box.add(new_file_label)
        bottom_box.add(line_box_bottom)
        bottom_box.add(save_box)


        self.main_gcode_calibrate_box.add(tools_grid)
        self.main_gcode_calibrate_box.add(center_box)
        self.main_gcode_calibrate_box.add(bottom_box)

        self.file_name_button.set_label(self.get_unique_filename(self.screen.files.gcodes_path))
        self.update_temp()

    def get_content(self):
        return self.main_gcode_calibrate_box,"Gcode Editor"

    def show_temp_circles(self, temp_progress_grid):
        for child in temp_progress_grid.get_children():
            temp_progress_grid.remove(child)
        width = 150
        height = 294
        self.progress_circle1 = ProgressCircle(self.screen, panel="gcode", w=width, h=height,
                                               name="extruder",
                                               label="01",
                                               progress=0,
                                               current_temp=0,
                                               style=self.style,
                                               active=False,
                                               angle=-math.pi / 2
                                              ,command=[lambda: self.change_tool(tool="extruder"),lambda: self.get_object_name(name="extruder")] )

        self.progress_circle2 = ProgressCircle(self.screen, panel="gcode", w=width, h=height,
                                               name="extruder1",
                                               label="02",
                                               progress=0,
                                               current_temp=0,
                                               style=self.style, active=True,
                                               angle=-math.pi / 2, command=[lambda: self.change_tool(tool="extruder1"),lambda: self.get_object_name(name="extruder1")]
                                               )

        self.progress_circle3 = ProgressCircle(self.screen, panel="gcode", w=width, h=height,
                                               name="extruder2",
                                               label="03",
                                               progress=0,
                                               current_temp=0,
                                               style=self.style, active=False,
                                               angle=-math.pi / 2, command=[lambda: self.change_tool(tool="extruder2"),lambda: self.get_object_name(name="extruder2")])

        self.progress_circle4 = ProgressCircle(self.screen, panel="gcode", w=width, h=height,
                                               name="extruder3",
                                               label="04",
                                               progress=0,
                                               current_temp=0,
                                               style=self.style, active=False,
                                               angle=-math.pi / 2, command=[lambda: self.change_tool(tool="extruder3"),lambda: self.get_object_name(name="extruder3")])

        self.progress_bed = ProgressCircle(self.screen, label="Bed", panel="gcode", progress=0, w=330, h=160,

                                           current_temp=0, side="left", style=self.style,
                                           command=lambda: self.get_object_name(name="heater_bed"))
        self.progress_env = ProgressCircle(self.screen, label="Env", panel="gcode", progress=0, w=330, h=160,

                                           current_temp=0, style=self.style, active=False,
                                           command=lambda: self.get_object_name(name="heater_generic Env_heater"))
        self.progress_devices = [
            self.progress_circle1, self.progress_circle2,
            self.progress_circle3, self.progress_circle4, self.progress_bed, self.progress_env

        ]

        self.bed_env_box.add(self.progress_bed)
        self.bed_env_box.add(self.progress_env)

        temp_progress_grid.attach(self.progress_circle1, 0, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle2, 1, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle3, 2, 1, 1, 1)
        temp_progress_grid.attach(self.progress_circle4, 3, 1, 1, 1)
        temp_progress_grid.attach(self.bed_env_box, 0, 2, 4, 1)
        temp_progress_grid.show_all()

    # def process_update(self, action, data):
    #     if action != "notify_status_update":
    #         return

    def update_temp(self,value = None,tool_number = None):
        for index,(device, progress) in enumerate(zip(
                self.screen.printer.get_origin_extruders() + self.screen.printer.get_heaters(), self.progress_devices,
                )):
            if device is None:
                continue
            index_device = self.find_str_index(self._extruder,device)
            if index_device == -1 and device != 'heater_bed':
                continue
            # self.temp[device] = self.screen.printer.get_dev_stat(device, "temperature")
            if self.device_name == device and self.device_name is not None and value is not None:
                if "heater_bed" in device:
                    self._next_bed_temp = value
                elif "extruder" in device:
                    self._next_temps[index_device] = value
                progress.set_target(value)
            if self.device_name == device and self.device_name is not None and tool_number is not None:
                self._next_tools[index_device] = f"T{int(tool_number)-1}"
                progress.change_tool_number(tool_number)

            if "heater_bed" in device:
                max_temp = self.screen.printer.get_dev_stat(device,
                                                            "max_temp")
                progress.set_current_temp(float(self._bed_temp),
                                              float(self._bed_temp) / max_temp, max_temp, True)

            elif "extruder" in device:
                max_temp = self.screen.printer.get_dev_stat(device,
                                                            "max_temp")
                min_temp = self.screen.printer.get_dev_stat(device,
                                                            "min_extrude_temp")
                if max_temp is None:
                    max_temp = 400
                if min_temp is None:
                    min_temp = 150
                if self._temps is not None:
                    progress.set_current_temp(float(self._temps[index_device]),
                                              float(self._temps[index_device]) / max_temp, max_temp, True)
    
    def get_object_name(self, widget=None, name=None):
        self.show_keypad(widget, name)
    
    def change_tool(self,tool):
        self.device_name = tool
        modal = FilamentSelectionModal(self.screen, self.theme_path, self.tools_numbers,
                                       selected_material=self._tools)
        response = modal.run()
        if response == Gtk.ResponseType.OK:
            self.selected_density = modal.selected_density
            self.selected_tool = modal.selected_material
            print(self.selected_density)
            self.update_temp(tool_number=self.selected_density)

        modal.destroy()
    
    def show_keypad(self, widget=None, type=None):
        # Determine the initial value for the keypad
        if type in self.screen.printer.get_active_extruders() + self.screen.printer.get_heaters():
            for progress, device in zip(self.progress_devices,
                                        self.screen.printer.get_active_extruders() + self.screen.printer.get_heaters()):
                if device != type:
                    progress.on_button_release()
                else:
                    index_device = self.find_str_index(self._extruder,device)
                    if index_device == -1 and device != 'heater_bed':
                        continue
                    if 'heater_bed' in type:
                        self.keypad_value = self._next_bed_temp
                    elif 'extruder' in type:
                        self.keypad_value = self._next_temps[index_device] #self.screen.printer.get_dev_stat(device, "target")
                    self.device_name = device
        elif widget:  # Read from widget label
            label_text = widget.get_label()
            try:
                # Try to parse the label as a number
                self.keypad_value = float(label_text)
            except (ValueError, TypeError):
                # If parsing fails, set the default value to 0
                self.keypad_value = 0
        else:
            self.keypad_value = 0  # Default value if none of the conditions match

        # Create a new Keypad instance and use lambda to pass the value directly to handle_keypad
        keypad_window = Keypad(
            self.screen,
            self.theme_path,
            lambda value: self.handle_keypad(value, widget, type)
        )
        keypad_window.show_keypad(text=self.keypad_value)

    def handle_keypad(self, value, widget, type):
        """
        Handle the value returned from the Keypad and update UI or state accordingly.
        """

        self.update_temp(value)
        # Optionally update the label of the widget
        if widget:
            try:
                if isinstance(value, str) and "%" in value:
                    # If the value contains '%', leave it as is
                    widget.set_label(value)
                else:
                    numeric_value = float(value)
                    # Check if the value is an integer
                    if numeric_value.is_integer():
                        # If the value is an integer, set it without decimals
                        widget.set_label(f"{int(numeric_value)}")

                    else:
                        # If the value is a float, format it with 2 decimal places
                        widget.set_label(f"{numeric_value:.2f}")
            except ValueError:
                # Handle non-numeric value gracefully
                widget.set_label("0")

    def add_layer(self,widget):
        value_str = self.value_button.get_label()
        if not value_str.isdigit():
            self.show_error("The input value is not a number!")
            return
        value = int(value_str)
        if value == 0:
            self.show_error("The value cannot be zero!")
            return
        if value in self.num_layers:
            self.show_error(f"The value {value} already exists in the list!")
            return
        self.num_layers.append(value)
        self.layer_col += 1
        if self.layer_col>3:
            self.layer_row += 1
            self.layer_col = 1
        l_box = self.make_layer_box(self.value_button.get_label(),self.layers_grid)
        self.layers_grid.attach(l_box, self.layer_col, self.layer_row, 1, 1)
        self.layers_grid.show_all()
    
    def make_layer_box(self,lbl,parent_container):
        box = Gtk.Box(spacing=0)
        box.set_size_request(30, 15)
        box.get_style_context().add_class("layer_box")
        box.set_valign(Gtk.Align.CENTER)
        layer_lbl = Gtk.Label("Layer "+lbl)
        layer_lbl.get_style_context().add_class("select_tool_label")
        close_button = Gtk.Button()

        def on_close_clicked(btn):
            # Remove the label from the stored array before removing from UI
            if int(lbl) in self.num_layers:
                self.num_layers.remove(int(lbl))

            parent_container.remove(box)
            parent_container.show_all()
            if not parent_container.get_children():
                self.layer_col = 0
                self.layer_row = 1

        close_button.connect("clicked", on_close_clicked)
        close_button.set_label("|X")
        close_button.get_style_context().add_class("gcode_editor_layer_button")
        box.add(layer_lbl)
        box.add(close_button)
        return box

    def set_layer_value(self, widget):
            try:
                # Attempt to convert the label to a float
                initial_text = str(int(self.value_button.get_label()))
            except ValueError:
                # If conversion fails, fallback to "0"
                initial_text = "0"
            # Open the Keypad and pass the handler for updating the distance
            keypad_window = Keypad(self.screen, self.theme_path, self.handle_layer_value, min_value=0)
            keypad_window.show_keypad(text=initial_text)
   
    def handle_layer_value(self,value):
            self.value_button.set_label(str(int(value)))
    
    def rename_clicked(self, widget):
        filename,ext = os.path.splitext(self.file_name_button.get_label())
        VirtualKeyboard(self.screen, self.theme_path, filename, final_callback = self.on_file_changed)

    def save_clicked(self, widget):
        def on_yes():
            dialog.destroy()
            xyprint = XYPrint()
            home_path = os.path.expanduser("~")
            filepath = os.path.join(home_path, "printer_data", "gcodes",self.file_name).replace("\\\\", "\\")
            # fixed_path = os.path.normpath(filepath)
            xyprint.replace_tools(filepath,self._tools,self._next_tools,self._next_temps,self._next_bed_temp,layer_numbers=self.num_layers,new_filename=self.file_name_button.get_label())
            PopupNotification(
                message=f"{self.file_name_button.get_label()} saved successfully",
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                timeout=5,
                tipe='C'
            )
        def on_no():
            dialog.destroy()
        dialog = C2PDialog(
            self.screen,
            self.screen,
            "Are you sure you want to change file parameter and save with new name?",
            theme_path=self.theme_path,
            title="Warning",
            button_names=["Yes", "No"],
            sp_commands=[on_yes, on_no]
        )
        
    def on_file_changed(self, entrytext):
        filename = entrytext + ".gcode"
        file_path = os.path.join(self.screen.files.gcodes_path, filename) 
        if not os.path.exists(file_path):
            self.file_name_button.set_label(filename)
        else:
            self.show_error("The file name already exists. Please choose a different name.")

    def find_str_index(self,array, target_string):
        try:
            return array.index(target_string)
        except ValueError:
            return -1
        
    def get_unique_filename(self,folder_path, base_filename="File Name...", prefix="new_file"):
        # Construct the initial full path
        file_path = os.path.join(folder_path, base_filename)

        # If the base file does not exist, return it directly
        if not os.path.exists(file_path):
            return base_filename

        # If file exists, find the next available "doneX.gcode"
        counter = 1
        while True:
            new_filename = f"{prefix}{counter}.gcode"
            new_file_path = os.path.join(folder_path, new_filename)

            # If the new file does not exist, return it
            if not os.path.exists(new_file_path):
                return new_filename

            counter += 1  # Increment counter to check the next number
        
    def show_error(self,text):
        PopupNotification(
                    message=text,
                    screen=self.screen,
                    them_path=self.theme_path,
                    show_button=False,
                    timeout=5,
                    tipe="E"
                )
        