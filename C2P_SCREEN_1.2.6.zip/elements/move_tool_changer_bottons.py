import math
import cairo
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk

class ToolChangerButtons(Gtk.DrawingArea):
    def __init__(self,commands_handler=None,style="dark"):
        super().__init__()
        # self.panel = panel
        self.d_button = False
        self.style = style
        self.tools_seleted = None
        self.commands_handler = commands_handler
        self.set_size_request(350, 250)
        self.selected_button = None  # Track selected button
        self.connect("draw", self.on_draw)
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.connect("button-press-event", self.on_button_press)

    def on_draw(self, widget, ctx):
        width = self.get_allocated_width()
        height = self.get_allocated_height()
        center_x, center_y = width / 2, height / 1.5  # Center for semicircle
        radius_outer = 120
        radius_inner = 50
        center_button_radius = 60
        # Draw the semicircular pie buttons
        for i in range(4):
            start_angle = math.pi  + i * (math.pi / 4)
            end_angle = start_angle + (math.pi / 4) -0.05
            # Set color: highlight selected
            if self.selected_button == i and self.tools_seleted is not None and self.tools_seleted [i] is not None and 'extrude' in self.tools_seleted [i]:
                if self.d_button:
                    if self.style == "light":
                        ctx.set_source_rgb(0.156, 0.318, 0.718)
                    else:
                        ctx.set_source_rgb(0.329, 0.702, 0.776)
                else:
                    if self.style == "light":
                        ctx.set_source_rgb(0.157, 0.318, 0.718)
                    else:
                        ctx.set_source_rgb(105 / 255, 224 / 255, 248 / 255)
            else:
                if self.style == "light":
                    ctx.set_source_rgb(0.80, 0.81, 0.86)
                else:
                    ctx.set_source_rgb(0.2, 0.2, 0.2)  # Default gray

            if self.tools_seleted[i] is None:
                if self.style == "light":
                    ctx.set_source_rgb(138/255, 138/255, 138/255)  #not active extruder color
                else:
                    ctx.set_source_rgb(92/255, 92/255, 92/255)

            ctx.move_to(center_x, center_y)
            ctx.arc(center_x, center_y, radius_outer, start_angle, end_angle)
            ctx.line_to(center_x, center_y)
            ctx.close_path()
            ctx.fill()
            # Draw button labels
            if self.style == "light":
                if self.selected_button == i and self.tools_seleted is not None and self.tools_seleted [i] is not None and 'extrude' in self.tools_seleted [i]:
                    ctx.set_source_rgb(1,1,1)
                else:
                    ctx.set_source_rgb(0, 0, 0)
            else:
                if self.tools_seleted[i] is not  None:
                    ctx.set_source_rgb(1, 1, 1)
                else:
                    ctx.set_source_rgb(0, 0, 0)
            ctx.set_font_size(15)
            angle = (start_angle + end_angle) / 2
            text_x = center_x + math.cos(angle) * (radius_outer + radius_inner) / 2 - 10
            text_y = center_y + math.sin(angle) * (radius_outer + radius_inner) / 2 + 5
            ctx.move_to(text_x, text_y)
            ctx.show_text(f"{i+1:02}")
        # Draw the circular center button
        if self.d_button:
            if self.style == "light":
                ctx.set_source_rgb(0.157, 0.318, 0.718)
            else:
                ctx.set_source_rgb(0.329, 0.702, 0.776)
        else:
            if self.style == "light":
                ctx.set_source_rgb(0.157, 0.318, 0.718)
            else:
                ctx.set_source_rgb(105 / 255, 224 / 255, 248 / 255)
        ctx.arc(center_x, center_y, center_button_radius, 0, 2 * math.pi)
        ctx.fill()
        # Center button label
        ctx.set_source_rgb(1, 1, 1)
        ctx.set_font_size(15)
        text = "Select\n Tool"
        for idx, line in enumerate(text.split("\n")):
            ctx.move_to(center_x -25, center_y + (idx * 15))
            ctx.show_text(line)

    def on_button_press(self, widget, event):
        selected_button_temp = None
        if self.d_button:
            return
        width = self.get_allocated_width()
        height = self.get_allocated_height()
        center_x, center_y = width / 2, height / 1.5
        radius_outer = 100
        center_button_radius = 50
        # Convert mouse click to polar coordinates
        dx = event.x - center_x
        dy = event.y - center_y
        distance = math.sqrt(dx**2 + dy**2)
        angle = math.atan2(dy, dx) % (2 * math.pi)
        if distance <= center_button_radius:
            print("Center button clicked: Select Tool")
            if self.commands_handler:
                self.commands_handler(None,self.selected_button)
        elif radius_outer > distance > center_button_radius:
            for i in range(4):
                start_angle = math.pi  + i * (math.pi / 4)
                end_angle = start_angle + (math.pi / 4)
                if start_angle <= angle <= end_angle:
                    if self.tools_seleted is not None and self.tools_seleted [i] is not None and 'extrude' in self.tools_seleted [i]:
                        print(f"Button {i+1} clicked")
                        selected_button_temp = i
                    break
        else:
            selected_button_temp = None
        if selected_button_temp is not None and self.selected_button != selected_button_temp:
            self.selected_button = selected_button_temp
            self.queue_draw()  # Redraw the widget

    def disable_button(self,tools_seleted):
        self.d_button = True
        self.tools_seleted = tools_seleted
        self.queue_draw()

    def enable_button(self,tools_seleted):
        self.d_button = False
        self.tools_seleted = tools_seleted
        self.queue_draw()

    def select_tools(self,selectnumber):
        self.selected_button = selectnumber
        self.queue_draw()