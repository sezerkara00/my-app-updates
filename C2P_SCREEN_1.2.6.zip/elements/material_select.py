import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk
from elements.c2p_gtk import CtoPGtk

class FilamentSelectionModal(Gtk.Dialog):
    """
    Filament selection modal using CtoPGtk design system.
    Displays filament options in a 4-column grid.
    """


    def __init__(self, screen, theme_path,labels, selected_material=None):
        """
        :param screen: Parent GTK window
        :param theme_path: Theme path for CtoPGtk
        :param selected_material: Pre-selected filament material name (if any)
        """
        super().__init__(title="Select Filament Type", transient_for=screen, flags=Gtk.DialogFlags.MODAL)
        self.set_default_size(500, 400)
        self.set_resizable(False)
        self.labels = labels
        self.set_decorated(False)  # Remove title bar
        self.set_app_paintable(True)
        self.ui = CtoPGtk(screen, theme_path)

        self.selected_density = None
        self.selected_material = selected_material
        self.selected_button = None
        screen = Gdk.Screen.get_default()
        visual = screen.get_rgba_visual()
        if visual is not None and screen.is_composited():
            self.set_visual(visual)
        self.get_style_context().add_class("dialog")




        # Main Content Box
        box = self.get_content_area()
        vbox = self.ui.c2p_box(style="print_control_box", orientation=Gtk.Orientation.VERTICAL, spacing=10)

        # Title Label
        title_label = self.ui.c2p_label("Select a filament type:", "info_label")
        vbox.pack_start(title_label, False, False, 5)

        # Grid Layout for Filament Buttons
        grid = self.ui.HomogeneousGrid()
        vbox.pack_start(grid, True, True, 5)

        row, col = 0, 0
        self.buttons = {}

        for filament, density in self.labels.items():
            btn = self.ui.Button_new(label=filament, style="bed_mesh_points_button", scale=0.5)
            btn.connect("clicked", self.on_filament_selected, filament, density)

            # Check if this filament is pre-selected
            if self.selected_material and self.selected_material == filament:
                btn.get_style_context().add_class("bed_mesh_points_button_pressed")
                self.selected_button = btn
                self.selected_density = density

            # Add to Grid (4 Columns)
            grid.attach(btn, col, row, 1, 1)
            self.buttons[filament] = btn

            col += 1
            if col >= 4:  # Move to next row after 4 columns
                col = 0
                row += 1

        # Buttons Box
        button_box = self.ui.c2p_box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        vbox.pack_start(button_box, False, False, 5)

        btn_confirm = self.ui.Button_new(label="Confirm", style="dialog_button")
        btn_confirm.connect("clicked", self.on_confirm)
        button_box.pack_start(btn_confirm, True, True, 5)

        btn_cancel = self.ui.Button_new(label="Cancel", style="dialog_button")
        btn_cancel.connect("clicked", self.on_cancel)
        button_box.pack_start(btn_cancel, True, True, 5)

        box.add(vbox)
        self.show_all()
        self.get_window().set_cursor(Gdk.Cursor.new_for_display(Gdk.Display.get_default(), Gdk.CursorType.BLANK_CURSOR))
    def on_filament_selected(self, button, filament, density):
        """Handles filament selection, highlights button, and updates density & material."""
        if self.selected_button:
            self.selected_button.get_style_context().remove_class("bed_mesh_points_button_pressed")

        # Highlight new selection
        button.get_style_context().add_class("bed_mesh_points_button_pressed")
        self.selected_button = button
        self.selected_density = density
        self.selected_material = filament  # Store selected material name

    def on_confirm(self, button):
        """Returns selected material & density and closes the modal."""
        self.response(Gtk.ResponseType.OK)

    def on_cancel(self, button):
        """Closes the modal without selection."""
        self.response(Gtk.ResponseType.CANCEL)
