import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib
from elements.c2p_gtk import CtoPGtk
from elements.popup import PopupNotification  # Assuming PopupNotification is in elements

class Keypad(Gtk.Box):
    def __init__(self, screen, them_path, command, min_value=None, max_value=None, type=None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.keypad = None
        self.screen = screen
        self.get_style_context().add_class("main_box")
        self.set_halign(Gtk.Align.CENTER)
        self.set_valign(Gtk.Align.CENTER)
        self.command = command
        self.theme_path = them_path
        self.min_value = min_value
        self.max_value = max_value
        self.type = type  # Store the type parameter as instance variable
        self.set_border_width(10)
        self.set_size_request(300, 350)
        self.ctopgtk = CtoPGtk(screen, them_path)

        # Entry box for input
        self.entry = Gtk.Entry()
        self.entry.set_size_request(100, 50)
        self.entry.get_style_context().add_class("entry")
        self.pack_start(self.entry, False, False, 0)

        # Grid to hold the keypad buttons
        grid = Gtk.Grid()
        grid.set_row_spacing(10)
        grid.set_column_spacing(10)
        self.pack_start(grid, True, True, 0)

        # Define button labels
        buttons = [
            ("1", 0, 0), ("2", 1, 0), ("3", 2, 0), ("X", 3, 0),  # First row
            ("4", 0, 1), ("5", 1, 1), ("6", 2, 1), ("", 3, 1),  # Second row
            ("7", 0, 2), ("8", 1, 2), ("9", 2, 2), ("", 3, 2),  # Third row
            (".", 0, 3), ("0", 1, 3), ("\u23CE", 2, 3), ("f", 3, 3)  # Fourth row
        ]

        # Add buttons to the grid
        for label, col, row in buttons:
            if label:  # Avoid empty placeholders
                if "X" in label:
                    button = self.ctopgtk.Button_new(image_name="close_keypad", style="keypad_button")
                    button.connect("clicked", self.close_keypad)
                    grid.attach(button, col, row, 1, 2)  # Attach to grid
                elif "f" in label:
                    button = self.ctopgtk.Button_new(image_name="enter", style="keypad_button")
                    button.connect("clicked", self.enter_text)
                    grid.attach(button, col, row - 1, 1, 2)
                elif "\u23CE" in label:
                    button = self.ctopgtk.Button_new(image_name="delete", style="keypad_button")
                    button.connect("clicked", self.delete_text)
                    grid.attach(button, col, row, 1, 1)  # Attach to grid
                else:
                    button = self.ctopgtk.Button_new(label=label, style="keypad_button")
                    grid.attach(button, col, row, 1, 1)  # Attach to grid
                    button.connect("clicked", self.on_button_clicked)
        # Set special styles for the last column
        for widget in grid.get_children():
            if widget.get_label() in ("X", "f", "\u23CE"):
                widget.get_style_context().add_class("special-button")

    def on_button_clicked(self, button):
        label = button.get_label()
        if self.entry.get_selection_bounds():
            # If there is a selection, clear the entire text
            self.entry.set_text("")
        self.entry.set_text(self.entry.get_text() + label)

    def delete_text(self, widget):
        """
        Delete text from the entry. If all text is selected, clear the entire entry.
        """
        # Check if any text is selected
        if self.entry.get_selection_bounds():
            # If there is a selection, clear the entire text
            self.entry.set_text("")
        else:
            # Otherwise, delete the last character
            text = self.entry.get_text()[:-1]
            self.entry.set_text(text)

    def enter_text(self, widget):
        """
        Validate the input based on min_value and max_value, and call the command if valid.
        """
        try:
            value = self.entry.get_text()
            
            if self.type == "ip":
                # For IP addresses, just pass the string value
                self.command(value)
                self.close_keypad()
            else:
                # For numeric values, do the regular validation
                value = float(value)
                if (self.min_value is not None and value < self.min_value) or \
                (self.max_value is not None and value > self.max_value):
                    error_message = f"Value must be "
                    if self.min_value is not None and self.max_value is not None:
                        error_message += f"between {self.min_value} and {self.max_value}."
                    elif self.min_value is not None:
                        error_message += f"greater than or equal to {self.min_value}."
                    elif self.max_value is not None:
                        error_message += f"less than or equal to {self.max_value}."
                    PopupNotification(
                        message=error_message,
                        screen=self.screen,
                        them_path=self.theme_path,
                        show_button=False,
                        timeout=3,
                        tipe="E"
                    )
                else:
                    print("Entered:", value)
                    self.command(value)
                    self.close_keypad()
        except ValueError:
            # Handle non-numeric input
            error_message = "Invalid input. Please enter a valid number."
            PopupNotification(
                message=error_message,
                screen=self.screen,
                them_path=self.theme_path,
                show_button=False,
                timeout=3,
                tipe="E"
            )

    def close_keypad(self, widget=None):
        self.keypad.destroy()

    def show_keypad(self, widget=None, text=None):
        # Create a new window for the keypad
        self.entry.set_text(str(text))
        self.keypad = Gtk.Window(title="Keypad")

        self.keypad.set_transient_for(
            self.screen)  # Make it behave like a dialog
        self.keypad.set_modal(True)  # Block interaction with the main window
        self.keypad.set_decorated(False)
        self.keypad.set_resizable(False)
        self.keypad.get_style_context().add_class(
            "power_panel")
        self.keypad.set_default_size(self.screen.width, self.screen.height)
       # self.keypad.set_position(Gtk.WindowPosition.CENTER)
        screen = Gdk.Screen.get_default()
        visual = screen.get_rgba_visual()
        if visual is not None and screen.is_composited():
            self.keypad.set_visual(visual)
        self.keypad.add(self)
        self.keypad.show_all()

