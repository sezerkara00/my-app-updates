import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Rsvg", "2.0")
from gi.repository import Gtk, Gdk, Rsvg, cairo, GLib
import math
from elements.c2p_gtk import CtoPGtk

class PrintingElement(Gtk.DrawingArea):
    def __init__(self,screen,file_name,file_image,theme_path, label="Click Me", file=None,width=200, height=90,orientation="horizontal",command=None,style="dark"):
        super().__init__()
        self.set_size_request(720, 279)
        self.style =style
        self.label = label
        self.file_name = file_name
        self.file_image = file_image
        self.command = command
        self.printing_progress = 0
        self.printing_state = ""
        self.file_image = file_image
        self.ctopgtk = CtoPGtk(screen,theme_path)
        self.connect("draw", self.on_draw)
        self.loading_dots = ""  # Current dots for loading
        self.loading_running = False  # Control flag for loading animation
        self.text_animation_running = False  # Control flag for text animation
        self.text_animation_phase = 0.0  # Phase for color or movement animation

    def on_draw(self,da,ctx):
        w = da.get_allocated_width()
        h = da.get_allocated_height()
        r_corner = h/2.01
        circle_radius = h/2.7
        if self.style == "light":
            ctx.set_source_rgb(0.827, 0.839, 0.886)
        else:
            ctx.set_source_rgb(0.2706, 0.2706, 0.2706)
        ctx.line_to(w - r_corner, 0)  # Stop before the right edge

        # Right edge (arc)
        ctx.arc_negative(w - r_corner, h / 2, r_corner, -math.pi / 2,
                         math.pi / 2)

        # Bottom edge
        ctx.line_to(r_corner, h)  # Stop before the bottom-left corner

        # Bottom-left corner (arc)
        ctx.arc(r_corner , h - r_corner , r_corner , math.pi / 2, math.pi)

        # Left edge
        ctx.line_to(0, r_corner)  # Up the left side

        # Top-left corner (arc)
        ctx.arc(r_corner , r_corner , r_corner , math.pi, 3 * math.pi / 2)
        ctx.close_path()
        ctx.fill()


        # Draw the progress circle
        x, y = w / 1.23, h / 2  # Center of the circle
        radius = h/2.48  # Circle radius

        line_width = 18  # Thickness of the progress circle
        color = (0.4, 0.8, 1.0)  # Light blue color

        self.draw_progress_circle(ctx, x, y, radius, line_width, color)


        # Add text in the center
        if self.style == "light":
            ctx.set_source_rgb(0, 0, 0)
        else:
            ctx.set_source_rgb(1, 1, 1)  # White text color
        ctx.select_font_face("Sans", cairo.FontSlant.NORMAL, cairo.FontWeight.BOLD)
        ctx.set_font_size(30)

        # Add animated text in the center
        self.draw_animated_text(ctx, w, h)

        # text = "......."
        # (x_bearing, y_bearing, text_width, text_height, x_advance, y_advance) = ctx.text_extents(text)
        ctx.move_to(w / 2.27, h / 1.5)  # Center the text
        ctx.show_text(self.loading_dots)

        # Calculate text position
        text = f"{self.printing_progress * 100:.0f}%"
        (x_bearing, y_bearing, text_width, text_height, x_advance, y_advance) = ctx.text_extents(text)
        ctx.move_to(x - text_width / 2, y + text_height / 2)  # Center the text
        ctx.show_text(text)


        xc = w/5.2
        yc = h/2
        radius = 130
        self.draw_circle(ctx, xc, yc, radius, False, 0)
        ctx.fill()

    def draw_progress_circle(self,ctx, x, y, radius,  line_width, color):
        """
        Draws a progress circle with rounded ends.

        :param ctx: Cairo context.
        :param x: X-coordinate of the circle center.
        :param y: Y-coordinate of the circle center.
        :param radius: Radius of the circle.
        :param progress: Progress value (0.0 to 1.0).
        :param line_width: Thickness of the progress circle.
        :param color: RGB tuple for the progress color.
        """
        # Set line width and cap style
        ctx.set_line_width(line_width)
        ctx.set_line_cap(cairo.LineCap.ROUND)  # Rounded ends

        # Set progress color
        ctx.set_source_rgb(*color)

        # Calculate start and end angles
        start_angle = -math.pi / 2  # Start at the top
        end_angle = start_angle + self.printing_progress * 2 * math.pi

        # Draw the progress arc
        ctx.arc(x, y, radius, start_angle, end_angle)
        ctx.stroke()

    def draw_circle(self, ctx, x, y, circle_radius, pressed, text_angle,
                    label=None):
        """Draw a circle with an optional shadow and an SVG."""

        # Shadow properties
        shadow_layers = 6  # Number of shadow layers for smooth blur
        shadow_opacity = 0.1  # Opacity for the shadow
        shadow_spread = 3  # Spread size for the shadow
        shadow_color = (0, 0, 0)  # Black shadow

        # Step 1: Draw the shadow
        for i in range(shadow_layers):
            ctx.save()
            shadow_radius = circle_radius + shadow_spread + i * 0.5  # Gradually increase shadow size
            ctx.set_source_rgba(*shadow_color, shadow_opacity / (
                        i + 1))  # Semi-transparent black
            ctx.arc(x, y, shadow_radius, 0, 2 * math.pi)
            ctx.fill()
            ctx.restore()
        if self.style == "light":
            ctx.set_source_rgb(0.827, 0.839, 0.886)
        else:
            ctx.set_source_rgb(0.2706, 0.2706, 0.2706)  # Light gray circle

        ctx.arc(x, y, circle_radius, 0, 2 * math.pi)
        ctx.fill()

        # Step 3: Draw the SVG with rotation
        ctx.save()
        if text_angle > 0:
            # Move the origin to the center of the circle
            ctx.translate(x, y)
            ctx.rotate(text_angle)  # Rotate the context by the given angle

            # Draw the SVG centered at the rotated origin
            if self.file_image is not None:
                self.ctopgtk.render_image(ctx, 0, 0, 1, self.file_image,self.style)
            else:
                self.ctopgtk.render_image(ctx, 0, 0, 1, "picture",self.style)
        else:
            if self.file_image is not None:
                self.ctopgtk.render_image(ctx, x, y, 1, self.file_image,self.style)
            else:
                # Draw the SVG centered at the circle center without rotation
                self.ctopgtk.render_image(ctx, x, y,  1, "picture",self.style)
        ctx.restore()

    def update_printing_progress(self,progress):
        self.printing_progress = progress
        self.queue_draw()

    def update_printing_state(self,text):
        self.printing_state = text
        self.queue_draw()

    def update_loading_dots(self):
        """Update the loading dots and redraw."""
        if self.loading_running:
            # Update dots in a cyclic manner
            if len(self.loading_dots) < 7:
                self.loading_dots += "."
            else:
                self.loading_dots = ""
            self.queue_draw()  # Request a redraw
            return True  # Continue the timer
        return False  # Stop the timer

    def stop_loading(self):
        """Stop the loading animation."""
        self.loading_running = False
        self.loading_dots = "......."
        self.queue_draw()  # Request a redraw

    def start_loading(self):
        """Stop the loading animation."""
        if not self.loading_running:
            self.loading_running = True
            # Start the loading animation
            GLib.timeout_add(150, self.update_loading_dots)

    def start_text_animation(self):
        """
        Start the animation for the text.
        """
        if not self.text_animation_running:
            self.text_animation_running = True
            GLib.timeout_add(50, self.update_text_animation)

    def stop_text_animation(self):
        """
        Stop the animation for the text.
        """
        self.text_animation_running = False

        # Reset the animation phase (optional)
        self.text_animation_phase = 0.0

        # Ensure the text color resets to white
        self.queue_draw()  # Trigger a redraw to apply the change

    def update_text_animation(self):
        """
        Update the text animation phase and redraw.
        """
        if self.text_animation_running:
            self.text_animation_phase += 0.1  # Increment the phase
            if self.text_animation_phase > 2 * math.pi:  # Reset after a full cycle
                self.text_animation_phase = 0.0
            self.queue_draw()
            return True  # Continue the timer
        return False  # Stop the timer

    def draw_animated_text(self, ctx, w, h):
        """
        Draw the printing state text with animation (color cycling).
        """
        if self.text_animation_running:
            # Update the color phase for animation
            r = (math.sin(self.text_animation_phase) + 1) / 2  # Cycle between 0 and 1
            g = (math.cos(self.text_animation_phase) + 1) / 2  # Cycle between 0 and 1
            b = 1.0  # Static blue
        else:
            # Set the color to white when animation is stopped
            r, g, b = 1.0, 1.0, 1.0

        # Set the animated color

        if self.style == "light":
            ctx.set_source_rgb(0, 0, 0)
        else:
            ctx.set_source_rgb(1.0, 1.0, 1.0)
        # Draw the animated text
        ctx.select_font_face("Sans", cairo.FontSlant.NORMAL, cairo.FontWeight.BOLD)
        ctx.set_font_size(22)
        text = self.printing_state
        (x_bearing, y_bearing, text_width, text_height, x_advance, y_advance) = ctx.text_extents(text)
        ctx.move_to(w / 2.5, h / 2 + text_height / 2)  # Center the text
        ctx.show_text(text)
        # Reset the color to white for other text
        if self.style == "light":
            ctx.set_source_rgb(0, 0, 0)
        else:
            ctx.set_source_rgb(1.0, 1.0, 1.0)

