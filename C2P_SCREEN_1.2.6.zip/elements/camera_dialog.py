import gi

from elements.c2p_gtk import CtoPGtk
from elements.custom_combo_box import CustomComboBox

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk,Gdk
import re
import textwrap
import math

class CameraDialog(Gtk.Window):
    def __init__(self,screen,theme_path, parent, tools_list,title="info",massage="Please Select Tool",yes_command=None):
        super().__init__(title="Select a Tool")
        ctop_gtk = CtoPGtk(screen, theme_path)
        # Configure the dialog window
        self.set_default_size(screen.width, screen.height)
        self.set_resizable(False)  # Prevent resizing the window
        self.set_decorated(False)  # Disable window decorations
        #self.set_app_paintable(True)
        self.get_style_context().add_class("power_panel")
        self.yes_command = yes_command
      #  self.connect('draw', self.draw)
        screenV = Gdk.Screen.get_default()
        visual = screenV.get_rgba_visual()
        if visual is not None and screenV.is_composited():
            self.set_visual(visual)
        # Split the string into words
        if not isinstance(massage, list):
            message = re.sub(r'\s+', ' ', massage).strip()
            massage = textwrap.fill(message, width=40, break_long_words=False, break_on_hyphens=False)

        # Create the main content area
        content_area = ctop_gtk.c2p_box(orientation=Gtk.Orientation.VERTICAL,width=screen.width/1.45,height=screen.height/3.2,style="dialog")
        content_area.set_valign(Gtk.Align.CENTER)
        content_area.set_halign(Gtk.Align.CENTER)
        box_info = ctop_gtk.c2p_box("dialog_box_info")

        image_info = ctop_gtk.Image("info-dialog")
        label = Gtk.Label(title)
        box_info.add(image_info)
        box_info.add(label)
        border_box = ctop_gtk.c2p_box("dialog_box_margin", 450, 1,
                                           Gtk.Orientation.VERTICAL)
        border_box.set_vexpand(False)
        # Label
        select_tool_label = ctop_gtk.c2p_label(massage,"message_label")

        items =  ['Reference-T1', 'Reference-T2', 'Reference-T3', 'Reference-T4']
        self.combo = CustomComboBox(items,self.on_option_selected,"Select Tool","dialog_button")




        self.show_all()
        # Add buttons to the dialog
        yes_button = ctop_gtk.Button_new(label="Yes")

        no_button = ctop_gtk.Button_new(label="No")
        yes_button.connect("clicked", self.on_yes_clicked)
        no_button.connect("clicked", self.on_no_clicked)
        yes_button.get_style_context().add_class(
            "dialog_button")
        no_button.get_style_context().add_class(
            "dialog_button")
        buttons_box = ctop_gtk.c2p_box()
        buttons_box.set_halign(Gtk.Align.END)
        buttons_box.set_valign(Gtk.Align.END)
        buttons_box.pack_start(yes_button, False, False, 10)
        buttons_box.pack_start(no_button, False, False, 10)
        buttons_box.pack_start(self.combo, True, True, 10)
        content_area.add(box_info)
        content_area.add(border_box)
        content_area.pack_start(select_tool_label, False, False, 10)
        content_area.pack_start(buttons_box, True, True, 10)
        self.add(content_area)
        # Show all widgets in the dialog
        self.show_all()

    def on_option_selected(self,widget, selected_item):
        print(f"Selected Item: {selected_item}")
    def on_popup_button_clicked(self, button):

        self.combo_box.popup()

    def draw(self, widget, context):
        # Widget dimensions
        allocation = self.get_allocation()
        width, height = allocation.width, allocation.height

        # Border and corner settings
        border_width = 5
        corner_radius = 20

        background_color = (128/255, 128/255, 128/255, 0.5)  # Light gray with transparency

        # Fill the background with a rounded rectangle
        self.draw_rounded_rectangle(context, border_width, corner_radius,
                                    width, height, background_color, fill=True)

    def draw_rounded_rectangle(self, context, border_width, radius, width,
                               height, color, fill):
        # Set color
        context.set_source_rgba(*color)

        # Adjust for border width
        inset = border_width / 2

        # Draw rounded rectangle
        context.new_path()
        context.arc(radius + inset, radius + inset, radius, math.pi,
                    1.5 * math.pi)  # Top-left corner
        context.arc(width - radius - inset, radius + inset, radius,
                    1.5 * math.pi, 0)  # Top-right corner
        context.arc(width - radius - inset, height - radius - inset, radius, 0,
                    0.5 * math.pi)  # Bottom-right corner
        context.arc(radius + inset, height - radius - inset, radius,
                    0.5 * math.pi, math.pi)  # Bottom-left corner
        context.close_path()

        if fill:
            context.fill()
        else:
            context.set_line_width(border_width)
            context.stroke()

    def get_selected_tool(self):
        # Get the currently selected tool from the combo box
        return self.combo.get_active_text()

    def on_yes_clicked(self, button):
        selected_tool=self.get_selected_tool()
        self.yes_command(selected_tool)
        self.destroy()
    def on_no_clicked(self, button):
        self.destroy()

#test
    # def test_dialog(self,widget):
    #     CameraDialog(self.screen,self.theme_path,self.screen,['T0','T1','T2','T3'],yes_command=self.testt)
    # def testt(self,tool):
    #     print("okkk",tool)