import os
import subprocess
import configparser
from enum import Enum
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk
from library.c2p_logging import LoggerSetup


class ConfigKeys(Enum):
    LANGUAGE = ("main", "language")
    FILAMENT_TOTAL = ("tools", "filament_total")
    FILAMENT_USED = ("tools", "filament_used")
    FILAMENT_COLOR = ("tools", "filament_color")
    FILAMENT_NAME = ("tools", "filament_name")
    NOZZLE_SIZE = ("tools", "nozzle_size")
    TEMP_SENSOR = ("graph Printer", "temperature_sensor")
    NTP = ("main", "ntp")
    TIMEZONE = ("main", "timezone")
    TIMEZONE_INDEX = ("main", "timezone_index")
    STATIC_IP = ("network", "static_ip")
    SERVER_IP = ("network", "server_ip")
    MASK_IP = ("network", "mask_ip")
    BLANK_TIME = ("main", "blank_time")
    DPMS = ("main", "dpms")
    THEME = ("main", "theme")
    WLAN_MANUAL = ("network", "wlan_manual")
    LAN_MANUAL = ("network", "lan_manual")
    WLAN_SWITCH = ("network", "wlan_switch")
    CURRENT_VERSION = ("main", "current_version")
    SERIES = ("main", "series")
class C2PConfig:
    logger_setup = LoggerSetup(interval=1, backup_count=5)
    _files = None
    do_not_edit_line = "#~# --- Do not edit below this line. This section is auto generated --- #~#"
    do_not_edit_prefix = "#~#"
    home_dir = os.path.expanduser('~')
    screen_config_path = os.path.join(home_dir, 'printer_data', 'config',
                                     'C2P_SCREEN.conf')

    # fixed_container = Gtk.Fixed()
    main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                       spacing=0)
    current_active_panel = False
    config_data = {}
    #fixed_container.put(main_box, 50, 50)

    def __init__(self,screen=None):
        self.extruders= [
            "extruder",
            "extruder1",
            "extruder2",
            "extruder3"]
        self.lock_state = True
        self.logger = self.logger_setup.get_logger("LangManager")
        self.config = configparser.ConfigParser()

        self.style = "dark"
        self.theme_path = os.path.join(self.home_dir, 'C2P_SCREEN', 'css', self.style,
                                       'images')
        if screen is not None:

             self.screen = screen

             # GlobalVariables.width = screen.width
             # GlobalVariables.height = screen.height

    def read_c2p_config(self):
        cleaned_config = self.separate_config(self.screen_config_path)
        config_string = '\n'.join(cleaned_config)
        self.config.read_string(config_string)
        try:
            self.config_data = {}
            for section in self.config.sections():
                self.config_data[section] = {}
                for key, value in self.config.items(section):
                    if ";" in value and ":" in value:
                        parsed_values = dict(item.split(":") for item in value.split(";"))
                        self.config_data[section][key] = parsed_values
                    else:
                        self.config_data[section][key] = value


            for section, values in self.config_data.items():
                print(f"[{section}]")
                for key, value in values.items():
                    print(f"{key} = {value}")
                print()

        except (configparser.NoSectionError, configparser.NoOptionError) as e:
            msg = f"Error reading config: {self.screen_config_path}\n{e}"
            self.logger.exception(msg)

    def get_value(self, key: ConfigKeys, sub_key=None,default=None):

        section, option = key.value
        data = self.config_data.get(section, {}).get(option, None)

        if sub_key and isinstance(data, dict):
            value = data.get(sub_key, None)
            if value is None:
                return default
            return value
        if data is None:
            return default
        return data

    def update_sub_value(self, key: ConfigKeys, device, new_value):
        section, option = key.value
        data = self.config_data.get(section, {}).get(option, None)
        if data is None and new_value is not None:
            data={}
            if section == "tools" and device is not None:
                for key in self.extruders:
                    data[key]=str(new_value)

        # # Handle NTP and TIMEZONE special cases
        # if section == "main" and (option == "ntp" or option == "timezone"
        #                           or option == "timezone_index" or option == "blank_time" or option == "dpms" or option == "theme"):
        #     if section not in self.config_data:
        #         self.config_data[section] = {}

        #     self.config_data[section][option] = str(new_value)

        #     # Update the config parser
        #     if section not in self.config.sections():
        #         self.config.add_section(section)

        #     self.config.set(section, option, str(new_value))

        #     # Write to file
        #     with open(self.screen_config_path, "w") as configfile:
        #         self.config.write(configfile)

        #     self.logger.info(f"Updated {section}.{option} -> '{new_value}'")
        #     return
        if section == "network" or section == "main":
            if section not in self.config_data:
                self.config_data[section] = {}

            self.config_data[section][option] = str(new_value)

            # Update the config parser
            if section not in self.config.sections():
                self.config.add_section(section)

            self.config.set(section, option, str(new_value))

            # Write to file
            with open(self.screen_config_path, "w") as configfile:
                self.config.write(configfile)

            self.logger.info(f"Updated {section}.{option} -> '{new_value}'")
            return
        if isinstance(data, dict):
            updated_data = {k: (str(new_value) if k == device else v) for k, v in data.items()}
            self.config_data[section][option] = updated_data
            formatted_value = ";".join(f"{k}:{v}" for k, v in updated_data.items())
            self.config.set(section, option, formatted_value)

            with open(self.screen_config_path, "w") as configfile:
                self.config.write(configfile)

            self.logger.info(f"Updated  -> '{new_value}'")
        else:
            self.logger.exception(f"Key {section}.{option} is not a dictionary or does not exist.")

    def separate_config(self,style_config_path):
        user_def = []
        saved_def = []
        found_saved = False
        with open(style_config_path) as file:
            for line in file:
                line = line.replace('\n', '')
                if line == self.do_not_edit_line:
                    found_saved = True
                    saved_def = []
                    continue
                if found_saved is False:
                    user_def.append(line.replace('\n', ''))
                elif line.startswith(self.do_not_edit_prefix):
                    saved_def.append(line[(len(self.do_not_edit_prefix) + 1):])

        return ["\n".join(user_def), None if saved_def is None else "\n".join(saved_def)]
