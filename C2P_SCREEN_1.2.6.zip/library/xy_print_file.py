#All file add by payam
#4.18.2024
import logging
import shutil
import os
import re

class XYPrint:
    def __init__(self):
        super().__init__()
        home_path = os.path.expanduser("~")
        self.filepath = os.path.join(home_path, "printer_data", "printer_gcode","_XY_Calibrate.gcode")
        self.filepathtemp = os.path.join(home_path, "printer_data", "printer_gcode","_XY_Calibrate_test.gcode")

    def initialvaluse(self):
        tools = self.Get_Tools()
        # path = self.Get_Print_File()
        # self.Replace_Tools("T1","T0")

    def replace_tools(self, filename, old_tools, new_tools, tools_temps, bed_temp,layer_numbers=None,new_filename=None):
        try:
            # Check if file exists
            if not os.path.exists(filename):
                print(f"Error: File '{filename}' not found.")
                return False
            print(filename, old_tools, new_tools, tools_temps, bed_temp)
            input_file = filename
            temp_output_file = self.filepathtemp

            if len(old_tools) != len(new_tools) or len(old_tools) != len(tools_temps):
                raise ValueError("Mismatched input lists for tools and temperatures.")

            tool_mapping = dict(zip(old_tools, new_tools))
            temp_mapping = dict(zip(old_tools, tools_temps))

            gcode_started = False
            layer_count = 0
            tools_same = False
            for old_tool, new_tool in tool_mapping.items():
                if new_tool == old_tool:
                    tools_same = True
            def replace_line(line):
                nonlocal gcode_started, layer_count

                # Ignore lines before the first G-code command
                if not gcode_started:
                    if line.lstrip().startswith(("G", "M",";STARTXYGCODE")):
                        gcode_started = True
                    else:
                        return line
                # Detect ;LAYER_CHANGE and increment layer count
                if layer_numbers:  
                    if ";LAYER_CHANGE" in line:
                        layer_count += 1
                        if layer_count in layer_numbers:
                            layer_numbers.remove(layer_count) 
                            return line + "M400\nPAUSE\n" 

                # Replace tool-specific temperature commands (M104 and M109)
                def temp_replacement(match):
                    cmd, temp_value, tool = match.groups()
                    if tool in tool_mapping:
                        temp = temp_mapping.get(tool, temp_value)
                        # Convert to float first (in case it's a string), then to int to remove the .0
                        temp = int(float(temp))
                        return f"{cmd} S{temp} {tool}"
                    return match.group(0)

                if "M104" in line or "M109" in line:
                    line = re.sub(r'(M10[49]) S(\d+) (T\d+)', temp_replacement, line)


                if "T" in line:
                    if tools_same:
                        for old_tool, new_tool in tool_mapping.items():
                            if old_tool in line:
                                line = re.sub(rf'\b{old_tool}\b', new_tool, line)  # Ensure exact match
                                break
                    else:
                        # Step 1: Replace each tool with a temporary placeholder
                        for old_tool, new_tool in tool_mapping.items():

                            if old_tool in line:
                                line = re.sub(rf'\b{old_tool}\b', f'__TEMP_{old_tool}__', line)
                            elif new_tool in line:
                                line = re.sub(rf'\b{new_tool}\b', f'__TEMP_{new_tool}__', line)
                        # Step 2: Replace placeholders with the new tool values
                        for old_tool, new_tool in tool_mapping.items():
                                line = re.sub(rf'__TEMP_{old_tool}__', new_tool, line)
                                line = re.sub(rf'__TEMP_{new_tool}__', old_tool, line)

                elif "M190" in line or "M140" in line:
                    # Replace bed temperature (M140, M190)
                    line = re.sub(r'(M1[49]0) S\d+', f'\\1 S{int(float(bed_temp))}', line)
                return line

            # Process file efficiently
            with open(input_file, 'r') as fin, open(temp_output_file, 'w') as fout:
                fout.writelines(map(replace_line, fin))

            if new_filename:
                directory = os.path.dirname(input_file)
                input_file = os.path.join(directory, new_filename)
            shutil.move(temp_output_file, input_file)
            return True
        except Exception as e:
            print(f"Error: {e}")
            return False


    
    def Get_Tools(self,filepath):
        try:
            input_file = filepath
            with open(input_file, 'r') as fin:
                for line in fin:
                        if line.strip() == ';STARTXYGCODE':
                            first_line = fin.readline().strip()
                            secound_line = fin.readline().strip()
                            break

            tools = []
            tools.append(re.search(r';(T\d+)\s;',first_line).group(1))
            tools.append(re.search(r';(T\d+)\s;',secound_line).group(1))
            if tools is not None and len(tools) ==2:
                return tools
            else:
                return None
        except Exception as e:
            print(e)
            return False
        
    def Get_Print_File(self):
        return (self.filepath)