import logging
import os
import base64
from gi.repository import GLib
from threading import Thread
from queue import Queue


class PrintFilesUSB:
    def __init__(self):
        #  Main file list and a separate filtered list (initially None)
        self.filelist = {'gcodes': {'directories': [], 'files': []}}
        self.filtered_filelist = None  # Filtered list starts as None
        self.usb_path = "/media/usb"  # "C:/Users/payam/printer_data/gcode"
        self.usb_path_image = "/media/.thumbnails"
        self.queue = Queue()  # Queue for handling updates from the thread

    def create_thumbnails_folder(self, folder_path):
        """Create a '.thumbnails' folder in the specified directory if it does not exist."""
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
        return folder_path

    def read_gcode_files(self, folder_path):
        """Read G-code files from all subdirectories and return their paths with metadata."""
        infoDict = {}
        if not os.path.isdir(folder_path):
            logging.warning(f"Error: '{folder_path}' is not a valid directory.")
            return infoDict

        for root, _, files in os.walk(folder_path):  # Walk through all folders
            for file_name in files:
                if file_name.endswith(".gcode"):
                    file_path = os.path.join(root, file_name)
                    relative_path = os.path.relpath(root, folder_path)  # Get relative folder path
                    full_filename = f"{relative_path}/{file_name}" if relative_path != "." else file_name
                    # Get file size and modification time
                    file_size = os.path.getsize(file_path)
                    file_modified = os.path.getmtime(file_path)
                    infoDict[full_filename] = {
                        'file_path': file_path,
                        'size': file_size,
                        'modified': file_modified
                    }
        return infoDict

    def extract_thumbnails(self, file_path, output_base_dir):
        """Extract and save all thumbnails from a G-code file."""
        try:
            relative_dir = os.path.dirname(os.path.relpath(file_path, self.usb_path))
            output_dir = os.path.join(output_base_dir, relative_dir)  # Unique folder for each file
            os.makedirs(output_dir, exist_ok=True)  # Ensure output directory exists

            thumbnail_paths = ""  # store thumbnail paths
            with open(file_path, 'r') as file:
                thumbnail_data = {}
                current_size = None

                for line in file:
                    if line.startswith("M") or line.startswith("G"):
                        break
                    if line.startswith("; thumbnail begin"):
                        parts = line.split()
                        if len(parts) >= 4:
                            current_size = parts[3]
                            thumbnail_data[current_size] = []
                    elif line.startswith("; thumbnail end"):
                        current_size = None
                    elif current_size:
                        thumbnail_data[current_size].append(line.strip("; ").strip())

                for size, data in thumbnail_data.items():
                    image_data = "".join(data)
                    image_bytes = base64.b64decode(image_data)
                    output_file = os.path.join(output_dir, f"{os.path.basename(file_path)}-{size}.png")
                    with open(output_file, 'wb') as img_file:
                        img_file.write(image_bytes)
                    logging.info(f"Saved thumbnail: {output_file}")
                    thumbnail_paths = output_file  # Save the path to the list

            return thumbnail_paths  # Return the list of thumbnail paths

        except Exception as e:
            logging.exception(f"Error extracting thumbnails from {file_path}: {str(e)}")
            return []  # Return an empty list if an error occurs

    def update_filelist(self):
        """Update the filelist and send results to the main thread via the queue."""
        try:
            if os.path.isdir(self.usb_path):
                thumbnails_path = self.create_thumbnails_folder(self.usb_path_image)
                flist = self.read_gcode_files(self.usb_path)

                updated_files = []
                for file, metadata in flist.items():
                    # Extract thumbnails and collect their paths
                    thumbnail_paths = self.extract_thumbnails(metadata['file_path'], thumbnails_path)

                    # Append file metadata along with thumbnail paths
                    updated_files.append({
                        "filename": file,
                        "path": metadata['file_path'],
                        "size": metadata['size'],
                        "modified": metadata['modified'],
                        "thumbnails": thumbnail_paths  # Add thumbnail paths
                    })

                self.queue.put(updated_files)  # Send updated files to the queue
            else:
                logging.info("USB path does not exist or is not mounted.")
                self.queue.put([])  # Send an empty list to signal no files
        except Exception as e:
            logging.exception("Error updating filelist: %s", str(e))
            self.queue.put([])

        self.queue.put(None)  # Add a sentinel value to indicate end of task

    def start_background_update(self):
        """Start the filelist update in a separate thread and process the results via callback."""

        def background_task():
            self.filelist = {'gcodes': {'directories': [], 'files': []}}
            self.update_filelist()

        def process_queue():
            while not self.queue.empty():
                updated_files = self.queue.get()
                if updated_files is None:  # Sentinel value received
                    logging.info("Processing completed. System is ready.")
                    return False  # Stop idle_add
                if isinstance(updated_files, list):  # Ensure valid data
                    self.filelist['gcodes']['files'] = updated_files
                else:
                    logging.warning("Received invalid data from the queue.")
            return True  # Continue processing queue

        # Start the background thread
        Thread(target=background_task, daemon=True).start()

        # Process the queue in the main thread
        GLib.idle_add(process_queue)

    def sort_file(self, sort_current):
        """
        Sort files based on the given criteria (name or modified date).
        """
        reverse = sort_current[1] != 0
        key_function = lambda x: x["filename"] if sort_current[0] == "name" else x["modified"]

        target_list = self.filtered_filelist if self.filtered_filelist else self.filelist['gcodes']['files']
        if target_list:
            self.filtered_filelist = sorted(target_list, key=key_function, reverse=reverse)

    def search_files(self, search_text):
        """
        Filter files based on the search text.
        """
        if search_text:
            self.filtered_filelist = [
                file for file in self.filelist['gcodes']['files']
                if search_text.lower() in file['filename'].lower()
            ]
        else:
            self.filtered_filelist = None

    def get_filelist(self):
        """
        Return the filtered or original file list.
        """
        return self.filtered_filelist or self.filelist['gcodes']['files']

    def reset_filelist(self):
        """
        Reset the file lists to their initial state.
        """
        self.filelist = {'gcodes': {'directories': [], 'files': []}}
        self.filtered_filelist = None
