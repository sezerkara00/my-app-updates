import os
import subprocess
import configparser
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk

from library.c2p_config import ConfigKeys
from library.c2p_logging import LoggerSetup
from library.c2p_config import ConfigKeys,C2PConfig


class GlobalVariables:
    logger_setup = LoggerSetup(interval=1, backup_count=5)
    _files = None
    do_not_edit_line = "#~# --- Do not edit below this line. This section is auto generated --- #~#"
    do_not_edit_prefix = "#~#"
    home_dir = os.path.expanduser('~')
    screen_config_path = os.path.join(home_dir, 'printer_data', 'config',
                                     'C2P_SCREEN.conf')

    # fixed_container = Gtk.Fixed()
    main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                       spacing=0)
   # main_box.set_size_request(800,880)
    main_box.set_vexpand(False)
    current_active_panel = False
    #fixed_container.put(main_box, 50, 50)

    def __init__(self,screen=None):
        self.lock_state = True
        self.logger = self.logger_setup.get_logger("LangManager")
        self.config = configparser.ConfigParser()
        self.config1=C2PConfig()
        self.config1.read_c2p_config()
        self.style = self.config1.get_value(ConfigKeys.THEME)
        self.theme_path = os.path.join(self.home_dir, 'C2P_SCREEN', 'css', self.style,
                                       'images')
        if screen is not None:
             GlobalVariables._files=screen.files
             self.screen = screen

    def restart_service(self,service_name):
        try:
            # Restart the service using systemctl
            subprocess.run(['service',  service_name, 'restart'],
                           check=True)
            print(f"Service {service_name} restarted successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Failed to restart service {service_name}: {e}")

    def lock_screen(self, widget,buttons):
        if self.lock_state:
            for button in buttons:
                button.set_sensitive(False)
            self.lock_state = False
        elif not self.lock_state:
            for button in buttons:
                button.set_sensitive(True)
            self.lock_state = True

    def refresh_content(self,obj,back=False,printing_panel=False):
        # Destroy previous panel
        if hasattr(self, 'active_panel') and self.active_panel:
            try:
                if hasattr(self.active_panel, 'active_panel') and self.active_panel.active_panel:
                    print("Nested active panel found, closing it...")
                    self.active_panel.active_panel.on_close()
                    # self.active_panel.active_panel = None
                self.active_panel.on_close()
            except Exception as e:
                print(f"Error closing panel: {e}")
        if printing_panel:
            for p in  self.screen.panels_back:
                self.screen.panels_back.remove(p)
        for child in self.main_box.get_children():
            self.main_box.remove(child)
        content,title = obj.get_content()
        print(f"Content returned: {content}")
        self.screen.base_panel.update_title(title)
        self.main_box.add(content)
        self.main_box.show_all()
        # Store the active panel
        self.active_panel = obj  # Save reference to the panel object
        GlobalVariables.current_active_panel = obj
        if not back:
            if obj not in self.screen.panels_back:
                print(":",obj)
                self.screen.panels_back.append(obj)
        else:
            long = len(self.screen.panels_back)
            if long > 1:
                 self.screen.panels_back.remove(self.screen.panels_back[long-1])

    def set_screen_blanking(self, time):
        if time == "None":
            # Screen blanking off and dpms off
            subprocess.run(["xset", "s", "off"])
            subprocess.run(["xset", "-dpms"])
            self.config.update_sub_value(ConfigKeys.BLANK_TIME, None, "None")
        elif time == "not_changed":
            blanking_mode = self.config.get_value(ConfigKeys.BLANK_TIME)
            blanking_mode = blanking_mode.split(" ")[0]
            blanking_mode = int(blanking_mode) * 60
            blanking_mode = str(blanking_mode)
            is_dpms = self.config.get_value(ConfigKeys.DPMS)
            # DPMS is active and set time
            subprocess.run(["xset", "s", is_dpms])  # screen blanking off
            subprocess.run(["xset", "+dpms"])
            subprocess.run(["xset", "dpms", blanking_mode, blanking_mode, blanking_mode])
        else:
            self.config.update_sub_value(ConfigKeys.BLANK_TIME, None, f"{time}")
            time = str(int(time.split()[0]) * 60)
            is_dpms = self.config.get_value(ConfigKeys.DPMS)
            # DPMS is active and set time
            subprocess.run(["xset", "s", is_dpms])  # screen blanking off
            subprocess.run(["xset", "+dpms"])
            subprocess.run(["xset", "dpms", time, time, time])

    def get_current_page(self):
        # if hasattr(self, 'active_panel') and self.active_panel:
        return  GlobalVariables.current_active_panel
        # return None
    @classmethod
    def get_style(cls):
        config = C2PConfig()
        config.read_c2p_config()
        return config.get_value(ConfigKeys.THEME)

    @staticmethod
    def format_time(seconds):
        seconds = int(seconds)
        if seconds is None or seconds <= 0:
            return "-"
        days = seconds // 86400
        seconds %= 86400
        hours = seconds // 3600
        seconds %= 3600
        minutes = seconds // 60
        seconds %= 60
        if days > 0:
            return f'{days:2.0f}d {hours:2.0f}h {minutes:2.0f}m {seconds:2.0f}s'
        elif hours > 0:
            return f'{hours:2.0f}h {minutes:2.0f}m {seconds:2.0f}s'
        elif minutes > 0:
            return f'{minutes:2.0f}m {seconds:2.0f}s'
        elif  days == 0 and hours == 0 and minutes == 0:
            return f'{seconds:2.0f}'
        else:
            return ''