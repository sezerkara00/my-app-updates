from venv import logger

import gi

from panels.settings_panel import SettingsMenu

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, GdkPixbuf, Gdk
from jinja2 import Environment
from panels.base_panel import Base_panel
from library.global_manager import GlobalVariables
from library.printer import Printer
from library.c2p_websocket import CtoPWebsocket
from library.c2p_Rest import CtoPRest
from library.print_files import PrintFiles
from library.lang_manager import LangManager
from library.c2p_config import C2PConfig
from library.c2p_usbmount import USBMonitorThread
from library.print_files_usb import PrintFilesUSB
from panels.controlling_panel import ControllingPanel
from elements.popup import PopupNotification
from library.notification_logger import NotificationLogger
from library.c2p_files_manager import c2p_config
from panels.emergency_panel import EmergencyPanel
import pathlib
import os
import subprocess
import configparser
import gettext


from elements.c2p_gtk import CtoPGtk
from panels.base_panel import Base_panel
from gi.repository import Gtk, GLib, GdkPixbuf, Gdk
import gi
import time
import configparser



PRINTER_BASE_STATUS_OBJECTS = [
    'bed_mesh',
    'configfile',
    'display_status',
    'extruder',
    'fan',
    'gcode_move',
    'heater_bed',
    'idle_timeout',
    'pause_resume',
    'print_stats',
    'toolhead',
    'virtual_sdcard',
    'webhooks',
    'motion_report',
    'firmware_retraction',
    'exclude_object',
    'manual_probe',
     'c2p_save_variables'
]


def state_execute(callback):
    callback()
    return False

home_dir = os.path.expanduser('~')


class MainWindow(Gtk.Window,GlobalVariables):
    printer = None
    files = None
    config_file = None
    def __init__(self):

        self.current_popup=None
        Gtk.Window.__init__(self, title="Main Window")
        GlobalVariables.__init__(self, self)
        self.set_decorated(False)
        # self.connect("realize", self.on_window_realized)
        self.logger = self.logger_setup.get_logger("MainWindow")
        super().__init__(title="Progress Circle Example") #*==> title string you can't use allways defined in static value (maybe change with language)
        display = Gdk.Display.get_default()
        self.config_file = C2PConfig()
        self.print_state = ""
        self.lang_manager = LangManager()
        self.env = Environment(extensions=["jinja2.ext.i18n"], autoescape=True)
        self.env.install_gettext_translations(self.lang_manager.get_lang())
        template = self.env.from_string("{{ _('Main Panel') }}")
        print(template.render())
        # Get the primary monitor (or any monitor)
        monitor = Gdk.Display.get_default().get_primary_monitor()
        if monitor is None:
            monitor = Gdk.Display.get_default().get_monitor(0)
        if monitor is None:
            self.logger.info("Couldn't get default monitor")
            raise RuntimeError("Couldn't get default monitor")

        # Get the screen dimensions
        geometry = monitor.get_geometry()
        # self.height = geometry.height
        # self.width = geometry.width
        monitor_width = geometry.width
        monitor_height = geometry.height
        desired_width = 800
        desired_height = 1000
        scale_width = monitor_width / desired_width
        scale_height = monitor_height / desired_height
        scale_factor = min(scale_width, scale_height)
        self.width = 800#int(desired_width * scale_factor)
        self.height = 1000#int(desired_height * scale_factor)
        self.set_default_size(self.width, self.height)
        self.set_resizable(False)
        self.connect("destroy", Gtk.main_quit)


        self.apiclient = None
        self.dialog_connection = None
        self.re_klipper_count = 0
        self.re_count = 0
        self.is_running = False
        self.started_init = False
        self.panels_back = []


        self.base_panel = Base_panel(self)
        # add content from base panel to main window
        self.add(self.base_panel.base_box)
        # Show all widgets
        self.init_css()
        self.show_all()
        self.logger.info("Screen Run")
        # add by payam
        mount_point = '/media/usb/'
        sudo_password = 'sezer1234'
        self.usb_monitor = USBMonitorThread(self, mount_point, sudo_password)
        self.usb_monitor.start()
        self.usb_PrintFile = PrintFilesUSB()
        self.initial_connection()


    def initial_connection(self):
        state_callbacks = {
            "disconnected": self.state_disconnected,
            "error": self.state_error,
            "paused": self.state_printing,
            "printing": self.state_printing,
            "ready": self.state_ready,
            "startup": self.state_startup,
            "shutdown": self.state_shutdown,
            # "waitcompleted": self.wait_completed #added by ahmed
        }
        self.printer = Printer(state_execute, state_callbacks,
                               self.process_busy_state)
        self.connect_printer()


        #*==>  update clock why here  !!!
    
    def update_clock(self):
        # Get the current time and format it
        current_time = time.strftime("%H:%M:%S")
        self.clock_label.set_text(current_time)
        return True

    def connect_printer(self, msg="Connecting to printer, please wait"): #*==> msg string you can't use allways defined in static value (maybe change with language) 
        self.config = configparser.ConfigParser()
        #*==>  you can't use static address like /home/ddt-arge  !!!
        self.config.read(
            "/home/biqu/KlipperScreen/ks_includes/defaults.conf")

        printers = ["Printer Printer"]
        self.printers = [
            {printer[8:]: {
                "moonraker_host": self.config.get(printer, "moonraker_host",
                                                  fallback="192.168.1.37"),
                "moonraker_port": self.config.get(printer, "moonraker_port",
                                                  fallback="7125"),
                "moonraker_api_key": self.config.get(printer,
                                                     "moonraker_api_key",
                                                     fallback="").replace('"',
                                                                          '')
            }} for printer in printers
        ]
        self.apiclient = CtoPRest(
            self.printers[0]["Printer"]["moonraker_host"],
            self.printers[0]["Printer"]["moonraker_port"],
            self.printers[0]["Printer"]["moonraker_api_key"],
        )
        self._ws = CtoPWebsocket(self,
                                 {
                                     "on_connect": self.init_printer,
                                     "on_message": self._websocket_callback,
                                     "on_close": self.websocket_disconnected
                                 },
                                 self.printers[0]["Printer"]["moonraker_host"],
                                 self.printers[0]["Printer"]["moonraker_port"],
                                 )

        self.files = PrintFiles(self)

        self._ws.initial_connect()

        self.control_dialog = self.base_panel.error_dialog( self, self,
                                                           ["Mr connected ", "Connecting to Klipper"
                                                            ,"Reading temperatures"], None,
                                                           False, True, tipe="control",
                                                           title="Printer Init",
                                                           theme_path=self.theme_path)
        self.control_dialog.show()
        
        self.control_dialog.update_control_message(1)
        if not self.is_running:
            self.dialog_connection = self.base_panel.error_dialog(self, self, msg,theme_path=self.theme_path)
            self.dialog_connection.show()
            self.is_running = True



        not_connected = self.check_moonraker_connection()
        if not_connected:
            GLib.timeout_add_seconds(3, self.check_moonraker_connection)


    #*==> I think this way is beter for connetction // i think beter evry check one way
    # define StateConnect = 0
    #  One function like Check_Connection()
    # {
    #     if StateConnect == 0 
    #         self.check_moonraker_connection()
    #     elif StateConnect == 1 
    #         self.check_klipper_connection
    #     elif StateConnect == 2
    #         self.init_printer()

    #     GLib.timeout_add_seconds(1, self.Check_Connection)
    # }
     ########/#
    def check_moonraker_connection(self):
        #*==>  why you have too much enter (space) between lines !!!
        #*==> this value where is check (self.re_count)? 


        self.server_info = self.apiclient.get_server_info()

        if self.server_info:
            self.logger.info("Moonraker connected!")

            self.close_dialog()
            not_connected = self.check_klipper_connection()
            if not_connected:
                self.close_dialog()
                GLib.timeout_add_seconds(1, self.check_klipper_connection)

            return False

        else:
            self.logger.info("Still waiting for Moonraker to connect...")
        if self.re_count > 10:
            self.close_dialog()
            if not self.is_running:
                self.is_running = True
                self.dialog_connection = self.base_panel.error_dialog(
                    self, self, "Lost Connection to Moonraker", theme_path=self.theme_path,button_names=['Moonraker Restart'],sp_commands=[self.restart_moonraker_service])
                self.dialog_connection.show()
            return False
            #return True
        else:
            self.re_count += 1
            if not self.is_running:
                self.is_running = True
                self.dialog_connection = self.base_panel.error_dialog(
                    self,self, "Connecting to Moonraker",theme_path=self.theme_path)
                self.dialog_connection.show()
            elif self.is_running:

                self.dialog_connection.update_error_message(
                    f"Connecting to Moonraker          {self.re_count}")
            return True

    def check_klipper_connection(self):
        self.server_info = self.apiclient.get_server_info()
        if isinstance(self.server_info, dict) and 'result' in self.server_info and 'klippy_connected' in self.server_info['result']:
            if self.server_info['result']['klippy_connected']:
                self.logger.info("Klipper connected")
                self.close_dialog()
                if self.re_klipper_count > 1:
                    self.printer.change_state(state="startup")
                    print("klipper Startup")
                if self.started_init:
                    self.started_init = False
                    self.init_printer()

                return False
            else:
                self.logger.info("Klipper not connected!")
                if self.re_klipper_count > 10:
                    self.close_dialog()
                    if not self.is_running:
                        self.is_running = True
                        self.dialog_connection = self.base_panel.error_dialog(self,self,
                                                            "Klipper Lost connection",theme_path=self.theme_path,button_names=['Klipper Restart'],sp_commands=[self.restart_klipper_service])
                        return False
                else:
                    self.re_klipper_count += 1
                    if not self.is_running:
                        self.is_running = True
                        self.dialog_connection = self.base_panel.error_dialog(self,self,
                                                            f"Connecting to Klipper",theme_path=self.theme_path)
                        self.dialog_connection.show()
                    elif self.is_running:
                        self.dialog_connection.update_error_message(
                            f"Connecting to Klipper          {self.re_klipper_count}")

                    return True
            return True
            # self.dialog_connection.set_modal(True)

    def _init_printer(self, msg, go_to_splash=False):
        if self._ws.connected and not self._ws.closing:
            GLib.timeout_add_seconds(3, self.init_printer)
        else:
            self.dialog_connection = self.base_panel.error_dialog(self,self, msg,theme_path=self.theme_path)

            # Start checking for Moonraker connection every 1 second
            GLib.timeout_add_seconds(3, self.check_moonraker_connection)

            # Run the dialog, which will block until the response is received
            self.dialog_connection.show()

    def init_printer(self):
        printer_info = self.apiclient.get_printer_info()
        if printer_info is False and not isinstance(printer_info, dict) or 'result' not in printer_info and self.re_count > 5:
            self.logger.info("Unable to get printer info from moonraker")
            return self._init_printer(
                "Unable to get printer info from moonraker")
        config = self.apiclient.send_request(
            "printer/objects/query?configfile")

        if config is False:
            return self._init_printer("Error getting printer configuration")
        variables_stb = self.apiclient.send_request(
        "printer/objects/query?c2p_save_variables")
        self.printer.reinit(printer_info['result'], config['result']['status'],
                            variables_stb['result']['status'])
        #    variables_stb['result']['status'])
        self.ws_subscribe()
        extra_items = (self.printer.get_tools()+self.printer.get_switches()
                       + self.printer.get_heaters()+self.printer.get_fans()+self.printer.get_filament_sensors()+self.printer.get_output_pins()
                       )
        data = self.apiclient.send_request(
            "printer/objects/query?" + "&".join(PRINTER_BASE_STATUS_OBJECTS +
                                                extra_items))
        if data is False:
            return self._init_printer(
                "Error getting printer object data with extra items")
        self.printer.process_update(data['result']['status'])
        self.logger.info("Printer connected")
        self.logger.info(f"Printer Info is--->{printer_info}")

        self.init_tempstore()
        # If devices changed it takes a while to register
        GLib.timeout_add_seconds(2, self.init_tempstore)
        
        self.files.initialize()
        self.files.refresh_files()
        self.base_panel.main_panel.reload_values(self)

    def init_tempstore(self):
        self.printer.init_temp_store(
            self.apiclient.send_request("server/temperature_store"))
        server_config = self.apiclient.send_request("server/config")
        if server_config:
            try:
                self.printer.tempstore_size = \
                    server_config["result"]["config"]["data_store"][
                        "temperature_store_size"]
                self.logger.info(
                    f"Temperature store size: {self.printer.tempstore_size}")
            except KeyError:
                self.logger.error("Couldn't get the temperature store size")
        return False

    def ws_subscribe(self):
        requested_updates = {
            "objects": {
                "bed_mesh": ["profile_name", "mesh_max", "mesh_min",
                             "probed_matrix", "profiles"],
                "configfile": ["config"],
                "display_status": ["progress", "message"],
                "fan": ["speed"],
                "gcode_move": ["extrude_factor", "gcode_position",
                               "homing_origin", "speed_factor", "speed"],
                "idle_timeout": ["state"],
                "pause_resume": ["is_paused"],
                "print_stats": ["print_duration", "total_duration",
                                "filament_used", "filename", "state",
                                "message",
                                "info"],
                "toolhead": ["homed_axes", "estimated_print_time",
                             "print_time", "position", "extruder",
                             "max_accel", "max_accel_to_decel", "max_velocity",
                             "square_corner_velocity"],
                "virtual_sdcard": ["file_position", "is_active", "progress", "current_tool", "current_z" ,"filaments_used"],
                "webhooks": ["state", "state_message","Emergency"],

                "firmware_retraction": ["retract_length", "retract_speed",
                                        "unretract_extra_length",
                                        "unretract_speed"],
                "motion_report": ["live_position", "live_velocity",
                                  "live_extruder_velocity"],
                "exclude_object": ["current_object", "objects",
                                   "excluded_objects"],
                "manual_probe": ['is_active'],
                "c2p_save_variables": ['tools_print']
            }
        }
        for extruder in self.printer.get_tools():
            requested_updates['objects'][extruder] = [
                "target", "temperature", "pressure_advance", "smooth_time",
                "power", "min_extrude_temp", "max_temp",
                "state_tool"]  # Added by Payam
        for h in self.printer.get_heaters():
            requested_updates['objects'][h] = ["target", "temperature",
                                               "power"]
        for f in self.printer.get_fans():
            requested_updates['objects'][f] = ["speed"]
        for f in self.printer.get_filament_sensors():
            requested_updates['objects'][f] = ["enabled", "filament_detected"]
        for p in self.printer.get_output_pins():
            requested_updates['objects'][p] = ["value"]
        for switch in self.printer.get_switches():
            requested_updates['objects'][switch] = ["state"]
        self._ws.klippy.object_subscription(requested_updates)

    def _websocket_callback(self, action, data):
        if action == "notify_status_update" and self.printer.state != "shutdown":
            self.printer.process_update(data)
            if self.control_dialog:
                self.control_dialog.destroy()
                self.control_dialog = None
            
        elif action == "notify_klippy_disconnected":
            self.started_init = True
            not_connected = self.check_klipper_connection()
            if not_connected:
                self.close_dialog()
                GLib.timeout_add_seconds(1, self.check_klipper_connection)
        elif action == "notify_metadata_update":
            self.files.request_metadata(data['filename'])
        elif action == "notify_filelist_changed":
            if self.files is not None:
                self.files.process_update(data)
        elif action == "notify_gcode_response":
            if data.startswith("TRG:"):
                if not hasattr(self, 'ControllingPanel') or self.ControllingPanel is None:
                    self.ControllingPanel =  ControllingPanel(self.screen,self.theme_path)
                self.ControllingPanel.check_ControlBox(data)
            elif data.startswith("MSG:") or data.startswith("!! "):
                self.show_Msg_From_Printer(data)
                self.process_update("notify_error", data)

        if self.printer.state != "ready" and self.printer.state != "printing" and self.printer.state != "paused":
            self.base_panel.main_panel.de_active_temp()
            return
        # GLib.timeout_add_seconds(1, self.check_emergency_state)
        
        # Add emergency panel handling
        # if not hasattr(self, 'emergency_panel'):
        #     self.emergency_panel = None
        

        # def check_emergency_state():
        #     if self.printer.get_emergency() == False:
        #         return False 
        #     else:
        #         print("emergency state is not printing")
        #         return True
            
        # if self.printer.get_emergency() == False:
        #     if self.dialog_connection is not None:
        #         # Update the check_disable_button property instead of calling the function directly
        #         self.dialog_connection.check_disable_button = check_emergency_state()
        #     if self.emergency_panel is None:
        #         message = "denme"
        #         if self.dialog_connection is None:
        #             self.dialog_connection = self.base_panel.error_dialog(self, self, message, theme_path=self.theme_path, button_names=["Settings","Firmware Restart"], sp_commands=[self.open_settings,self.firmware_restart], title="Error", check_disable_button=check_emergency_state())
        #     else:
        #         message = "denme"
                           
        # else:
        #     if self.dialog_connection is not None:
        #             # Update the check_disable_button property instead of calling the function directly
        #         self.dialog_connection.check_disable_button = check_emergency_state()
        #     if self.emergency_panel is not None:
        #         self.emergency_panel = None
        #     self.dialog_connection = None

        self.process_update(action, data)
      
    def process_update(self, *args):
        GLib.idle_add(self.base_panel.main_panel.process_update, *args)
        active_panel = self.get_current_page()
        if hasattr(active_panel, 'process_update'):
            try:
                    # print(f"Calling process_update on active panel: {active_panel}")
                GLib.idle_add(active_panel.process_update, *args)
            except Exception as e:
                print(f"Error calling process_update: {e}")

    def websocket_disconnected(self, msg):
        self.close_dialog()
        self.connect_printer(msg)
        print(msg)

    def process_busy_state(self, busy):
        self.process_update("notify_busy", busy)
        if busy:
            return False
        else:
            if hasattr(self, 'ControllingPanel') and self.ControllingPanel is not None:
                if self.ControllingPanel.check_ControlBox_finish():
                    self.ControllingPanel = None
        return False


    def state_error(self):
        self.re_klipper_count = 0
        if hasattr(self, 'ControllingPanel') and self.ControllingPanel is not None:
                    self.ControllingPanel._handle_close()
                    self.ControllingPanel = None
        self.close_dialog()
        msg = ("Printer has encountered an error.") + "\n"
        state = self.printer.get_stat("webhooks", "state_message")
        if "FIRMWARE_RESTART" in state:
            msg += ("A FIRMWARE_RESTART may fix the issue.") + "\n"


        elif "micro-controller" in state:
            msg += ("Please recompile and flash the micro-controller.") + "\n"
        if not self.is_running:
            self.is_running = True
            self.dialog_connection = self.base_panel.error_dialog(self,self, state, theme_path=self.theme_path, button_names=["Settings","Firmware Restart"],sp_commands=[self.open_settings,self.firmware_restart],title="Error")
          #  self.dialog_connection.show()

        # response = self.dialog_connection.run()
        # if response == Gtk.ResponseType.APPLY:

            print("firmware restart button clicked")
    def open_settings(self):
        self.refresh_content(SettingsMenu(self))
        self.panels_back = []
        for b in self.base_panel.menu_buttons:
            if b != "settings":
                self.base_panel.menu_buttons[b].set_sensitive(False)
            else:
                self.base_panel.settings_pressed(self.base_panel.menu_buttons[b], self.base_panel.menu_buttons[b])
        self.dialog_connection.destroy()
    def firmware_restart(self):
        self._ws.klippy.restart_firmware()
    
    def state_disconnected(self):
        if hasattr(self, 'ControllingPanel') and self.ControllingPanel is not None:
                    self.ControllingPanel._handle_close()
                    self.ControllingPanel = None
        print("disconnected")

    def state_printing(self):
        GLib.timeout_add_seconds(1, self.base_panel.show_panel)
        # GLib.idle_add(self.base_panel.show_panel())
        print("printing")

    def state_ready(self, wait=True):
        if self.control_dialog is not None:
            self.control_dialog.update_control_message(2)
        if self.is_running :
            self.re_count = 0
            self.re_klipper_count = 0
            self.close_dialog()
        # self.close_dialog()
        print("ready")

    def state_startup(self):
        print("startup")
        state = "Printer is not ready. Please retry in a few moments."
        if not self.is_running:
            self.is_running = True
            self.dialog_connection = self.base_panel.error_dialog(self,self, state, theme_path=self.theme_path)

        elif self.is_running:
            self.dialog_connection.update_error_message(state, True)

    # def check_emergency_state(self):
    #     try:
    #         if self.printer.get_emergency() == False:
    #             print("emergency is not active")
    #             self.dialog_connection.check_disable_button = False
    #             return False 
    #         else:
    #                 print("emergency is active")

    #                 return True
    #     except Exception as e:
    #         print(f"Error checking emergency state: {e}")
    #         return False

    def state_shutdown(self):
        def check_emergency_shutdown_state():
                try:
                    response = self.apiclient.send_request(
                        "printer/objects/query?webhooks"
                    )
                    emergency_state = response.get('result', {}).get('status', {}).get('webhooks', {}).get('Emergency', {})
                    if emergency_state == False:
                        self.dialog_connection.check_disable_button = False
                        return False 
                    else:
                        return True
                except Exception as e:
                    print(f"Error checking emergency state: {e}")
                    return False
        print("sutdown")
        if hasattr(self, 'ControllingPanel') and self.ControllingPanel is not None:
                    self.ControllingPanel._handle_close()
                    self.ControllingPanel = None
        state = self.printer.get_stat("webhooks", "state_message")
        if not self.is_running:
            self.is_running = True

            if self.dialog_connection is not None:
                # Update the check_disable_button property instead of calling the function directly
                self.dialog_connection.check_disable_button = check_emergency_shutdown_state()
                GLib.timeout_add_seconds(3, check_emergency_shutdown_state)
            if check_emergency_shutdown_state() == True:

                    state += "Emergency is active"
            self.dialog_connection = self.base_panel.error_dialog(self,self, state, theme_path=self.theme_path,button_names=["Settings","Firmware Restart"],sp_commands=[self.open_settings,self.firmware_restart],check_disable_button=check_emergency_shutdown_state())

        elif self.is_running:
            self.dialog_connection.update_error_message(state, True)
        if self.dialog_connection is not None:
                        # Update the check_disable_button property instead of calling the function directly
            self.dialog_connection.check_disable_button = check_emergency_shutdown_state()
            GLib.timeout_add_seconds(1, check_emergency_shutdown_state)

    def close_dialog(self):
        if self.dialog_connection:
            self.is_running = False
            self.dialog_connection.destroy()
            self.dialog_connection = None

    def init_css(self):
        css_data = pathlib.Path(
            os.path.join(home_dir, "C2P_SCREEN", "css","dark",
                         "style.css")).read_text()
        if self.style == "light":
            css_data = pathlib.Path(
                os.path.join(home_dir, "C2P_SCREEN", "css","light",
                             "style.css")).read_text()


        style_provider = Gtk.CssProvider()
        style_provider.load_from_data(css_data.encode())
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            style_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

    def restart_moonraker_service(self):
        try:
            # Run the systemctl restart command
            self.close_dialog()
            self.re_count = 0
            self.re_klipper_count = 0
            self.initial_connection()
            subprocess.run([ "systemctl", "restart", "moonraker"], check=True)
            #self.connect_printer()
            print("Moonraker service restarted successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Failed to restart Moonraker service: {e}")
        except Exception as e:
            print(f"An error occurred: {e}")

    def restart_klipper_service(self):
        try:
            # Run the systemctl restart command
            self.re_klipper_count = 0
            self.close_dialog()
            self.initial_connection()
            subprocess.run([ "systemctl", "restart", "klipper"], check=True)
            #self.connect_printer()
            print("Klipper service restarted successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Failed to restart Klipper service: {e}")
        except Exception as e:
            print(f"An error occurred: {e}")

    def show_Msg_From_Printer(self, data):
        """
        Processes the message received from the printer.
        Ensures the message contains mandatory keys: TYPE, TIME, and TEXT.
        Args:
            data (str): The raw message string from the printer.
        Returns:
            None
        """
        # Check if the data starts with the prefix 'MSG:'
        if data.startswith("MSG:"):
            # Remove the 'MSG: ' prefix from the message
            raw_data = data[5:]
            # Initialize a dictionary for parsed data
            parsed_data = {}
            # Use a more robust parsing approach
            parts = raw_data.split(" ")
            current_key = None
            for part in parts:
                if "=" in part:
                    key, value = part.split("=", 1)
                    parsed_data[key] = value
                    current_key = key  # Update the current key
                elif current_key:  # Append to the last key if no '=' is present
                    parsed_data[current_key] += f" {part}"

            # Define the required keys that must be present in the message
            required_keys = {"TYPE", "TIME", "TEXT"}
            # Check for any missing keys
            missing_keys = required_keys - parsed_data.keys()
            if missing_keys:
                print(f"Invalid data format: Missing keys: {', '.join(missing_keys)}")
                return
            
        elif data.startswith("!! "):
            parsed_data = {}
            parsed_data["TEXT"] = data[3:]
            parsed_data["TYPE"] = 'E'
            parsed_data["TIME"] = '0'
        
        if not parsed_data["TEXT"].strip():
            print("Invalid data format: TEXT is empty or contains only spaces.")
            return
        if parsed_data["TIME"] == '0':
                if hasattr(self, 'ControllingPanel') and self.ControllingPanel is not None:
                    self.ControllingPanel._handle_close()
                    self.ControllingPanel = None
        if self.current_popup:
            self.current_popup.dismiss()
            self.current_popup = None
        # Create a popup notification with the parsed data
        logger = NotificationLogger()
        logger.add_log(parsed_data["TEXT"],parsed_data["TYPE"])
        self.current_popup = PopupNotification(
            message=parsed_data["TEXT"],
            screen=self.screen,
            them_path=self.theme_path,
            show_button=True if parsed_data["TIME"] == '0' else False,
            timeout=int(parsed_data["TIME"]),
            tipe=parsed_data["TYPE"]
        )

    def set_cursor_to_blank(self):
        # Hide the pointer globally by setting it to blank
        window = self.get_window()
        if window:
            window.set_cursor(Gdk.Cursor.new_for_display(Gdk.Display.get_default(), Gdk.CursorType.BLANK_CURSOR))
            os.system("xsetroot  -cursor library/emptyCursor.xbm library/emptyCursor.xbm")

    def on_window_realized(self, widget):
        # This method is called when the window is fully realized (ready for drawing)
        self.set_cursor_to_blank()

    def show_Msg_Popup(self, msg,type='E',time=5):
        self.current_popup = PopupNotification(
            message=msg,
            screen=self.screen,
            them_path=self.theme_path,
            show_button=True if time == '0' else False,
            timeout=int(time),
            tipe=type
        )

if __name__ == "__main__":
    win = MainWindow()
    win.connect("destroy", Gtk.main_quit)
    Gtk.main()
